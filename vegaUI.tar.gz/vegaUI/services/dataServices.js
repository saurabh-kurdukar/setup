var app = angular.module('experienceApp.appDataFactory', []);
app.factory('dataFactory', ['$http', '$interval', '$state', '$q',function($http ,$interval ,$state, $q) {    
    var dataFactory = {};
    var domainsApiUrl = baseApiUrl + "/domains";
    var salesOwnersApiUrl = baseApiUrl + "/salesOwners";
	var experiencesApiUrl = baseApiUrl + "/experiences";
    var sandboxesApiUrl = baseApiUrl + "/sandboxes";
	var componentApiUrl = baseApiUrl + "/component";
	var servicesBaseUrl = baseApiUrl + "/services";
	var companiesBaseUrl = baseApiUrl + "/companies";
    var appsBaseUrl = baseApiUrl + "/apps";
    var docsApiUrl = baseApiUrl + "/documents";
    var provisionedBaseUrl = baseApiUrl+"/provision";
	var setRatingUrl = baseApiUrl + "/surveyresponses";
	var getRatingUrl = baseApiUrl + "/surveyassociations ";
    var ratingsMap = localStorage.getItem( "ratingsMap" );
	var platformUsersBaseUrl = baseApiUrl+"/platformusers";
    var topExpBaseUrl = baseApiUrl+"/experiences";
    var traceApiUrl = baseApiUrl+"/trace";
    var servicesEnd="services";	

	
    var lastSandboxSelection = {type : "", company : {}};
    
	var selectedDomain = "" ;	
	var selectedDomainIndex = 0 ;	
    
    var cartExperiences = "";
    
    var loginApiUrl = baseApiUrl + "/auth/login";
	var forgetPasswordUrl = baseApiUrl + "/forgotPassword";
    //var loginApiUrl = "http://10.44.16.177:8080/v1.0/auth/login";
	var userApiUrl = baseApiUrl + "/platformusers";
	//var userApiUrl = "http://10.44.16.177:8080/v1.0" + "/platformusers";
	var captchaUrl = baseApiUrl+"/captcha";
	//var cartApiUrl = "http://localhost:1377/v1.0/cart";
	var cartApiUrl = baseApiUrl+"/cart";
	var usersUrl = baseApiUrl+"/users";
	var provisionApiUrl=baseApiUrl+"/provision";
    var resendActEmailApiUrl = baseApiUrl+"/activation";
    var QRcodeApiUrl = baseApiUrl+"/userAttributes";
    var QRcodeBaselocation=basePath+"/";
	//var experienceEnrolledApiUrl=baseApiUrl+"/experiencesenrolled";
    var isSandboxRequested = false;
    var selectedExperience = "";
    var selectedExperiences = angular.fromJson(localStorage.getItem('selectedExperiences'));
    //var experiences = angular.fromJson(localStorage.getItem('experiences'));
    var experiences = "";
 //   var domains = angular.fromJson(localStorage.getItem('domains'));;
    var domains = "" ;
    var currentState = "home";
    var loggedInUser = angular.fromJson(localStorage.getItem('loggedInUser'));
    var loginStatus = localStorage.getItem('loggedInStatus');
    var provisionedExperineces = [];
    var isLoading = true;
    var loadingText = "Loading...";
	var selectedExpDetail=""; 
    var idlePromise;
	var secondsIdle;
	var accesstoken= localStorage.getItem('accesstoken');	
    var hiddenNavbarFooter = false;
    var tracePopupData = {};
    var popupData = {};
    
    var showLoading = false;
    
    var experiencesMap =  angular.fromJson(localStorage.getItem('experiencesMap'));
    var domainsMap = angular.fromJson(localStorage.getItem('domainsMap'));
    var appMap = angular.fromJson(localStorage.getItem("appMap"));
    var docMap = angular.fromJson( localStorage.getItem( "docMap" ) );
    
    if( !docMap )
        docMap = {};

    
	var orgId;		
    if (!loginStatus)
        loginStatus = false;
    if (!loggedInUser)
        loggedInUser = {
            username: "",
            password: ""
        };
	
	
    var callApi = function(URL, METHOD, HEADERS, DATA, ShowLoader) {	
        
        console.log("url", URL, "data", DATA);
        var req = {
            method: METHOD,
            url: URL
        }
        if (DATA && (Object.keys(DATA).length != 0)) {
            req.data = DATA;
        }
        if (HEADERS && (Object.keys(HEADERS).length != 0)) {
            HEADERS.username = loggedInUser.username;
            req.headers = HEADERS;
        }

        
        if( ShowLoader && (ShowLoader == true) )
            req.showLoader = true;
        return $http(req);
    };		
		
      dataFactory.idleLogoutUser = function(){
				//idlePromise=0;
				secondsIdle=0;
          if(idlePromise)
				$interval.cancel(idlePromise);
				$(document).mousemove(function (e) {
						secondsIdle = 0;
						//console.log("enter session logout mousemove",secondsIdle);
				});
				$(document).keypress(function (e) {
					secondsIdle = 0;
						//console.log("enter session logout keypress",secondsIdle);
				});
				idlePromise = $interval(function(){
				
					secondsIdle += 1;	
                   // console.log("secondsIdle",secondsIdle);
					//console.log("enter session logout update",secondsIdle);					
					if(secondsIdle > 600 ){
							console.log("enter session logout",secondsIdle);
                        dataFactory.logout();
						//	dataFactory.setLogout();					
						//	dataFactory.setCurrentIndex(0);							
		 				//	angular.element("#password").val("");
						//	angular.element("#username").val("");
                        alert('session timeout');
							$interval.cancel(idlePromise);
						//	$location.path("/");
					}
				}, 1000);
		};		
		
		

    
    dataFactory.getCurrentState = function() {
        return currentState;
    };
    
    dataFactory.setCurrentState = function(state) {
        currentState = state;
    };
    
    dataFactory.getSelectedExperiences = function() {
         selectedExperiences = JSON.parse( localStorage.getItem( "selectedExperiences" ) );
        if ((selectedExperiences == undefined) || (selectedExperiences == null))
        {
            selectedExperiences = [];
            selectedExperiences = [];
        }
        return selectedExperiences;
    };
    
    dataFactory.setSelectedExperiences = function( sExperiences ) {
        selectedExperiences = sExperiences;
        localStorage.setItem('selectedExperiences', angular.toJson(sExperiences));
    };
    

	dataFactory.addExperienceToCart = function(expId) {                
		var user = dataFactory.getLoggedInUser();
		var orgId = dataFactory.getOrgId();
		var body ={"orgId" : orgId,
		"expId" : expId}
		return callApi(cartApiUrl,"POST",{'access-token':accesstoken,'rolename':localStorage.getItem('currentRole')},body,{});                                
    }
    
	dataFactory.getExperienceFromCartByOrgId = function( fetchFromApi , showLoader ) {     
        
        if( ( ( cartExperiences != "" ) || ( cartExperiences instanceof Array )  ) && ( !fetchFromApi ) )
            return cartExperiences;
		return callApi(cartApiUrl+"/"+dataFactory.getOrgId()+"?" + Date.now(),"GET",{'access-token':accesstoken,'rolename':localStorage.getItem('currentRole')},{},showLoader);              
	}
    
    dataFactory.setCartExperiences = function ( cartExp )
    {
        cartExperiences = cartExp;
    }

    
	dataFactory.deleteExperienceFromCart = function(cartItemId ) {               
		return callApi(cartApiUrl+"/"+cartItemId,"delete",{'access-token':accesstoken,'rolename':localStorage.getItem('currentRole')},{},{});                    
	}

	dataFactory.provisionExperiences=function(body, showLoader ){
	var user = dataFactory.getLoggedInUser();
	console.log(JSON.stringify(body));
	     return callApi(provisionApiUrl+"/","post",{'access-token':accesstoken,'rolename':localStorage.getItem('currentRole')},body,showLoader);
	}
    
	dataFactory.deProvisionExperiences=function( expId ,showLoader ){
        
	     return callApi(provisionApiUrl+"/"+expId,"DELETE",{'access-token':accesstoken,'rolename':localStorage.getItem('currentRole')},{},showLoader);
	}	
	
	
	dataFactory.getProvisionedExperiences=function( showLoader ){
	
	     return callApi(provisionApiUrl+"/companies/"+dataFactory.getOrgId(),"get",{'access-token':accesstoken,'rolename':localStorage.getItem('currentRole')},{} ,showLoader);
	}
	
	
	/*
	dataFactory.provisionExperiences=function(body){
	var user = dataFactory.getLoggedInUser();
	     return callApi(provisionApiUrl+"/","post",{'access-token':accesstoken,'username':user.username},body,{});
	}
	
	dataFactory.deProvisionExperiences=function(provisionedId){
	var user = dataFactory.getLoggedInUser();
	     return callApi(provisionApiUrl+"/"+provisionedId,"delete",{'access-token':accesstoken,'username':user.username},{},{});
	}
	
	
	dataFactory.experienceEnrolled=function(body){
		var user = dataFactory.getLoggedInUser();
	     return callApi(experienceEnrolledApiUrl+"/","post",{'access-token':accesstoken,
		 'username':user.username},body,{});
	}
	
	dataFactory.updateExperienceEnrolled=function(enrolledId){
	     return callApi(experienceEnrolledApiUrl+"/"+enrolledId,"put",{'access-token':accesstoken,
		 'username':user.username},body,{});
	}
	
	dataFactory.deleteExperienceEnrolled=function(enrolledId){
	     return callApi(experienceEnrolledApiUrl+"/"+enrolledId,"delete",{'access-token':accesstoken,
		 'username':user.username},body,{});
	}
	*/
    
    dataFactory.setExperiences = function( response ) {
        experiences = response;
        dataFactory.experiencesMap( response );
       // localStorage.setItem('experiences', angular.toJson(response));
    };
    
    dataFactory.getExperiences = function( showLoader ) {
       // var exp = angular.fromJson( localStorage.getItem( "experiences" ) );
        if ( experiences != "" ) {
            return experiences;
        } else {
            return callApi(experiencesApiUrl + "?status=PUBLISHED", "GET", {'access-token':accesstoken,'rolename':localStorage.getItem('currentRole')}, {} ,showLoader );
        }
    };   
	dataFactory.getExperiencesByExperienceIds = function(experienceIds) {		
        return callApi(experiencesApiUrl+"?companyId="+dataFactory.getOrgId()+"&experiences="+experienceIds, "GET", {'access-token':accesstoken,'rolename':localStorage.getItem('currentRole')}, {});
       
    };   	
	dataFactory.getAppsByExperienceId = function(expId) {        
        return callApi(experiencesApiUrl+"/"+expId+"/apps", "GET", {'access-token':accesstoken,'rolename':localStorage.getItem('currentRole')}, {});       
    };
	

    dataFactory.getDomains = function( showLoader ) {	
      //  var d = angular.fromJson( localStorage.getItem( "domains" ) );
        if ( domains != "" )
            return domains;
        else
            return callApi(domainsApiUrl, "GET", {'access-token':accesstoken,'rolename':localStorage.getItem('currentRole')}, {} ,showLoader);
    };
    
    dataFactory.setDomains = function( response ) {
        domains = response;
        dataFactory.domainsMap( response );        
       // localStorage.setItem('domains', angular.toJson(response));
    };
    
    dataFactory.provisionSandbox = function(sandbox) {
        return callApi(sandboxesApiUrl, "POST", {'access-token':accesstoken,'rolename':localStorage.getItem('currentRole')}, sandbox);
    };
    
    dataFactory.getSandboxDetail = function(id) {
        return callApi(sandboxesApiUrl + "/" + id, "GET", {'access-token':accesstoken,'rolename':localStorage.getItem('currentRole')}, {});
    };
    
    dataFactory.logIn = function(user) {

/*        localStorage.removeItem("loggedInUser");
		localStorage.removeItem("orgId");
		localStorage.removeItem("fromExperiences")
		localStorage.removeItem("domains")
		//localStorage.removeItem("experiences")
		localStorage.removeItem("selectedExperiences")
        localStorage.removeItem("loggedInStatus");
        localStorage.removeItem("accesstoken");
        localStorage.removeItem("experienceDeatil");
        localStorage.removeItem("experiences");
        localStorage.removeItem("selectedExperience");
        localStorage.removeItem("selectedExperiences");  */
        localStorage.clear();
        
        user.password = user.password + "";
        return callApi(loginApiUrl, "POST", {}, user);
    };
    
	dataFactory.forgetPassword = function(user) {
	 return callApi(forgetPasswordUrl, "POST", {}, user);
	};
	
	dataFactory.forgotResetPassword = function(user,username) {     //need to correct
	var myUrl='';
	if(username.toLowerCase().includes('persistent'))
	{
	myUrl=baseApiUrl+'/platformusers/'+username+'/forgotPasswordReset';
	return callApi(myUrl, "POST", {}, user);
	}
	else{
	myUrl=baseApiUrl+'/users/'+username+'/forgotPasswordReset';
	return callApi(myUrl, "POST", {}, user);
	}
	 
	};
	
	dataFactory.ResetPasswordFn = function(user,username) {     //need to correct
	var myUrl='';
	if(username.toLowerCase().includes('persistent'))
	{
	myUrl=baseApiUrl+'/platformusers/'+username+'/resetPassword';
	return callApi(myUrl, "POST", {'access-token':accesstoken,'rolename':localStorage.getItem('currentRole')}, user);
	}
	else{
	myUrl=baseApiUrl+'/users/'+username+'/resetPassword';
	return callApi(myUrl, "POST", {'access-token':accesstoken,'rolename':localStorage.getItem('currentRole')}, user);
	}
	 
	};
	
	
	
    dataFactory.logout = function() {
        dataFactory.setLoginStatus(false);
        cartExperiences = "";
        experiences = "";
        domains = "";
        selectedExperiences = "";
        selectedDomain = "";
        selectedDomainIndex = "";
/*        localStorage.removeItem("loggedInUser");
		localStorage.removeItem("orgId");
		localStorage.removeItem("fromExperiences")
		localStorage.removeItem("domains")
		//localStorage.removeItem("experiences")
		localStorage.removeItem("selectedExperiences")
        localStorage.removeItem("loggedInStatus");
        localStorage.removeItem("accesstoken");
        localStorage.removeItem("experienceDeatil");
        localStorage.removeItem("experiences");
        localStorage.removeItem("selectedExperience");
        localStorage.removeItem("selectedExperiences");*/
        localStorage.clear();
      
		dataFactory.setSelectedExperiences([]);
        
		//dataFactory.setExperiences([]);
		$interval.cancel(idlePromise);
        $state.go( 'home' );
    };    
    
    dataFactory.getLoginStatus = function() {
        
        return localStorage.getItem('loggedInStatus');
    };
    
    dataFactory.setLoginStatus = function(status) {
        localStorage.setItem('loggedInStatus', status);
        loginStatus = status;
    };
    dataFactory.getLoggedInUser = function() {
        return angular.fromJson ( localStorage.getItem('loggedInUser') );
    };
    
    dataFactory.setLoggedInUser = function(user) {
        loggedInUser = user;
        localStorage.setItem('loggedInUser', angular.toJson(user));
    }; 
	
	dataFactory.setOrgId = function(orgId) {
        localStorage.setItem('orgId', orgId);
		orgId = orgId;
    };
    
	
	dataFactory.getOrgId = function() {
        return localStorage.getItem('orgId');
		
    };
    dataFactory.signUp = function(user) {
        return callApi(userApiUrl, "POST", {'access-token':accesstoken,'rolename':localStorage.getItem('currentRole')}, user);
    };
    
   dataFactory.getSelectedExperience = function() {
        return JSON.parse(localStorage.getItem('selectedExperience'));
    };
    dataFactory.setSelectedExperience = function(experience) {
		localStorage.setItem('selectedExperience', angular.toJson(experience));
       // selectedExperience = experience;
    };   
	
	dataFactory.getExperienceDetailById = function(expId) {
		var expDetailAPIUrl=experiencesApiUrl+"/"+expId+"/manifest";
		//var expDetailAPIUrl=experiencesApiUrl+"/32/manifest";
        return callApi(expDetailAPIUrl, "GET", {'access-token':accesstoken,'rolename':localStorage.getItem('currentRole')}, {});
    };
	
	dataFactory.setExperienceDetail = function( expDetail ) {			
        selectedExpDetail = expDetail;
       		localStorage.setItem('experienceDeatil', angular.toJson(expDetail));
    };
	dataFactory.getExperienceDetail = function() {		
        return JSON.parse(localStorage.getItem('experienceDeatil'));
    }; 
	
	
	
    dataFactory.getProvisionedExperineces = function() {
        if(loggedInUser.mail){
            var response = callApi(sandboxesApiUrl + "?email=" + loggedInUser.mail, "GET", {'access-token':accesstoken,'rolename':localStorage.getItem('currentRole')}, {});
            return response;
        }
        return "";
    };
    
    dataFactory.setProvisionedExperineces = function(experience) {
        provisionedExperineces = experience;
    };
    dataFactory.updateProvisionSandbox = function(sandboxId, experience) {
        return callApi(sandboxesApiUrl + "/" + sandboxId, "PUT", {'access-token':accesstoken,'rolename':localStorage.getItem('currentRole')}, experience);
    };
    dataFactory.deleteSandbox = function(sandboxId) {
        return callApi(sandboxesApiUrl + "/" + sandboxId, "DELETE", {'access-token':accesstoken,'rolename':localStorage.getItem('currentRole')}, {});
    };
    
    dataFactory.hasRequestedSandbox = function(flag) {
        if (typeof(flag) === "boolean")
            isSandboxRequested = flag;
        return isSandboxRequested;
    };
    
    dataFactory.loadingText = function(text) {
        if (text)
            loadingText = text;
        return loadingText;
    };
    
    dataFactory.isLoading = function( status )
    {
        if( typeof( status ) === "boolean" )
            isLoading = status;
        return isLoading;
    };
    dataFactory.getCaptcha = function() {        
        return callApi(captchaUrl+"?" + Date.now(), "GET", {}, {});       
    };
	
    dataFactory.getComponent = function() {        
        return callApi(componentApiUrl, "GET", {'access-token':accesstoken,'rolename':localStorage.getItem('currentRole')}, {});
    };
    dataFactory.getServices = function(experianceId) {  
		var serviceUrl=servicesBaseUrl+"/"+experianceId+"/"+servicesEnd;
		return callApi(serviceUrl, "GET", {'access-token':accesstoken,'rolename':localStorage.getItem('currentRole')}, {});
    };
	
	dataFactory.setAccessToken = function(access_token) {
        localStorage.setItem('accesstoken', access_token);
        accesstoken = access_token;
    };
	
	dataFactory.getAccessToken = function() {
       return angular.toJson( localStorage.getItem('accesstoken') );
       
    };
	
	dataFactory.getUsersByOrgId = function(expId) {        
        return callApi(companiesBaseUrl+"/"+expId+"/users", "GET", {'access-token':accesstoken,'rolename':localStorage.getItem('currentRole')}, {});       
    };
	dataFactory.addNewCompany = function(company){
		return callApi(companiesBaseUrl,"POST",{'access-token':accesstoken,'rolename':localStorage.getItem('currentRole')},company);
	}
	dataFactory.addNewUser = function(companyUser){		
		
		/* var user = {
		  "username": companyUser.username,	
		  "password": companyUser.username,
		  "firstname": "mark",
		  "lastname": "wahlberg",
		  "gender": "male",
		  "dateOfBirth": "18-09-1975",
		  "termsAndConditions": "terms And Conditions",
		  "CreatedBy": "admin",
		  "UpdatedBy": "admin"
		} */
		
		
		var user = {
		"username":companyUser.email,
		"password":"12345",
		"firstname":"mark",
		"lastname":"wahlberg",
		"gender":"M",
		"dateOfBirth":"08/12/1975",
		"termsAndConditions":"terms",
		"CreatedBy":"admin",
		"UpdatedBy":"admin",
		"telephoneNumber":"1234567890"
		}
		
		var headers = {
			"Content-type" : "application/json",
			"companyId" : companyUser.headers.companyId
		}
		return callApi(usersUrl,"POST",headers,user);
	}
	
	
	dataFactory.fetchCompanyUsers = function(companyId){
	
		var companiesUrlUsers = companiesBaseUrl+"/"+companyId+"/users";
		//alert(companiesBaseUrl+"/"+companyId+"/users");
		return callApi(companiesUrlUsers,"GET",{'access-token':accesstoken,'rolename':localStorage.getItem('currentRole')});
	}
	
	dataFactory.fetchCompanies = function(){
	
		return callApi(companiesBaseUrl,"GET",{'access-token':accesstoken,'rolename':localStorage.getItem('currentRole')});
	}
	
	dataFactory.fetchCompany = function(companyId){
		var companyByIdUrl = companiesBaseUrl+"/"+companyId;
		return callApi(companyByIdUrl,"GET",{'access-token':accesstoken,'rolename':localStorage.getItem('currentRole')});
	}
    
	dataFactory.getSandboxStatus = function( orgId ){
		
		return callApi(provisionApiUrl + "/companies/" + orgId ,"GET",{'access-token':accesstoken,'rolename':localStorage.getItem('currentRole')});
	}  
    
    dataFactory.hiddenNavbarFooter = function( status ){
        
        if( (status == true) || (status == false)  )
            hiddenNavbarFooter = status;
		
		return hiddenNavbarFooter;
	}    
    
	dataFactory.checkActivationStatusPU = function( email , token ){
	
		return callApi(userApiUrl + '/activationLink/active?e=' + email + '&t=' + token ,"GET",{'access-token':accesstoken,'rolename':localStorage.getItem('currentRole')});
	}   
    
	dataFactory.checkActivationStatus = function( email , token ){
	
		return callApi(usersUrl + '/activationLink/active?e=' + email + '&t=' + token ,"GET",{'access-token':accesstoken,'rolename':localStorage.getItem('currentRole')});
	}   
    
    dataFactory.getSelectedDomain = function(  ){
	
		return selectedDomain;
	}
    dataFactory.setSelectedDomain = function( domain ){
	
		selectedDomain = domain;
	}
    
    dataFactory.getSelectedDomainIndex = function(  ){
	
		return selectedDomainIndex;
	}
    
    dataFactory.setSelectedDomainIndex = function( domainIndex ){
	
		selectedDomainIndex = domainIndex;
	} 
    
    dataFactory.domainsMap = function( domains ){
	
        if( domains )
        {
            var dMap = {};
            domains.forEach( function( domain ){
                dMap[domain.id] = domain;
            });
            
            domainsMap = dMap;
		localStorage.setItem('domainsMap', angular.toJson(domainsMap));            
        }
		return domainsMap;
	}    
    
    dataFactory.experiencesMap = function( experiences ){
	
        if( experiences )
        {
            var eMap = {};
            experiences.forEach( function( experience ){
                eMap[experience.id] = experience;
            });
            
            experiencesMap = eMap;
		localStorage.setItem('experiencesMap', angular.toJson(experiencesMap));                    
        }
		return angular.fromJson( localStorage.getItem('experiencesMap') );
	}     
    
    dataFactory.ratingsMap = function( ratings ){
	
        if( ratings )
        {
            var rMap = {};
            ratings.forEach( function( rating ){
                rMap[ rating.surveyEntityTypeReF ] = rating;
            });
            
            ratingsMap = rMap;
		    localStorage.setItem('ratingsMap', angular.toJson( ratingsMap ));                    
        }
		return ratingsMap;
	}
  
    
    dataFactory.getExperienceRating = function( expId ){
	   if( expId )
        return callApi( getRatingUrl + "/" + expId,"GET",{'access-token':accesstoken,'rolename':localStorage.getItem('currentRole')});

	}     
    
    dataFactory.getAllExperiencesRating = function( showLoader ){
	   
        return callApi( getRatingUrl ,"GET",{'access-token':accesstoken,'rolename':localStorage.getItem('currentRole')} ,{} ,showLoader);

	}  
    
    dataFactory.setExperienceRating = function( data ){
	 
        if( data )
         return callApi(  setRatingUrl + "/" + expId,"GET",{'access-token':accesstoken,'rolename':localStorage.getItem('currentRole')} ,data);

	}
    
    dataFactory.getAppsByType = function ( appType )
    {
        if( appType )
         return callApi(  appsBaseUrl + "?type=" + appType,"GET",{'access-token':accesstoken,'rolename':localStorage.getItem('currentRole')} );        
    }
    
    dataFactory.appMap = function( mapData ){
        if( mapData )
        {
            var temp = [];
            mapData.forEach( function( app ){
                if(!temp [ app.experienceId ])
                    temp [ app.experienceId ] = [];
                temp [ app.experienceId ].push(app);            
            });
            localStorage.setItem("appMap", angular.toJson(temp));
         }
        else if ( !localStorage.getItem( "appMap" ) )
        {
          return dataFactory.getAppsByType("webapp");
         }
        return angular.fromJson( localStorage.getItem("appMap") );
    };
    
    dataFactory.addToDocMap = function( experienceId ,doc ){
        
        if( !doc )
            doc = [];
        docMap[ experienceId ] = doc;
        localStorage.setItem("docMap", angular.toJson(docMap));
        return docMap;
    
    };
    
    dataFactory.getDocMap = function( experienceId ){
        if( experienceId )
        {
            if( docMap[ experienceId ] == undefined )
            {
                return callApi( experiencesApiUrl + "/" + experienceId + "/documents","GET",{'access-token':accesstoken,'rolename':localStorage.getItem('currentRole')});
            }
            else
            {
                return docMap[ experienceId ];
            }
        }

        return angular.fromJson( localStorage.getItem("docMap") );
    };
    
    
    dataFactory.getExperienceDocumentation = function( expId ){
	   if( expId )
        return callApi( experiencesApiUrl + "/" + expId + "/documents","GET",{'access-token':accesstoken,'rolename':localStorage.getItem('currentRole')});

	}       
    
    
    dataFactory.getAppsDocumentation = function( appId ){
	   if( appId )
        return callApi( appsBaseUrl + "/" + appId + "/documents","GET",{'access-token':accesstoken,'rolename':localStorage.getItem('currentRole')});

	}  
    
    
    dataFactory.getServicesDocumentation = function( serviceId ){
	   if( serviceId )
        return callApi( servicesBaseUrl + "/" + serviceId + "/documents","GET",{'access-token':accesstoken,'rolename':localStorage.getItem('currentRole')});

	}
    
    dataFactory.previousState = function ( state )
    {
        if( state )
        {
            localStorage.setItem("previousState",state);
        }
        
        return localStorage.getItem( "previousState" );
    
    }
    
    dataFactory.getTopExperiences = function ( top )
    {
        if( top )
         return callApi(  topExpBaseUrl + "?top=" + top,"GET",{'access-token':accesstoken,'rolename':localStorage.getItem('currentRole')} );        
    }
    
    dataFactory.getTotalUsers = function ()
    {
        
         return callApi(  userApiUrl,"GET",{'access-token':accesstoken,'rolename':localStorage.getItem('currentRole')} );        
    }
    
    dataFactory.getTopPlatformUsers = function ( top )
    {
        if( top )
         return callApi(platformUsersBaseUrl + "?top=" + top,"GET",{'access-token':accesstoken,'rolename':localStorage.getItem('currentRole')} );        
    }
    
    dataFactory.getProvisionedExp = function ( top )
    {
       
         return callApi(provisionedBaseUrl ,"GET",{'access-token':accesstoken,'rolename':localStorage.getItem('currentRole')} );        
    }
    
    dataFactory.showLoading = function( status )
    {
        if( (status == true) || (status == false) )
            showLoading = status;
        return showLoading;
    }
    
    dataFactory.getLiveTrace = function( id ){
        if( id )
            return callApi( traceApiUrl + "?expID=" + id ,"GET",{'access-token':accesstoken,'rolename':localStorage.getItem('currentRole')} );        
    }
    
    dataFactory.tracePopupData = function( data )
    {
        if(data)
        {
            tracePopupData = data;
        }
        return tracePopupData;
    }
    
    dataFactory.popupData = function( data )
    {
        if(data)
        {
            popupData = data;
        }
        return popupData;
    }
    
    dataFactory.searchExperiences = function( data )
    {
            var keys = Object.keys(data);
			var url = experiencesApiUrl + "/search" + "?status=PUBLISHED";

			keys.forEach(function( key ){
				 var str = data[key].join();
				 url = url + "&" + key + "=" + str;
			})
			return callApi( url, "GET", {'access-token':accesstoken,'rolename':localStorage.getItem('currentRole')}, {} ,true);   
    }
    
    dataFactory.getAllDocuments = function( )
    {
        
            return callApi( docsApiUrl, "GET", {'access-token':accesstoken,'rolename':localStorage.getItem('currentRole')}, {} ,true);   
    }
    
    dataFactory.getExperiencesV2 = function( showLoader ) {
            var deferred = $q.defer();
            var promise = deferred.promise;

            if ( experiences != "" ) {
                   dataFactory.setExperiences(experiences);
                   deferred.resolve(experiences);
            } else {
                callApi(experiencesApiUrl + "?status=PUBLISHED", "GET", {'access-token':accesstoken,'rolename':localStorage.getItem('currentRole')}, {} ,showLoader )
                .success(expSuccess)
                .error(expError);

            }

            function expSuccess(response)
            {
                dataFactory.setExperiences(response);
                deferred.resolve(response);
            }

            function expError(error)
            {
                deferred.reject(error);
            }
            return promise;    
        }

  
                            
	dataFactory.getExperienceFromCartByOrgIdV2 = function( fetchFromApi , showLoader ) {    
        var deferred = $q.defer();
        var promise = deferred.promise;                            
        
        if( ( ( cartExperiences != "" ) || ( cartExperiences instanceof Array )  ) && ( !fetchFromApi ) )
            {
                deferred.resolve(cartExperiences);
            }
        else
            {
                callApi(cartApiUrl+"/"+dataFactory.getOrgId()+"?" + Date.now(),"GET",{'access-token':accesstoken,'rolename':localStorage.getItem('currentRole')},{},showLoader)
                    .success(cartSuccess)
                    .error(cartError)
            }
                            
            function cartSuccess(response) 
            {
                dataFactory.setCartExperiences(response);
                deferred.resolve(response);                            
            }

            function cartError(error)
            {
                deferred.reject(error);
            }                            
                            
        return promise;
	}       
                            
	
	dataFactory.getProvisionedExperiencesV2 = function( showLoader ){
        var deferred = $q.defer();
        var promise = deferred.promise;    
                            
	    callApi( provisionApiUrl +"/companies/" +dataFactory.getOrgId(), "get", {'access-token':accesstoken,'rolename':localStorage.getItem('currentRole')}, {} ,showLoader)
            .success(provSuccess)
            .error(provError);
                            
        function provSuccess(response) 
        {
            dataFactory.setProvisionedExperineces(response);
            deferred.resolve(response);                                        
        }
                            
        function provError(error)
        {
            deferred.reject(error);
        }                                 
                            
        return promise;
	}             
	
	dataFactory.getCompaniesV2=function( showLoader ){
        var deferred = $q.defer();
        var promise = deferred.promise;    
                            
	    callApi(companiesBaseUrl,"get",{'access-token':accesstoken,'rolename':localStorage.getItem('currentRole')},{} ,showLoader)
            .success(provSuccess)
            .error(provError);
                            
        function provSuccess(response) 
        {
            deferred.resolve(response);                                        
        }
                            
        function provError(error)
        {
            deferred.reject(error);
        }                                 
                            
        return promise;
	}
    
    dataFactory.provisionExperiencesV2=function(body, showLoader ){

        var deferred = $q.defer();
        var promise = deferred.promise;    

        callApi(provisionApiUrl+"/","post",{'access-token':accesstoken,'rolename':localStorage.getItem('currentRole')},body,showLoader)
            .success(provSuccess)
            .error(provError);

        function provSuccess(response) 
        {
            deferred.resolve(response);                                        
        }

        function provError(error)
        {
            deferred.reject(error);
        }                                 

        return promise;            

    }
    
    dataFactory.deProvisionExperiencesV2 = function(expId, showLoader ){

        var deferred = $q.defer();
        var promise = deferred.promise;    

        callApi(provisionApiUrl+"/"+expId,"DELETE",{'access-token':accesstoken,'rolename':localStorage.getItem('currentRole')},{},showLoader)
            .success(deProvSuccess)
            .error(deProvError);

        function deProvSuccess(response) 
        {
            deferred.resolve(response);                                        
        }

        function deProvError(error)
        {
            deferred.reject(error);
        }                                 

        return promise;            

    }
    
    dataFactory.getCompanyUsersV2 = function ( companyId )
    {

        var deferred = $q.defer();
        var promise = deferred.promise;    
        
        callApi(companiesBaseUrl + "/" + companyId + "/users","GET",{'access-token':accesstoken,'rolename':localStorage.getItem('currentRole')})
            .success(usersuccess)
            .error(usersError);

        function usersuccess(response) 
        {
            deferred.resolve(response);                                        
        }

        function usersError(error)
        {
            deferred.reject(error);
        }                                 

        return promise;        
            
    }

    dataFactory.addExperienceToCartV2 = function ( expId, showloader, addFlag )
    {

        var deferred = $q.defer();
        var promise = deferred.promise;  
        
		var orgId = dataFactory.getOrgId();
        
        var body =
        {
            "orgId" : orgId,
            "expId" : expId
        }
        
        callApi(cartApiUrl, "POST", {'access-token':accesstoken,'rolename':localStorage.getItem('currentRole')}, body, showloader)
            .success(cartSuccess)
            .error(cartError);

        function cartSuccess(response) 
        {
            if(addFlag)
                dataFactory.getExperienceFromCartByOrgIdV2()
                .then(function(cartExperiences){
                        cartExperiences.push(response);
                        dataFactory.setCartExperiences(cartExperiences);
                    });
         
            deferred.resolve(response);                                        
        }

        function cartError(error)
        {
            deferred.reject(error);
        }                                 

        return promise;        
            
    } 
    
    dataFactory.deleteExperienceFromCartV2 = function ( cartItemId, showloader, deleteFlag )
    {

        var deferred = $q.defer();
        var promise = deferred.promise;  
        
        callApi(cartApiUrl + "/" + cartItemId, "DELETE", {'access-token':accesstoken,'rolename':localStorage.getItem('currentRole')}, {}, showloader)
            .success(cartSuccess)
            .error(cartError);

        function cartSuccess(response) 
        {
            if(deleteFlag)
            {
                dataFactory.getExperienceFromCartByOrgIdV2()
                .then(function(cartExperiences){

                    cartExperiences.forEach(function(cartExp, index){
                        if(cartExp.cartItemId == cartItemId)
                        {
                            cartExperiences.splice(index, 1);
                            dataFactory.setCartExperiences(cartExperiences);
                            return;
                        }
                    });
                    deferred.resolve(response);

                })
                .catch(function(error){
                    console.log("error getting cart exps in dataFactory.deleteExperienceFromCartV2()");
                    deferred.resolve(response);                    
                });
                
            }
            else
            {
                deferred.resolve(response);
            }
        }

        function cartError(error)
        {
            deferred.reject(error);
        }                                 

        return promise;        
            
    }  
    
    dataFactory.addCompanyUsersV2 = function ( companyId, user, showloader )
    {

        var deferred = $q.defer();
        var promise = deferred.promise;  
        
        var headers = {
            "Content-type" : "application/json",
            "companyId" : companyId
        }
        
        callApi(usersUrl,"POST", headers, user, showloader)
            .success(usersuccess)
            .error(usersError);

        function usersuccess(response) 
        {
            deferred.resolve(response);                                        
        }

        function usersError(error)
        {
            deferred.reject(error);
        }                                 

        return promise;        
            
    }
    
    dataFactory.addNewCompanyV2 = function ( company, showLoader )
    {
        var deferred = $q.defer();
        var promise = deferred.promise;    
        
        callApi(companiesBaseUrl, "POST", {'access-token': accesstoken,'rolename':localStorage.getItem('currentRole')}, company, showLoader)
            .success(companysuccess)
            .error(companyError);

        function companysuccess(response) 
        {
            deferred.resolve(response);                                        
        }

        function companyError(error)
        {
            deferred.reject(error);
        }                                 

        return promise;        
    }
    
    dataFactory.getPlatformUsersV2 = function ( top )
    {
        var apiResponse;
        
        var deferred = $q.defer();
        var promise = deferred.promise;    
        
        if( top )
           apiResponse = callApi(platformUsersBaseUrl + "?top=" + top,"GET",{'access-token':accesstoken,'rolename':localStorage.getItem('currentRole')} )
        else
           apiResponse = callApi(platformUsersBaseUrl,"GET",{'access-token':accesstoken,'rolename':localStorage.getItem('currentRole')} );
        
        apiResponse.success(platformSuccess)
        apiResponse.error(platformError);

        function platformSuccess(response) 
        {
            deferred.resolve(response);                                        
        }

        function platformError(error)
        {
            deferred.reject(error);
        }                                 

        return promise;        
            
    }
    
    dataFactory.fetchCompanyUsersV2 = function ( top )
    {
        var apiResponse;
        
        var deferred = $q.defer();
        var promise = deferred.promise;    
        
        if( top )
           apiResponse = callApi(platformUsersBaseUrl + "?top=" + top,"GET",{'access-token':accesstoken,'rolename':localStorage.getItem('currentRole')} )
        else
           apiResponse = callApi(platformUsersBaseUrl,"GET",{'access-token':accesstoken,'rolename':localStorage.getItem('currentRole')} );
        
        apiResponse.success(platformSuccess)
        apiResponse.error(platformError);

        function platformSuccess(response) 
        {
            deferred.resolve(response);                                        
        }

        function platformError(error)
        {
            deferred.reject(error);
        }                                 

        return promise;        
            
    }
    
    dataFactory.getDomainsV2 = function( showLoader ) {	
        
        var deferred = $q.defer();
        var promise = deferred.promise;    
        
        if ( domains != "" )
            deferred.resolve(domains); 
        else
        {
            callApi(domainsApiUrl, "GET", {'access-token':accesstoken,'rolename':localStorage.getItem('currentRole')}, {}, showLoader )
                .success(domainSuccess)
                .error(domainError);
        }

        function domainSuccess(response) 
        {
            domains = response;
            deferred.resolve(response);                                        
        }

        function domainError(error)
        {
            deferred.reject(error);
        }     
        
        return promise;

    };    
    
    dataFactory.fetchCompanybyIdV2 = function ( companyId )
    {   // console.log("company id in service",companyId);
        if(!companyId)
		{
		$q.defer.reject();
		}
        var deferred = $q.defer();
        var promise = deferred.promise;    
        
        callApi(companiesBaseUrl + "/" + companyId, "GET", {'access-token': accesstoken,'rolename':localStorage.getItem('currentRole')})
            .success(companysuccess)
            .error(companyError);

        function companysuccess(response) 
        {
            deferred.resolve(response);                                        
        }

        function companyError(error)
        {
            deferred.reject(error);
        }                                 

        return promise;        
            
    }
    
    dataFactory.lastSandboxSelection = function( type, company )
    {
        if( !((!type) || (!company)) )
        {
            lastSandboxSelection.type = type;
            lastSandboxSelection.company = company;
        }
        return lastSandboxSelection;
    }
    
    
    dataFactory.extractOrgId = function( user, setFlag ){
        var id = -1;
        
        if(!user)
            return id;
        
        if ( user.attributes && user.attributes.length > 0) {
            for (var i = 0; i < user.attributes.length; i++) {
                if ( user.attributes[i].attributeName == 'referenceCompanyId') {
/*
                    dataFactory.setOrgId( user.attributes[i].attributeValue );
*/
                    id = user.attributes[i].attributeValue;
                    break;
                }
            }
        }
        
        else if (user.referenceCompanyId)
                id = user.referenceCompanyId;
        else
            id = user.companyId; 
        
        if(setFlag)
            dataFactory.setOrgId(id);
        return id;
    }
    
    dataFactory.experienceFilter = function( filterData ){
        if(filterData)
        {
            localStorage.setItem("filterData", angular.toJson( filterData));
            return filterData;
        }
        return angular.fromJson(localStorage.getItem("filterData"));
    }
    
    dataFactory.resendActivationEmail = function( email,showLoader ){
        var deferred = $q.defer();
        var promise = deferred.promise;    
                            
	    callApi(resendActEmailApiUrl+"?username="+email, "post", {}, {} ,showLoader)
            .success(mailsendSuccess)
            .error(mailsendError);
                            
        function mailsendSuccess(response) 
        {
           deferred.resolve(response);                                        
        }
                            
        function mailsendError(error)
        {
            deferred.reject(error);
        }                                 
                            
        return promise;
	}   
   
    dataFactory.getQRCode = function( showloader ){
        var deferred = $q.defer();
        var promise = deferred.promise;    
        var attr = "ENTERPRISE_APPSTORE_QR_CODE";
        
	    callApi(QRcodeApiUrl+"?username="+dataFactory.getLoggedInUser().username+"&attribute="+attr,"get",{'access-token': accesstoken,    'rolename':localStorage.getItem('currentRole')},{},showloader)
            .success(QRCodeSuccess)
            .error(QRCodeError);
                            
        function QRCodeSuccess(response) 
        {   console.log("response",response);
           deferred.resolve(response);                                        
        }
                            
        function QRCodeError(error)
        {
            deferred.reject(error);
        }                                 
                            
        return promise;
	}   
     dataFactory.getQRcodeBaselocation = function(  ){
	
		return QRcodeBaselocation;
	}
    
	
	//below functions by Nisar Nadaf
	
	dataFactory.setVisualizationData=function(Data){
	if(Data)
        {
            localStorage.setItem("VisualizationData", angular.toJson( Data));
            return Data;
        }
        return angular.fromJson(localStorage.getItem("VisualizationData"));
	
	   }
	   
	   dataFactory.previousTabs=function(Data){
	if(Data)
        {
            localStorage.setItem("previousTabs", Data);
            return Data;
        }
        return localStorage.getItem("previousTabs");
	
	   }
	
	
    return dataFactory;    
}]);

var app = angular.module('ui.filters', []);
app.filter('unique', function () {

  return function (items, filterOn) {

    if (filterOn === false) {
      return items;
    }

    if ((filterOn || angular.isUndefined(filterOn)) && angular.isArray(items)) {
      var hashCheck = {}, newItems = [];

      var extractValueToCompare = function (item) {
        if (angular.isObject(item) && angular.isString(filterOn)) {
          return item[filterOn];
        } else {
          return item;
        }
      };

      angular.forEach(items, function (item) {
        var valueToCheck, isDuplicate = false;

        for (var i = 0; i < newItems.length; i++) {
          if (angular.equals(extractValueToCompare(newItems[i]), extractValueToCompare(item))) {
            isDuplicate = true;
            break;
          }
        }
        if (!isDuplicate) {
          newItems.push(item);
        }

      });
      items = newItems;
    }
    return items;
  };
});