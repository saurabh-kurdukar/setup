//var basePath = "${basepathurl}";
//for HC Vega
var basePath="http://vega1nodeweb.centralindia.cloudapp.azure.com"
var baseApiUrl = basePath+":8080/v1.0";
var basePathFhir='http://vega1fhir.centralindia.cloudapp.azure.com';
var vegaFhirBaseUrl=basePathFhir+'/fhir';
var integrationEngineBaseUrl='http://vega1mirth.centralindia.cloudapp.azure.com:9090/integrationserver/api';




//for FinVega
/*var basePath="http://finvegastore.cloudapp.net"
var baseApiUrl = basePath+":8080/v1.0";
var basePathFhir='http://findev0mirth.centralindia.cloudapp.azure.com:9090/vega-analytics/';
var vegaFhirBaseUrl=basePathFhir+'api';
var integrationEngineBaseUrl='http://findev0mirth.centralindia.cloudapp.azure.com:9090/integrationserver/api';*/


// if true url will be redirected to maintainance page,please use boolean values only
var isUnderMaintainance = false ;

var provisionongApiInterval = 5000;//in milli seconds

var isHealthCareSandBox=false;

var PERSISTENT_COMPANY_ID = 1;
var PERSISTENT_COMPANY_NAME = 'Persistent Systems';

//for signup password length change below reg exp
var passwordLength=/\b\d{8}\b/;

// urls for dataset page
var dataset_dashboardUrl='http://vega1lakehdpnode2.centralindia.cloudapp.azure.com:8888/search/';
var dataset_BrowserUrl='http://vega1lakehdpnode2.centralindia.cloudapp.azure.com:8888/hbase/#Cluster';

//swagger url in api page
var api_fhir_SwaggerUrl='http://vega1fhir.centralindia.cloudapp.azure.com/docs';
//var api_fhir_SwaggerUrl='http://vega1fhir.centralindia.cloudapp.azure.com'

var api_intgrationEngine_SwaggerUrl='http://vega1mirth.centralindia.cloudapp.azure.com:9090/integrationserver/';
var api_openEmpi_swaggerURl='http://vega1nodeweb.centralindia.cloudapp.azure.com:8080/docs/#/OpenEMPI';
var api_vega_swaggerURl='http://vega1nodeweb.centralindia.cloudapp.azure.com:8080/docs/';


// url for Pipeline page
var data_pipeline_Url='http://vega1lakehdpdb.centralindia.cloudapp.azure.com:8080/#/main/views/Falcon/1.1.0/Falcon_View';
var data_pipelineEdit_url='http://vega1lakehdpnode2.centralindia.cloudapp.azure.com:8888/oozie/editor/workflow/list/';
