angular.module('appRoutes', ['ui.router'])
.config(function($stateProvider, $urlRouterProvider,$locationProvider) {
      /* $locationProvider.html5Mode({
  enabled: true,
  requireBase: true
});*/
  //
  // For any unmatched url, redirect to /state1
  $urlRouterProvider.otherwise("/home");
  //
  // Now set up the states
  $stateProvider
    .state('home', {
      url: "/home",
      templateUrl: "./views/templates/home.html",
	   controller : "DashboardController"
    })
	.state('experiences', {
      url: "/experiences",
      templateUrl: "./views/templates/experiences.html",
	  controller : "ExperiencesController"
    })
    .state('dashboard', {
      url: "/dashboard",
      templateUrl: "./views/templates/dashboard.html",
      controller : "vegaDashboardController"
    })
	  .state('yoursandbox', {
      url: "/yoursandbox",
      templateUrl: "./views/templates/yoursandbox.html",
	  controller : "YourSandboxController"
    })
	  .state('gallery', {
      url: "/gallery",
      templateUrl: "./views/templates/gallery.html",
	  controller : "GalleryController"
    })
	  .state('login', {
      url: "/login",
      templateUrl: "./views/templates/login.html",
	  controller : "LoginController"
    })	
	  .state('signup', {
      url: "/signup",
      templateUrl: "./views/templates/signup.html",
	  controller : "SignupController"
    }).state('expDetails', {
      url: "/expDetails",
      templateUrl: "./views/templates/Exp_Details.html",
	  controller : "expDetailsController"
    }).state('resetPwd', {
        url: "/resetPwd",
        templateUrl: "./views/templates/ResetPassword.html",
        controller : "ResetPasswordCtrl"
    }).state('activation', {
        url: "/activation?e&t",
        templateUrl: "./views/templates/activation.html",
        controller : "activationController"
    }).state('documentation', {
        url: "/documentation",
        templateUrl: "./views/templates/documentation.html",
        controller : "documentationController"
    }).state('admin-docs', {
        url: "/admin-docs",
        templateUrl: "./views/templates/admin_docs.html",
        controller : "adminDocController"
    }).state('developer-docs', {
        url: "/developer-docs",
        templateUrl: "./views/templates/developer_docs.html",
        controller : "developerDocController"
    }).state('provisionStatus', {
        url: "/provisionstatus",
        templateUrl: "./views/templates/provision_status.html",
        controller : "provisionStatusController"
    }).state('experience-guide', {
        url: "/experience-guide",
        templateUrl: "./views/templates/experience_guide.html",
        controller : "expGuideController"
    }).state('sa-yourSandbox', {
        url: "/YourSandboxSa",
        templateUrl: "./views/templates/sa-your-sandbox.html",
        controller : "saYourSandbox",
        controllerAs: 'syb'
    }).state('forgot-password', {
        url: "/forgotPassword",
        templateUrl: "./views/templates/ForgotPassword.html",
        controller : "forgotPasswordController",
    }).state('QRCode', {
        url: "/QRCode",
        templateUrl: "./views/templates/QRCode.html",
        controller : "QRCodeCtrl",
    }).state('faq-doc', {
        url: "/frequently-asked-questions",
        templateUrl: "./views/templates/FAQs.html",
        controller : "FAQsCtrl",
    }).state('interfaces', {
        url: "/interfaces",
        templateUrl: "./views/templates/integrationEngine.html",
        controller : "integrationEngineController",
    }).state('dataLake', {
        url: "/dataLake",
		controller :"dataLakeController",
        templateUrl: "./views/templates/dataLake.html",
    }).state('Datasets', {
        url: "/datasets",
		controller : "datasetsController",
        templateUrl: "./views/templates/datasets.html",
    }).state('apis', {
        url: "/apis",
		controller : "apisController",
        templateUrl: "./views/templates/apis.html",
    }).state('algorithms', {
        url: "/algorithms",
		controller : "algorithmController",
        templateUrl: "./views/templates/algorithms.html",
    }).state('pipeline', {
        url: "/pipeline",
		controller : "pipelineController",
        templateUrl: "./views/templates/dataPipeline.html",
    }).state('tryItVisualization', {
        url: "/visualization/tryIt",
		controller : "tryItController",
        templateUrl: "./views/templates/tryItVisualization.html",
    });
});
