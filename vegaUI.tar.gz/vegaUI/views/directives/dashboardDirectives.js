var app = angular.module('experienceApp.dashboradDirectives', []);

app.directive('pagefooter', ['dataFactory', function(dataFactory) {
    return {
        restrict: 'E',
        templateUrl: 'views/templates/footer.html',
        link: function($scope) {
           // console.log("footer controller");
        }
    };
}]);

app.directive('carousel', ['$http', function($http) {
    return {
        restrict: 'E',
        templateUrl: 'views/templates/carousel.html',
        link: function(scope, ele, attrs) {
           console.log("carousel controller");
		    $http.get('server/home.json', {
            }).success(function(data) {
            scope.features=data;
              
            }).error(function(data) {
               console.log(data);
            });
        }
    };
}]);

app.directive('topnavbar', ['dataFactory', '$state', function(dataFactory, $state) {
    return {
        restrict: 'E',
        templateUrl: 'views/templates/navbar.html',
        link: function($scope) {
            $scope.loginStatus = dataFactory.getLoginStatus();
            $scope.loggedInUser = dataFactory.getLoggedInUser();
           // console.log("loggedInUser", $scope.loggedInUser);
            $scope.selectedExperiences = dataFactory.getSelectedExperiences();
            $scope.curentState = dataFactory.getCurrentState();
            $scope.collapseNavbar = false;
            $scope.curentState = dataFactory.getCurrentState();
            $scope.curentState = $state.current.name;
            $scope.stateObj = $state;
        
            $scope.$watch(function() {
                return dataFactory.getCurrentState();
            }, function(newValue, oldValue) {
                $('.nav-collapse').removeClass('in');
                $('.navbar-toggle').addClass('collapsed');
                $scope.curentState = newValue;
				
                /*
                loadercode
                if( newValue != "yoursandbox" )
                    dataFactory.isLoading( true );*/
				if(newValue=='home')
				    $scope.isShowCarousel=true;
				else
				    $scope.isShowCarousel=false;
 
                if( ( !dataFactory.getAccessToken() ) || ( dataFactory.getLoginStatus() == undefined ) || ( dataFactory.getLoginStatus() == false ) || ( dataFactory.getLoginStatus() == "false" ) )
                {
                    if( !( $scope.curentState == 'home' ||  $scope.curentState == 'login' || $scope.curentState == 'signup' || $scope.curentState == 'activation' || $scope.curentState == 'faq-doc'|| $scope.curentState == 'resetPwd') )
                    {
                        $state.go('home');
                        console.log('going to home when not logged in');
                    }            
                       
                }

                angular.element(window).scrollTop(0);
            });
            
            $scope.$watch(function() {
                return dataFactory.getLoginStatus();
            }, function(newValue, oldValue) {
                $scope.loginStatus = newValue;
                $scope.loggedInUser = dataFactory.getLoggedInUser();
                if( $scope.loggedInUser && $scope.loggedInUser.username)
                $scope.loggedInUser.username = $scope.loggedInUser.username.split("@")[0];
                $scope.selectedExperiences = dataFactory.getSelectedExperiences();
                if( newValue == true )
                     dataFactory.idleLogoutUser();   
                
            });
            
            //this water updates username in navbar if different user is logged in from different tab.
            $scope.$watch(function() {
                if( dataFactory.getLoggedInUser() )
                    return dataFactory.getLoggedInUser().id;
            }, function(newValue, oldValue) {
                    $scope.loggedInUser = dataFactory.getLoggedInUser();
            });            
            
           /* $scope.$watch(function() {
                return dataFactory.getSelectedExperiences();
            }, function(newValue, oldValue) {
                $scope.selectedExperiences = dataFactory.getSelectedExperiences();
            });*/
            
            $scope.logout = function() {
                dataFactory.logout();
                $state.go('home');
            };
            $scope.goToAdmin = function() {
                console.log("in gotoadmin:");
                window.open("/admin");
            }
            $scope.goToNFS = function() {
                window.open("http://13.67.49.70:8080/#");
            }
            $scope.goToApiCards = function() {
                window.open("http://edt-experience.cloudapp.net:9999/#/app/apicards");
            }
            $scope.openDocumentation = function (){
                var url = $state.href('documentation');
                window.open(url,'_blank');
            };
            $scope.goToProvisionStatus = function ()
            {
                dataFactory.previousState( dataFactory.getCurrentState() );
                $state.go("provisionStatus"); 
            };
        }
    };
}]);

app.directive('loading', ['$http', 'dataFactory', function($http, dataFactory) {
    return {
        restrict: 'A',
        link: function(scope, elm, attrs) {
            
            scope.isLoading = function() {

/*                var n = $http.pendingRequests.length;
                var state = dataFactory.getCurrentState();
                if( (n == 0) || ( state == "provisionStatus" ) || ( state == "home" )|| ( state == "expDetails" ) || (state =="login") || (state =="signup")  )
                {
                    return false;
                }
                var flag = true;
                if(  (state == "experiences")  )
                {
                    $http.pendingRequests.forEach( function( req ){
                        var split = req.url.split("/") ;
                        console.log("split",split);
                        if( (split.length>2) && ( (split[ split.length-2 ] == "cart") || (split[ split.length-2 ] == "captcha") ) )
                        {flag = false;return;}

                        if( (split.length>1) && ( (split[ split.length-1 ] == "cart") || (split[ split.length-1 ] == "captcha")    ) )
                        {flag = false;return;}
                    });
                }
               

                console.log("$http.pendingRequests",$http.pendingRequests);
  
                 return flag;
                 */
                if( dataFactory.showLoading() )
                    return true;
//console.log("$http.pendingRequests",$http.pendingRequests);                
                var flag = false;
                $http.pendingRequests.forEach( function( req ){
                    
                    if( req.showLoader )
                    {
                        flag = true;
//console.log("$http.pendingRequests",$http.pendingRequests);                        
                        return;
                    }
                    
                });
                
                return flag;
                
                
 
                    
            };
            scope.$watch(scope.isLoading, function(v) {
                if (v) {
                    elm.show();
                } else {
                  //  dataFactory.loadingText('Loading...');
                    elm.hide();
                }
            });
        }
    };
}]);





var INTEGER_REGEXP = /^[A-Za-z0-9 _./-]*$/;    
var MAX_DIGITS_6 = passwordLength;
//var ONLYDIGITS_REGEXP = /[0-9]/g;   
var ONLYDIGITS_REGEXP = /^[0-9\b]+$/;
var EMAIL_BASIC=/^(([^<>()\[\] "\\.,;:\s@"\\.,;:\s@"]+(\.[^<>()\[\] "\\.,;:\s@"\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;           //format xyz@xyz.com
var ONLY_ALPHABETS = /^[A-z]+$/  
var ONLY_ALPHABETS_SPACE = /^[a-zA-Z ]*$/  
//var ONLY_ALPHABETS_SPACE = /^[a-zA-Z ]+$/; 


var createDirective=function(directiveName,regEx){
app.directive(directiveName, function() {
  return {
    require: 'ngModel',
    link: function(scope, elm, attrs, ctrl) {
      ctrl.$validators.customError = function(modelValue, viewValue) {
       if (ctrl.$isEmpty(modelValue)) {
          // consider empty models to be valid
        return true;
        }

        if (regEx.test(viewValue)) {
          // it is valid
          // console.log('true');
          return true;
        }
        // it is invalid
      //  console.log('false');
		//ctrl.$setViewValue("");
         //     ctrl.$render();
        return false;
      };
    }
  };
});
}

createDirective('alphanumeric', INTEGER_REGEXP );
createDirective('onlyDigits', ONLYDIGITS_REGEXP );
createDirective('limit6digits', MAX_DIGITS_6 );
createDirective('onlyAlphabets', ONLY_ALPHABETS );
createDirective('aplhabetWithSpace', ONLY_ALPHABETS_SPACE );
//createDirective('emailbasic', EMAIL_BASIC);


app.directive('emailbasic', function() {
  return {
    require: 'ngModel',
    link: function(scope, elm, attrs, ctrl) {
      ctrl.$validators.customError = function(modelValue, viewValue) {
       if (ctrl.$isEmpty(modelValue)) {
          // consider empty models to be valid
        return true;
        }

        if (EMAIL_BASIC.test(viewValue)) {
          // it is valid
          var LI = viewValue.lastIndexOf('@');
            console.log("viewValue",viewValue);
            console.log("LI",LI);    
          var first = viewValue.substring(0,LI+1);
          var last = viewValue.substring(LI+1).toLowerCase();
            console.log("first",first,"last",last);
            
            if( last == 'persistent.co.in' || last == 'persistent.com' ||last == 'persistentsys.com')
                {
                    console.log("formatted value",first + last );
                    ctrl.$setViewValue( first + last );
                    ctrl.$render();  
                    return true;
                }

          return false;
        }
        // it is invalid
        console.log('false');
		//ctrl.$setViewValue("");
         //     ctrl.$render();
        return false;
      };
    }
  };
});

  app.directive('formWizard', formWizard);

    formWizard.$inject = ['$parse'];
    function formWizard ($parse) {
        var directive = {
            link: link,
            restrict: 'A',
            scope: '='
        };
        return directive;

        function link(scope, element, attrs) {
          var validate = $parse(attrs.validateSteps)(scope),
              wiz = new Wizard(attrs.steps, !!validate, element);
          scope.wizard = wiz.init();
        }

        function Wizard (quantity, validate, element) {
          
          var self = this;
          self.quantity = parseInt(quantity,10);
          self.validate = validate;
          self.element = element;
          
          self.init = function() {
            self.createsteps(self.quantity);
            self.go(1); // always start at fist step
            return self;
          };

          self.go = function(step) {
            
            if ( angular.isDefined(self.steps[step]) ) {

              if(self.validate && step !== 1) {
                var form = $(self.element),
                    group = form.children().children('div').get(step - 2);

                if (false === form.parsley().validate( group.id )) {
                  return false;
                }
              }

              self.cleanall();
              self.steps[step] = true;
            }
          };

          self.active = function(step) {
            return !!self.steps[step];
          };

          self.cleanall = function() {
            for(var i in self.steps){
              self.steps[i] = false;
            }
          };

          self.createsteps = function(q) {
            self.steps = [];
            for(var i = 1; i <= q; i++) self.steps[i] = false;
          };

        }
    }
/* 
app.directive('progressbar', function() {
    return {
        restrict: 'EA',
        replace: true,
        transclude: true,
        controller: 'ProgressController',
        scope: {
            value: '=',
            type: '@'
        },
        templateUrl: 'template/progressbar/progressbar.html',
        link: function(scope, element, attrs, progressCtrl) {
            progressCtrl.addBar(scope, angular.element(element.children()[0]));
        }
    };
});

app.controller('ProgressController', ['$scope', '$attrs', 'progressConfig', function($scope, $attrs, progressConfig) {
    var self = this,
        animate = angular.isDefined($attrs.animate) ? $scope.$parent.$eval($attrs.animate) : progressConfig.animate;

    this.bars = [];
    $scope.max = angular.isDefined($attrs.max) ? $scope.$parent.$eval($attrs.max) : progressConfig.max;

    this.addBar = function(bar, element) {
        if ( !animate ) {
            element.css({'transition': 'none'});
        }

        this.bars.push(bar);

        bar.$watch('value', function( value ) {
            bar.percent = +(100 * value / $scope.max).toFixed(2);
        });

        bar.$on('$destroy', function() {
            element = null;
            self.removeBar(bar);
        });
    };

    this.removeBar = function(bar) {
        this.bars.splice(this.bars.indexOf(bar), 1);
    };
}]);

 */