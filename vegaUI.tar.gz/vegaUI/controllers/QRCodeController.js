(function(){
    
angular
    .module('experienceApp.QRCodeCtrl', ['ui.bootstrap'])
    .controller('QRCodeCtrl', QRCodeCtrl);
                
QRCodeCtrl.$injector = ['$scope', '$rootScope', 'dataFactory', '$state','$uibModal'];

function QRCodeCtrl ($scope, $rootScope, dataFactory, $state,$uibModal) {
    var previousState = dataFactory.getCurrentState();
    dataFactory.setCurrentState('QRCode');
     //binded functions
    $scope.QRCodeInit=QRCodeInit;
    
    //binded variables
    $scope.QRCodeSrc;
    
    
    var showloader = true;
    function callErrorHandler (method, apiResponse, postApiDataSent) {
        errorObj = {
            controller: "QRCodeController",
            method: method,
            postApiDataSent: postApiDataSent,
            apiResponse: apiResponse
        }
        $rootScope.handleErrors(errorObj);
    };

    function QRCodeInit()
    {
	
        dataFactory.getQRCode(showloader)
            .then(QRCodeSuccess)
            .catch(QRCodeFailure);

        function QRCodeSuccess(response) {
            $scope.QRCodeSrc=dataFactory.getQRcodeBaselocation()+response.attributes[0].attributeValue;
       
        }					

        function QRCodeFailure(error) {
            callErrorHandler("getQRCode", error, "error fetching QRCode");
        }
			
    };
   
        //    Content goes here for Reset Password Flow
    $scope.backToLastPage = function () {
        if (previousState == '' || previousState == undefined) {
            $state.go('home');
        } else {
            $state.go(previousState);
        }
    }
}
    
})();