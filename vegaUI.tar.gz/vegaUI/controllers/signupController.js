(function(){

angular
    .module('experienceApp.signupController', ['ui.bootstrap'])
    .controller('SignupController', SignupController)
    .controller('modalInstanceController', modalInstanceController);

SignupController.$injector = ['$scope', '$rootScope', 'dataFactory', '$state', '$http', '$uibModal'];
modalInstanceController.$injector = ['$scope', '$uibModalInstance','dataFactory','$rootScope'];



function SignupController($scope, $rootScope, dataFactory, $state, $http, $uibModal) {
    
	dataFactory.setCurrentState("signup");
    $scope.disableSignUpButton = false;
    
    if( dataFactory.getLoginStatus() )
    {
        dataFactory.logout();
    }
    else
    {
        var errorObj = {};
        var callErrorHandler = function (method, apiResponse, postApiDataSent) {
            errorObj = {
                controller: "YOUR SANDBOX",
                method: method,
                postApiDataSent: postApiDataSent,
                apiResponse: apiResponse
            }
            $rootScope.handleErrors(errorObj);
        };

        $scope.captchaRefresh = function (isPopUpCaptcha) {
            var captchaData = dataFactory.getCaptcha();
            captchaData.success(function (response) {
                $scope.isConnectionError = false;
                if(isPopUpCaptcha)
                {
                    $scope.popupCatcheImg = 'data:image/jpeg;base64,' + base64ArrayBuffer(response.captchaImage.data);
                    $scope.popupCatchecode = response.captchaCode;
                }
                else{
                    $scope.catcheImg = 'data:image/jpeg;base64,' + base64ArrayBuffer(response.captchaImage.data);
                    $scope.catchecode = response.captchaCode;
                }
            }).error(function (error) {
                $scope.isConnectionError = true;
                console.log("error fetching captchaData");
            });

            function base64ArrayBuffer(arrayBuffer) {
                var base64 = ''
                var encodings = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/'
                var bytes = new Uint8Array(arrayBuffer);
                var byteLength = bytes.byteLength;
                var byteRemainder = byteLength % 3;
                var mainLength = byteLength - byteRemainder;
                var a, b, c, d;
                var chunk;
                for (var i = 0; i < mainLength; i = i + 3) {
                    chunk = (bytes[i] << 16) | (bytes[i + 1] << 8) | bytes[i + 2] ;
                    a = (chunk & 16515072) >> 18 ;
                    b = (chunk & 258048) >> 12 ;
                    c = (chunk & 4032) >> 6 ;
                    d = chunk & 63 ;
                    base64 += encodings[a] + encodings[b] + encodings[c] + encodings[d];
                }
                if (byteRemainder == 1) {
                    chunk = bytes[mainLength] ;
                    a = (chunk & 252) >> 2 ;
                    b = (chunk & 3) << 4 ;
                    base64 += encodings[a] + encodings[b] + '==';
                } else if (byteRemainder == 2) {
                    chunk = (bytes[mainLength] << 8) | bytes[mainLength + 1] ;
                    a = (chunk & 64512) >> 10 ;
                    b = (chunk & 1008) >> 4 ;
                    c = (chunk & 15) << 2 ;
                    base64 += encodings[a] + encodings[b] + encodings[c] + '=';
                }
                return base64;
            }
        };
        $scope.PopCaptcha = function () {
            $scope.captchaRefresh("PopUpCaptcha");            
        }
        $scope.captchaRefresh();
        var resetData = function () {
            $scope.signUpData = {
                "username": "",
                "password": "",
                "email": ""
            };
            $scope.showSignupError = {
                "userName": {
                    show: false,
                    msg: "Full Name*"
                },
                "password": {
                    show: false,
                    msg: " Password(should be numeric & exactly 8 digit long)*"
                },
                "email": {
                    show: false,
                    msg: "Please enter valid Email address(Only Persistent Domain is allowed). *"
                },
                "captcha": {
                    show: false,
                    msg: " Please enter above Captcha*"
                }
            };
        };

        $scope.resetSignUpError = function () {
            $scope.showSignupError.email.show = false;
            $scope.showSignupError.email.msg = "Please enter valid Email(Only Persistent Domain is allowed). *";
        };

        $scope.signUp = function () {
            $scope.captcha = false;
            if ($scope.signUpData.captcha == $scope.catchecode) {
                if ($scope.signUpData.email != "" && $scope.signUpData.username != "" && $scope.signUpData.password != "") {
                    var nameSplit = $scope.signUpData.username.split(" ");
                    var firstname = "";
                    var lastname = " ";
                    if (nameSplit.length > 1) {
                        lastname = nameSplit[nameSplit.length - 1];
                        nameSplit.splice(nameSplit.length - 1, 1);
                    }
                    firstname = nameSplit.join(" ");
                    var d = {
                        "username": $scope.signUpData.email,
                        "userpassword": $scope.signUpData.password + "",
                        "givenName": firstname,
                        "sn": lastname,
                        "mail": $scope.signUpData.email,
                        "telephoneNumber": "9812346578"
                    };
                    resetData();
                    $scope.disableSignUpButton = true;
                    dataFactory.signUp(d).then(function successCallback(response) {
                        console.log("sign up success", response);
                        if (!response.data.verified)
                        {   
                            $scope.activationSuccess();
                            
                        } else {
                            loginUser({
                                username: d.username,
                                password: d.userpassword
                            });
                        }
                    }, function errorCallback(error) {
                        $scope.disableSignUpButton = false;
                        callErrorHandler("$scope.signUp", error, d);
                        if (error.status == 500) {
                            if (error.data.errorCode == "PU001") {
                                $scope.showSignupError.email.msg = "Email Already Registered.Please LogIn";
                                $scope.showSignupError.email.show = true;
                            } else $scope.isConnectionError = true;
                        } else {
                            $scope.isConnectionError = true;
                        }
                        $scope.captchaRefresh();
                    });
                } else {
                        $scope.disableSignUpButton = false;
                        $scope.signUpmsg = "All fields are mandatory";
                }
            } else {
                $scope.showSignupError.captcha.msg = "Please Enter Valid Captcha";
                $scope.showSignupError.captcha.show = true;
                $scope.disableSignUpButton = false;
                $scope.captchaRefresh();
            }
        };

        var loginUser = function (loginData) {
            dataFactory.logIn(loginData).then(function successCallback(response) {
                sessionStorage.setItem("loggedInUser", response.config.data);
                dataFactory.setLoginStatus(true);
                dataFactory.setLoggedInUser(response.config.data);
                state.go('yoursandbox');
            }, function errorCallback(error) {
                console.log("Error Logging In after signup:-", error);
            });
        };

        $scope.canSubmitRequest = function () {
            if (($scope.isConnectionError) || !($scope.signUpData.email) || !($scope.signUpData.username) || !($scope.signUpData.password) || ($scope.valid) || ($scope.disableSignUpButton)  ) {
                return false;
            } else {
                return true;
            }
        }

        $scope.open  =   function  (size) { 

            var  modalInstance  =  $uibModal.open({      
                animation: $scope.animationsEnabled,
                      templateUrl:   'showActivationPopUp.html',
                      controller:   'modalInstanceController',
                      size: size,
                      resolve: {              }    
            }); 
            modalInstance.result.then(function  (selectedItem) {      
                $scope.selected  =  selectedItem;    
            },  function  () {          });
        }

        $scope.signupErrorMsg = "Email Id is required.*";
        resetData();
    }

  
    $scope.activationSuccess  =   function  (size) {
        var  modalInstance  =  $uibModal.open({      
            animation: $scope.animationsEnabled,
                  templateUrl:   'showActivationPopUp.html',
                  controller:   'modalInstanceController',
                  
        }); 
        modalInstance.result.then(function  (value) {      
            if (value == 'didNotGet') {
                $scope.PopCaptcha()
                $scope.resendActivationPopup();
            }
        },  function  () {          });
    }

    $scope.resendActivationPopup = function () {
          var modalInstance = $uibModal.open({
          templateUrl: 'resendActivationMail.html',
          controller: 'modalInstanceController',
            scope : $scope
          });
        modalInstance.result.then(function (value) {
                if (value == 'resendActivationMail') {
                    $scope.activationSuccess();
                }
            }, function () {
                console.log('error');
            }
        );
      };
}

function modalInstanceController($scope, $uibModalInstance, $uibModal,dataFactory,$rootScope) {
	$scope.closePopUp = function (input) {
	    if (input != undefined) {
	        $uibModalInstance.close(input);
	    } else {
	        $uibModalInstance.close();
	    }
	};
	$scope.resendActivationPopup = function () {
        var modalInstance = $uibModal.open({
          templateUrl: 'resendActivationMail.html',
          controller: 'modalInstanceController',
            scope : $scope
          });

        modalInstance.result.then(function () {
                console.log('success');
            }, function () {
                console.log('error');
            }
        );
      };
  
    //bindable functions
    $scope.resendActivationEmail=resendActivationEmail;
    function resendActivationEmail()
    {
        
        if($scope.popupCatchecode==$scope.captchaEntered)
        {
            
            dataFactory.resendActivationEmail($scope.enteredEmail)
            .then(resendEmailSuccess)
            .catch(resendEmailError);  

            function resendEmailSuccess(response)
            {   
                $scope.closePopUp("resendActivationMail");
            }

            function resendEmailError(error)
            {
               
                if(error.errorMessage == "Invalid username")
                {
                    $scope.showPopupSignupError.email.msg= " Please Enter valid Registered EmailID";
                    $scope.showPopupSignupError.email.show = true;
                    
                }
                else if(error.errorMessage == "User Already Verified")
                {
                    $scope.showPopupSignupError.email.msg = " User is Already Verified";
                    $scope.showPopupSignupError.email.show = true;
                   
                }
                else
                    callErrorHandler("Error", error, "Error while resending the email");
            } 
        }
        else
            $scope.showPopupSignupError.Captcha.show=true;
    }
    
    
    
    
    
     $scope.showPopupSignupError = {
                "Captcha": {
                    show: false,
                    msg: " Invalid Captcha"
                },
                "email": {
                    show: false,
                    msg: " Please enter valid Email address"
                }
     }
      $scope.resetPopUpEmail = function () {
            $scope.showPopupSignupError.email = {
                show: false,
                msg: " Please enter valid Email address"
            }
        };
    
    
        $scope.canSubmitResendMailRequest = function () {
           
            if (($scope.isConnectionError) || !($scope.captchaEntered) || !($scope.enteredEmail)) {
                return false;
            } else {
                return true;
            }
        }
    
    
    var errorObj = {};
    var callErrorHandler = function (method, apiResponse, postApiDataSent) {
        errorObj = {
            controller: "YOUR SANDBOX",
            method: method,
            postApiDataSent: postApiDataSent,
            apiResponse: apiResponse
        }
        $rootScope.handleErrors(errorObj);
    };
    
}

    
})();