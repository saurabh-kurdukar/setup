var app = angular.module('experienceApp.yoursandboxController', []);
app.controller('YourSandboxController', ['$scope', '$rootScope', 'dataFactory', '$state', '$timeout', function YourSandboxController($scope, $rootScope, dataFactory, $state, $timeout) {
    /****removed this hardcode ordId once work done*****/
   // sessionStorage.setItem("orgId", 1175);
    dataFactory.setCurrentState("yoursandbox");
    $scope.selectedExperiences = dataFactory.getSelectedExperiences();
    $scope.provisionedExperineces = dataFactory.getProvisionedExperineces();
    var user = dataFactory.getLoggedInUser();
    $scope.isLoggedIn = dataFactory.getLoginStatus();

    $scope.provisions = [];
    $scope.provisonsArray = [];
    $scope.expApis = [];
    $scope.companies = [];
    $scope.arrApps = [];

    $scope.searchCompany = false;
    $scope.isShowCompanySearchSection = false;
    $scope.isShowAddUserExperienceSection = false;
    $scope.isShowAddedUsersExperiencesSection = true;
    $scope.isSandBoxAdded = false;
    $scope.showSuccess = false;
    $scope.showStatusColumn = false;
    
    var allExperiences = dataFactory.getExperiences();
    var expMap = {};
    allExperiences.forEach( function( exp ){ 
        expMap[ exp.id ] = exp;
    });
/*
    if (sessionStorage.getItem("fromExperiences")) {
        $scope.isShowCompanySearchSection = false;
        $scope.isShowAddUserExperienceSection = false;
        $scope.isShowAddedUsersExperiencesSection = true;
        $scope.isSandBoxAdded = false;
        //$rootScope.fetchUsers(sessionStorage.getItem("orgId"));
        dataFactory.fetchCompanyUsers(sessionStorage.getItem("orgId"))
            .success(function (response) {
                console.log("Successfully fetched users for comapanyId: ", sessionStorage.getItem("orgId"));
                $scope.userArray = response;
                // console.log("userArray:==== ",$scope.userArray.length);
            }).error(function (err) {
				//$scope.isConnectionError=true;
                console.log("Error in fetching users for comapanyId: " + sessionStorage.getItem("orgId") + ", Error:" + JSON.stringify(err));
            });
        sessionStorage.setItem("fromExperiences", false);
    }

    $scope.fetchCompanies = function () {
        dataFactory.fetchCompanies()
            .success(function (response) {
                $scope.companylist = response;
                $scope.companylist.forEach(function (company) {
                    $scope.companies.push({
                        "companyId": company.companyId,
                        "name": company.companyName
                    })
                });
                $scope.addNewCompanyBtn = true;
                console.log('Successfully fetched companies');
            })
            .error(function (err) {
				// $scope.isConnectionError=true;
                console.log('Error in fetching companies, Error: ' + JSON.stringify(err));
            });

    };

    $scope.fetchCompanies();
    $scope.$watch('customSelected', function (newVal, oldVal) {
        if (newVal == undefined || newVal == '') {
            $scope.addNewCompanyBtn = true;
        } else {
            $scope.addNewCompanyBtn = false;
        }

        if (newVal != undefined && newVal.companyId != undefined && newVal.companyId != '' && newVal.name != undefined && newVal.name != undefined) {
            $scope.fetchCompany(newVal.companyId);
            $scope.fetchUsers(newVal.companyId);

        }
    });

    $scope.addNewCompany = function () {
        var customSelected = $scope.customSelected;
        var company = {
            "companyName": customSelected,
            "companyAddress": "HJ, Pune",
            "city": "Pune",
            "state": "Maharastra",
            "country": "India",
            "zipCode": "411057",
            "companyURL": "http://www.company1.com",
            "companyImageURL": "https://www.internations.org/magazine/repatriate-issues-and-company-support-15343/company-benefits-for-repatriates-2",
            "phone": "123",
            "fax": "12345",
            "email": "abc@company1.com",
            "adminFullName": "admin",
            "adminMobile": "9989",
            "adminEmail": "admin@company1.com",
            "status": "progress",
            "createdOn": "11-02-2016",
            "createdBy": "Admin",
            "updatedOn": "12-02-2016",
            "updatedBy": "Admin",
            "adminMobileVerified": "true",
            "adminEmailVerified": "true"
        }
        dataFactory.addNewCompany(company)
            .success(function (response) {

                //Assigning values to required variables after success of company API				
                $scope.companyId = response.companyId;
                $scope.companyname = response.companyName;
                $rootScope.companyname1 = response.companyName;
                dataFactory.setOrgId($scope.companyId);

                //Setting flag to true 			
                $scope.isSandBoxAdded = false;
                $scope.isShowAddUserExperienceSection = true;
                console.log("Added company Id: ", $scope.companyId);

                //$scope.fetchUsers($scope.companyId);
                $scope.userArray = {};
                $scope.username = "";
                $scope.email = "";

                console.log("Successfully Added companyId:", response.companyId);
            })
            .error(function (err) {
				//$scope.isConnectionError=true;
                console.log("Error in Adding company, Error: ", $scope.companyId);
            });
    }
    $scope.addNewUser = function () {
        var companyId = $scope.companyId;
        var username = $scope.username;
        var email = $scope.email;

        var companyUser = {
            "username": username,
            "email": email,
            "headers": {
                "companyId": companyId
            }
        }
        dataFactory.addNewUser(companyUser)
            .success(function (response) {
                console.log("Added new users for companyId: " + response.comapanyId);
                $scope.username = "";
                $scope.email = "";
                $rootScope.fetchUsers($scope.companyId);

            })
            .error(function (err) {
				//$scope.isConnectionError=true;
                console.log("Error in fetching users for companyId: " + $scope.companyId + ", Error:" + JSON.stringify(err));
            });

    }

    $scope.func = function () {
        $state.go('experiences');
    }

    $rootScope.fetchUsers = function (companyId) {
        dataFactory.fetchCompanyUsers(companyId)
            .success(function (response) {
                console.log("Successfully fetched users for comapanyId: ", companyId);
                $scope.userArray = response;
                $scope.userCount = $scope.userArray.length;
                console.log("userArray:==== ", $scope.userArray.length);
            })
            .error(function (err) {
				//$scope.isConnectionError=true;
                console.log("Error in fetching users for comapanyId: " + companyId + ", Error:" + JSON.stringify(err));
            });
    }

    $scope.fetchCompany = function (companyId) {
        var companyObj = dataFactory.fetchCompany(companyId);
        companyObj.success(function (response) {
            $scope.companyId = response.companyId;
            $scope.companyname = response.companyName;
            $rootScope.companyname1 = response.companyName;
            dataFactory.setOrgId(response.companyId);

            console.log("Successfully fetched company for companyId: " + response.companyId);

            $scope.addNewCompanyBtn = true;
            $scope.isShowCompanySearchSection = true;
            $scope.isSandBoxAdded = false;
            $scope.isShowAddUserExperienceSection = true;

        }).error(function (err) {
			//$scope.isConnectionError=true;
            console.log("Error in fetching company, Error: " + JSON.stringify(err));
        });
    }*/

    var getExperiences = dataFactory.getExperienceFromCartByOrgId();
    getExperiences.success(function (response) {
        $scope.companyCartDetail = response;
        console.log("dataFactory.getExperienceFromCartByOrgId:::==", $scope.companyCartDetail);
        var experienceIds = "";
        var cartExperiences = [];
        
        $scope.companyCartDetail.forEach( function( cartItem ){
            
            cartExperiences.push( expMap[ cartItem.expId ] );
          
        });
        $scope.companyCartExperiences = cartExperiences;
       // console.log("/************ $scope.companyCartExperiences ****/ ",$scope.companyCartExperiences);
        /*for (var i = 0; i < $scope.companyCartDetail.length; i++) {
            if (experienceIds != "") {
                experienceIds = experienceIds + "," + $scope.companyCartDetail[i].expId;
            } else {
                experienceIds = $scope.companyCartDetail[i].expId;
            }
        }
	if(experienceIds)
	{
        var experiences = dataFactory.getExperiencesByExperienceIds(experienceIds);
        experiences.success(function (response) {
            console.log("dataFactory.getExperiencesByExperienceIds",response);
            $scope.companyCartExperiences = response;
            console.log("$scope.companyCartExperiences", $scope.companyCartExperiences)
            //getApps(response);
            //fetchSandboxStatus(dataFactory.getOrgId());
        }).error(function (err) {
			$scope.isConnectionError=true;
            console.log("error in fetching Experiences By id");
        });
		
	}*/
		
    }).error(function (err) {
		 //$scope.isConnectionError=true;
        console.log("error Experiances By OrgId !!!");
    })

   /* var getApps = function (experiences) {
        for (i = 0; i < experiences.length; i++) {
            dataFactory.getAppsByExperienceId(experiences[i].id)
                .success(function (response) {
                    $scope.app1 = response;
                    //console.log("$scope.app1=======",$scope.app1.length);
                    $scope.app1.forEach(function (app) {
                        $scope.arrApps.push({
                            "experienceId": app.experienceId,
                            "name": app.name,
                            "id": app.id,
                            "len": $scope.app1.length
                        });
                    });

                }).error(function (error) {
					$scope.isConnectionError=true;
                    console.log("error apps By ExpId !!!");
                });
        }

    }*/

    $scope.provision = function () {

        console.log("In provision");
        $scope.hidepencil = true;
        var cartExperiences = dataFactory.getSelectedExperiences();
        console.log("");
        var successCount = 0;

        cartExperiences.forEach(function (experience) {

            console.log(dataFactory.getOrgId());
            var body = {
                "orgId": dataFactory.getOrgId(),
			"experienceId":parseInt(experience.expId),
			"createdBy":dataFactory.getLoggedInUser().mail
            }
            console.log("calling dataFactory.provisionExperiences");
            var provisionExperiences = dataFactory.provisionExperiences(body);
            provisionExperiences.success(function (response) {
                    console.log("/******* response *******/", response);//need work
                 
                    $scope.showStatusColumn = true;
                    console.log("provisionExperiences post data", response);
			/*	
					var tempcartExperiences = JSON.parse( JSON.stringify($scope.cartExperiences));
				for (var i = 0; i < $scope.cartExperiences.length; i++){
				if ($scope.cartExperiences[i].expId == body.experienceId) {
					tempcartExperiences.splice(i, 1); 
					dataFactory.setSelectedExperiences(tempcartExperiences);					
				   } 
				}
				$scope.cartExperiences=tempcartExperiences;
				*/
                    dataFactory.deleteExperienceFromCart(experience.cartItemId);
                    $scope.showSuccess = true;
                    setTimeout(function () {
                        $scope.showSuccess = false;
                    }, 3000);
                $state.go('provisionStatus');
                    //fetchSandboxStatus(dataFactory.getOrgId());
                  
                }).error(function (error) {
					$scope.isConnectionError=true;
                 dataFactory.deleteExperienceFromCart(experience.cartItemId)
                 .success( function( response ){
                    console.log(" success deleting cart on experience error:-",response);
                 })
                 .error( function ( error ) {
                      console.log(" error deleting cart on experience error:-",error);
                 
                 });
                    console.log("error provisioned apps By ExpId !!!",error);
                });

        });//end of forEach
         
        $scope.companyCartExperiences = [];
        $scope.selectedExperiences = [];
        dataFactory.setSelectedExperiences([]);
    }
   /* var statusFetchCount = 0;
    var fetchSandboxStatus = function (orgId) {
        console.log("");
         if(dataFactory.getCurrentState() != "yoursandbox")
         {
             return;
         }
        */
       /* console.log("called fetchSandboxStatus times :-", ++statusFetchCount);

        dataFactory.getSandboxStatus(orgId)
            .success(function (response) {

                var inProgressCheck = false;
                /*if(response.length == 0)
                { 
                     setTimeout(function() {  fetchSandboxStatus( orgId ) }, 1000);
                }*/
               /* response.forEach(function (exp, index, array) {
                    if (exp.status == "IN-PROGRESS")
                        inProgressCheck = true;
                    console.log("checking for exp:", exp);
                    $scope.companyCartExperiences.forEach(function (cartExp) {

                        if (exp.id == cartExp.experienceId) {
                            console.log("found obj:", cartExp);
                            cartExp.provisionStatus = exp.status;

                            return;
                        }

                    });

                });
                // $scope.$apply();
                console.log("scope.companyCartExperiences finished", $scope.companyCartExperiences);

                console.log("dataFactory.getSandboxStatus", response);

                if (inProgressCheck) {

                    setTimeout(function () {
                        fetchSandboxStatus(orgId)
                    }, 5000);

                }

            })
            .error(function (error) {
			$scope.isConnectionError=true;
            });

    };*/

    $scope.showsandbox = function () {
        $scope.isShowCompanySearchSection = false;
        $scope.isShowAddUserExperienceSection = false;
        $scope.isShowAddedUsersExperiencesSection = true;
    }

    $scope.onCompanyChange = function () {
        var c = $scope.company.toLowerCase();
        $scope.companies.forEach(function (company) {
            if (company.name.toLowerCase() == c) {
                $scope.foundCompany = true;
                return;
            }
        });
    };

    var typeaheadCode = function () {

        var substringMatcher = function (strs) {
            return function findMatches(q, cb) {
                var matches, substringRegex;

                // an array that will be populated with substring matches
                matches = [];

                // regex used to determine if a string contains the substring `q`
                substrRegex = new RegExp(q, 'i');

                // iterate through the pool of strings and for any string that
                // contains the substring `q`, add it to the `matches` array
                $.each(strs, function (i, str) {
                    if (substrRegex.test(str)) {
                        matches.push(str);
                    }
                });

                cb(matches);
            };
        };

        $('.typeahead').typeahead({
            hint: true,
            highlight: true,
            minLength: 1
        }, {
            name: 'companies',
            source: substringMatcher(companies)
        });
    };
    //provisoned experineces
    $scope.getProvisionedExperience = function () {
        console.log("/*****calling getprovisioned experiences****/");
        
        $scope.IOSfilename = [];
        
        $scope.IOSStringFilename;
        $scope.expName = [];
        var getProvisionedExperiences = dataFactory.getProvisionedExperiences();
        getProvisionedExperiences.success(function (response) {
            console.log("/********** In Success OF     provisioned experiences     ******/", response);
            var provisionedDetail = response;
            var provisionedAppMap = {};
            for (var i = 0; i < provisionedDetail.length; i++) {
                var j = i;

                console.log("calling getExperienceDetailById for Id:- ",provisionedDetail[j].experienceId);
                var experiences = dataFactory.getExperienceDetailById(provisionedDetail[j].experienceId);
                experiences.success(function (response) {
//this is exp obj
                    console.log("/******exp in provision array****/","provisionedDetail[j]",provisionedDetail[j]);
                    console.log("/***** exp response from get exp by id**********/", response);
                    
                                   
                    provisionedAppMap[response.experienceId] = response.applications;
                   // provisionedAppMap[response.experienceId] = "";
                    /*provisionedAppMap[response.experienceId].forEach( function( app ,index ,array){
                        if(index == 0)
                            var appsInString = "";
                        
                        if( app.type == "ANDROID" || app.type == "IOS")
                        {
                             appsInString = appsInString+app.name
                        }
                        
                        if( index == (array.length-1))
                            provisionedAppMap[response.experienceId] = appsInString
                    
                    });
                    */
                     response.webAppOffered = false;    
                    
                    console.log("/*******provisionedAppMap*****/", response.experienceId, provisionedAppMap[response.experienceId]);
                    angular.forEach(response.applications, function (application) {
                        console.log("/***************in application*************/");
                        var provisioned = {
                            "ExpName": "",
                            "mobileAppNames": "",
                            "webAppsNames": ""

                        }
                        
                        console.log("application.type$$$$$", application.type);
                        if (application.type == "ANDROID" || application.type == "IOS") {
                                $scope.androidfilename = [];
                                $scope.androidstringFilename;
                            $scope.androidfilename.push(application.name);
                           
                            console.log("/*********  $scope.androidfilename   ******/", $scope.androidfilename);
                            $scope.androidstringFilename = $scope.androidfilename.join(", ");
                             response.androidstringFilename = $scope.androidstringFilename;
                            console.log("/********  $scope.androidstringFilename ******/", $scope.androidstringFilename);

                        } else if (application.type == "WEBAPP") {

                            
                            response.webAppOffered = true;
							response.weburl=application.url;
							
						/*	
                                $scope.webfilename = [];
                                $scope.webstringFilename;
								$scope.url="http://10.52.64.4:8080/docs"
								//$scope.webAppname=application.name;
							
                            $scope.webfilename.push(application.name);
                           
                            console.log("  $scope.webfilename   ", $scope.webfilename);
                            $scope.webstringFilename = $scope.webfilename.join(", ");
							var webApp={"showtext":$scope.text,
							"Url":$scope.url
							
							}
							
                             response.weburl = webApp;
							 
                            console.log("  $scope.webstringFilename ", webApp);                            
                            
                           */ 
                            
                            
                            
                            
                            
                            
                            
                            
                            
                        }
                        console.log("expname!!!!!!!!!!!!!!", $scope.expName);
                    });//end forEach
                    response.logo = expMap [ response.experienceId ].logo;
/*                    alert(JSON.stringify(response));
                    response.forEach(function( exp ){
                        exp.logo = expMap [ exp.experienceId ];
                    });*/
                    $scope.expName.push(response);
                }).error(function (err) {
				 $scope.isConnectionError=true;
                    console.log("error in fetching Experiences By id");
                });
                
            }//end for

        }).error(function (err) {
			 //$scope.isConnectionError=true;
            console.log("error getProvisionedExperiences By OrgId !!!", err);
        })

    }
    $scope.getProvisionedExperience();

}]);