(function(){

angular
    .module('experienceApp.provisionStatusController', [])
    .controller('provisionStatusController', provisionStatusController);

provisionStatusController.$injector = ['$scope', '$rootScope', 'dataFactory', '$state', '$timeout'];

function provisionStatusController($scope, $rootScope, dataFactory, $state, $timeout) {
    
	dataFactory.setCurrentState('provisionStatus');
	$scope.expMap = {};
	$scope.webAppMap = {};
	$scope.experienceDocsMap = [];
	$scope.fetchingWebApps = true;
    
	var allExperiences = dataFactory.getExperiences();
	var appMap = dataFactory.appMap();
    
	var callErrorHandler = function (method, apiResponse, postApiDataSent) {
		errorObj = {
			controller: "provisionStatusController",
			method: method,
			postApiDataSent: postApiDataSent,
			apiResponse: apiResponse
		}
		$rootScope.handleErrors(errorObj);
	};
    
	if (appMap.success || appMap.error) {
		appMap.success(function (response) {
			dataFactory.appMap(response);
			$scope.webAppMap = dataFactory.appMap();
			$scope.fetchingWebApps = false;
			console.log("dataFactory.appMap()", dataFactory.appMap());
		}).error(function (error) {
			callErrorHandler("fetchAppMap", error, "webapps fetch failure");
            $scope.fetchingWebApps = false;
		});
	} else {
		$scope.webAppMap = appMap;
		$scope.fetchingWebApps = false;
	};

	var fetchSandboxStatus = function (orgId) {
        
		if (dataFactory.getCurrentState() != 'provisionStatus') {
			return;
		};
        
		dataFactory.getSandboxStatus(orgId).success(function (response) {
			console.log("response", response);
			var rMap = {};
			if (!$scope.provisionedExperiences || ($scope.provisionedExperiences.length != response.length)) {
				$scope.provisionedExperiences = response;
				for(var i=0;i<$scope.provisionedExperiences.length;i++)
				{
					for(var j=0;j<$scope.provisionedExperiences[i].appsAttributes.length;j++)
					{
						for(var k=0;k<$scope.provisionedExperiences[i].appLinks.length;k++)
						{
							if($scope.provisionedExperiences[i].appsAttributes[j].appId==$scope.provisionedExperiences[i].appLinks[j].appId)
							{
								if($scope.provisionedExperiences[i].appsAttributes[j].attributes.length>1)
								{
								$scope.provisionedExperiences[i].appLinks[j].userName=$scope.provisionedExperiences[i].appsAttributes[j].attributes[0].attributeValue;
								$scope.provisionedExperiences[i].appLinks[j].password=$scope.provisionedExperiences[i].appsAttributes[j].attributes[1].attributeValue;
								}
								else
								{
								$scope.provisionedExperiences[i].appLinks[j].userName="No username";
								$scope.provisionedExperiences[i].appLinks[j].password=$scope.provisionedExperiences[i].appsAttributes[j].attributes[0].attributeValue;
								}
								break;
							}
						}
					}	
				}
				fetchDocs($scope.provisionedExperiences);
			} else {
				response.forEach(function (r) {
					rMap[r.experienceId] = r;
				});
				$scope.provisionedExperiences.forEach(function (pExp) {
					pExp.status = rMap[pExp.experienceId].status;
				});
			}

            setTimeout(function () {
				fetchSandboxStatus(dataFactory.getOrgId());
			}, 3000);
		}).error(function (error) {
			callErrorHandler("fetchSandboxStatus", error, "error fetching sandbox status orgId:-" + orgId);
			$scope.isConnectionError = true;
		});
        
	};
    
	var init = function () {
		if (allExperiences.success) {
			allExperiences.success(function (response) {
				dataFactory.setExperiences(response);
				$scope.expMap = dataFactory.experiencesMap();
				fetchSandboxStatus(dataFactory.getOrgId());
			}).error(function (error) {
				callErrorHandler("init", error, "error fetching exps");
			});
		} else {
			$scope.expMap = dataFactory.experiencesMap();
			fetchSandboxStatus(dataFactory.getOrgId());
		}
	};
    
	var fetchDocs = function (provisionedExperiences) {
		provisionedExperiences.forEach(function (pExp) {
			fetchDocuments(pExp);
		});
	};
	var fetchDocuments = function (experienceObj) {
		experienceObj.docStatus = "fetching.."
		var docRes = dataFactory.getDocMap(experienceObj.experienceId);
		if (docRes.success || docRes.error) {
			docRes.success(function (response) {
				var documents = {
					"NoDocAvailable": true
				};
				if (!(response.errorCode == "E00012")) {
					documents = response;
					addDoc(documents, experienceObj);
				} else {
					experienceObj.docStatus = "NA";
				}
				dataFactory.addToDocMap(experienceObj.experienceId, documents);
			}).error(function (error) {
				experienceObj.docStatus = "NA";
				console.log("error experience documents", error);
				$scope.fetchingDocs = false;
				callErrorHandler("fetchDocuments", error, "error fetching experience documents")
			});
		} else {
			if ((!docRes) || (docRes.NoDocAvailable) || (docRes.length == 0)) experienceObj.docStatus = "NA";
			else addDoc(docRes, experienceObj);
		}
	};
    
	var addDoc = function (docs, experienceObj) {
		var experienceDocs = [];
		var appsDocs = [];
		var servicesDocs = [];
		docs.forEach(function (doc) {
			if (doc.appId) 
                appsDocs.push(doc);
			else if (doc.serviceId) 
                servicesDocs.push(doc)
			else 
                experienceDocs.push(doc);
		});
		if (experienceDocs.length == 0) 
            experienceObj.docStatus = "NA";
		$scope.experienceDocsMap[experienceObj.experienceId] = experienceDocs;
	};
    
	$scope.onBackClick = function () {
		var state = dataFactory.previousState();
		if (!state) 
            state = "home";
		$state.go(state);
	}
    
	init();
}
    
})();