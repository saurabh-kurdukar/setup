
(function(PERSISTENT_COMPANTY_ID){

angular
.module('experienceApp.yoursandboxController', ['ngAnimate', 'ui.bootstrap'])
.controller('YourSandboxController', YourSandboxController)
.controller('addUserModelController', addUserModelController);
/* .controller('userConfirmController', userConfirmController);
 */
addUserModelController.$injector = ['$scope', '$uibModalInstance', '$uibModal', 'dataFactory','$rootScope'];
YourSandboxController.$injector = ['$scope', '$rootScope', 'dataFactory', '$state', '$timeout', '$uibModal'];



function YourSandboxController($scope, $rootScope, dataFactory, $state, $timeout, $uibModal) {

	dataFactory.setCurrentState("yoursandbox");
    dataFactory.hiddenNavbarFooter(false);
	
	//non-binded variables
		var user = dataFactory.getLoggedInUser();
		var persistentId = PERSISTENT_COMPANTY_ID;
		var userStatus = JSON.parse(localStorage.getItem('userStatus'));
        var experiencesFetched = false; //true if all experiences have been fetched
        var allCartExperiences = []//stroes a copy of all cart Experiences
		var deprovisionMap = {};
		var cartArray = [];
		var cartMap = {};
		var errorObj = {};		
		var filterData = {  
			"deviceSupported":[],
			"domains":[],
			"classification":[],
			"platforms":[]
		}		
		
		
	
	//binded variables
		$scope.isLoggedIn = dataFactory.getLoginStatus();
		$scope.users = [];
		$scope.disableDeprovisionButton = true;
		$scope.disableProvisionButton = true;
		$scope.disableDeprovisionCheckboxes = false;
		$scope.disableProvisionCheckboxes = false;	
		$scope.webAppsMap = [];
		$scope.devices = [{name : "Mobile"}, {name : "Tablet"}, {name : "Desktop"}, {name : "Wearable"}];
		$scope.platforms = [{name : "Android"}, {name : "Windows"}, {name : "IOS"}, {name : "Web App"}];
		$scope.classifications = [{name : "Employee"}, {name : "Product"}, {name : "Customer"}, {name : "Partner"}, {name : "Topline"}, {name : "Productivity"}, {name : "Bottomline"}, {name : "Satisfaction"}];
		$scope.disableFilters = false;		
		$rootScope.isSuperUser =  userStatus.isSuperUser;
		$rootScope.isAdmin = userStatus.isAdmin;
		$rootScope.isUser = userStatus.isUser;	
    
		function showFilter() {
			 if(user && user.companyId)
				return user.companyId == persistentId;
		 }		
	//binded functions
		$scope.showFilter = showFilter;	
        $scope.onExpInit = onExpInit;
        $scope.provision = provision;
        $scope.addRemoveCartAdmin = addRemoveCartAdmin;
        $scope.addRemoveDeprovision = addRemoveDeprovision;
        $scope.deProvision = deProvision;
        $scope.addUserPopup = addUserPopup;
        $scope.goToExpDetails = goToExpDetails;
    //filter functions
        $scope.onDomainSelect = onDomainSelect;
        $scope.onDeviceSelect = onDeviceSelect;
        $scope.onPlatformSelect = onPlatformSelect;
        $scope.onClassificationSelect = onClassificationSelect;   
		
	function init(){
		getDomains(true);
		getExperiences(true);
		getCartExperiences(true);
		getProvisionedExperiences();
		getWebApps();
        getCompanyUsers();
		//initialize filter here
	}
	init();
	
	function callErrorHandler (method, apiResponse, postApiDataSent) {
		errorObj = {
			controller: "expDetailsController",
			method: method,
			postApiDataSent: postApiDataSent,
			apiResponse: apiResponse
		}
		$rootScope.handleErrors(errorObj);
	};	
	
	function onExpInit(experience) {
		//populateDeviceFlags(experience);
	}
	
	function getDomains(showLoading){
		
		dataFactory.getDomainsV2(showLoading)
		.then(domainSuccess)
		.catch(domainFailure);			
		
		function domainSuccess(response) {
			$scope.domains = response;
		}					
		
		function domainFailure(error) {
			callErrorHandler("getDomains", error, "error fetching domains")
		}			
	};
	
	function getCartExperiences(showLoading){

		//first arguments to true forces fetching data from api
		dataFactory.getExperienceFromCartByOrgIdV2(true, showLoading)
		.then(cartSuccess)
		.catch(cartFailure);
		
		function cartSuccess(response) {
            if(experiencesFetched)
            {
                allCartExperiences = JSON.parse(JSON.stringify(response));
                $scope.companyCartExperiences = response;
                insertDeviceFlags();
                //$scope.$apply();
            }
            else
            {
                $timeout(function(){
                    cartSuccess(response);
                },800);
            }
		}					
		
		function cartFailure(error) {
			callErrorHandler("getCartExperiences", error, "error fetching Cart Experiences");
		}
		
	};
	
	function getProvisionedExperiences( showLoading ){

		dataFactory.getProvisionedExperiencesV2( showLoading )
			.then(provExpSuccess)
			.catch(provExpFailure);
			
		function provExpSuccess(response) {
			$scope.provisionedExperiences = response;
		}					
		
		function provExpFailure(error) {
			callErrorHandler("getProvisionedExperiences", error, "error fetching Provisioned Experiences");
		}
		
	};
	
	function getWebApps(){
        var appMap = dataFactory.appMap();
		if (appMap.success || appMap.error) {
			appMap.success(function (response) {
                webAppMapSuccess(response);
			}).error(function (error) {
                webAppMapFailure(error);
			});
		} else {
			$scope.webAppsMap = appMap;
		};
        
        
        function webAppMapSuccess(response){
            	dataFactory.appMap(response);
				$scope.webAppsMap = dataFactory.appMap();
        }
        
        function webAppMapFailure(error){
            callErrorHandler("getWebApps", error, "error fetching appMap");            
        }  	
	}
	
	function getExperiences( showLoading ){

		dataFactory.getExperiencesV2( showLoading )
			.then(expSuccess)
			.catch(expFailure);
			
		function expSuccess(response) {
			dataFactory.setExperiences(response);
			$scope.expMap = dataFactory.experiencesMap();	
            experiencesFetched = true;
			//allExperiences = JSON.parse(JSON.stringify(response));        
			//$scope.experiences = response;
			
			
		}					
		
		function expFailure(error) {
			callErrorHandler("getExperiences", error, "error fetching Experiences");
		}
		
	};
    
    function getCompanyUsers(){

        var companyId = dataFactory.extractOrgId(dataFactory.getLoggedInUser(), true); //gets reference company id for persistent users and companyId for non persistent users

       	  
		dataFactory.getCompanyUsersV2( companyId )
		.then(getUsersSuccess)
        .catch(getUsersError) ; 

	
        function getUsersSuccess(response) {
                $scope.users = response;
        }

        function getUsersError(error) {
            console.log("getUsersError",error);
            /* if((error.httpResponseCode=="500" || errorObj.httpResponseCode==500)&&(error.errorMessage!="Invalid company id")){
            callErrorHandler("error", error, "");} */
        }
        
    }
	
	function removeFromCart(cartItemId) {
        var cartItemId = cartItemId;
		dataFactory.deleteExperienceFromCartV2( cartItemId, false, true)
		.then(cartRemoveSuccess)
		.catch(cartRemoveFailure);
		
		function cartRemoveSuccess(response){
       			
		}
		function cartRemoveFailure(error){
            //experience.isSelected = true;                        
			callErrorHandler("removeFromCart", error, experience);
		}		
	}
	
	//add remove from cart for admin
	function addRemoveCartAdmin  (isSelected, experience) {
		experience.isDisabled = true;
		for(var i = 0;i< cartArray.length;i++){
			if (cartArray[i].expId == experience.expId) {
				console.log("in if of add remove");
				cartArray.splice(i,1);
				if (cartArray.length <= 0) 
					$scope.disableProvisionButton = true;
				experience.isSelected = false;
				console.log("cartArray",cartArray);
				return;
			} 
		}
		
		experience.isSelected = true;
		$scope.disableProvisionButton = false;
		cartArray[i] = experience;
		/* experience.isDisabled = false; */
		console.log("cartArray",cartArray);
		
	};



    function provision () {
		dataFactory.showLoading(true);
		//var cartExperiences = dataFactory.getExperienceFromCartByOrgId();
		var cartExperiences = cartArray;
		console.log("cartExperiences", cartExperiences);
		cartExperiences.forEach(function (exp) {
			exp.androidAppOffered = $scope.expMap[exp.expId].androidAppOffered;
			exp.iOSAppOffered = $scope.expMap[exp.expId].iOSAppOffered;
		});
		var len = 0;
		if (cartExperiences) {
			len = cartExperiences.length;
		}
		if (len > 1) {
			if ((cartExperiences[len - 1].androidAppOffered == "true") || (cartExperiences[len - 1].iOSAppOffered == "true")) {} else {
				for (var x = 0; x < (len - 1); x++) {
					if ((cartExperiences[x].androidAppOffered == "true") || (cartExperiences[x].iOSAppOffered == "true")) {
						var temp = cartExperiences[len - 1];
						cartExperiences[len - 1] = cartExperiences[x];
						cartExperiences[x] = temp;
						break;
					}
				}
			}
		}
		var provisionTimeOutCount = 0;
		var initateProvision = function (len) {
			var tOut = 5;
			if (provisionTimeOutCount == 1) {
				tOut = provisionongApiInterval;
			}
			setTimeout(function () {
				provisionTimeOutCount++;
				--len;
				provisionExperience(cartExperiences[len], len);
				if (len != 0) {
					initateProvision(len);
				}
			}, tOut);
		};
		initateProvision(len);
	}
	var provisionExperience = function (experience, len) {
		var body = {
			"orgId": dataFactory.getOrgId(),
			"experienceId": parseInt(experience.expId),
			"createdBy": dataFactory.getLoggedInUser().mail
		}
		var provisionExperiences = dataFactory.provisionExperiences(body, true);
		
		provisionExperiences.success(function (response) {
			onProvisionSuccess(response);
		}).error(function (error) {
			onProvisionFailure(error);
		});
		
		function onProvisionSuccess(response){
			console.log("provision success");
			removeFromCart(experience.cartItemId);
			if (len == 0) {
				dataFactory.previousState(dataFactory.getCurrentState());
				dataFactory.showLoading(false);
				$state.go('provisionStatus');
			}		
		}
		
		function onProvisionFailure(error){
			$scope.isConnectionError = true;
			callErrorHandler("$scope.provision", error, body);
			removeFromCart(experience.cartItemId);
			//deleteFromCart(experience.expId, experience.cartItemId);
			if (len == 0) {
				dataFactory.showLoading(false);
			}
		}
	};
	
	function addRemoveDeprovision (experience) {
		experience.isDisabled = true;
		if (deprovisionMap[experience.experienceId]){
			delete deprovisionMap[experience.experienceId];
			if (Object.keys(deprovisionMap).length <= 0) 
				$scope.disableDeprovisionButton = true;
			experience.isSelected = false;
		} else {
			experience.isSelected = true;
			$scope.disableDeprovisionButton = false;
			deprovisionMap[experience.experienceId] = experience["_id"];
		}
		experience.isDisabled = false;
	};
	
	function deProvision() {
		$scope.disableDeprovisionButton = true;
		$scope.disableDeprovisionCheckboxes = true;
		var keys = Object.keys(deprovisionMap);
		var len = keys.length;
		if (len > 0) {
			dataFactory.showLoading(true);
			var initateDeprovision = function (len) {
				setTimeout(function () {
					--len;
					deProvisionExperience(keys[len], len);
					if (len != 0) {
						initateDeprovision(len);
					}
				}, provisionongApiInterval);
			}
			initateDeprovision(len);
		} else {
			$scope.disableDeprovisionButton = false;
			$scope.disableDeprovisionCheckboxes = false;
		}
	};
	
	var deProvisionExperience = function (expId, len) {
		dataFactory.deProvisionExperiences(deprovisionMap[expId], true).success(function (response) {
			console.log("provisioned successfuly", response);
			$scope.provisionedExperiences.forEach(function (pExp, index) {
				if (expId == pExp.experienceId) {
					$scope.provisionedExperiences.splice(index, 1);
					delete deprovisionMap[expId];
					return;
				}
			});
            
			if (len <= 0) {

				dataFactory.previousState(dataFactory.getCurrentState());
				dataFactory.showLoading(false);
				$state.go("provisionStatus");
			}
		}).error(function (error) {
			console.log("error deprovisioning ", error);
			callErrorHandler("$scope.deProvision", error, "error deprovisioning experience with id:-" + expId);
			if (len <= 0) {
				dataFactory.previousState(dataFactory.getCurrentState());
				dataFactory.showLoading(false);
				$state.go("provisionStatus");
			}
		});
	};	
    
	function addUserPopup(){
		var modalInstance = $uibModal.open({
          templateUrl: 'addUsers.html',
                  controller: addUserModelController,
				  scope : $scope,
          windowClass: 'md-Modal'
          });

        modalInstance.result.then(function () {      }
         , function () {      }
         );
	}    
    
    function insertDeviceFlags(){
        $scope.companyCartExperiences.forEach(function(cartItem){
            populateDeviceFlags(cartItem);
        });
    }

     function populateDeviceFlags (cartExp) {

         var experience = $scope.expMap[cartExp.expId];
         cartExp.androidAppOffered = stringToBool(experience.androidAppOffered);
         cartExp.webAppOffered = stringToBool(experience.webAppOffered);
         cartExp.iOSAppOffered = stringToBool(experience.iOSAppOffered);
         cartExp.wearableOffered = stringToBool(experience.wearableOffered);
         
        if (experience.deviceSupported && experience.deviceSupported.length > 0) 
        { 
            if ( experience.deviceSupported.indexOf("Both iPhone and iPad") != -1 ) {
                    cartExp.iphoneCompitable = true;
                    cartExp.ipadCompitable = true;
                } 
            else if ( experience.deviceSupported.indexOf("iPhone Only") != -1 ) {
                    cartExp.iphoneCompitable = true;
                    cartExp.ipadCompitable = false;
                } 
            else if ( experience.deviceSupported.indexOf("iPad Only") != -1 ) {
                    cartExp.ipadCompitable = true;
                    cartExp.iphoneCompitable = false;
                }            
/*            experience.deviceSupported.forEach(function (device){           
                if (device == "Both iPhone and iPad") {
                    cartExp.iphoneCompitable = true;
                    cartExp.ipadCompitable = true;
                } else if (device == "iPhone Only") {
                    cartExp.iphoneCompitable = true;
                    cartExp.ipadCompitable = false;
                } else if (device == "iPad Only") {
                    cartExp.ipadCompitable = true;
                    cartExp.iphoneCompitable = false;
                }
            });*/
        }

     };
		
    function stringToBool( str ){
        if(!str)
        {
            return false;
        }
        if(typeof str == "boolean")
            return str;
        if(  str.toLowerCase() == "true" )
            return true;
        return false;
    }
    
    
 //filter functions
        
    function onDomainSelect(domain, isSelected) {
        if(isSelected)
            filterData.domains.push(domain.name);
        else
        {
            filterData.domains.forEach(function(d, index){
                if( domain.name == d )
                {
                    filterData.domains.splice(index, 1);
                    return;
                }
            });
        }
        filterExperiences(filterData);
    };
    
    function onDeviceSelect(device, isSelected) {
        
        var deviceName = device.name.toUpperCase().split(' ').join('');
        if(isSelected)
            filterData.deviceSupported.push(deviceName);
        else
        {
            filterData.deviceSupported.forEach(function(d, index){
                if(d == deviceName)
                {
                    filterData.deviceSupported.splice(index, 1);
                    return;
                }
            });
        }
        filterExperiences(filterData);       
    };
    
    function onPlatformSelect(platform, isSelected) {
        
        var platformName = platform.name.toUpperCase().split(' ').join('');
        if(isSelected)
            filterData.platforms.push(platformName);
        else
        {
            filterData.platforms.forEach(function(p, index){
                if(p == platformName)
                {
                    filterData.platforms.splice(index, 1);
                    return;
                }
            });
        }
        filterExperiences(filterData);           
    };
    
    function onClassificationSelect (classification, isSelected) {
        if(isSelected)
            filterData.classification.push(classification.name);
        else
        {
            filterData.classification.forEach(function(c, index){
                if(c == classification.name)
                {
                    filterData.classification.splice(index, 1);
                    return;
                }
            });
        }
        filterExperiences(filterData);     
    };
    
    function filterExperiences(filterData)
    {
        $scope.disableFilters = true;
        var data = JSON.parse(JSON.stringify(filterData));

  /*      if(data.deviceSupported.length == 0)//to be enebled when filter called from api
            delete data.deviceSupported;
        if(data.domains.length == 0)
            delete data.domains;
        if(data.classification.length == 0)
            delete data.classification;
        if(data.platforms.length == 0)
            delete data.platforms;*/
        var deviceSupported = data.deviceSupported;
        var domains = data.domains;
        var classification = data.classification;
        var platforms = data.platforms;
        
        var filteredData = [];
        var keys = Object.keys(data);
        var cartExperiences = JSON.parse(JSON.stringify(allCartExperiences));
        var experiences = [];
        
        cartExperiences.forEach(function(cartItem){
            experiences.push( $scope.expMap[ cartItem.expId ] );
        });

        if( deviceSupported.length > 0)
        {        
            for(var i=0; i<experiences.length; i++) {
                    var devices = experiences[i].deviceSupported;
                    for(var j=0; j<devices.length; j++)
                        for(var k=0; k< deviceSupported.length; k++)
                        {
                            if( devices[j] ==  deviceSupported[k] )
                            {
                                filteredData.push(experiences[i]);
                                j = 5000;
                                break;
                            }
                        }
            }
        }
        
        if( deviceSupported.length > 0)
        {
            experiences = filteredData;
            filteredData = [];
        }
            
        if( domains.length > 0)
        {
           for(var i=0; i<experiences.length; i++) {                
                var domain = experiences[i].domain;
                for(var j=0; j< domains.length; j++)
                {
                        if( domain ==  domains[j] )
                        {
                            filteredData.push(experiences[i]);
                            break;
                        }
                }
            }
        }
        
        if( domains.length > 0)
        {
            experiences = filteredData;
            filteredData = []; 
        } 
        
        if( platforms.length > 0)
        {
            var iOSAppOffered = false;
            var androidAppOffered = false;
            var windowsAppOffered = false;
            var webAppOffered = false;
            
            platforms.forEach(function(platform){
                if(platform ==  "ANDROID")
                    androidAppOffered = true;
                if(platform ==  "IOS")
                    iOSAppOffered = true;
                if(platform ==  "WINDOWS")
                    windowsAppOffered = true;
                if(platform ==  "WEBAPP")
                    webAppOffered = true;
            });    
        
            for(var i=0; i<experiences.length; i++) {
                
                var found = false;
                if( androidAppOffered && stringToBool(experiences[i].androidAppOffered) )
                    found = true;
                else if( iOSAppOffered && stringToBool(experiences[i].iOSAppOffered) )
                    found = true;
                else if( windowsAppOffered && stringToBool(experiences[i].windowsAppOffered) )
                    found = true;
                else if( webAppOffered && stringToBool(experiences[i].webAppOffered) )
                    found = true;

                if(found)
                    filteredData.push(experiences[i]);
            }
        }
        
        if( platforms.length > 0)
        {
            experiences = filteredData;
            filteredData = [];            
        }        
            
        if( classification.length > 0)
        {
            for(var i=0; i<experiences.length; i++) {
                var classifications = experiences[i].classification;
                for(var j=0; j<classifications.length; j++)
                    for(var k=0; k< classification.length; k++)
                    {
                        if( classifications[j] ==  classification[k] )
                        {
                            filteredData.push(experiences[i]);
                            j = 5000;
                            break;
                        }
                    }
            }    
        }
        
        if( classification.length > 0)
        {
            experiences = filteredData;
            filteredData = []; 
        }
                   
        
        console.log("filteredData", experiences);
        var temp = [];
        cartExperiences.forEach(function(cartExp){
            for(var i=0; i<experiences.length; i++)
            {
                if(experiences[i].id == cartExp.expId)
                {
                    temp.push(cartExp);
                    experiences.splice(i, 1);
                    break;
                }
            }
                
        });
        $scope.companyCartExperiences = temp;
        insertDeviceFlags();
        $scope.disableFilters = false;
        
    }        
    //end filter functions
    
    
        
    function goToExpDetails(exp) {
        dataFactory.setSelectedDomain($scope.selectedDomain);
        dataFactory.setSelectedDomainIndex($scope.selectedDomainIndex);
        dataFactory.setSelectedExperience(exp);
        dataFactory.previousState(dataFactory.getCurrentState());
        $state.go('expDetails');
    }

      $scope.isHealthCareSandBox=false;
	// by Nisar
	if(isHealthCareSandBox){
	 var companyId = dataFactory.extractOrgId(dataFactory.getLoggedInUser(), false);
	 dataFactory.fetchCompanybyIdV2(companyId)
                    .then(companyFetchSuccess)
                    .catch(companyFetchFailure);
	        function companyFetchSuccess(response)
				{
				  if(response.companyAddress && response.companyAddress=='healthCareBox')
				  {
				  console.log("got healthCareBox");
				  $scope.isHealthCareSandBox=true;
				  }
				  else{
				  $scope.isHealthCareSandBox=false;
				  }
                 
				}
				function companyFetchFailure(error)
				{
				  console.log("error in get company");
				}
	    }
       $scope.componentDetailslist=[{
	'name': 'OpenEMR',
	'imageUrl': 'http://demo-vega.cloudapp.net/files/file_1468327442646.jpg',
	'url': 'http://vegahcare.cloudapp.net/openemr/interface/login/login_frame.php?site=default'
},{
	'name': 'OpenEMPI',
	'imageUrl': 'http://demo-vega.cloudapp.net/files/file_1468327466859.jpg',
	'url': 'http://vegahcare.cloudapp.net:8080/openempi-entity-webapp-web-3.1.0'
},
{
	'name': 'Connect Gateway',
	'imageUrl': 'http://demo-vega.cloudapp.net/files/file_1468491198180.PNG',
	'url': 'http://vegahcare.cloudapp.net:8080/CONNECTUniversalClientGUI/faces/Page2.jsp'
},
{
	'name': 'Data lake',
	'imageUrl': 'http://demo-vega.cloudapp.net/files/file_1468483908376.png',
	'url': 'http://10.46.34.35:8080/'
},
{
	'name': 'Mirth Connect',
	'imageUrl': 'http://demo-vega.cloudapp.net/files/file_1468327485397.png',
	'url': 'https://vegamirth.cloudapp.net/'
}]; 
$scope.datasetDetailslist=[{
	'name': 'HL7 v2',
	'imageUrl': 'http://demo-vega.cloudapp.net/files/file_1468484126106.jpg',
	'url': 'http://10.46.34.35:8080/#/main/views/ZEPPELIN/1.0.0/INSTANCE_1'
},{
	'name': 'FHIR',
	'imageUrl': 'http://demo-vega.cloudapp.net/files/file_1468484126106.jpg',
	'url': 'http://10.46.34.35:8080/#/main/views/ZEPPELIN/1.0.0/INSTANCE_1'
},
{
	'name': 'CCDA',
	'imageUrl': 'http://demo-vega.cloudapp.net/files/file_1468484126106.jpg',
	'url': 'http://10.46.34.35:8080/#/main/views/ZEPPELIN/1.0.0/INSTANCE_1'
},
{
	'name': 'Claims',
	'imageUrl': 'http://demo-vega.cloudapp.net/files/file_1468484126106.jpg',
	'url': 'http://10.46.34.35:8080/#/main/views/ZEPPELIN/1.0.0/INSTANCE_1'
}];	
	


}

  
    function addUserModelController ($scope, $uibModalInstance, $uibModal, dataFactory, $rootScope){
		var callErrorHandler = function (method, apiResponse, postApiDataSent) {
		errorObj = {
			controller: "addUserModelController",
			method: method,
			postApiDataSent: postApiDataSent,
			apiResponse: apiResponse
		}
		$rootScope.handleErrors(errorObj);
	};
     //  $scope.users = dataFactory.getUsersForSandbox();
        var parent = $scope.$parent;
         var confirmModal;
        $scope.newUser = {"fullname" : "", "username" : "", isAdmin : false};        
        $scope.users = parent.users;
        $scope.removeUser = removeUser;
        $scope.editUser = editUser;
        /* $scope.confirmAdd = confirmAdd; */
        $scope.addUser = addUser;
        $scope.closePopUp = closePopUp;
        $scope.addUserResponse = addUserResponse;
        var parent = $scope.$parent;
        $scope.addUserResponse = parent.addUserResponse; 
        
        /* function confirmAdd() {
                confirmModal = $uibModal.open({
                templateUrl: 'confirm.html',
                controller: 'userConfirmController',
                scope : $scope
            });
        } */
        
        function closePopUp(reponse ) {
            console.log("closePopUp",response);
          };
        
        function addUserResponse(response){
            if(response)
                $scope.addUser();
            confirmModal.dismiss('cancel');
        }
        
        function closePopUp() {
            $uibModalInstance.dismiss('cancel');
          };
        
        function addUser( newUser ) {
            newUser = $scope.newUser;
           
            var companyId = dataFactory.getLoggedInUser().referenceCompanyId;
            
            if( (!newUser) || (!newUser.fullname) || (!newUser.username) || (!companyId) || (newUser.fullname == "") || ( newUser.username == "" ) )
            {
                return;
            }
            
            var nameSplit = newUser.fullname.split(" ");
            var firstname = "";
            var lastname = " ";//initialized with space
            
            if (nameSplit.length > 1)
            {
                lastname = nameSplit[nameSplit.length - 1];
                nameSplit.splice(nameSplit.length - 1, 1);
            }
            firstname = nameSplit.join(" ");
            
            
            var user =
            {
                "username": newUser.username,
                "type": "addUser",
                "firstname": firstname,
                "lastname": lastname
            }
            

            
            dataFactory.addCompanyUsersV2(companyId, user, true)
            .then(addCompnayUserSuccess)
            .catch(addCompanyUserFailure);
          };
        
        function removeUser(user, index) {
            $scope.users.splice(index, 1);
          };
        
        function editUser(user, index)
        {
            console.log("$scope.editUser", user);
            $scope.newUser = user;
            $scope.users.splice(index, 1);
        }
        
        function addCompnayUserSuccess(response) 
        {
            $scope.newUser = {"fullname" : "", "username" : "", isAdmin : false};      
            $scope.users.push(response);
        }
        
        function addCompanyUserFailure(error) 
        {
            console.log("adding company user failure:",error);
			if((error.httpResponseCode=="500" || errorObj.httpResponseCode==500)&&(error.errorMessage!="Invalid company id")){
			callErrorHandler("error", error, "");}
        }
    };     	
		
})(PERSISTENT_COMPANY_ID);
