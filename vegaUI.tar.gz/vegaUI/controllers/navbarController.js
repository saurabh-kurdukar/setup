(function(){

angular
    .module('experienceApp.navbarController', ['ngAnimate', 'ui.bootstrap'])
    .controller('navbarController', navbarController);

navbarController.$injector = ['$scope', '$rootScope', 'dataFactory', '$state', '$timeout','$uibModal','$localStorage','$http'];

function navbarController($scope, $rootScope, dataFactory, $state, $timeout,$uibModal,$localStorage,$http) {
	 $scope.userStatus = {};
	 $scope.userStatus.isUser = false;
	 $scope.userStatus.isAdmin = false;
	 $scope.userStatus.isSuperUser = false;
	 var userFlag=false;
	// console.log("userFlag",userFlag);
	 $scope.persistentName = PERSISTENT_COMPANY_NAME;
      $http.get('server/menu.json', {
            }).success(function(data) {
             $rootScope.menuItems=data;
            }).error(function(data) {
               console.log(data);
            });
    
	/*  if( (localStorage.getItem('userStatus') ))
	 {
         console.log("********localstorage",localStorage.getItem('userStatus'));
         userFlag=true;
         console.log("userFlag",userFlag);
	 }
	 else{
		 userFlag=false;
	 } */
	 /* else{
		 console.log("********************************** i m in setItem");
	 localStorage.setItem('userStatus', JSON.stringify($scope.userStatus));
	 userFlag=false;
	 console.log("userFlag",userFlag);
	 } */
	 
	 
	 
	  $scope.$watch(function() {
                return dataFactory.getLoginStatus();
            }, function(newValue, oldValue) {
				
				 if( (localStorage.getItem('userStatus') ))
	               {        
                   userFlag=true;   
	               }
	              else{
		             userFlag=false;
	                }
				
                $scope.loginStatus = newValue;
                $scope.loggedInUser = dataFactory.getLoggedInUser();
				
                if($scope.loggedInUser)
                {
                    dataFactory.fetchCompanybyIdV2($scope.loggedInUser.companyId)
                    .then(companyFetchSuccess)
                    .catch(companyFetchFailure);
                }
				
				function companyFetchSuccess(response)
				{
				  
				  if(response.companyName ==  $scope.persistentName)
				  {
				   $rootScope.currentCompany='Persistent Sandbox';
				  }
				  else
				  {
				   $rootScope.currentCompany=response.companyName;
				  }
                  
				}
				function companyFetchFailure(error)
				{
				  console.log("error");
				}
				
				
				
				if(userFlag){
					var userStatus =JSON.parse(localStorage.getItem('userStatus'));
					$scope.userStatus = userStatus;
                     if(userStatus&&userStatus.isUser)
					 {
						$rootScope.currentRole='User'; 
   					 }
					 else
					 if(userStatus&&userStatus.isAdmin)
					 {
						$rootScope.currentRole='Admin'; 
                         
					 }
					 else if(userStatus&&userStatus.isSuperUser)
					 {
					 $rootScope.currentRole='SuperAdmin';    
					 }
					 localStorage.setItem('currentRole',$rootScope.currentRole);
				}
                else if($scope.loginStatus){
					if(($scope.loggedInUser.userroles==undefined)||($scope.loggedInUser.userroles.length==0))
					{
					   $rootScope.currentRole = 'User';
                         localStorage.setItem('currentRole',$rootScope.currentRole);
					   //console.log("$rootScope.currentRole**************",$rootScope.currentRole);
					}else{
					var hierarchy=0;
					for(var ij=0;ij<$scope.loggedInUser.userroles.length;ij++)
					{
					 if(hierarchy<$scope.loggedInUser.userroles[ij].hierarchy)
						{
						hierarchy=$scope.loggedInUser.userroles[ij].hierarchy;
						 $rootScope.currentRole = $scope.loggedInUser.userroles[ij].roleName;
						}					 
					}
					//console.log("currentRole and hierarchy**************"+$rootScope.currentRole+"hierarchy-"+hierarchy);
					  /*  $rootScope.currentRole = $scope.loggedInUser.userroles[0].roleName;
					    console.log("$rootScope.currentRole**************",$rootScope.currentRole); */
					}
					changeRole();
					
				}
				else
				{
					if($scope.loginStatus && userFlag)
					{	
					var userStatus =JSON.parse(localStorage.getItem('userStatus'));
					$scope.userStatus = userStatus;
                     if(userStatus&&userStatus.isUser)
					 {
						$rootScope.currentRole='User'; 
						 
					 }
					 else
					 if(userStatus&&userStatus.isAdmin)
					 {
						$rootScope.currentRole='Admin';  
					 }
					 else if(userStatus&&userStatus.isSuperUser)
					 {
					 $rootScope.currentRole='SuperAdmin';						 
					 }
					changeRole();				
					}
				/* else{
					 $scope.userStatus.isUser = false;
					 $scope.userStatus.isAdmin = false;
					 $scope.userStatus.isSuperUser = false;
					 localStorage.setItem('userStatus', JSON.stringify($scope.userStatus));
				} */
			}
			$scope.changedRole = $rootScope.currentRole;	
            });
            
			$rootScope.submitRole = function(){
				changeRole();	
				$('#signupModal').modal('hide');

			};
    
			function changeRole(){
				$('#signupModal').modal('hide');
				if($rootScope.currentRole == "SuperAdmin"){
					 var type = "Create Sandbox";
					 var company = {"companyName":""}
					 dataFactory.lastSandboxSelection(type, company);
					 $state.go('experiences');
					 $scope.userStatus.isUser = false;
					 $scope.userStatus.isAdmin = false;
					 $scope.userStatus.isSuperUser = true;
                     localStorage.setItem('currentRole',$rootScope.currentRole);
					 localStorage.setItem('userStatus',JSON.stringify($scope.userStatus));
				}
				else if($rootScope.currentRole == "Admin"){
					$state.go('yoursandbox',{}, {reload: true});
					$scope.userStatus.isUser = false;
					 $scope.userStatus.isAdmin = true;
					 $scope.userStatus.isSuperUser = false;
                     localStorage.setItem('currentRole',$rootScope.currentRole);
					 localStorage.setItem('userStatus', JSON.stringify($scope.userStatus));
                    dataFactory.extractOrgId($scope.loggedInUser, true);
/*                    if($scope.loggedInUser.referenceCompanyId)
                        dataFactory.setOrgId($scope.loggedInUser.referenceCompanyId);
                    else
                        dataFactory.setOrgId($scope.loggedInUser.companyId);*/
				}
				else if($rootScope.currentRole == "User"){
				    $state.go('home',{}, {reload: true});
					$scope.userStatus.isUser = true;
                    $scope.userStatus.isAdmin = false;
                    $scope.userStatus.isSuperUser = false;
                    dataFactory.extractOrgId($scope.loggedInUser, true);
                    
/*                    if($scope.loggedInUser.referenceCompanyId)
                        dataFactory.setOrgId($scope.loggedInUser.referenceCompanyId);
                    else
                        dataFactory.setOrgId($scope.loggedInUser.companyId);*/  
                    localStorage.setItem('currentRole',$rootScope.currentRole);
                    localStorage.setItem('userStatus', JSON.stringify($scope.userStatus));
				}
				$scope.changedRole = $rootScope.currentRole;
			};
}

    
})();