(function(){
    
angular
    .module('experienceApp.documentationController', [])
    .controller('documentationController', documentationController);

documentationController.$injector = ['$scope', '$rootScope', 'dataFactory', '$state', '$stateParams'];

function documentationController($scope, $rootScope, dataFactory, $state, $stateParams) {

    dataFactory.setCurrentState("documentation");
    
}
    
})();