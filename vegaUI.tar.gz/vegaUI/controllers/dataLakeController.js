/**=========================================================
 * Module: dataLakeController
 * Setup options and data for flot chart
 =========================================================*/
angular
    .module('experienceApp.expGuideController', ['ui.codemirror'])
	.directive('vsusenameAvailable', function($http, $rootScope, $timeout, $q) {
	  return {
		restrict: 'AE',
		require: 'ngModel',
		link: function(scope, elm, attr, model) { 
		  model.$asyncValidators.usernameExists = function() {
			console.log(elm.val());
			//here you should access the backend, to check if username exists
			//and return a promise
			//here we're using $q and $timeout to mimic a backend call 
			//that will resolve after 1 sec
			
			$http.get(baseApiUrl+'/visualization?name='+elm.val(), {
				headers: {
					'Content-Type': 'application/json',
					'access-token': $rootScope.accessToken
				}
			}).success(function(data) {
				model.$setValidity('usernameExists', false); 
				//return $q.resolve;
				//return defer.promise;
			}).error(function(data) {
				//var defer = $q.defer();
				model.$setValidity('usernameExists', true);
				//return $q.reject;	
				//return defer.promise;
			});
		  };
		}
	  } 
	})
	.controller('dataLakeController', ['$sce','$http','$state', '$scope', '$timeout','ngDialog','dataFactory','$rootScope','$window','$state', function($sce, $http, $state, $scope, $timeout,ngDialog,dataFactory,$rootScope,$window,$state) {

	$scope.loadingVisible=false;
	var URL=vegaFhirBaseUrl;
	var vms = this;
    $rootScope.accessToken=$window.localStorage.accesstoken;
	dataFactory.setCurrentState("dataLake");
   
	$scope.myVisulisationFlag=false;
	$scope.myGallaryFlag=true;
	$scope.visualisationData={};
	$scope.filteredVisualization=[];
	$scope.selectedIndex=0;
	$scope.editVisualizationFlag=false;
	$scope.deleteThumb=true;
	$scope.deletedDependantFiles=[];

	
	 $scope.editorOptions = {
          lineNumbers: true,
          styleActiveLine: true,
          matchBrackets: true
    };
	
	
	$scope.openMyVisualization=function(){
	  $scope.graph = 'list';
	  $scope.myVisulisationFlag=true;
	  $scope.myGallaryFlag=false;
	  $scope.selectedIndex=0;
	  getMyVisulization();
	};

	$scope.openGallary=function(){
	  $scope.visualization = 'list';
	  $scope.myVisulisationFlag=false;
	  $scope.myGallaryFlag=true;
	  	$scope.selectedIndex=0;
	  getAllvisualization();
	}
	$scope.checkUserExist = function(name){
			$http.get(baseApiUrl+'/visualization?name='+name, {
				headers: {
					'Content-Type': 'application/json',
					'access-token': $rootScope.accessToken
				}
			}).success(function(data) {
				$scope.usernameExists = true;
			}).error(function(data) {
				$scope.usernameExists = false;
			});
		}
    if(dataFactory.previousTabs() && dataFactory.previousTabs()=='myVisualization')
{
$scope.openMyVisualization();
$('.filter-category').toggleClass('inactive-category active-category');
dataFactory.previousTabs("no State");
}	

	

function initialiseScript(){
	
   $scope.visualization = 'list';
   $scope.graph = 'list';
   $scope.visualisationForm={};
   $scope.visualisationForm.name='';
   $scope.visualisationForm.description='';
   $scope.visualisationForm.version ='';
   $scope.editVisualizationFlag=false;
   $("#chartLibraryFiles").val(''); 
   $("#sampleCodeFile").val('');  
   $("#thumbnailFile").val('');  
   }

   initialiseScript();


  	$scope.addNewScript=function(){
	$scope.scriptAddForm=true;

	};
	$scope.cancelScriptForm=function(){
	$scope.scriptAddForm=false;
	initialiseScript();
	};
	
	$scope.visualisationForm_libraryFiles=function(element){
	
	$scope.visualisationForm.librarydata=element.files;
	};
	
	// add new visualisation
	$scope.submitScriptForm=function(){
	var fd = new FormData();
             fd.append("name", $scope.visualisationForm.name);
			 fd.append("description",$scope.visualisationForm.description);
		     fd.append("version", $scope.visualisationForm.version);
		     fd.append("chartLibName",$scope.visualisationForm.chartLibName);
		     fd.append("createdBy",dataFactory.getLoggedInUser().mail);
			 fd.append("inputJson",$scope.visualisationForm.inputJson);
			 fd.append("thumbnail",$scope.visualisationForm.thumbnail);
			 if($scope.visualisationForm.tags)
			 {
				 for(var i=0;i<$scope.visualisationForm.tags.length;i++)
				 {
				 fd.append("tags["+i+"]",$scope.visualisationForm.tags[i]['text']);
				 }
		     }
			 if($scope.visualisationForm.script)
			 {
			  fd.append("jsCode",$scope.visualisationForm.script);
			 }
			 if($scope.visualisationForm.librarydata)
			 {
			 for(var i=0;i<$scope.visualisationForm.librarydata.length;i++)
			   {
			      fd.append("library["+i+"]",$scope.visualisationForm.librarydata[i]);
			   }
			 }

            $scope.loadingVisible = true;
            $http.post(baseApiUrl+'/visualization', fd, {
                transformRequest: angular.identity,
                headers: {
                    'Content-Type': undefined,
                    'access-token': $rootScope.accessToken
                }
            }).success(function(data) {
                toastr.success("created Visualization");
				$scope.scriptAddForm=false;
				getAllvisualization();
                $scope.loadingVisible = false;
				initialiseScript();
            }).error(function(data) {
			console.log('error');
			if(data && data.httpResponseCode == 409) {
				$(".myForm .name").focus();
				$scope.visualizationName = true;
			}
			if (data&&data.httpResponseCode == 401) {
                    dataFactory.logout();
                }
			    $scope.loadingVisible = false;
            });
	};

	function getAllvisualization(type){
	  $scope.loadingVisible = true;
	$http.get(baseApiUrl+'/visualization', {
                    headers: {
                        'Content-Type': 'application/json',
                        'access-token': $rootScope.accessToken
                    }
                }).success(function(data) {
				 angular.forEach(data, function(record){
					var temp = [];
					if(record.dependentFiles){
						angular.forEach(record.dependentFiles, function(file){
							temp.push({'url':file,'name':file.substring(file.lastIndexOf('/')+1,file.length)});
						});
						record.dependentFiles = temp;
					}
					if(record.tags) {
						var tags = [];
						angular.forEach(record.tags, function(tag){
							tags.push({'text':tag});
						});
						record.tags = tags;
					}
				 });
				 
				 $scope.filteredVisualization=data;
				 $scope.allScripts=data;
				 console.log($scope.allScripts)
				if(type)
				{
				$scope.filterVisualization(type);
				}
			
				  $scope.loadingVisible = false;
                  //  console.log(data);
                }).error(function(data) {
				if (data&&data.httpResponseCode == 401) {
                    dataFactory.logout();
                }
                    console.log(data);
					  $scope.loadingVisible = false;
                });

	};

	$scope.getAllvisualization=getAllvisualization;
	$scope.filterVisualization=function(type,index)
	{
	  $('li.list-group-item').addClass('inactive-category');
	  $('li.list-group-item').removeClass('active-category');
      $('li.list-group-item').first().toggleClass('inactive-category active-category');
	 $scope.myVisulisationFlag=false;
	  $scope.myGallaryFlag=true;
	$scope.selectedIndex=index;
	$scope.filteredVisualization=[];
	for(var i=0;i< $scope.allScripts.length;i++)
	  {  
	  	  if($scope.allScripts[i].chartLibName==type)
		  {
		    $scope.filteredVisualization.push($scope.allScripts[i]);		  
		  }
	  }

	}
	
	getAllvisualization();
	
	$scope.deleteVisualization=function(visualization)
	{

	$scope.visualizationId=visualization.id;
	ngDialog.open({
                template: 'deleteVisualizationTemplete',
                scope: $scope,
                closeByDocument: false
            });
	setTimeout(function(){
		$("#deletePop").parent().css({'width':'450px'})
	},100)
	};
	
	
	$scope.deleteVisualizationConfirm=function(){
	
     $scope.loadingVisible = true;
            $http.delete(baseApiUrl + '/visualization/' + $scope.visualizationId, {
                headers: {
                    'Content-Type': 'application/json',
                    'access-token': $rootScope.accessToken
                }
            }).success(function(data) {
                toastr.success("Deleted Visualization successfully");
                 getAllvisualization();
                $scope.loadingVisible = false;
            }).error(function(data) {
                $scope.loadingVisible = false;
                if (data&&data.httpResponseCode == 401) {
                    dataFactory.logout();
                }
				else
				{
                toastr.error("Delete Visualization Failed");
                 }
            });
            ngDialog.close();
	
	};



	$scope.visualisationForm_thumbnail=function(file)
	{
	$scope.visualisationForm.thumbnail=file.files[0];

	};

	 $scope.visualisationForm_Script = function(element) {
	   $scope.visualisationForm.script = element.files[0];
       }


	$scope.displayVisualizationSample=function(data)
	{
	$scope.visualisationData=data;
	 ngDialog.open({
                template: 'DisplayGraph',
                scope: $scope,
                closeByDocument: false
       });
	  
     for(var i=0;i<data.dependentFiles.length;i++)
       {	         
	   if(data.dependentFiles[i].includes('.js')||data.dependentFiles[i].includes('.JS'))
	        { 
	          loadScripts([data.dependentFiles[i]],function(){
			  $http.get($scope.visualisationData.jsCode, {
                }).success(function(response) {
				var res=eval(response);				
                }).error(function(data) {
                    console.log(data);
                });          
             });
			}  else
			  {
			  $("<link/>", {
                  rel: "stylesheet",
                  type: "text/css",
                  href: data.dependentFiles[i],
                 }).appendTo("head");
			  
			  }
	   }
	   // can be removed. added for insuring display graph if not already loaded
	  setTimeout(function(){ 	  
              console.log("in timeout");			  
	            $http.get($scope.visualisationData.jsCode, {
                }).success(function(response) {
					var res=eval(response);		
                }).error(function(data) {
                    console.log(data);
                });
   	   
	   },1500);
	};

function loadScripts(array,callback){
    var loader = function(src,handler){
        var script = document.createElement("script");
        script.src = src;
        script.onload = script.onreadystatechange = function(){
            script.onreadystatechange = script.onload = null;
            handler();
        }
        var head = document.getElementsByTagName("head")[0];
        (head || document.body).appendChild( script );
    };
    (function run(){
        if(array.length!=0){
            loader(array.shift(), run);
        }else{
            callback && callback();
        }
    })();
};
	
	$scope.closeDetails = function(){
		
		$scope.visualization = 'list';
		
	}
	$scope.closeGraph = function(){
		
		$scope.graph = 'list';
		
	}

$scope.displayDetails=function(script){
	$window.scrollTo(0, 0);
	$scope.editor={};
	$scope.editor.scriptEditorData = '';
	$scope.fileContent = '';
	$scope.loadingVisible = true;
	$scope.visualization = 'details';
	$scope.loadingVisible = false;
	if(script.jsCode){
		$http.get(script.jsCode, {
			headers: {			
			}
		}).success(function(content) {
			$scope.fileContent=content;
			$scope.editor.scriptEditorData="//input Data\n\n"+
			script.inputJson+"\n\n"+
			"//Graph function\n\n"+$scope.fileContent;
		}).error(function(data) {
			toastr.error("Error in fetching JS code.");
		});
	}
	
	//$scope.fileContent = $sce.trustAsResourceUrl(script.jsCode);
	
	$scope.details=script;
	
	$scope.visualisationData=script;
	
	
/* 	try {
    eval(script.inputJson);
} catch (e) {
    if (e instanceof SyntaxError) {
        console.log(e.message);
    }
} */
	for(var i=0;i<script.dependentFiles.length;i++)
	{	         
	if(script.dependentFiles[i].url.includes('.js')||script.dependentFiles[i].url.includes('.JS'))
		{ 
		  loadScripts([script.dependentFiles[i].url],function(){
		 /*  $http.get($scope.visualisationData.jsCode, {
			}).success(function(response) {
			var res=eval(response);				
			}).error(function(data) {
				console.log(data);
			});  */  
	try {
       var res=eval($scope.editor.scriptEditorData);
} catch (e) {
    if (e instanceof SyntaxError) {
        alert("error in script:"+e.message);
    }
    }	
			
		 });
		}  else
		  {
		  $("<link/>", {
			  rel: "stylesheet",
			  type: "text/css",
			  href: script.dependentFiles[i],
			 }).appendTo("head");
		  
		  }
	}
	   // can be removed. added for insuring display graph if not already loaded
	  setTimeout(function(){ 	              
   	     try {
       var res=eval($scope.editor.scriptEditorData);
} catch (e) {
    if (e instanceof SyntaxError) {
        alert("error in script:"+e.message);
    }
    }
	   },1500);
	/* $http.get($scope.scriptDetails.jsCode, {
                    headers: {
                        'Content-Type': 'application/json'
                    }
                }).success(function(data) {
				$scope.scriptDetails.jsCode=data;
                   // console.log(data);

                }).error(function(data) {
                    console.log(data);
                }); *
         	ngDialog.open({
                template: 'showDetails',
                scope: $scope,
                closeByDocument: false
            });
			setTimeout(function(){
        $(".showDetails").parent().css({"width":"530px","margin-top":"-65px","background":"transparent"});
			}, 200);*/

	};
	
	$scope.refreshGraph=function(){	
	  try {
       var res=eval($scope.editor.scriptEditorData);
} catch (e) {
    if (e instanceof SyntaxError) {
        alert("error in script:"+e.message);
    }
    }
	};
	
	
	
	 $scope.closePopUp = function() {
            ngDialog.close();
        };

    $scope.goToTryPage=function(entity)
	{
	dataFactory.setVisualizationData(entity);
	  $state.go('tryItVisualization'); 
	};
    $scope.editVisualization=function(data){
	  $scope.scriptAddForm=true;	
	  $scope.editVisualizationFlag=true;
	  angular.copy(data,$scope.visualisationForm);
	//$scope.visualisationForm=data;
	  $scope.deleteThumb=true;
	  $scope.deleteJsCode=true;
	};
   
  $scope.deleteScriptFile=function(url)
  {
	var i = 0;
	angular.forEach($scope.visualisationForm.dependentFiles, function(file){
		var index = file.url.indexOf(url.url);
		if(index > -1){
			 $scope.visualisationForm.dependentFiles.splice(i,1);
			 console.log("deleted");
		}
		i++;
	 });
    $scope.deletedDependantFiles.push(url.url);
  };
  
  // add new visualisation
	$scope.updateVisualizationForm=function(id){
	var fd = new FormData();
             fd.append("name", $scope.visualisationForm.name);
			 fd.append("description",$scope.visualisationForm.description);
		     fd.append("version", $scope.visualisationForm.version);
		     fd.append("chartLibName",$scope.visualisationForm.chartLibName);
		     fd.append("createdBy",dataFactory.getLoggedInUser().mail);
			 fd.append("inputJson",$scope.visualisationForm.inputJson);
			 if($scope.visualisationForm.tags)
			 {
				 for(var i=0;i<$scope.visualisationForm.tags.length;i++)
				 {
				 fd.append("tags["+i+"]",$scope.visualisationForm.tags[i]['text']);
				 }
		     }
			 if((typeof $scope.visualisationForm.thumbnail)!="string")
			  {
			    fd.append("thumbnail",$scope.visualisationForm.thumbnail);
			  }		  
			//  fd.append("deleteFiles",$scope.deletedDependantFiles);
			  if($scope.deletedDependantFiles)
			 {
			 for(var i=0;i<$scope.deletedDependantFiles.length;i++)
			   {
			      fd.append("deleteFiles["+i+"]",$scope.deletedDependantFiles[i]);
			   }
			 }
			 if($scope.visualisationForm.script)
			 {
			  fd.append("jsCode",$scope.visualisationForm.script);
			 }
			 if($scope.visualisationForm.librarydata)
			 {
			 for(var i=0;i<$scope.visualisationForm.librarydata.length;i++)
			   {
			      fd.append("library["+i+"]",$scope.visualisationForm.librarydata[i]);
			   }
			 }

            $scope.loadingVisible = true;
            $http.put(baseApiUrl+'/visualization/'+id, fd, {
                transformRequest: angular.identity,
                headers: {
                    'Content-Type': undefined,
                    'access-token': $rootScope.accessToken
                }
            }).success(function(data) {
                toastr.success("Updated Visualization");
				$scope.scriptAddForm=false;
				getAllvisualization();
                $scope.loadingVisible = false;
				initialiseScript();
            }).error(function(data) {
			    $scope.loadingVisible = false;
            });
	};
  
  
 function getMyVisulization(){
 $scope.loadingVisible = true;
$http.get(baseApiUrl+'/myVisualization?username='+dataFactory.getLoggedInUser().mail, {
                    headers: {
                        'Content-Type': 'application/json',
                        'access-token': $rootScope.accessToken
                    }
                }).success(function(data) {
				
				  $scope.myVisulisations=data;
				  $scope.loadingVisible = false;
                  //  console.log(data);
                }).error(function(data) {
				if (data&&data.httpResponseCode == 401) {
                    dataFactory.logout();
                }
                    console.log(data);
					  $scope.loadingVisible = false;
                });
};

$scope.deleteMyVisualization=function(visualization)
	{

	$scope.visualizationId=visualization.id;
	ngDialog.open({
                template: 'deletemyVisulization',
                scope: $scope,
                closeByDocument: false
            });
	setTimeout(function(){
		$("#deletePop").parent().css({'width':'450px'})
	},100)
	};

	
$scope.deleteMyVisualizationConfirm=function(){

 $scope.loadingVisible = true;
            $http.delete(baseApiUrl + '/myVisualization/' + $scope.visualizationId, {
                headers: {
                    'Content-Type': 'application/json',
                    'access-token': $rootScope.accessToken
                }
            }).success(function(data) {
                toastr.success("Deleted Visualization successfully");
                 getMyVisulization();
                $scope.loadingVisible = false;
            }).error(function(data) {
                $scope.loadingVisible = false;
                if (data&&data.httpResponseCode == 401) {
                    dataFactory.logout();
                }
				else
				{
                toastr.error("Delete Visualization Failed");
                 }
            });
            ngDialog.close();

};

}]);
