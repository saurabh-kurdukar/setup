(function() {

angular
    .module('experienceApp.loginController', ['ui.bootstrap'])
    .controller('LoginController', LoginController)
    .controller('modalInstController', modalInstController);

LoginController.$injector =  ['$scope', '$rootScope', 'dataFactory', '$state', '$uibModal'];
modalInstController.$injector = ['$scope', '$uibModalInstance', '$uibModal','dataFactory','$rootScope', '$state'];

function LoginController($scope, $rootScope, dataFactory, $state, $uibModal) {
    
	dataFactory.setCurrentState("login");
    if( dataFactory.getLoginStatus() )
    {
        dataFactory.logout();
    }
    else
    {
        $scope.user = {
            "username": "",
            "password": "",
            "captcha": ""
        };
        $scope.showLoginError = {
            "userName": {
                show: false,
                msg: "Email Id is required*"
            },
            "password": {
                show: false,
                msg: "Password is required.*"
            },
            "captcha": {
                show: false,
                msg: "Please enter above Captcha.*"
            }
        };
        $scope.loggedInUser = dataFactory.getLoggedInUser();
        $scope.disableLoginButton = false;                        

        var callErrorHandler = function (method, apiResponse, postApiDataSent) {
            errorObj = {
                controller: "LoginController",
                method: method,
                postApiDataSent: postApiDataSent,
                apiResponse: apiResponse
            }
            $rootScope.handleErrors(errorObj);
        };

      $scope.captchaRefresh = function (isPopUpCaptcha) {
        var captchaData = dataFactory.getCaptcha();
        captchaData.success(function (response) {
            $scope.isConnectionError = false;
            if(isPopUpCaptcha)
            {
                $scope.CaptchaImgLogin = 'data:image/jpeg;base64,' + base64ArrayBuffer(response.captchaImage.data);
                $scope.popupCatchecode = response.captchaCode;
               
            }
            else{
                $scope.catcheImg = 'data:image/jpeg;base64,' + base64ArrayBuffer(response.captchaImage.data);
                $scope.catchecode = response.captchaCode;
            }
        }).error(function (error) {
            $scope.isConnectionError = true;
            console.log("error fetching captchaData");
        });
        $scope.PopCaptcha = function () {
            $scope.captchaRefresh("PopUpCaptcha");            
        }

            function base64ArrayBuffer(arrayBuffer) {
                var base64 = '';
                var encodings = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/';
                var bytes = new Uint8Array(arrayBuffer);
                var byteLength = bytes.byteLength;
                var byteRemainder = byteLength % 3;
                var mainLength = byteLength - byteRemainder;
                var a, b, c, d;
                var chunk;
                for (var i = 0; i < mainLength; i = i + 3) {
                    chunk = (bytes[i] << 16) | (bytes[i + 1] << 8) | bytes[i + 2] ;
                    a = (chunk & 16515072) >> 18 ;
                    b = (chunk & 258048) >>12 ;
                    c = (chunk & 4032) >> 6 ;
                    d = chunk & 63 ;
                    base64 += encodings[a] + encodings[b] + encodings[c] + encodings[d];
                }
                if (byteRemainder == 1) {
                    chunk = bytes[mainLength] ;
                    a = (chunk & 252) >> 2 ;
                    b = (chunk & 3) << 4 ;
                    base64 += encodings[a] + encodings[b] + '==';
                } else if (byteRemainder == 2) {
                    chunk = (bytes[mainLength] << 8) | bytes[mainLength + 1] ;
                    a = (chunk & 64512) >> 10 ;
                    b = (chunk & 1008) >> 4 ;
                    c = (chunk & 15) << 2 ;
                    base64 += encodings[a] + encodings[b] + encodings[c] + '=';
                }
                return base64;
            }
        };
        $scope.captchaRefresh();

        $scope.loginUser = function (loginData) {
            if ($scope.user.captcha == $scope.catchecode) {
                $scope.disableLoginButton = true;
                $scope.user = {
                    "username": "",
                    "password": ""
                };
                dataFactory.logIn(loginData).then(function successCallback(response, status, headers, config) {
                    dataFactory.setAccessToken(response.headers()['access-token']);
                    dataFactory.setLoggedInUser(response.data);
                    dataFactory.setLoginStatus(true);
                    dataFactory.extractOrgId(response.data, true);
                    localStorage.setItem("currentRole","User"); 
                    $rootScope.currentRole='User'; 
 /*                   if(response.data.referenceCompanyId)
                        dataFactory.setOrgId(response.data.referenceCompanyId);
                    else
                        dataFactory.setOrgId(response.data.companyId);*/
                    $state.go('home');
                }, function errorCallback(error) {
                    $scope.disableLoginButton = false;                    
                    callErrorHandler("$scope.loginUser", error, loginData);
                    if (error && error.data && (error.data.errorMessage == "User not activated")) {
                        $rootScope.alertBoxMessage = "Account NOT Activated";
                        $scope.open();
                        return;
                    }
                    if (error && error.data && ((error.data.errorMessage == "Unauthorized user") || (error.data.errorMessage == "Invalid username"))) {
                        $rootScope.alertBoxMessage = "Username/Password combination does not exist";
                        $scope.InvalidUsernamePopup();
                    } else {
                        $scope.showLoginError.userName.msg = "Some error occured.please try again.";
                        $scope.isConnectionError = true;
                    }
                    $scope.captchaRefresh();
                    
                });
            } else {
                $scope.showLoginError.captcha.msg = "Please Enter Valid Captcha";
                $scope.showLoginError.captcha.show = true;
                $scope.disableLoginButton = false;                
            }
        };

        $scope.open  =   function  (size) {    
            var  modalInstance  =  $uibModal.open({      
                animation: $scope.animationsEnabled,
                      templateUrl:   'showActivationPopUpForMail.html',
                      controller:   'modalInstController',
                      scope : $scope,
                      size: size,
                      resolve: {              }    
            });
        modalInstance.result.then(function  (selectedItem) {      
                $scope.selected  =  selectedItem;    
            },  function  () {          });
        }
        
         $scope.InvalidUsernamePopup  =   function  (size) {    
            var  modalInstance  =  $uibModal.open({      
                animation: $scope.animationsEnabled,
                      templateUrl:  'InvalidUsername.html',
                      controller:   'modalInstController',
                      scope : $scope,
                      size: size,
                      resolve: {              }    
            });
        modalInstance.result.then(function  (selectedItem) {      
                $scope.selected  =  selectedItem;    
            },  function  () {          });
        }
         
        $scope.resetUserName = function () {
            $scope.showLoginError.userName = {
                show: false,
                msg: "Email Id is required.*"
            }
        };
        
        
        
        
    $scope.activationSuccess  =   function  (size) { 
        var  modalInstance  =  $uibModal.open({      
            animation: $scope.animationsEnabled,
                  templateUrl:   'showActivationPopUp.html',
                  controller:   'modalInstController',
                  scope : $scope
        }); 
        modalInstance.result.then(function  (value) {      
            if (value == 'didNotGet') {
                
                $scope.resendActivationPopup();
            }
        },  function  () {          });
    }

    $scope.resendActivationPopup = function () {
          var modalInstance = $uibModal.open({
          templateUrl: 'resendActivationMail.html',
          controller: 'modalInstController',
        
          });
    modalInstance.result.then(function (value) {
                if (value == 'resendActivationMail') {
                    $scope.activationSuccess();
                }
            }, function () {
                console.log('error');
            }
        );
      };
    }
    
}

    
function modalInstController($scope, $uibModalInstance, $uibModal,dataFactory,$rootScope, $state) {
    var parent = $scope.$parent;
  
	$scope.closePopUp = function (input) {
	    if (input != undefined) {
	        $uibModalInstance.close(input);
	    } else {
	        $uibModalInstance.close();
	    }
	};
	$scope.resendActivationPopup = function () {
        var modalInstance = $uibModal.open({
          templateUrl: 'resendActivationMail.html',
          controller: 'modalInstController',
           scope: parent
           });

          modalInstance.result.then(function (value) {
                if (value == 'resendActivationMail') {
                    $scope.activationSuccess();
                }
            }, function () {
                console.log('error');
            }
        );
      };
  
    //bindable functions
    $scope.resendActivationEmail=resendActivationEmail;
    function resendActivationEmail()
    {
        if($scope.popupCatchecode==$scope.captchaEntered)
        {
            dataFactory.resendActivationEmail($scope.enteredEmail)
            .then(resendEmailSuccess)
            .catch(resendEmailError);  

            function resendEmailSuccess(response)
            {   
                $scope.closePopUp("resendActivationMail");
            }

            function resendEmailError(error)
            {
               
                if(error.errorMessage == "Invalid username")
                {
                    $scope.showPopupLoginError.email.msg= " Please Enter valid Registered EmailID";
                    $scope.showPopupLoginError.email.show = true;
                    
                }
                else if(error.errorMessage == "User Already Verified")
                {
                    $scope.showPopupLoginError.email.msg = " User is Already Verified";
                    $scope.showPopupLoginError.email.show = true;
                   
                }
                else
                    callErrorHandler("Error", error, "Error while resending the email");
            } 
        }
        else
            $scope.showPopupLoginError.Captcha.show=true;
    }
    
    
    $scope.goToLogin = function() {
        dataFactory.logout();
        $state.go('login');
    }
    $scope.showPopupLoginError = {
                "Captcha": {
                    show: false,
                    msg: " Invalid Captcha"
                },
                "email": {
                    show: false,
                    msg: " Please enter valid Email address"
                }
     }
    
      $scope.resetPopUpEmail = function () {
         $scope.showPopupLoginError.email = {
                show: false,
                msg: " Please enter valid Email address"
            }
        };
    
    $scope.canSubmitResendMailRequest = function () {
        
      if (($scope.isConnectionError) || !($scope.captchaEntered) || !($scope.enteredEmail)) {
                return false;
            } else {
                return true;
            }
        }
    
    
    }
    
    

    

})();