(function() {

angular
    .module('experienceApp.galleryController', [])
    .controller('GalleryController', GalleryController);
    
    GalleryController.$injector = ['$scope','$state', '$rootScope', 'dataFactory'];
    function GalleryController($scope ,$state,$rootScope ,dataFactory) {

        dataFactory.setCurrentState("gallery");
        if(!dataFactory.getLoginStatus())
        {
            $state.go('login');
        }
    }    
    
})();