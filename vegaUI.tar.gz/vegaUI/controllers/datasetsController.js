/*=========================================================
 * Module: addExperienceController.js
 * Controller to add or update the new or existing experience
=========================================================*/
angular.module('experienceApp.datasets', ['ngDialog'])
.controller('datasetsController', ['$rootScope', '$scope', '$http', '$state', '$stateParams', '$compile', '$window','dataFactory','ngDialog',
    function($rootScope, $scope, $http, $state, $stateParams, $compile, $window,dataFactory,ngDialog) {
       		
		dataFactory.setCurrentState("Datasets");
		$scope.dataTableFlag=false;
		$scope.selectedTableName='empty';
		$rootScope.accessToken=$window.localStorage.accesstoken;
		
	$scope.dashboardUrl=dataset_dashboardUrl;	
	$scope.BrowserUrl=dataset_BrowserUrl;

	$scope.dataExplorerFlag=false;
	
	$scope.isCountZero = function(script) {
		return script.count!=0;
	}
	$scope.loadingVisible = true;
	function getTableNames(){
		$scope.loadingVisible = true;
		$http.get(vegaFhirBaseUrl+'/Metadata/$tables', {
                headers: {
                    'Content-Type': 'application/json'
                    /* 'access-token':$rootScope.accessToken */ //uncomment for fin vega
                }
            }).success(function(data) {
            $scope.allTables=data;
                $scope.loadingVisible = false;
            }).error(function(data) {
               console.log(data);
			   $scope.loadingVisible=false;
			    if (data&&data.errorCode == 'IE0010') {
                    dataFactory.logout();
                }
            });
	};
	
	getTableNames();
	
	
	// will get datatable names based on type . not using now.	
$scope.loadDataSet=function(type){
	$scope.loadingVisible=true;
	$scope.dataExplorerFlag=false;
	$scope.CarenetDataSetFlag=false;
	 var url="";
	if(type=='Claims')
	{
	    url=vegaFhirBaseUrl+'/Metadata/$tablesByClaim';	
	}
	else
	{
	   url=vegaFhirBaseUrl+'/Metadata/$tablesByCategory';
	}

	   $http.get(url, {
                headers: {
                    'Content-Type': 'application/json'
                    /* 'access-token':$rootScope.accessToken */ //uncomment for fin vega
                }
            }).success(function(data) {
             $scope.tableNames=data;
			 $scope.selectedTableName=data[0];
			 $scope.getDataForTable($scope.selectedTableName);
                $scope.loadingVisible = false;
            }).error(function(data) {
               console.log(data);
			   $scope.loadingVisible=false;
            });
	
	
		$scope.dataTableFlag=false;
		
		console.log("dataset Loaded",type);
	
	};
	
$scope.loadExplorer=function(){
	$scope.dataExplorerFlag=true;	
	};
	
	//not using now
$scope.loadCarenetDataSet=function()
	{
	$scope.dataExplorerFlag=false;
	$scope.CarenetDataSetFlag=true;
	$scope.getDataForTable('PATIENTS_PALLIATIVE_CARE');
	};
	
		
$scope.getDataForTable=function(tableName,index,count){
	$scope.tableName=tableName;
	$scope.selectedIndex=index;
	$scope.loadingVisible=true;
		$scope.dataTableFlag=true;
		
		var url=vegaFhirBaseUrl+"/Metadata/$tableSchema?tableName="+tableName;
		
		  $http.get(url, {
                headers: {
                    'Content-Type': 'application/json' 
                    /* 'access-token':$rootScope.accessToken */ //uncomment for fin vega
                }
            }).success(function(data) {
			if(tableName=='TRANSACTION')  //for finvega
			{
			  $scope.data= processTableColumns(data);
			}
			else
			{
              $scope.data=data;
			}
			$scope.TableSize=count;
            $scope.loadingVisible = false;
            }).error(function(data) {
			$scope.loadingVisible=false;
               console.log(data);
			   if (data&&data.errorCode == 'IE0010') {
                    dataFactory.logout();
                }
            });	
	};
function processTableColumns(TableData)
	{
		var tempObj={};
		var firstColumns=["Id","Iso_message_header","Trans_date","Processing_code","Transaction_amount","Merchant_type","Stan","Acquiring_inst_id_code","Txn_datetime"];
		var dataTypes=["INTEGER","VARCHAR","DATE","VARCHAR","DOUBLE","VARCHAR","VARCHAR","VARCHAR","VARCHAR"]
		tempObj.columnNames=firstColumns;
		tempObj.columnvalues=dataTypes;
		
		tempObj.resourceList=TableData.resourceList;
		
		for(keys in TableData.columnMap)
			{
				 if(firstColumns.indexOf(keys)==-1)
					 {
						 tempObj.columnNames.push(keys);
						 tempObj.columnvalues.push(TableData.columnMap[keys]);
					 }
				 else
					 {
						//console.log("got");
					 }
			}
	return tempObj;   
	}
	
	$scope.openRowDetails = function(entity){
		$scope.selectedEntity = entity;
		ngDialog.open({
				  template: 'rowDetails',
				  scope: $scope,
				  closeByDocument: true
			  });
	}
	$scope.closeRowDetails = function(){
		ngDialog.close();
	}	
}]);