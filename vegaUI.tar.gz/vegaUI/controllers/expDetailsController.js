(function(){

angular
    .module('experienceApp.expDetailsController', [])
    .controller('expDetailsController', expDetailsController)
    .controller("modalPopUpCtrl", modalPopUpCtrl);

expDetailsController.$injector = ['$scope', '$state', '$rootScope', 'dataFactory', '$http', '$stateParams', '$uibModal'];
modalPopUpCtrl.$injector = ['$scope','$uibModalInstance', 'dataFactory'];

function expDetailsController($scope, $state, $rootScope, dataFactory, $http, $stateParams, $uibModal) {
    
	dataFactory.setCurrentState("expDetails");
	dataFactory.hiddenNavbarFooter(true);
	$scope.width = "100%";
	//$scope.disableviewbtn = true;
/*	$('viewSandbox').click(function () {
		return false
	});*/
//	$scope.btntext = "Add to cart";
	$scope.traceData = [];
	$scope.traceMessage = "fetching.Please Wait.";
	$scope.fetchingLiveTrace = true;
    $scope.fetchingDocs = true;
    $scope.isDocsAvailable = false;
    $scope.experienceDocs = [];
    $scope.appsDocs = [];
    $scope.servicesDocs = [];
    $scope.selectedTrace = { trace : "NA"};
	var experiences = [];  
    
	$scope.selectedExperience = dataFactory.getSelectedExperience();
	var selectedExperiences = dataFactory.getExperienceFromCartByOrgId();   
    var expRes = dataFactory.getExperiences();
    var expDetail = dataFactory.getExperienceDetailById($scope.selectedExperience.id);
    
    
	var callErrorHandler = function (method, apiResponse, postApiDataSent) {
		errorObj = {
			controller: "expDetailsController",
			method: method,
			postApiDataSent: postApiDataSent,
			apiResponse: apiResponse
		}
		$rootScope.handleErrors(errorObj);
	};
	var shuffleArray = function (array) {
		var currentIndex = array.length,
			temporaryValue, randomIndex;
		while (0 !== currentIndex) {
			randomIndex = Math.floor(Math.random() * currentIndex);
			currentIndex -= 1;
			temporaryValue = array[currentIndex];
			array[currentIndex] = array[randomIndex];
			array[randomIndex] = temporaryValue;
		}
		return array;
	}
	var populateSimilarApps = function (experiences, experience) {
		var similarExperiences = [];
		$scope.similarExperiences = [];
		experiences.forEach(function (exp, index, array) {
			if ((exp.domain == $scope.selectedExperience.domain) && (exp.id != $scope.selectedExperience.id)) similarExperiences.push(exp);
		});
		$scope.similarExperiences = shuffleArray(similarExperiences);
	};


	if (expRes.success || expRes.error) {
		expRes.success(function (response) {
            
			response.forEach(function (experience) {
				experience.isSelected = false;
				experience.isProvisioned = false;
			});
			dataFactory.setExperiences(response);
			experiences = response;
			populateSimilarApps(experiences, $scope.selectedExperience);
            
		}).error(function (error) {
            
			callErrorHandler("init", error, "error fetching experiences");
			$scope.isConnectionError = true;
			$scope.expMsg = "some network issue occured..please reload."
            
		});
	} else {
		experiences = expRes;
		populateSimilarApps(experiences, $scope.selectedExperience);
	}
    
/*	if (selectedExperiences.success || selectedExperiences.error) {
		selectedExperiences.success(function (response) {
			$scope.selectedExperiences = response;
			dataFactory.setCartExperiences(response);
			if ($scope.selectedExperiences.length > 0) {
				$scope.selectedExperiences.forEach(function (sExperience) {
					if ($scope.selectedExperience.id == sExperience.expId) {
						$scope.btntext = "Added";
						$scope.disableviewbtn = false;
					};
				});
			}
		}).error(function (error) {
			callErrorHandler("none", error, "error fetching selected experiences ");
			$scope.expMsg = "some network issue occured..please reload."
			console.log("error fetching experiences");
			$scope.isConnectionError = true;
		});
	} else {
		$scope.selectedExperiences = selectedExperiences;
		populateSimilarApps(experiences, selectedExperiences);
	};*/
    
    expDetail.success(function (response) {
		
		response.services.forEach(function(service){
			if(!service.swaggerURL || service.swaggerURL=="null")
			{
				service.swaggerURL = "NA";
			}
		});
		
        dataFactory.setExperienceDetail(response);
        $scope.selectedExpDetail = dataFactory.getExperienceDetail();
		console.log("$scope.selectedExpDetail",$scope.selectedExpDetail);
		
    
        fetchDocuments($scope.selectedExpDetail);
    }).error(function (error) {
        $scope.isConnectionError = true;
        $rootScope.selectedExpDetail = error;
    });
    
    
	$scope.goToSandbox = function () {
		$state.go('yoursandbox');
	}
	$scope.goToExpDetails = function (exp) {
		dataFactory.setSelectedExperience(exp);
		$state.transitionTo($state.current, $stateParams, {
			reload: true,
			inherit: false,
			notify: true
		});
	}
	
	var fetchDocuments = function (experienceObj) {
		var docRes = dataFactory.getDocMap(experienceObj.experienceId);
		if (docRes.success || docRes.error) {
			docRes.success(function (response) {
				var documents = response;
				if (response.errorCode == "E00012") 
                    documents = [];
				dataFactory.addToDocMap(experienceObj.experienceId, documents);
				addDoc(documents, experienceObj);
			}).error(function (error) {
				$scope.fetchingDocs = false;
				$scope.isDocsAvailable = false;
				callErrorHandler("fetchDocuments", error, "error fetching experience documents")
			});
		} else {
			addDoc(docRes, experienceObj);
		}
	};
	var addDoc = function (docs, experienceObj) {
		if ((!docs)  || (docs.length == 0)  || (docs.NoDocAvailable)) {
			$scope.experienceDocs = [];
			$scope.appsDocs = [];
			$scope.servicesDocs = [];
			$scope.isDocsAvailable = false;
			return;
		}
		var appsDocs = [];
		var experienceDocs = [];
		var servicesDocs = [];
		docs.forEach(function (doc) {
			if (doc.appId) appsDocs.push(doc);
			else if (doc.serviceId) servicesDocs(doc)
			else experienceDocs.push(doc);
		});
		$scope.experienceDocs = experienceDocs;
		$scope.appsDocs = appsDocs;
		$scope.servicesDocs = servicesDocs;
		$scope.fetchingDocs = false;
		$scope.isDocsAvailable = ($scope.experienceDocs.length > 0) || ($scope.appsDocs.length > 0) || ($scope.servicesDocs.length > 0);
	};
    
    $scope.showApiDetails = function( selectedTrace ){
              dataFactory.tracePopupData( selectedTrace );
              $scope.selectedTrace.trace = selectedTrace;
              $scope.open();
        };

    $scope.open = function ( ) {

        var modalInstance = $uibModal.open({
          templateUrl: 'showLiveTraceDetails.html',
          controller: 'modalPopUpCtrl',
          windowClass: 'md-Modal'
          });

        modalInstance.result.then(function () {      }
         , function () {      }
         );
      };
    
    
	var fetchLiveTrace = function (expId) {
        if( dataFactory.getCurrentState() != "expDetails")
        {
            return;
        }
		dataFactory.getLiveTrace(expId).success(function (response) {
            var traceData = [];
            if( response.length !=traceData.length )
                response.forEach(function( trace ){
                    if( trace.expID == $scope.selectedExperience.id )
					traceData.push( trace );
                });
			console.log("traceData****",traceData);
            if( traceData.length == 0 )
                $scope.traceMessage = "No Trace Data Available.";
               $scope.traceData = JSON.parse(JSON.stringify(traceData));
		}).error(function (error) {
			if (error && (error.errorCode == "T0002")) {
				$scope.traceData = [];
				$scope.traceMessage = "No Trace Data Available.";
				return;
			}
			$scope.isConnectionError = true;
			$scope.traceMessage = "could not fetch live status.";
			callErrorHandler("fetchLiveTrace", error, "error fetching live trace");
		});
		$scope.fetchingLiveTrace = false;
        
        setTimeout(function( ){
            //fetchLiveTrace(dataFactory.getLoggedInUser().mail);
            fetchLiveTrace($scope.selectedExperience.id);
			
			
        },60000);
        
	};
    
	//fetchLiveTrace(dataFactory.getLoggedInUser().mail);
	fetchLiveTrace($scope.selectedExperience.id);
	
	$scope.goToPreviousState = function(){
		var gotoState = dataFactory.previousState();
		console.log("gotoState",gotoState);
		dataFactory.hiddenNavbarFooter(false);
		$state.go(gotoState);
	}
}






function modalPopUpCtrl ($scope, $uibModalInstance, dataFactory){
    $scope.tracePopupData = { requestHeader : "NA", requestType : "NA", requestBody : "NA",responseHeader:"NA",responseBody:"NA",responseCode:"NA",timestamp:"NA",userID:"NA",api:"NA",id:"NA",targetApi:"NA"};
    
    $scope.$watch(function(){
        return dataFactory.tracePopupData();
    },function( oldValue, newValue ){
        if( !newValue.requestHeader )
            newValue.requestHeader = "NA";
        if( !newValue.requestType )
            newValue.requestType = "NA";
		if( !newValue.requestBody )
            newValue.requestBody = "NA";
		if( !newValue.responseHeader )
            newValue.responseHeader = "NA";
		if( !newValue.responseBody )
            newValue.responseBody = "NA";
		if( !newValue.responseCode )
            newValue.responseCode = "NA";
		if( !newValue.timestamp )
            newValue.timestamp = "NA";
		if( !newValue.userID )
            newValue.userID = "NA";
		if( !newValue.api )
            newValue.api = "NA";
		if( !newValue.id )
            newValue.id = "NA";
		if( !newValue.targetApi )
            newValue.targetApi = "NA";
         $scope.tracePopupData = newValue;
        
        console.log(oldValue,newValue);
    });
    
    $scope.closePopUp = function () {
        $uibModalInstance.dismiss('cancel');
      };
    
}


})();