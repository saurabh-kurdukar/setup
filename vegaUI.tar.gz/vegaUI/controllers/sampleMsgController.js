/**=========================================================
 * Module: dataLakeController
 * Setup options and data for flot chart 
 =========================================================*/
angular
    .module('experienceApp.apiForm', ['ui.codemirror'])
	.directive('smusernameAvailable', function($http, $rootScope, $timeout, $q) {
	  return {
		restrict: 'AE',
		require: 'ngModel',
		link: function(scope, elm, attr, model) { 
		  model.$asyncValidators.usernameExists = function() {
			console.log(elm.val());
			//here you should access the backend, to check if username exists
			//and return a promise
			//here we're using $q and $timeout to mimic a backend call 
			//that will resolve after 1 sec
			
			$http.get(baseApiUrl+'/sampleMsg?name='+elm.val(), {
				headers: {
					'Content-Type': 'application/json',
					'access-token': $rootScope.accessToken
				}
			}).success(function(data) {
				model.$setValidity('usernameExists', false); 
				//return $q.resolve;
				//return defer.promise;
			}).error(function(data) {
				//var defer = $q.defer();
				model.$setValidity('usernameExists', true);
				//return $q.reject;	
				//return defer.promise;
			});
		  };
		}
	  } 
	})
	.controller('sampleMsgController', ['$sce','$http', '$scope', '$timeout','ngDialog','dataFactory','$rootScope','$window', function($sce,$http, $scope, $timeout,ngDialog,dataFactory,$rootScope,$window) {
	$rootScope.accessToken=$window.localStorage.accesstoken;
	
function initialiseScript(){
	$scope.messages = 'list';
   $scope.scriptForm={};
   $scope.scriptForm.name='';
   $scope.scriptForm.description='';	
   $scope.scriptForm.version ='';  
   $scope.EditScriptFlag=false; 
   $("#messageFile").val("");   
   }
 	
   initialiseScript();  
  
	$scope.checkUserExist = function(name){
			$http.get(baseApiUrl+'/sampleMsg?name='+name, {
				headers: {
					'Content-Type': 'application/json',
					'access-token': $rootScope.accessToken
				}
			}).success(function(data) {
				$scope.usernameExists = true;
			}).error(function(data) {
				$scope.usernameExists = false;
			});
		}
  
  	$scope.addNewScript=function(){
	$scope.scriptAddForm=true;
	
	};
	$scope.cancelScriptForm=function(){
	$scope.scriptAddForm=false;
	initialiseScript();
	};
	
	 $scope.scriptForm_Script = function(element) {	
	$scope.scriptForm.script = element.files[0];
	
       }
	$scope.submitScriptForm=function(){
	var fd = new FormData();
             fd.append("name", $scope.scriptForm.name);
			 fd.append("description",$scope.scriptForm.description);
		     fd.append("version", $scope.scriptForm.version);
		     fd.append("messageFile",$scope.scriptForm.script);
		     fd.append("createdBy",dataFactory.getLoggedInUser().mail);
			 if($scope.scriptForm.tags)
			 {
				 for(var i=0;i<$scope.scriptForm.tags.length;i++)
				 {
				 fd.append("tags["+i+"]",$scope.scriptForm.tags[i].text);
				 }
		     }	
            $scope.loadingVisible = true;
            $http.post(baseApiUrl+'/sampleMsg', fd, {
                transformRequest: angular.identity,
                headers: {
                    'Content-Type': undefined,
                    'access-token': $rootScope.accessToken
                }
            }).success(function(data) {
                toastr.success("Message created");
				$scope.scriptAddForm=false;
				getAllScripts();
                $scope.loadingVisible = false;
				initialiseScript();
            }).error(function(data) {
			    toastr.error(data.errorMessage);
			    $scope.loadingVisible = false;              
            });	
	};
	
	function getAllScripts(){
	$scope.messages = 'list';
	$scope.loadingVisible = true;
	$http.get(baseApiUrl+'/sampleMsg', {
                    headers: {
                        'Content-Type': 'application/json',
                        'access-token': $rootScope.accessToken
                    }
                }).success(function(data) {
				$scope.allScripts=data;
				var temp = [];
				angular.forEach($scope.allScripts, function(script){
					angular.forEach(script.tags, function(tag){
						temp.push({'text':tag});
					});
					script.tags = temp;
					temp = [];
				});
				$scope.loadingVisible = false;
                }).error(function(data) {
				 $scope.loadingVisible = false;
				 if (data&&data.httpResponseCode == 401) {
                    dataFactory.logout();
                }
                    console.log(data);
                });
	
	};
	
	getAllScripts();
	
 $scope.deleteScript = function(entity) {
            $scope.scriptId = entity.id;
            ngDialog.open({
                template: 'deleteMessageTemplete',
                scope: $scope,
                closeByDocument: false
            });
        };
	
	
	$scope.deleteScriptConfirm=function()
	{
	  $http.delete(baseApiUrl+'/sampleMsg/'+$scope.scriptId, {
                    headers: {
                        'Content-Type': 'application/json',
                        'access-token': $rootScope.accessToken
                    }
                }).success(function(data) {				
				    getAllScripts();
				    ngDialog.close();
                }).error(function(data) {
                    console.log(data);
                });

	};
	
	
	$scope.editScript=function(data)
	{
	 $scope.scriptId = data.id;
	$scope.EditScriptFlag=true;
	$scope.scriptAddForm=true;
	angular.copy(data,$scope.scriptForm);
	$scope.scriptForm.script='';
	$scope.deleteJsCode=true;

	};
	
	$scope.updateScriptForm=function(){
	var fd = new FormData();
             fd.append("name", $scope.scriptForm.name);
			 fd.append("description",$scope.scriptForm.description);
		     fd.append("version", $scope.scriptForm.version);
			 if($scope.scriptForm.script!='')
			 {
		     fd.append("scriptFile",$scope.scriptForm.script);
			 }
		     fd.append("updatedBy",dataFactory.getLoggedInUser().mail);
			 if($scope.scriptForm.tags)
			 {
				 for(var i=0;i<$scope.scriptForm.tags.length;i++)
				 {
				 fd.append("tags["+i+"]",$scope.scriptForm.tags[i].text);
				 }
		     }	
            $scope.loadingVisible = true;
            $http.put(baseApiUrl+'/sampleMsg/'+$scope.scriptId, fd, {
                transformRequest: angular.identity,
                headers: {
                    'Content-Type': undefined,
                    'access-token': $rootScope.accessToken
                }
            }).success(function(data) {
                toastr.success("Updated Message");
				$scope.scriptAddForm=false;
                $scope.loadingVisible = false;
				getAllScripts();
				initialiseScript();
            }).error(function(data) {
			 toastr.error(data.errorMessage);
			    $scope.loadingVisible = false;              
            });	
	};
	$scope.closeDetails = function(){
		
		$scope.messages = 'list';
		
	}
	$scope.displayDetails=function(script){
	 /*$scope.scriptDetails=script;
	
	$http.get($scope.scriptDetails.messageFileLocation, {
                    headers: {
                        'Content-Type': 'application/json'
                    }
                }).success(function(data) {
				$scope.scriptDetails.messageFileLocation=data;
                   // console.log(data);

                }).error(function(data) {
                    console.log(data);
                });
         	ngDialog.open({
                template: 'showDetails',
                scope: $scope,
                closeByDocument: false
            });
				setTimeout(function(){ 
	 $(".detailView").parent().css({"width":"633px"});
	 }, 200);*/
		 $scope.loadingVisible = true;
		 $scope.messages = 'details';
			
				//$scope.fileContent = $sce.trustAsResourceUrl(data.messageFileLocation);
				
			$http.get(script.messageFileLocation, {
			headers: {			
			}
			}).success(function(content) {
			$scope.loadingVisible = false;
			$scope.fileContent=content;
			
			}).error(function(data) {
				$scope.loadingVisible = false;
			  toastr.error("Error in fetching sample message.");
			});	
				$scope.details=script;
		
			
	
	
	};
	
}]);
