/**=========================================================
 * Module: dataLakeController
 * Setup options and data for flot chart
 =========================================================*/
angular
    .module('experienceApp.dataPipeline', []).controller('pipelineController', ['$http', '$scope', '$timeout','ngDialog','dataFactory','$rootScope','$window', function($http, $scope, $timeout,ngDialog,dataFactory,$rootScope,$window) {
	console.log("in dataPipeline controller");

	dataFactory.setCurrentState("pipeline");
	$rootScope.accessToken=$window.localStorage.accesstoken;
     $scope.pipeline_Url=data_pipeline_Url;
	$scope.pipeline_edit_url=data_pipelineEdit_url;
	
    $http.get('server/pipeline.json', {
            }).success(function(data) {
             $scope.allPipelines=data;
              
            }).error(function(data) {
               console.log(data);
            });

/* function initialiseScript(){
   $scope.scriptForm={};
   $scope.scriptForm.name='';
   $scope.scriptForm.description='';
   $scope.scriptForm.version ='';
   }

   initialiseScript();


  	$scope.addNewScript=function(){
	$scope.scriptAddForm=true;

	};
	$scope.cancelScriptForm=function(){
	$scope.scriptAddForm=false;
	initialiseScript();
	};

	 $scope.scriptForm_Script = function(element) {
	$scope.scriptForm.script = element.files[0];

       }
	$scope.submitScriptForm=function(){
	var fd = new FormData();
             fd.append("name", $scope.scriptForm.name);
			 fd.append("description",$scope.scriptForm.description);
		     fd.append("version", $scope.scriptForm.version);
		     fd.append("messageFile",$scope.scriptForm.script);
		     fd.append("createdBy",dataFactory.getLoggedInUser().mail);

            $scope.loadingVisible = true;
            $http.post(baseApiUrl+'/sampleMsg', fd, {
                transformRequest: angular.identity,
                headers: {
                    'Content-Type': undefined,
                    'access-token': $rootScope.accessToken
                }
            }).success(function(data) {
                toastr.success("created script");
				$scope.scriptAddForm=false;
                $scope.loadingVisible = false;
				initialiseScript();
            }).error(function(data) {
			    $scope.loadingVisible = false;
            });
	};

	function getAllScripts(){

	$http.get(baseApiUrl+'/sampleMsg', {
                    headers: {
                        'Content-Type': 'application/json',
                        'access-token': $rootScope.accessToken
                    }
                }).success(function(data) {
				$scope.allScripts=data;
                    console.log(data);
                }).error(function(data) {
                    console.log(data);
                });

	};

	//getAllScripts();

	$scope.deleteScript=function(script)
	{



	};


  $scope.SampleData1={
  code:`st=>start: Start | past
e=>end: End  | future
op1=>operation: ADT Interface | past
cond1=>condition: Validated? | past
op2=>operation: Copy file to HDFS | past
cond2=>condition: Copied? | past
op3=>operation: v2 to FHIR convertor | current
cond3=>condition: Converted? | future
op4=>operation: put FHIR resource into HBase  | future
err=>operation: error  | future

st->op1(right)->cond1
cond1(yes)->op2(right)->cond2
cond1(no)->err
cond2(yes)->op3(right)->cond3
cond2(no)->err
cond3(yes)->op4(right)->e
cond2(no)->err`

  };

	$scope.SampleData2={
  code:`st=>start: Start | past
e=>end: End  | future
op1=>operation: Carenet Interface | past
cond1=>condition: Validated? | past
op2=>operation: Copy file to HDFS | past
cond2=>condition: Copied? | past
op3=>operation: PPI | current
cond3=>condition: Converted? | future
op4=>operation: Put into HBase  | future
err=>operation: error  | future

st->op1(right)->cond1
cond1(yes)->op2(right)->cond2
cond1(no)->err
cond2(yes)->op3(right)->cond3
cond2(no)->err
cond3(yes)->op4(right)->e
cond2(no)->err`

  };
	$scope.displayPipe=function(id)
	{
	$scope.idForPipe=id;
	 ngDialog.open({
                template: 'Displaypipe',
                scope: $scope,
                closeByDocument: false
       });

	 setTimeout(function(){


	  var code;
       if (id == '1212-uuid') {
			code =$scope.SampleData2.code;
	   }
	   else {
		code =$scope.SampleData1.code;
	   }

	   chart = flowchart.parse(code);
                    chart.drawSVG('canvas',{'flowstate' : {
                       'past' : { 'fill' : '#CCCCCC', 'font-size' : 12},
                       'current' : {'fill' : 'yellow', 'font-color' : 'red', 'font-weight' : 'bold'},
                       'future' : { 'fill' : '#FFFF99'},
                    }});

	   },1000);


	};

	$scope.pipeline_Message=function(element){

	  $scope.sampleMessage=element.files[0];

	};

	$scope.ValidateChannel=function()
	{
  	var id='';
  	var skipFlag=false;
  	if($scope.idForPipe=='1212-uuid')
  	{
  	 id='8fc62dc8-4987-43d1-bcdd-d90f9c909115';
  	 skipFlag=true;
  	}
  	else{
  	id='8fc62dc8-4987-43d1-bcdd-d90f9c909115';

  	}

  	if(!skipFlag)
  	{
  	   var url = integrationEngineBaseUrl + '/channels/'+id+'/messages';
              var fd = new FormData();

              var rawessagedata = {
                  "binary": false,
                  "rawData": ''
              }
              fd.append("rawMessageDTO", JSON.stringify(rawessagedata));
              fd.append("rawMessage",  $scope.sampleMessage);
              $scope.loadingVisible = true;
              $http.post(url, fd, {
                  transformRequest: angular.identity,
                  headers: {
                      'Content-Type': undefined,
                      'access-token': $rootScope.accessToken
                  }
              }).success(function(data) {
                 // $scope.response = data;
                  $scope.statusOFValidation=data.status;
                  $scope.loadingVisible = false;


  				callProcessApi();






              }).error(function(data) {
  			 if (data&&data.errorCode == 'IE0010') {
                      dataFactory.logout();
                  }
                 else
  			   {
                  toastr.error(data.errorMessage);
  				}
                  $scope.loadingVisible = false;
              });
  	}


  		function callStatusApi(id){

  	var apiv=baseApiUrl+'/pipeline/instance/'+id;

  	$http.get(apiv, {
                 headers: {
                          'Content-Type': 'application/json',
                          'access-token': $rootScope.accessToken
                      }
              }).success(function(data) {
             console.log("final Data"+JSON.stringify(data));
              }).error(function(data) {

              });
  	};

  	function callProcessApi(){

  	var apiv=baseApiUrl+'/pipeline/process';
  	  var data={
         "id": "1213-uuid"
     };
  	$http.put(apiv, data, {
                 headers: {
                          'Content-Type': 'application/json',
                          'access-token': $rootScope.accessToken
                      }
              }).success(function(data) {
             $scope.ProcessOutput=data;

  		  var interval= setInterval(function(){

  		   callStatusApi(data.id);

  		   }, 2000);

              }).error(function(data) {

              });
  	};
 }; */
}]);
