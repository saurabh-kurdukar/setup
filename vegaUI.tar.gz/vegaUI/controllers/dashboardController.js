(function() {

angular
    .module('experienceApp.dashboardController', [])
    .controller('DashboardController', DashboardController);

DashboardController.$injector = ['$scope', '$rootScope', 'dataFactory', '$state','$http'];

function DashboardController($scope ,$rootScope ,dataFactory  ,$state,$http) {
    
    var callErrorHandler = function ( method , apiResponse, postApiDataSent){

     errorObj = {
                    controller : "ExperiencesController",
                    method : method,
                    postApiDataSent : postApiDataSent,
                    apiResponse : apiResponse
                }
                $rootScope.handleErrors ( errorObj );
        };    
    
	 $http.get('server/home.json', {
            }).success(function(data) {
            $scope.features=data;
              
            }).error(function(data) {
               console.log(data);
            });
    if($rootScope.isActivation)
    {
         $state.go('activation');
    }

    $scope.domainsMap = {};
    
    var init = function(){

	
	
	
        if( dataFactory.getLoginStatus() )
        {
            var domains = dataFactory.getDomains(); 
            if( domains.success || domains.error )
            {
                domains.success( function( response ){

                    populateDomainsMap( response );

                })
                .error( function( error ){
                    callErrorHandler("init", error, "error fetching domains.")               
                });
            }
            else
            {
                 populateDomainsMap( domains );
            }
        }
    };    

    var populateDomainsMap = function( domains ){
        domains.forEach( function( domain ,index ){

            domain.domainNameInLowerCase = domain.name.split(" ").join("").toLowerCase();
            domain.index = index;
            $scope.domainsMap[ domain.domainNameInLowerCase ] = domain;

        });
    }
    
    $scope.onGetStartedClick = function(){
        if( dataFactory.getLoginStatus() )
        {
            var userStatus = JSON.parse(localStorage.getItem('userStatus'));	 
            $scope.isSuperUser =  userStatus.isSuperUser;
            $scope.isAdmin = userStatus.isAdmin;
            $scope.isUser = userStatus.isUser;	
            if($scope.isSuperUser)
                $state.go('experiences');
			else if($scope.isUser||$rootScope.isAdmin){
				$state.go('yoursandbox');
			}
        }
        else{
            $state.go('login');
        }
        
    };    

    $scope.gotoExperiences = function( selectedDomain ){
        
        if( $scope.domainsMap[ selectedDomain ] )
        {
            /*dataFactory.setSelectedDomain( $scope.domainsMap[ selectedDomain ] );
            dataFactory.setSelectedDomainIndex( $scope.domainsMap[ selectedDomain ].index );*/
			console.log("$scope.domainsMap[ selectedDomain ].index",$scope.domainsMap[ selectedDomain ]);
			var filterData = { "domains" : [ $scope.domainsMap[ selectedDomain ].name ]};
			dataFactory.experienceFilter( filterData );
        }
        $scope.onGetStartedClick();
        
    };
	
    dataFactory.setCurrentState( "home" )
    dataFactory.hiddenNavbarFooter(false);
    init();
 
}
    
})();