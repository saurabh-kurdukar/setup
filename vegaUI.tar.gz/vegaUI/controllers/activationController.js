(function(){
    
    
angular
    .module('experienceApp.activationController', [])
    .controller('activationController', activationController);
    
activationController.$injector =  ['$scope', '$rootScope', 'dataFactory', '$state', '$stateParams'];    
    
function activationController($scope, $rootScope, dataFactory, $state, $stateParams) {
    
    $scope.showJourneyButton = false;
    
    var activationMessages = {};
    
    activationMessages.pre = "Please wait, Your account is being activated!";
    activationMessages.success = "Congratulations!! Your account is activated.";
    activationMessages.error = "An error has occurred.Please contact Vega Support Team.";
    
    var email = $rootScope.activation.e;
    var token = $rootScope.activation.t; 
    var u = $rootScope.activation.u; 
    
    $scope.onActivateClick = function (){
      dataFactory.hiddenNavbarFooter(false);
        
        $state.go('home');
    }
    
    dataFactory.setCurrentState("activation");
    dataFactory.hiddenNavbarFooter(true);
    $rootScope.isActivation = false;        
    
    if( ( email == undefined) || ( token == undefined ) || ( u == undefined ) )
    {
         $scope.activationMSG = activationMessages.error + "\n either email or token or user role missing.";
    
    }
    else
    {
    
    $scope.activationMSG = activationMessages.pre ;

        console.log("/********* Activating *******/");
        console.log("e",email,"t",token,"u",u);
    
        if(u == "PU")
        {
            dataFactory.checkActivationStatusPU( email ,token)
            .success( function( response ){
                $scope.activationMSG = activationMessages.success;
                $scope.showJourneyButton = true;
              console.log("success response",response);
            })
            .error( function( error ){
                 $scope.activationMSG = activationMessages.error+"\n"+error.errorMessage;
              console.log("error response",error);

            });
        }
        else
        {

            dataFactory.checkActivationStatus( email ,token)
            .success( function( response ){
                $scope.activationMSG = activationMessages.success;
                $scope.showJourneyButton = true;
              console.log("success response",response);
            })
            .error( function( error ){
                 $scope.activationMSG = activationMessages.error+"\n"+error.errorMessage;
              console.log("error response",error);

            });
        }
    }  
    
}    
    
})();