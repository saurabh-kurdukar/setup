/**=========================================================
 * Module: addExperienceController.js
 * Controller to add or update the new or existing experience
=========================================================*/
angular.module('experienceApp.forgotPasswordController', ['ngDialog','ui.bootstrap.tpls','ui.select','ngSanitize','ui.codemirror'])
.controller('integrationEngineController', ['$rootScope', '$scope', '$http', '$state', '$stateParams', '$compile', '$window','dataFactory','ngDialog',
    function($rootScope, $scope, $http, $state, $stateParams, $compile, $window,dataFactory,ngDialog) {
        $scope.name = '';
       // $scope.name = $stateParams.name;
	   $scope.name='Registration and Identity';
	   $scope.showAllDevices='Registration and Identity';
        $scope.myobj = {};
        if ($scope.name == '') {
            alert("Invalid url");
            console.log("Error : invalid url");
        }
		$rootScope.accessToken=$window.localStorage.accesstoken;

		dataFactory.setCurrentState("interfaces");

       $scope.integrationEngineServer=integrationEngineBaseUrl;

       // getChannelsByGroup($scope.name);
        $scope.interfaceActiveState = [false, false, false, false, false];
		$scope.selectedIndex=0;
		$scope.scripts=false;
        var rawMessagedata = {
                "binary": false,
                "rawData": ''
            }

  $scope.getChannels=function(value,index,flag){
         //selected index is for highlight selected interface
         $scope.showAllDevices=value;
         $scope.selectedIndex=index;
         $scope.name=value;
         $scope.formData.group=value;

	 $scope.InterfaceAddForm=false;
	 $scope.scriptsForms=false;
	 $scope.sampleForms=false;
     $scope.integrationForm=true;
     $scope.showChannelsTableFlag=true;
	 $scope.showAppForm = false; 	
	 $scope.showAddDestinationForm=false;
	 $scope.allDestinations=[];
	 $scope.forms={};
	  $scope.forms.destination={};
	 
    $('li.list-group-item').addClass('inactive-category');
	$('li.list-group-item').removeClass('active-category');
    $('li.list-group-item').first().toggleClass('inactive-category active-category');
  if(flag)
  { 
  if(! $(".interfaceCollapse").find('i').hasClass( "fa-minus" ))
    {
     $(".interfaceCollapse").find('i').toggleClass('fa-plus fa-minus');
    // $(".collapse-exp-devices").addClass('in');
	 $('.collapse-exp-devices').collapse('show');
    }
  }

		 getChannelsByGroup(value);
		};



        function initialise() {
            $scope.showAppForm = false;
            $scope.showEditFunctions = false;
            $scope.editInScript = false;
            $scope.editOutScript = false;
            $scope.editButtonEnable = false;
            $scope.formData = {};
            $scope.formData.group = $scope.name;
            $scope.formData.name = '';
            $scope.formData.description = '';
            $scope.formData.deploy = true;
            $scope.formData.sourceConnector = {};
            $scope.formData.sourceConnector.name = '';
            $scope.formData.sourceConnector.connectorType = '';
            $scope.formData.sourceConnector.inMessageType = '';
            $scope.formData.sourceConnector.outMessageType = '';
            $scope.formData.sourceConnector.host = '';
			$scope.formData.sourceConnector.script = '';
            $scope.allDestinations=[];
			$scope.allDestinationsScripts=[];
			$scope.showEditDestinationForm=false;
            /* $scope.destinationConnector = {};
            $scope.destinationConnector.connectorType = '';
            $scope.destinationConnector.messageType = '';
            $scope.destinationConnector.name = '';
            $scope.destinationConnector.fileName = '';
            $scope.destinationConnector.directoryPath = '';
            $scope.destinationConnector.outboundTemplate = '';
			$scope.destinationConnector.script = ''; */
        };

        initialise();

		$scope.checkUserExist = function(name){
			$http.get($scope.integrationEngineServer + '/interfaces?name='+name, {
				headers: {
					'Content-Type': 'application/json',
					'access-token': $rootScope.accessToken
				}
			}).success(function(data) {
				$scope.usernameExists = true;
			}).error(function(data) {
				$scope.usernameExists = false;
			});
		}


        $scope.listOfChannels = [];
        var row = '';
        $scope.scripts = [];
        $scope.response = {};
		$scope.mirthDashboardOn=false;

        $scope.load_image = function(element) {
            $scope.file = '';
            var index = angular.element(element).scope().$index;
            $scope.listOfChannels[index].validationMessage = true;
            $scope.file = element.files[0];
        }

        $scope.inboundload_Script = function(element) {
            $scope.scripts[0] = element.files[0];
        }

        $scope.outboundload_Script = function(element) {
            $scope.scripts[1] = element.files[0];
        }


        $scope.addNewChannel = function() {
            $scope.showAppForm = true;
			$scope.AddnewScript=false;
			$scope.AddnewOutScript=false;
			$scope.showAddDestinationForm=false;
            //$scope.uploadForm.$setPristine();
            $('.maxAreaWidth').attr("style", "");
        };
        $scope.cancelAppForm = function() {
           // $scope.uploadForm.$setPristine();
            $scope.showAppForm = false;
			$scope.showAddDestinationForm=false;
            $('.maxAreaWidth').attr("style", "");
            initialise();
        };

		$scope.getOutTransScript=function(script){

		     //script.scriptFileLocation;

		};




        function getChannelsByGroup(groupname) {
            $scope.loadingVisible = true;
			$scope.mirthDashboardOn=false;
			$scope.currentGroupName=groupname;
            $http.get($scope.integrationEngineServer + '/channels?group=' + groupname, {
                headers: {
                    'Content-Type': 'application/json',
                    'access-token': $rootScope.accessToken
                }
            }).success(function(data) {
                $scope.listOfChannels = processDataNames(data);
                $scope.loadingVisible = false;
                /* if (data.length <= 15) {
                    setTimeout(function() {
                        $('#integrationWizard .dataTables_paginate').hide();
                    }, 500);

                } else {
                    $('#integrationWizard .dataTables_paginate').show();
                } */

            }).error(function(data) {
			 $scope.loadingVisible = false;
                if (data&&data.errorCode == 'IE0010') {
                    dataFactory.logout();
                }
               else
			   {
                toastr.error("Unable to load Channels");
				}
            });

        }




        function handleFileSelect(evt) {
            evt.stopPropagation();
            evt.preventDefault();

            var files = evt.dataTransfer.files; // FileList object.

        };


        function processDataNames(data) {
            for (var i = 0; i < data.length; i++) {
                if (data[i].sourceConnector && data[i].sourceConnector.inMessageType == 'HL7V2') {
                    data[i].sourceConnector.inMessageType = 'HL7 V2.x';
                }
				 if (data[i].sourceConnector && data[i].sourceConnector.inMessageType == 'HL7V3') {
                    data[i].sourceConnector.inMessageType = 'HL7 V3.x';
                }
				
				if (data[i].sourceConnector && data[i].sourceConnector.outMessageType == 'HL7V2') {
                    data[i].sourceConnector.outMessageType = 'HL7 V2.x';
                }
				 if (data[i].sourceConnector && data[i].sourceConnector.outMessageType == 'HL7V3') {
                    data[i].sourceConnector.outMessageType = 'HL7 V3.x';
                }
				
                if (data[i].destinationConnector.length)
				{
				  for(var j=0;j<data[i].destinationConnector.length;j++)
				   {
					if(data[i].destinationConnector[j].inMessageType == 'HL7V2')
					    {
						 data[i].destinationConnector[j].inMessageType = 'HL7 V2.x';
						}
					if(data[i].destinationConnector[j].inMessageType == 'HL7V3')
					    {
						 data[i].destinationConnector[j].inMessageType = 'HL7 V3.x';
						}
					if(data[i].destinationConnector[j].outMessageType == 'HL7V2')
					    {
						 data[i].destinationConnector[j].outMessageType = 'HL7 V2.x';
						}
					if(data[i].destinationConnector[j].outMessageType == 'HL7V3')
					    {
						 data[i].destinationConnector[j].outMessageType = 'HL7 V3.x';
						}
				   }
				 data[i].destinationConnector = handleDuplicateNames(data[i].destinationConnector,false);
                }
            }
            return data;
        };

		
		// add new channel
        $scope.submitChannelForm = function() {
           // console.log(JSON.stringify($scope.formData));
            ngDialog.open({
                template: 'createChannelProgress',
                scope: $scope,
                closeByDocument: false
            });
            $scope.response.Message = '';
            $scope.response.progress = 0;
            $scope.response.isError = false;
            $scope.response.errorMessage = '';

            var fd = new FormData();
            if ($scope.scripts[0]) {
                fd.append("inboundTransformationScript", $scope.scripts[0]);
            }
            if ($scope.allDestinationsScripts.length>0) 
			{
			   for(var i=0;i<$scope.allDestinationsScripts.length;i++)
			  {
			    fd.append("outboundTransformationScript", $scope.allDestinationsScripts[i]);
				var tempFileName=$scope.allDestinations[i].fileName.split(".");
				$scope.allDestinations[i].fileName=tempFileName[0]+"_${date.get('yyyy-M-d_H.m.s')}."+tempFileName[1];
			  }   
			  
            // fd.append("outboundTransformationScript", $scope.allDestinationsScripts);   
            }
			
			
			if($scope.formData.sourceConnector.connectorType=='MLLP')
     		{
 		      $scope.formData.sourceConnector.host='0.0.0.0';
 		   }
			$scope.formData.destinationConnector=[];
			$scope.formData.destinationConnector=handleDuplicateNames($scope.allDestinations,true);
			
			
			
			
            fd.append("channelDTO", angular.toJson($scope.formData));
            var id = setInterval(frame2, 700);
				$http.post($scope.integrationEngineServer + '/channels', fd, {
					transformRequest: angular.identity,
					headers: {
						'Content-Type': undefined,
						'access-token': $rootScope.accessToken
					}
				}).success(function(data) {
					//toastr.success("Created new Channel");
					 $scope.response.Message = 'Channel Created \n Please Open required Port to use the channel';
					 getChannelsByGroup($scope.formData.group);
					 initialise();
					 $scope.showAppForm = false;
					 $scope.loadingVisible = false; 
				}).error(function(data) {
					$scope.loadingVisible = false;
					$scope.response.isError = true;
					clearInterval(id);
					if (data&&data.errorCode == 'IE0010') {
						dataFactory.logout();
					}
					if (data) {
						$scope.response.errorMessage = data.errorMessage;
						$scope.response.progress = 100;
					}
				});


            function frame2() {
                $http.get($scope.integrationEngineServer + '/channels/status/1', {
                    headers: {
                        'Content-Type': 'application/json',
                        'access-token': $rootScope.accessToken
                    }
                }).success(function(data) {
                    console.log(data);
                    $scope.response.Message = data;
                    if (!$scope.response.isError) {
                        if (data == "Validating Channel Data") {
                            $scope.response.progress = $scope.response.progress + 2;
                        }
                        if (data == "Creating Channel") {
                            $scope.response.progress = 50;
                        } else if (data == "adding channel to group") {
                            $scope.response.progress = 70;
                        } else if (data == "Deploying Channel") {
                            $scope.response.progress = 90;
                        } else if (data == "Done") {
						 $scope.response.Message = 'Channel Created . Please Open required Port to use the channel';
                            $scope.response.progress = 100;
                            clearInterval(id);
                        }
                    }
                }).error(function(data) {
                    console.log(data);
                });
            }
        };

        $scope.ValidateChannel = function(entity) {
            var url = $scope.integrationEngineServer + '/channels/' + entity.id + '/messages';
            var fd = new FormData();
            $scope.file='';
           
            fd.append("rawMessageDTO", JSON.stringify(rawMessagedata));
           // fd.append("rawMessage", $scope.file);
            $scope.loadingVisible = true;
            $http.post(url, fd, {
                transformRequest: angular.identity,
                headers: {
                    'Content-Type': undefined,
                    'access-token': $rootScope.accessToken
                }
            }).success(function(data) {
                $scope.response = data;
                setTimeout(function() {
                    var objrow = row.clone();
                    objrow.empty();
                    objrow.append("<td colspan='3'></td>");
                    var resultDiv = $("#validationResultBox").clone();
                    $(resultDiv).removeAttr("id");
                    resultDiv.css('display', 'block');
                    objrow.children().eq(0).append(resultDiv);
                    $(objrow).insertAfter($(row));
                }, 500);
                $scope.loadingVisible = false;
            }).error(function(data) {
			 if (data&&data.errorCode == 'IE0010') {
                    dataFactory.logout();
                }
               else
			   {
                toastr.error(data.errorMessage);
				}
                $scope.loadingVisible = false;
            });

        };

        $("#integrationMain").on('click', '.validationBtn', function() {
            row = $(this).parent().parent();
            $(row).next().has(".validationBox").remove();

        });

        $("#integrationMain").on('click', '.closeResultBox', function() {
            $(this).parents().eq(4).remove();
        });


        $scope.selectInterface = function(index, value) {
            for (var i = 0; i < $scope.interfaceActiveState.length; i++) {
                if (i == index) {
                    $scope.interfaceActiveState[i] = true;
                } else {
                    $scope.interfaceActiveState[i] = false;
                }
            }
            $scope.formData.group = value;
            getChannelsByGroup($scope.formData.group);
            initialise();
        };

        $scope.editChannelForm = function(data) {
            initialise();
			// $scope.formData = data;
			 angular.copy(data,$scope.formData);
            $scope.formData.sourceConnector.port = parseInt($scope.formData.sourceConnector.port);
			//angular.copy(data.destinationConnector,$scope.destinationConnector);
			$scope.allDestinations = handleDuplicateNames(data.destinationConnector,false);
			for(var i=0;i<$scope.allDestinations.length;i++)
			{
			 $scope.allDestinationsScripts.push('');
			}
            if ($scope.formData.sourceConnector.inMessageType == 'HL7 V2.x') {
                $scope.formData.sourceConnector.inMessageType = 'HL7V2';
            }
			if ($scope.formData.sourceConnector.outMessageType == 'HL7 V2.x') {
                $scope.formData.sourceConnector.outMessageType = 'HL7V2';
            }
			if ($scope.formData.sourceConnector.inMessageType == 'HL7 V3.x') {
                $scope.formData.sourceConnector.inMessageType = 'HL7V3';
            }
			if ($scope.formData.sourceConnector.outMessageType == 'HL7 V3.x') {
                $scope.formData.sourceConnector.outMessageType = 'HL7V3';
            }
          /*   if ($scope.destinationConnector.messageType == 'HL7 V2.x') {
                $scope.destinationConnector.messageType = 'HL7V2';
            } */
			if ($scope.allDestinations.length)
				{
				  for(var j=0;j<$scope.allDestinations.length;j++)
				   {
					if($scope.allDestinations[j].inMessageType == 'HL7 V2.x')
					    {
						$scope.allDestinations[j].inMessageType = 'HL7V2';
						}
					if($scope.allDestinations[j].inMessageType == 'HL7 V3.x')
					    {
						$scope.allDestinations[j].inMessageType = 'HL7V3';
						}
					if($scope.allDestinations[j].outMessageType == 'HL7 V2.x')
					    {
						$scope.allDestinations[j].outMessageType = 'HL7V2';
						}
					if($scope.allDestinations[j].outMessageType == 'HL7 V3.x')
					    {
						$scope.allDestinations[j].outMessageType = 'HL7V3';
						}
				     var tempFileName=$scope.allDestinations[j].fileName.replace("_${date.get('yyyy-M-d_H.m.s')}", "");
				     $scope.allDestinations[j].fileName=tempFileName;
				   }
				  
                }
			
			
			//$scope.allDestinations=$scope.destinationConnector;    
            $scope.editButtonEnable = true;
            $scope.editInScript = true;
            $scope.editOutScript = true;
            $scope.showAppForm = true;
			$scope.showAddDestinationForm=false;
        };

        $scope.showEditableField = function(type) {
            if (type == 'inScript') {
            delete $scope.formData.sourceConnector.script;
                $scope.editInScript = false;
            }
            if (type == 'outScript') {		
			 delete $scope.allDestinations[$scope.editDestinationIndex].script;
                $scope.editOutScript = false;
            }

        };

        $scope.editChannel = function() {
            console.log(JSON.stringify($scope.formData));
            var fd = new FormData();
            var formData = angular.copy($scope.formData);
            delete formData.id;
            var id = $scope.formData.id;
			formData.destinationConnector=[];
			formData.destinationConnector=handleDuplicateNames($scope.allDestinations,true);     
			
            if ($scope.scripts[0]) {
                fd.append("inboundTransformationScript", $scope.scripts[0]);
            }
             for(var i=0;i<$scope.allDestinationsScripts.length;i++)
			  {
			  fd.append("outboundTransformationScript", $scope.allDestinationsScripts[i]);
			    var tempFileName=$scope.allDestinations[i].fileName.split(".");
				if(!tempFileName[1])
				{
				tempFileName[1]="txt";
				}
				$scope.allDestinations[i].fileName=tempFileName[0]+"_${date.get('yyyy-M-d_H.m.s')}."+tempFileName[1];
			  }
			  
			if($scope.formData.sourceConnector.connectorType=='MLLP')
 		     {
			 $scope.formData.sourceConnector.host='0.0.0.0';
			 }
			 else
			 {
			 delete formData.sourceConnector.port;
			 console.log("deleted port");
			 }
			
            fd.append("channelDTO", angular.toJson(formData));
            $scope.loadingVisible = true;
            $http.put($scope.integrationEngineServer + '/channels/' + id + '/update', fd, {
                transformRequest: angular.identity,
                headers: {
                    'Content-Type': undefined,
                    'access-token': $rootScope.accessToken
                }
            }).success(function(data) {
                toastr.success("Updated Channel");
                getChannelsByGroup($scope.formData.group);
                initialise();
                $scope.showAppForm = false;
                $scope.loadingVisible = false;
            }).error(function(data) {
			        $scope.loadingVisible = false;
                if (data&&data.errorCode == 'IE0010') {
                    dataFactory.logout();
                }
                else if (data) {
                    toastr.error(data.errorMessage);
                }
            });

        }

        $scope.deployChannel = function(entity) {
		$scope.entity=entity;
            $scope.loadingVisible = true;
			var data='';
            $http.post($scope.integrationEngineServer + '/channels/deploy/' + entity.id,data, {
                headers: {
                    'Content-Type': 'application/json',
                    'access-token':$rootScope.accessToken
                }
            }).success(function(data) {
              //  toastr.success("deployed Channel");
	    	      autoValidateMessage($scope.entity.name);
               // getChannelsByGroup($scope.formData.group);
                $scope.loadingVisible = false;
            }).error(function(data) {
                $scope.loadingVisible = false;
                if (data&&data.errorCode == 'IE0010') {
                    dataFactory.logout();
                }
                else {
                    toastr.error("Error Occurred while deploying channel");
                }
            });
            ngDialog.close();

        };

        $scope.undeployChannel = function(entity) {
		$scope.entity=entity;
            $scope.loadingVisible = true;
			var data='';
            $http.post($scope.integrationEngineServer + '/channels/undeploy/' + entity.id,data, {
                headers: {
                    'Content-Type': 'application/json',
                    'access-token': $rootScope.accessToken
                }
            }).success(function(data) {
                toastr.success("Undeployed Channel");
                getChannelsByGroup($scope.formData.group);
                $scope.loadingVisible = false;
            }).error(function(data) {
                $scope.loadingVisible = false;
                if (data&&data.errorCode == 'IE0010') {
                    dataFactory.logout();

                }
                else if (data) {
                    toastr.error(data.errorMessage);
                }
            });
            ngDialog.close();


        };
        $scope.closePopUp = function() {
            ngDialog.close();
        };

        $scope.deployChannelBox = function(entity) {

            $scope.ChannelIdForDeployement = entity.id;
			$scope.entity=entity;
            ngDialog.open({
                template: 'deployConfirmBox',
                scope: $scope,
                closeByDocument: false

            });

        };

        $scope.deleteChannelConfirmBox = function(entity) {
            $scope.ChannelIdForDeployement = entity.id;
            ngDialog.open({
                template: 'deleteChannelTemplete',
                scope: $scope,
                closeByDocument: false
            });
        };


        $scope.deleteChannel = function() {
            $scope.loadingVisible = true;
            $http.delete($scope.integrationEngineServer + '/channels/' + $scope.ChannelIdForDeployement, {
                headers: {
                    'Content-Type': 'application/json',
                    'access-token': $rootScope.accessToken
                }
            }).success(function(data) {
                toastr.success("Deleted channel successfully");
                getChannelsByGroup($scope.formData.group);
                $scope.loadingVisible = false;
            }).error(function(data) {
                $scope.loadingVisible = false;
                if (data&&data.errorCode == 'IE0010') {
                    dataFactory.logout();
                }
				else
				{
                toastr.error("Delete Channel Failed");
                 }
            });
            ngDialog.close();
        }


		$scope.goToMirth=function()
		{
		  $scope.selectedIndex=0;
		  $scope.mirthDashboardOn=true;

		};

		
		
		

function autoValidateMessage(id){

$http.get('./vendor/sampleMsgs/'+id+'.txt').success(function(datamsg) {				
        if(datamsg)
           {
       		 datamsg=transformData(datamsg) ;
		     var fd = new FormData();
            var rawessagedata = {
                "binary": false,
                "rawData": datamsg
            }
			var url = $scope.integrationEngineServer + '/channels/' + $scope.entity.id + '/messages';
            fd.append("rawMessageDTO", JSON.stringify(rawessagedata));
            $scope.loadingVisible = true;
          $http.post(url, fd, {
						transformRequest: angular.identity,
						headers: {
							'Content-Type': undefined,
							'access-token': $rootScope.accessToken
						}
					}).success(function(data) {
					    toastr.success("Channel deployed and passed message");
						getChannelsByGroup($scope.formData.group);
						$scope.loadingVisible = false;
					}).error(function(data) {			
					   toastr.warning("Channel deployed but could not pass message");
						getChannelsByGroup($scope.formData.group);
						$scope.loadingVisible = false;
					});
	  }else
	  {
	        toastr.success("Channel deployed without passing message");
            getChannelsByGroup($scope.formData.group);
            $scope.loadingVisible = false;
	  }
}).error(function(data) {
  getChannelsByGroup($scope.formData.group);
  toastr.success("Channel deployed without passing message");
});

};

function transformData(data)
{

   var today = new Date();
var dd = today.getDate();
var mm = today.getMonth()+1; //January is 0!
var yyyy = today.getFullYear();

if(dd<10) {
    dd='0'+dd
}

if(mm<10) {
    mm='0'+mm
}
var time= today.getHours() + ":"
                + today.getMinutes() + ":"
                + today.getSeconds();
today = mm+'/'+dd+'/'+yyyy+'/'+time;

   data=data.replace(/000010702/g, "000010702_auto_"+today);
   data=data.replace(/Violet.M.Phelps@direct.mihintest.org/g, "Violet.M.Phelps@direct.mihintest.org_auto_"+today);
   data=data.replace(/Encounter-64439/g, "Encounter-64439_auto_"+today);
   data=data.replace(/Encounter-63590/g, "Encounter-64439_auto_"+today);
   data=data.replace(/Encounter-65667/g, "Encounter-64439_auto_"+today);

   console.log(data);
   return data;
};


$scope.scriptsForms=false;
$scope.integrationForm=true;
$scope.sampleForms=false;
$scope.connectorsForm=false;
$scope.dataTypesForm=false;
$scope.showChannelsTableFlag=false;
$scope.interfaceForm={};
$scope.InterfaceAddForm=false;
$scope.editInterfaceFlag=false;

    $scope.openScripts=function(){
	$scope.scriptsForms=true;
	$scope.sampleForms=false;
	$scope.integrationForm=false;
	$scope.connectorsForm=false;
	$scope.dataTypesForm=false;
	$scope.selectedIndex=0;
	};


	$scope.openSamples=function(){
	 $scope.scriptsForms=false;
	 $scope.sampleForms=true;
     $scope.integrationForm=false;
	 $scope.connectorsForm=false;
	 $scope.dataTypesForm=false;
	 $scope.selectedIndex=0;
	};
	
	$scope.openConnectors=function(){
	$scope.scriptsForms=false;
	$scope.sampleForms=false;
	$scope.integrationForm=false;
	$scope.connectorsForm=true;
	$scope.dataTypesForm=false;
	$scope.selectedIndex=0;
	};

	$scope.openDataTypes=function(){
	$scope.scriptsForms=false;
	$scope.sampleForms=false;
	$scope.integrationForm=false;
	$scope.connectorsForm=false;
	$scope.dataTypesForm=true;
	$scope.selectedIndex=0;
	};
	$scope.openIntegration=function(){
	 $scope.selectedIndex=0;
	 $scope.InterfaceAddForm=false;
	 $scope.dataTypesForm=false;
	 $scope.connectorsForm=false;
	 $scope.scriptsForms=false;
	 $scope.sampleForms=false;
     $scope.integrationForm=true;
     $scope.showChannelsTableFlag=false;
	 getAllScripts();
	 getAllMessages();
	};

	$scope.addNewInterface=function(){
	 $scope.InterfaceAddForm=true;
	  $scope.interfaceForm={};
	 $scope.interfaceForm.name='';
	 $scope.interfaceForm.description='';
	 
	};

	$scope.cancelInterfaceForm=function(){
	 $scope.InterfaceAddForm=false;
	 $scope.interfaceForm={};
	 $scope.interfaceForm.name='';
	 $scope.interfaceForm.description='';
	 $scope.editInterfaceFlag=false;
	};


	function getAllScripts(){
     $scope.allScripts=[];
	 var tempData={};
		tempData.name="Loading.... Please wait";
		tempData.script="";
		$scope.allScripts.push(tempData);
	$http.get(baseApiUrl+'/script', {
                    headers: {
                        'Content-Type': 'application/json',
                        'access-token': $rootScope.accessToken
                    }
                }).success(function(data) {
				
				$scope.allScripts=data;
				var newData={};
				newData.name="Add New Script";
				newData.script="";
				$scope.allScripts.unshift(newData); 
				
                }).error(function(data) {
				 if (data&&data.httpResponseCode == 401) {
                    dataFactory.logout();
                }
                    console.log(data);
                });

	};
	getAllScripts();
	
	
	function getAllMessages(){

	$http.get(baseApiUrl+'/sampleMsg', {
                    headers: {
                        'Content-Type': 'application/json',
                        'access-token': $rootScope.accessToken
                    }
                }).success(function(data) {
				$scope.allSampleMessages=data;
                }).error(function(data) {
				 if (data&&data.httpResponseCode == 401) {
                    dataFactory.logout();
                }
                    console.log(data);
                });

	};
	
	getAllMessages();

	

	function getAllInterfaces(){
	$scope.loadingVisible = true;
	$http.get($scope.integrationEngineServer+'/interfaces', {
                    headers: {
                        'Content-Type': 'application/json',
                        'access-token': $rootScope.accessToken
                    }
                }).success(function(data) {
				$scope.allInterfaces=data;
                    //console.log(data);
					$scope.loadingVisible = false;
                }).error(function(data) {
				 if (data&&data.httpResponseCode == 401) {
                    dataFactory.logout();
                }
                    console.log(data);
					$scope.loadingVisible = false;
                });


	};

	getAllInterfaces();


	$scope.submitInterfaceForm=function()
	{
	        $scope.loadingVisible = true;
            $http.post($scope.integrationEngineServer + '/interfaces',$scope.interfaceForm, {
                headers: {
                    'Content-Type': 'application/json',
                    'access-token': $rootScope.accessToken
                }
            }).success(function(data) {
                toastr.success("Created Interface");
                getAllInterfaces();
				$scope.InterfaceAddForm=false;
                $scope.loadingVisible = false;
            }).error(function(data) {
                $scope.loadingVisible = false;
                if (data&&data.errorCode == 'IE0010') {
                    dataFactory.logout();
                }
                else if (data) {
                    toastr.error(data.errorMessage);
                }
            });

	};

   
	$scope.ScriptChange=function(script,source){
	 if(script.name.toLowerCase()=='loading.... please wait')
	 {
	    return;
	 }
	if(script.name.toLowerCase()=='add new script')
	{
		if(source)
		{
		   $scope.AddnewScript=true;
		   $scope.formData.sourceConnector.script='';
		}
    else{
	    $scope.AddnewOutScript=true;
	    $scope.destinationConnector.script='';
	   }
	return;
	}
	else{
	  if(source)
	   {
	   $scope.AddnewScript=false;
	   }
	   else{
	   $scope.AddnewOutScript=false;
	   }
	  
	}
	
	
 $scope.loadingVisible = true;	

 $http.get(script.scriptFileLocation, {
                    headers: {
                        'Content-Type': 'text/plain' 
                    }
                }).success(function(data) {
				if(source)
				  {
			       $scope.formData.sourceConnector.script=data;
				  }
				 else
				 {
				  $scope.destinationConnector.script=data;
				 }
				  $scope.loadingVisible = false;
                }).error(function(data) {
                    console.log(data);
				  $scope.loadingVisible = false;
                });
	};
	
	$scope.MessageChange=function(messages){
	 $scope.loadingVisible = true;
	    $http.get(messages.messageFileLocation).success(function(data) {				
                 if((typeof data)=='object')
                   {
				   data=JSON.stringify(data)
				   }						   
				rawMessagedata.rawData=data;
                    $scope.loadingVisible = false;				
                }).error(function(data) {
                    console.log("error"+data);
					$scope.loadingVisible = false;		
                });

	};
	
	$scope.undeployAllChannels=function(){
	  var channelList=[];
	for(var i=0;i<$scope.listOfChannels.length;i++)
	 {
	  channelList.push($scope.listOfChannels[i].id);
	 }
	
	 $scope.loadingVisible = true;	
	$http.post($scope.integrationEngineServer + '/channels/undeployAll',channelList, {
                    headers: {
                    'Content-Type': 'application/json',
                    'access-token': $rootScope.accessToken
                }
                }).success(function(data) {				
                    $scope.loadingVisible = false;	
               getChannelsByGroup($scope.currentGroupName) ;
           
			$scope.currentGroupName					
                }).error(function(data) {
                    console.log(data);
					$scope.loadingVisible = false;		
                });
	};
	
	$scope.editInterfaceForm=function(data)
	{
	   $scope.editInterfaceFlag=true;
	   $scope.InterfaceAddForm=true;
	   $scope.interfaceForm=data;
	  
	};
	
	$scope.editInterface=function()
	{
	   $scope.loadingVisible = true;
            $http.put($scope.integrationEngineServer + '/interfaces',$scope.interfaceForm, {
                headers: {
                    'Content-Type': 'application/json',
                    'access-token': $rootScope.accessToken
                }
            }).success(function(data) {
                toastr.success("Interface Updated");
                getAllInterfaces();
				$scope.InterfaceAddForm=false;
                $scope.loadingVisible = false;
            }).error(function(data) {
                $scope.loadingVisible = false;
                if (data&&data.errorCode == 'IE0010') {
                    dataFactory.logout();
                }
                else if (data) {
                    toastr.error(data.errorMessage);
                }
            });
	
	};
	
	
  $scope.updateDestinationInType=function(){
	  if($scope.destinationConnector)
	$scope.destinationConnector.inMessageType =$scope.formData.sourceConnector.outMessageType;
	
	for(var i=0;i<$scope.allDestinations.length;i++)
		{
		 $scope.allDestinations[i].inMessageType=$scope.formData.sourceConnector.outMessageType;
		}		
	  
  };	
	
$scope.addDestinationForm=function(){
    $scope.showAddDestinationForm=true;
	setTimeout(function(){
		$scope.forms.destination.$setPristine();
	},50);
	$scope.showEditDestinationForm=false;
	$scope.editOutScript=false;
	$scope.destinationConnector = {};
	$scope.destinationConnector.connectorType = '';
	$scope.destinationConnector.inMessageType = $scope.formData.sourceConnector.outMessageType;
	$scope.destinationConnector.outMessageType = '';
	$scope.destinationConnector.name = '';
	$scope.destinationConnector.fileName = '';
	$scope.destinationConnector.directoryPath = '';
	$scope.destinationConnector.outboundTemplate = '';
	$scope.destinationConnector.script = '';
	$scope.AddnewOutScript=false;
	$scope.selectedDestScript='';
	$("#outboundScipt").val('');
	$scope.scripts[1]='';
	

};


$scope.closeDestinationForm=function(){
    $scope.showAddDestinationForm=false;
};
$scope.addDestination=function(data){
    $scope.showAddDestinationForm=false;
	
	//console.log(data);
	$scope.allDestinations.push(data);
	
	if($scope.scripts[1]!='')
	{
      $scope.allDestinationsScripts.push($scope.scripts[1]);	
	}
	else
	{
	 $scope.allDestinationsScripts.push('');	
	}
};
$scope.updateDestination=function(data){
    $scope.showAddDestinationForm=false;
	
	//console.log(data);
	$scope.allDestinations[$scope.editDestinationIndex] = data;
	if($scope.scripts[1]!='')
	{
      $scope.allDestinationsScripts[$scope.editDestinationIndex] = $scope.scripts[1];	
	}
	else
	{
	 $scope.allDestinationsScripts[$scope.editDestinationIndex]='';
	}
};


$scope.editDestinationIndex='';
$scope.editDestinationForm=function(data,index){
   $scope.editDestinationIndex=index;
   $scope.editOutScript=true;
   $scope.showEditDestinationForm=true;
    $scope.showAddDestinationForm=true;
					if(data.inMessageType == 'HL7 V2.x')
					    {
						data.inMessageType = 'HL7V2';
						}
					if(data.inMessageType == 'HL7 V3.x')
					    {
						data.inMessageType = 'HL7V3';
						}
					if(data.outMessageType == 'HL7 V2.x')
					    {
						data.outMessageType = 'HL7V2';
						}
					if(data.outMessageType == 'HL7 V3.x')
					    {
						data.outMessageType = 'HL7V3';
						}
	$scope.destinationConnector=data;
};
$scope.deleteDestination=function(index){
    $scope.showAddDestinationForm=false;
	$scope.allDestinations.splice(index, 1);
	$scope.allDestinationsScripts.splice(index, 1);
};

function handleDuplicateNames(connector,flag)
{
	
if(flag)
{
	for(var i=0;i<connector.length;i++){
		count=1;
		for(var j=i+1;j<connector.length;j++){
			var n=connector[i].name.localeCompare(connector[j].name) 
			if(n==0){
				count=count+1;
				connector[j].name=connector[j].name+"-"+count;
			}
		}
		if(count!=1)
			connector[i].name=connector[i].name+"-1";
	}
}
else
{
 for(var i=0;i<connector.length;i++)
 {
	 var index=connector[i].name.indexOf("-");
	if(index>-1)
	{
	var temp=connector[i].name.split("-");
	connector[i].name=temp[0];
	}		
	 
 }
}
return connector;
	
}


	
}]);
