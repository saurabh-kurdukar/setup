(function() {

angular
    .module('experienceApp.expGuideController', [])
    .controller('expGuideController', expGuideController);


expGuideController.$injector =  ['$scope', '$rootScope', 'dataFactory', '$state', '$stateParams'];

function expGuideController($scope, $rootScope, dataFactory, $state, $stateParams) {

    dataFactory.setCurrentState("experience-guide");
    
    
    var callErrorHandler = function (method, apiResponse, postApiDataSent) {
        errorObj = {
            controller: "expDetailsController",
            method: method,
            postApiDataSent: postApiDataSent,
            apiResponse: apiResponse
        }
        $rootScope.handleErrors(errorObj);
    };    
    
    var init = function(){
            dataFactory.getAllDocuments()
            .success(function(response){
                $scope.expGuideList = response;
            })
            .error(function(error){
                callErrorHandler("init", error, "get all documenst failed");
            })
        }
    init();
}

})();