(function(){
    
angular
    .module('experienceApp.adminDocController', [])
    .controller('adminDocController', adminDocController);
                                       
adminDocController = ['$scope', '$rootScope', 'dataFactory', '$state', '$stateParams'];
    
function adminDocController($scope, $rootScope, dataFactory, $state, $stateParams) {

    dataFactory.setCurrentState("admin-docs");
    
    $scope.adminDocs = 
        [
            {
				"name" : "Installation Guide",
                "url"  :  "./Documentation/Admin/Vega_Installation_Guide.docx",
                "format" : "docx"
            },
            {
				"name" :"Maintenance Guide",
                "url"  :  "./Documentation/Admin/Vega_Maintenance_Guide.docx",
                "format" : "docx"
            },
            {
				"name" : "Experience Provisioning Guide",
                "url"  :  "./Documentation/Admin/Experience_Provisioning_Guide.docx",
                "format" : "docx"
            }				
        ];    
    
    $scope.docIcons =
        {
             "docx" : "./img/word_icon.png",
             "ppt"  : "",
             "pdf"  : "./img/pdf_icon.png",
             "excel": "./img/exl_icon.png"
          }
}      
    
})();    