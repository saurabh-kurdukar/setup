(function(){
angular
    .module('experienceApp.forgotPassword', [])
    .controller('forgotPasswordController', forgotPasswordController);

    forgotPasswordController.$injector =  ['$scope', '$rootScope', 'dataFactory','$uibModal'];

    function forgotPasswordController($scope, $rootScope, dataFactory,$uibModal) {
	  $scope.user={};
	   $scope.captchaError=false;
	
        $scope.captchaRefresh = function () {
            var captchaData = dataFactory.getCaptcha();
            captchaData.success(function (data) {
                $scope.catcheImg = 'data:image/jpeg;base64,' + base64ArrayBuffer(data.captchaImage.data);
                $scope.catchecode = data.captchaCode;
            });

            function base64ArrayBuffer(arrayBuffer) {
                var base64 = '';
                var encodings = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/';
                var bytes = new Uint8Array(arrayBuffer);
                var byteLength = bytes.byteLength;
                var byteRemainder = byteLength % 3;
                var mainLength = byteLength - byteRemainder;
                var a, b, c, d;
                var chunk;
                for (var i = 0; i < mainLength; i = i + 3) {
                    chunk = (bytes[i] << 16) | (bytes[i + 1] << 8) | bytes[i + 2] ;
                    a = (chunk & 16515072) >> 18 ;
                    b = (chunk & 258048) >>12 ;
                    c = (chunk & 4032) >> 6 ;
                    d = chunk & 63 ;
                    base64 += encodings[a] + encodings[b] + encodings[c] + encodings[d];
                }
                if (byteRemainder == 1) {
                    chunk = bytes[mainLength] ;
                    a = (chunk & 252) >> 2 ;
                    b = (chunk & 3) << 4 ;
                    base64 += encodings[a] + encodings[b] + '==';
                } else if (byteRemainder == 2) {
                    chunk = (bytes[mainLength] << 8) | bytes[mainLength + 1] ;
                    a = (chunk & 64512) >> 10 ;
                    b = (chunk & 1008) >> 4 ;
                    c = (chunk & 15) << 2 ;
                    base64 += encodings[a] + encodings[b] + encodings[c] + '=';
                }
                return base64;
            }
        };
        $scope.captchaRefresh();
		
		$scope.resetPasswordBtn=function(size){
		$scope.apiErrorOccured=false;
		$scope.captchaError = false;
		if ($scope.user.captcha != $scope.catchecode) {
		      $scope.captchaError = true;
			  return;
		}
		// call api and goto login page
		var resetData={
		"username":$scope.user.email
		}
		dataFactory.forgetPassword(resetData).then(function successCallback(response, status, headers, config) {
                     var  modalInstance  =  $uibModal.open({      
                animation: $scope.animationsEnabled,
                      templateUrl:   'showForgetPasswordPopUp.html',
                      controller:   'modalInstController',
                      scope : $scope,
                      size: size,
                      resolve: {}    
            });             
                 
                }, function errorCallback(error) {
                  //  $scope.disableLoginButton = false;                    
                    console.log("Error in forgot password",error);
					$scope.apiErrorOccured=true;
					$scope.error=error;
                    $scope.captchaRefresh();
                    
                });
		
		
		
		
		
		
		};
		
		
		
    }

})();