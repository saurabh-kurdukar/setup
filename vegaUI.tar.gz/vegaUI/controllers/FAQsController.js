(function(){
angular
    .module('experienceApp.FAQsCtrl', [])
    .controller('FAQsCtrl', FAQsCtrl);

FAQsCtrl.$injector =  ['$scope', '$rootScope', 'dataFactory'];

    function FAQsCtrl($scope, $rootScope, dataFactory) {
        var previousState = dataFactory.getCurrentState();
        dataFactory.setCurrentState('faq-doc');
        
    }

})();