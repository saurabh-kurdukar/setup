/**=========================================================
 * Module: tryItController
 * 
 =========================================================*/
angular
    .module('experienceApp.tryItvisualization', ['datatables','ui.codemirror']).controller('tryItController', ['$http', '$scope', '$timeout','ngDialog','dataFactory','$rootScope','$window','$state', function($http, $scope, $timeout,ngDialog,dataFactory,$rootScope,$window,$state) {
	
		dataFactory.setCurrentState("dataLake");
	$rootScope.accessToken=$window.localStorage.accesstoken;
	$scope.tryItData={};
	$scope.tryItData.queryLink='';
	$scope.tryItData.script='';
	$scope.tryItData.queryData='';
	$scope.tryItData.scriptEditor='';
    var QueryData='';
	$scope.themeName='default';
	$scope.editvisualizationFlag=false;
  function initialiseForm(){	
	$scope.scriptForm={};
	$scope.scriptForm.version='';
	$scope.scriptForm.description='';
	$scope.scriptForm.name='';
	}
	initialiseForm();


	
	var myVisualizationData=dataFactory.setVisualizationData();
	console.log(myVisualizationData);
	
	
	
	$scope.getScripts=function()
  {
    $scope.saveFormFlag=false;
	console.log($scope.tryItData.scriptEditor);
	if($scope.tryItData.scriptEditor!="")
	{
	$http.get($scope.details.jsCode).success(function(response)
 		{		       		
        $scope.tryItData.scriptEditor="var queryString=\""+$scope.tryItData.queryLink+"\";\n\n"+	
	     "$.ajax({\n"+
         "url:'"+vegaFhirBaseUrl+"/Query/$execute',\n"+
         "data:\"query=\"+queryString,"+"\n"+
         "success: function(queryData) {\n\n"+  
         "//**Transformation Script**/\n\n\n"+
         "//Graph script\n\n"+response+"\n"+		     		 
         "}})";
	
        }).error(function(data) {
            console.log(data);
        });   
	}
	else{	
        $scope.tryItData.scriptEditor=$scope.tryItData.scriptEditor+"\n";
	}
  };
	
	
	
	if(myVisualizationData.referenceId)
	{
	 $scope.details=myVisualizationData.referenceId;
	 $scope.scriptForm.name=myVisualizationData.name;
	 $scope.scriptForm.description=myVisualizationData.description;
	 $scope.scriptForm.version=myVisualizationData.version;
	 $scope.scriptForm.tags=myVisualizationData.tags;
	 $scope.tryItData.queryLink=myVisualizationData.queryString;	
	 console.log(myVisualizationData.transformationScriptLocation);
	 $http.get(myVisualizationData.transformationScriptLocation).success(function(response)
 		{		  
console.log(response);		
         $scope.tryItData.scriptEditor=response;
		// $scope.getScripts();
	
        }).error(function(data) {
            console.log(data);
        }); 
	$scope.editvisualizationFlag=true;

	}
	else{
	  $scope.details=myVisualizationData;
	  $scope.tryItData.scriptEditor='';
	  $scope.getScripts();
	}
			
	 $scope.editorOptions = {
          lineNumbers: true,
          styleActiveLine: true,
          matchBrackets: true
    };
	   

  
$scope.getScripts();



	
$scope.selectTheme=function(themeName){
	$scope.theme=themeName;
	 $scope.editorOptions = {
          lineNumbers: true,
          styleActiveLine: true,
          matchBrackets: true,
		  theme:$scope.themeName
      };
	
	};
	
	$scope.displayVisualizationSample=function()
	{
     var data=$scope.details;
     for(var i=0;i<data.dependentFiles.length;i++)
       {	         
	   if(data.dependentFiles[i].includes('.js')||data.dependentFiles[i].includes('.JS'))
	        { 
	          loadScripts([data.dependentFiles[i]],function(){    
             });
			}  else
			  {
			  $("<link/>", {
                  rel: "stylesheet",
                  type: "text/css",
                  href: data.dependentFiles[i],
                 }).appendTo("head");
			  
			  }
	   }
	};
	
	$scope.displayVisualizationSample();
	   
	
	function loadScripts(array,callback){
    var loader = function(src,handler){
        var script = document.createElement("script");
        script.src = src;
        script.onload = script.onreadystatechange = function(){
            script.onreadystatechange = script.onload = null;
            handler();
        }
        var head = document.getElementsByTagName("head")[0];
        (head || document.body).appendChild( script );
    };
    (function run(){
        if(array.length!=0){
            loader(array.shift(), run);
        }else{
            callback && callback();
        }
    })();
};
 function callback(json) {
        console.log(json);
    }	
	
	
	
//need to modify 
	$scope.executeQuery=function()
	{
	
	    $scope.loadingVisible = true;
        $http.get(vegaFhirBaseUrl+'/Query/$execute?query='+$scope.tryItData.queryLink, {
                    headers: {
                        'Content-Type': 'application/json',
                        //'access-token': $rootScope.accessToken
                    }
                }).success(function(data) {
				$scope.tryItData.queryData=data;
			   setTimeout(function(){  $('#queryDatatable').DataTable(); }, 1000);
               
				$scope.loadingVisible = false;
                }).error(function(data) {
				if (data&&data.httpResponseCode == 401) {
                    dataFactory.logout();
                }
                    console.log(data);
					$scope.loadingVisible = false;
                });
	
	};
	
   
	
$scope.evaluateScript=function()
{
	 $scope.ScriptFail=false;
	 $scope.ScriptSuccess=false;
	  QueryData=$scope.tryItData.queryData; 

	 
	//  var index=$scope.tryItData.scriptEditor.indexOf('/**');
	  // var queryString=$scope.tryItData.scriptEditor.substring(6,index);
	   
	   
	   $scope.loadingVisible = true;
				
	//var evaluationScript=$scope.tryItData.scriptEditor.replace($scope.tryItData.scriptEditor.substring(0,index),'');
	   try {
	        eval($scope.tryItData.scriptEditor);
           } catch (e) 
		   {
           if (e instanceof SyntaxError) 
		     {
              $scope.ScriptFail=true;
		      alert("ERROR in script:",e);
            }
          }
				
		$scope.loadingVisible = false;
	   
};
	
	$scope.openGallary=function(myVisuals){
	$state.go('dataLake'); 
	dataFactory.previousTabs(myVisuals);
	};
	
	$scope.closeDetails=function(){
	$state.go('dataLake'); 
	};
	
	function getAllVisualization(){
	
	$http.get(baseApiUrl+'/visualization', {
                    headers: {
                        'Content-Type': 'application/json',
                        'access-token': $rootScope.accessToken
                    }
                }).success(function(data) {
				 $scope.allScripts=data;
				  $scope.loadingVisible = false;
                  //  console.log(data);
                }).error(function(data) {
				if (data&&data.httpResponseCode == 401) {
                    dataFactory.logout();
                }
                    console.log(data);
					  $scope.loadingVisible = false;
                });

	};
	getAllVisualization();
	
$scope.saveScript=function()
{
  $scope.saveFormFlag=true;

};

$scope.cancelScriptForm=function(){
   $scope.saveFormFlag=false;
};

$scope.submitScriptForm=function(){

$scope.scriptForm.username=dataFactory.getLoggedInUser().mail;
$scope.scriptForm.createdBy=dataFactory.getLoggedInUser().mail;
//$scope.scriptForm.queryString=$scope.tryItData.queryLink;
$scope.scriptForm.transformationScript=$scope.tryItData.scriptEditor;
$scope.scriptForm.referenceId=$scope.details.id;
var tags = [];
if($scope.scriptForm.tags)
 {
	 for(var i=0;i<$scope.scriptForm.tags.length;i++)
	 {
	 tags.push($scope.scriptForm.tags[i]['text']);
	 }
 }
 $scope.scriptForm.tags = tags;
 $scope.loadingVisible = true;
$http.post(baseApiUrl+'/myVisualization',$scope.scriptForm, {
                    headers: {
                        'Content-Type': 'application/json',
                        'access-token': $rootScope.accessToken
                    }
                }).success(function(data) {
				toastr.success("Visualization saved");
				$scope.loadingVisible = false;
				 $scope.saveFormFlag=false;
                }).error(function(data) {
				if (data&&data.httpResponseCode == 401) {
                    dataFactory.logout();
                }
                    console.log(data);
					  $scope.loadingVisible = false;
                });

};
	
$scope.editScriptForm=function(){
$scope.scriptForm.username=dataFactory.getLoggedInUser().mail;
$scope.scriptForm.updatedBy=dataFactory.getLoggedInUser().mail;
//$scope.scriptForm.queryString=$scope.tryItData.queryLink;
$scope.scriptForm.transformationScript=$scope.tryItData.scriptEditor;
$scope.scriptForm.referenceId=$scope.details.id;
var tags = [];
if($scope.scriptForm.tags)
 {
	 for(var i=0;i<$scope.scriptForm.tags.length;i++)
	 {
	 tags.push($scope.scriptForm.tags[i]['text']);
	 }
 }
 $scope.scriptForm = tags;
 $scope.loadingVisible = true;
$http.put(baseApiUrl+'/myVisualization/'+myVisualizationData.id,$scope.scriptForm, {
                    headers: {
                        'Content-Type': 'application/json',
                        'access-token': $rootScope.accessToken
                    }
                }).success(function(data) {
				toastr.success("Visualization updated");
				$scope.loadingVisible = false;
				 $scope.saveFormFlag=false;
                }).error(function(data) {
				if (data&&data.httpResponseCode == 401) {
                    dataFactory.logout();
                }
                    console.log(data);
					  $scope.loadingVisible = false;
                });
};
	
}]);
