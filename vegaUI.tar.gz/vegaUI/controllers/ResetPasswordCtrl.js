(function(){
    
angular
    .module('experienceApp.resetPasswordCtrl', ['ui.bootstrap'])
    .controller('ResetPasswordCtrl', ResetPasswordCtrl);
                
    ResetPasswordCtrl.$injector = ['$scope', '$rootScope', 'dataFactory', '$state','$uibModal','$location','$state'];

function ResetPasswordCtrl($scope, $rootScope, dataFactory, $state,$uibModal,$location,$state) {
    var previousState = dataFactory.getCurrentState();
    dataFactory.setCurrentState('resetPwd');
     $scope.resetData={};
	 $scope.resetData =$location.search();
	$scope.resetData.password='';
	$scope.resetData.confirmPassword='';
	$scope.captchaError=false;
	$scope.resetPasswordError=false;
	$scope.changeUserpassword=false;
	
	if(!($scope.resetData&&$scope.resetData.username))
	{
	 $scope.loggedInUser = dataFactory.getLoggedInUser();
	   if(!($scope.loggedInUser && $scope.loggedInUser.username))
	   {
	     $state.go('login'); 
		 return;
	   }
	   $scope.changeUserpassword=true;
	   $scope.resetData.username= $scope.loggedInUser.username;	   
	}
	
	$scope.changeUserPasswordFn=function(size){
	$scope.captchaError=false;
	if($scope.resetData.password!=$scope.resetData.confirmPassword)
	{
	   $scope.captchaError=true;
	   return;
	}
	
	
	var myPostData={
	'userpassword':$scope.resetData.password,
	'currentpassword':$scope.resetData.oldPassword  
	}
	dataFactory.ResetPasswordFn(myPostData,$scope.resetData.username).then(function successCallback(response, status, headers, config) {
                     var  modalInstance  =  $uibModal.open({      
                animation: $scope.animationsEnabled,
                      templateUrl:   'showResetPasswordPopUp.html',
                      controller:   'modalInstController',
                      scope : $scope,
                      size: size,
                      resolve: {}    
            });             
                  //  $state.go('login');
                }, function errorCallback(error) {
                    $scope.resetPasswordError=true; 
					 $scope.Error={};
					if(error && (error.code==410||error.code=='410'))
					{
					  $scope.Error.errorMessage="URL Expired"	
					}	
                    else{
                         $scope.Error=error;
                     }					
                    console.log("Error in reset password",error);                  
                });
	
	};
	
	
	
	$scope.resetUserPassword=function(size){
	$scope.captchaError=false;
	if($scope.resetData.password!=$scope.resetData.confirmPassword)
	{
	   $scope.captchaError=true;
	   return;
	}
	
	
	var myPostData={
	'userpassword':$scope.resetData.password,
	'tokenId':$scope.resetData.tokenId,
	'confirmationId':$scope.resetData.confirmationId,   
	}
	dataFactory.forgotResetPassword(myPostData,$scope.resetData.username).then(function successCallback(response, status, headers, config) {
                     var  modalInstance  =  $uibModal.open({      
                animation: $scope.animationsEnabled,
                      templateUrl:   'showResetPasswordPopUp.html',
                      controller:   'modalInstController',
                      scope : $scope,
                      size: size,
                      resolve: {}    
            });             
                  //  $state.go('login');
                }, function errorCallback(error) {
                    $scope.resetPasswordError=true;     
                    $scope.Error={};					
                   if(error && (error.code==410||error.code=='410'))
					{
					  $scope.Error.errorMessage="URL Expired"	
					}	
					else{
                         $scope.Error=error;
                     }						
                    console.log("Error in reset password",error);                  
                });
	
	};
	
	
        //    Content goes here for Reset Password Flow
    $scope.backToLastPage = function () {
        if (previousState == '' || previousState == undefined) {
            $state.go('home');
        } else {
            $state.go(previousState);
        }
    }
}
    
})();

