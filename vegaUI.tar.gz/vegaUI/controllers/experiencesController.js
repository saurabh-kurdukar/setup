(function(){

angular
    .module('experienceApp.experiencesController', [])
	.controller('ExperiencesController', ExperiencesController);
	
	ExperiencesController.$injector = ['$scope', '$rootScope', 'dataFactory', '$state', '$q','$timeout'];	
	
	function ExperiencesController($scope, $rootScope, dataFactory, $state, $q, $timeout) {
    
        dataFactory.setCurrentState("experiences");
        dataFactory.hiddenNavbarFooter(false);
        
        //binded variables
		$scope.cartMap = {};
		$scope.provisionMap = {};
        $scope.expMsg
            //filter options
        $scope.devices = [{name : "Mobile"}, {name : "Tablet"}, {name : "Desktop"}, {name : "Wearable"}];
        $scope.platforms = [{name : "Android"}, {name : "Windows"}, {name : "IOS"}, {name : "Web App"}];
        $scope.classifications = [{name : "Employee"}, {name : "Product"}, {name : "Customer"}, {name : "Partner"}, {name : "Topline"}, {name : "Productivity"}, {name : "Bottomline"}, {name : "Satisfaction"}];
        $scope.disableFilters = false;   
        $scope.hideExperienceCheckbox = true;
        
        //binded functions
        $scope.addRemoveExperience = addRemoveExperience;
		$scope.populateDeviceFlags = populateDeviceFlags;        
        $scope.viewSandboxButtonText = viewSandboxButtonText;
        $scope.experienceCheckBoxText = experienceCheckBoxText;
        $scope.onExpInit = onExpInit;
        $scope.goToSandbox = goToSandbox;
        $scope.goToExpDetails = goToExpDetails;
        
        //non binded variables
        var selectedCompany = dataFactory.lastSandboxSelection();
        var selectedCompanyName = selectedCompany.company.companyName;
        var allSelectedMessage = 'You have already provisioned all experiences';
        var selectionMessage =  'Select experiences to provision';
        var viewButtonText = "View My sandbox"; 
        var currentCartSuccessCount = 0;//to control overlapping of cart success messages
		var filterFlag = false; 
		
		var filterData = dataFactory.experienceFilter();
		if(filterData  instanceof Array)
			filterData = {};
		if(filterData && (Object.keys(filterData).length > 0) )
		{
			filterFlag = true;
			if(!filterData.deviceSupported)
				filterData.deviceSupported = [];//for all 4 keys
			if(!filterData.domains)
				filterData.domains = [];	
			if(!filterData.classification)
				filterData.classification = [];
			if(!filterData.platforms)
				filterData.platforms = [];
		}
		else
		{
			 filterData = {  
				"deviceSupported":[],
				"domains":[],
				"classification":[],
				"platforms":[]
			};
		}
		
		
        var allExperiences = [];
        
        if(selectedCompanyName == undefined)
        {
            selectedCompanyName =  "My Sandbox";
        }


        if ( (selectedCompany.type != "") && (selectedCompany.company != undefined) && (selectedCompany.company.companyId != undefined) && (selectedCompany.type != "Select Sandbox") && (selectedCompany.type != "Create Sandbox") )
        {
            if( selectedCompany.type != "My Sandbox")
            {
                 allSelectedMessage = 'You have already allocated all experiences for ' + selectedCompany.company.companyName;
                 selectionMessage =  'Select experiences to allocate for ' + selectedCompany.company.companyName;

                viewButtonText = "View Allocated experiences";
            }

            $scope.hideExperienceCheckbox = false;
        }
        else
        {
            allSelectedMessage = 'Explore Experiences';
            selectionMessage =  'Explore Experiences';       
            $scope.hideExperienceCheckbox = true;
        }

        $scope.expMsg = selectionMessage; 
        
        
        
	
	    function callErrorHandler (method, apiResponse, postApiDataSent) {
			errorObj = {
				controller: "expDetailsController",
				method: method,
				postApiDataSent: postApiDataSent,
				apiResponse: apiResponse
			}
			$rootScope.handleErrors(errorObj);
		};
		
		function init(){
            $('#cartPopup').hide();
			getDomains(true);		            
            if(!$scope.hideExperienceCheckbox)
            {
                getCartExperiences(true);
                getProvisionedExperiences(true);
            }
			getExperiences(true);
		}
		init();
        
        function onExpInit(experience) {
            populateDeviceFlags(experience);
        }
		
		function getDomains(showLoading){
			
			dataFactory.getDomainsV2(showLoading)
			.then(domainSuccess)
			.catch(domainFailure);			
			
			function domainSuccess(response) {
				$scope.domains = response;
				for(var obj in $scope.domains){
                    $scope.domains[obj].isSelected=false;
                    filterData.domains.forEach(function(d, index){
                        if (d == $scope.domains[obj].name) {
                            $scope.domains[obj].isSelected=true;
                        }
                    });
                }
			}					
			
			function domainFailure(error) {
				callErrorHandler("getDomains", error, "error fetching domains")
			}			
		};
		
		function getCartExperiences(showLoading){
	
			//first arguments to true forces fetching data from api
			dataFactory.getExperienceFromCartByOrgIdV2(false, showLoading)
			.then(cartSuccess)
			.catch(cartFailure);
			
			function cartSuccess(response) {
				
				var cartMap = {};
				response.forEach(function(cartItem){
					cartMap[cartItem.expId] = cartItem;
				});
				$scope.cartMap = cartMap;
				
				//$scope.cartExperiences = response;
			}					
			
			function cartFailure(error) {
				callErrorHandler("getCartExperiences", error, "error fetching Cart Experiences");
			}
			
		};
		
		function getProvisionedExperiences( showLoading ){
	
			dataFactory.getProvisionedExperiencesV2( showLoading )
				.then(provExpSuccess)
				.catch(provExpFailure);
				
			function provExpSuccess(response) {
				response.forEach(function(provExp){
					$scope.provisionMap[provExp.experienceId] = provExp.experienceId;
				});
				//$scope.provisionedExperiences = response;
				
			}					
			
			function provExpFailure(error) {
				callErrorHandler("getProvisionedExperiences", error, "error fetching Provisioned Experiences");
			}
			
		};
		
		function getExperiences( showLoading ){
	
			dataFactory.getExperiencesV2( showLoading )
				.then(expSuccess)
				.catch(expFailure);
				
			function expSuccess(response) {
                allExperiences = JSON.parse(JSON.stringify(response));  
				filterData.domains=[];
          filterData.domains.push('Health Care');
          filterExperiences(filterData);				
				if(filterFlag)
				filterExperiences(filterData);
				else
					$scope.experiences = response;				
			}					
			
			function expFailure(error) {
				callErrorHandler("getExperiences", error, "error fetching Experiences");
			}
			
		};		
		
	function addRemoveExperience(isSelected, experience) {
		experience.disable = true;
		if(isSelected)
			removeFromCart(experience);
		else
			addToCart(experience);
	}		

	function addToCart(experience) {
        experience.isSelected = true;
		dataFactory.addExperienceToCartV2(experience.id, false, true)
		.then(cartAddSuccess)
		.catch(cartAddFailure);
		
		function cartAddSuccess(response){
			experience.disable = false;
           // experience.isSelected = true;
			$scope.cartMap[response.expId] = response;
			//$scope.cartExperiences.push(response);
			showCartMessage(experience, 'allocated to ');
		}
		function cartAddFailure(error){
			experience.disable = false;	
            //experience.isSelected = false;            
			callErrorHandler("addToCart", error, experience);
		}
		
		function showCartAddFailure(experience) {
			$scope.popupMSg = 'fail to allocate' + experience.name + ' to ' + selectedCompanyName;			
		}
	}
        

        
    function showCartMessage(experience, type) {
        if(currentCartSuccessCount == 0)
        {
            $scope.popupMSg = 'Congratulations ! '+ experience.name +' has been ' + type + selectedCompanyName;  
            $("#popupMSg").html($scope.popupMSg);
            currentCartSuccessCount = 1;
            $('#cartPopup').show();                
            $timeout(function(){ 
                console.log("$scope.allocateMsg", $scope.allocateMsg);                    
                $('#cartPopup').hide();
                currentCartSuccessCount = 0;                     
                 //$scope.allocateMsg = false;
            }, 2000);

        }
        else
        {
            setTimeout(function(){            
                showCartMessage(experience, type); 
            }, 2000);                
        }
    }        

	function removeFromCart(experience) {
        experience.isSelected = false;		
        var cartItemId = $scope.cartMap[ experience.id ].cartItemId;
		dataFactory.deleteExperienceFromCartV2( cartItemId, false, true)
		.then(cartRemoveSuccess)
		.catch(cartRemoveFailure);
		
		function cartRemoveSuccess(response){
			experience.disable = false;
       //   experience.isSelected = false;  
			showCartMessage(experience, 'de-allocated from ');
			delete $scope.cartMap[experience.id];			
		}
		function cartRemoveFailure(error){
			experience.disable = false;		
            //experience.isSelected = true;                        
			callErrorHandler("removeFromCart", error, experience);
		}
		
		function showCartRemoveSuccess(experience) {
			$scope.popupMSg = experience.name +' has been de-allocated from '+ selectedCompanyName+' successfully';
		}
        
		
		function showCartRemoveFailure(experience) {
			$scope.popupMSg = 'fail to allocate' + experience.name + ' to ' + selectedCompanyName;			
		}
		
	}
		
	function populateDeviceFlags (experience) {
	   
		 experience.androidAppOffered = stringToBool(experience.androidAppOffered);
		 experience.webAppOffered = stringToBool(experience.webAppOffered);
		 experience.iOSAppOffered = stringToBool(experience.iOSAppOffered);
		 experience.wearableOffered = stringToBool(experience.wearableOffered);
		 
		if (experience.deviceSupported && (experience.deviceSupported.length > 0)) 
			
			experience.deviceSupported.forEach(function (device) {
			if (device == "Both iPhone and iPad") {
				experience.iphoneCompitable = true;
				experience.ipadCompitable = true;
			} else if (device == "iPhone Only") {
				experience.iphoneCompitable = true;
				experience.ipadCompitable = false;
			} else if (device == "iPad Only") {
				experience.ipadCompitable = true;
				experience.iphoneCompitable = false;
			}
		});
		 
	};
		
    function stringToBool( str ){
        if(!str)
        {
            console.log("strstrstr", str);
            return false;
        }
        if(typeof str == "boolean")
            return str;
        if(  str.toLowerCase() == "true" )
            return true;
        return false;
    }
        
	function viewSandboxButtonText(){
        return viewButtonText;
    }
        
    //returns checkbox text basede on Experience status
    function experienceCheckBoxText(experience)
    {
        if( $scope.provisionMap[experience.id] )
            {
                experience.isSelected = true;
                return "Provisioned";
            }
        if( $scope.cartMap[experience.id] )
        {
            if(!experience.disable)// to immediately allow checkbox to be checked else it would only be checked on reciving response
                experience.isSelected = true;
            if(selectedCompany.type != "My Sandbox")
                return "Allocated";
            else
                return "Added to sandbox";
        }
        else
        {         
            if(!experience.disable)// to immediately allow checkbox to be checked else it would only be checked on reciving response
                experience.isSelected = false;
        }
        
        if(selectedCompany.type != "My Sandbox")
            return "Allocate Experience";
        return "Add to sandbox"
    }
        
    //filter functions
        
    $scope.onDomainSelect = function(domain, isSelected) {
        if(isSelected)
            filterData.domains.push(domain.name);
        else
        {
            filterData.domains.forEach(function(d, index){
                if( domain.name == d )
                {
                    filterData.domains.splice(index, 1);
                    return;
                }
            });
        }
        filterExperiences(filterData);
    };
    
    $scope.onDeviceSelect = function(device, isSelected) {
        
        var deviceName = device.name.toUpperCase().split(' ').join('');
        if(isSelected)
            filterData.deviceSupported.push(deviceName);
        else
        {
            filterData.deviceSupported.forEach(function(d, index){
                if(d == deviceName)
                {
                    filterData.deviceSupported.splice(index, 1);
                    return;
                }
            });
        }
        filterExperiences(filterData);       
    };
    
    $scope.onPlatformSelect = function(platform, isSelected) {
        
        var platformName = platform.name.toUpperCase().split(' ').join('');
        if(isSelected)
            filterData.platforms.push(platformName);
        else
        {
            filterData.platforms.forEach(function(p, index){
                if(p == platformName)
                {
                    filterData.platforms.splice(index, 1);
                    return;
                }
            });
        }
        filterExperiences(filterData);           
    };
    
    $scope.onClassificationSelect = function(classification, isSelected) {
        if(isSelected)
            filterData.classification.push(classification.name);
        else
        {
            filterData.classification.forEach(function(c, index){
                if(c == classification.name)
                {
                    filterData.classification.splice(index, 1);
                    return;
                }
            });
        }
        filterExperiences(filterData);     
    };
    
    var filterExperiences = function(filterData)
    {
        $scope.disableFilters = true;
        var data = JSON.parse(JSON.stringify(filterData));

  /*      if(data.deviceSupported.length == 0)//to be enebled when filter called from api
            delete data.deviceSupported;
        if(data.domains.length == 0)
            delete data.domains;
        if(data.classification.length == 0)
            delete data.classification;
        if(data.platforms.length == 0)
            delete data.platforms;*/
        var deviceSupported = data.deviceSupported;
        var domains = data.domains;
        var classification = data.classification;
        var platforms = data.platforms;
        
        var filteredData = [];
        var keys = Object.keys(data);
        var experiences = JSON.parse(JSON.stringify(allExperiences));

        if( deviceSupported.length > 0)
        {        
            for(var i=0; i<experiences.length; i++) {
                    var devices = experiences[i].deviceSupported;
                    for(var j=0; j<devices.length; j++)
                        for(var k=0; k< deviceSupported.length; k++)
                        {
                            if( devices[j] ==  deviceSupported[k] )
                            {
                                filteredData.push(experiences[i]);
                                j = 5000;
                                break;
                            }
                        }
            }
        }
        
        if( deviceSupported.length > 0)
        {
            experiences = filteredData;
            filteredData = [];
        }
            
        if( domains.length > 0)
        {
           for(var i=0; i<experiences.length; i++) {                
                var domain = experiences[i].domain;
                for(var j=0; j< domains.length; j++)
                {
                        if( domain ==  domains[j] )
                        {
                            filteredData.push(experiences[i]);
                            break;
                        }
                }
            }
        }
        
        if( domains.length > 0)
        {
            experiences = filteredData;
            filteredData = []; 
        } 
        
        if( platforms.length > 0)
        {
            var iOSAppOffered = false;
            var androidAppOffered = false;
            var windowsAppOffered = false;
            var webAppOffered = false;
            
            platforms.forEach(function(platform){
                if(platform ==  "ANDROID")
                    androidAppOffered = true;
                if(platform ==  "IOS")
                    iOSAppOffered = true;
                if(platform ==  "WINDOWS")
                    windowsAppOffered = true;
                if(platform ==  "WEBAPP")
                    webAppOffered = true;
            });    
        
            for(var i=0; i<experiences.length; i++) {
                
                var found = false;
                if( androidAppOffered && stringToBool(experiences[i].androidAppOffered) )
                    found = true;
                else if( iOSAppOffered && stringToBool(experiences[i].iOSAppOffered) )
                    found = true;
                else if( windowsAppOffered && stringToBool(experiences[i].windowsAppOffered) )
                    found = true;
                else if( webAppOffered && stringToBool(experiences[i].webAppOffered) )
                    found = true;

                if(found)
                    filteredData.push(experiences[i]);
            }
        }
        
        if( platforms.length > 0)
        {
            experiences = filteredData;
            filteredData = [];            
        }        
            
        if( classification.length > 0)
        {
            for(var i=0; i<experiences.length; i++) {
                var classifications = experiences[i].classification;
                for(var j=0; j<classifications.length; j++)
                    for(var k=0; k< classification.length; k++)
                    {
                        if( classifications[j] ==  classification[k] )
                        {
                            filteredData.push(experiences[i]);
                            j = 5000;
                            break;
                        }
                    }
            }    
        }
        
        if( classification.length > 0)
        {
            experiences = filteredData;
            filteredData = []; 
        }
                   
        
        console.log("filteredData", experiences);
		if(experiences.length > 0)
			dataFactory.experienceFilter(data);
        $scope.experiences = experiences;
        $scope.disableFilters = false;
        
    }



	
    //end filter functions
	$scope.isHealthCareSandbox=false;
	if(isHealthCareSandBox)
	{
	 var companyId = selectedCompany.company.companyId;
	 if(companyId){
	 
	 dataFactory.fetchCompanybyIdV2(companyId)
                    .then(companyFetchSuccess)
                    .catch(companyFetchFailure);
	        function companyFetchSuccess(response)
				{
				  if(response.companyAddress && response.companyAddress=='healthCareBox')
				  {
                   console.log("************got healthCareBox");				   
 				  
				   var flagfil=false;
				   filterData.domains.forEach(function(d, index){
                          if('Health Care' == d )
                         {
                           flagfil=true;
                         }
                       });
				      if(!flagfil)
				         {
				          filterData.domains.push('Health Care');
				          }
				   $scope.isHealthCareSandbox = true;	
				   filterExperiences(filterData);              			   
				  }
				  else{
				  filterData.domains.forEach(function(d, index){
                  if('Health Care' == d )
                  {
                    filterData.domains.splice(index, 1);
                  }
                 });
				  $scope.isHealthCareSandBox=false;
				  }
                 
				}
				function companyFetchFailure(error)
				{
				  console.log("error in get company");
				}	
				
				}
	}
	
	
        
    function goToExpDetails(exp) {
        dataFactory.setSelectedDomain($scope.selectedDomain);
        dataFactory.setSelectedDomainIndex($scope.selectedDomainIndex);
        dataFactory.setSelectedExperience(exp);
        dataFactory.previousState('experiences');
        $state.go('expDetails');
    }
        
	function goToSandbox() {
		$state.go('sa-yourSandbox');
	}    
		

		
	}
	
})();


