(function(){

angular
    .module('experienceApp.developerDocController', [])
    .controller('developerDocController', developerDocController);

developerDocController.$injector =  ['$scope', '$rootScope', 'dataFactory', '$state', '$stateParams'];

 function developerDocController($scope, $rootScope, dataFactory, $state, $stateParams) {

    dataFactory.setCurrentState("developer-docs");
    
    $scope.developerDocs = 
        [
            {
				"name" : "Experience Creator Guide",
                "url"  :  "./Documentation/Developer/Experience_Creator_Dev_Guide.docx",
                "format" : "docx"
            },
            {
				"name" :"API Catalogue",
                "url"  :  "./Documentation/Developer/Vega_API_Catalogue.docx",
                "format" : "docx"
            },
            {
				"name" : "eMee Dev Guide",
                "url"  :  "./Documentation/Developer/Vega_eMee_Dev_Guide.docx",
                "format" : "docx"
            },
            {
				"name" : "Hoopz Dev Guide",
                "url"  :  "./Documentation/Developer/Vega_Hoopz_Dev_Guide.docx",
                "format" : "docx"
            },
            {
				"name" : "OIAM Dev Guide",
                "url"  :  "./Documentation/Developer/Vega_OIAM_Dev_Guide.docx",
                "format" : "docx"
            },
            {
				"name" : "SI Dev Guide",
                "url"  :  "./Documentation/Developer/Vega_SI_Dev_Guide.docx",
                "format" : "docx"
            },
            {
				"name" : "Design Style Guidelines",
                "url"  :  "./Documentation/Developer/Design_Style_Guidelines_Vega.pptx",
                "format" : "ppt"
            }				
        ];
    
        $scope.docIcons =
            {
                 "docx" : "./img/word_icon.png",
                 "ppt"  : "./img/pdf_icon.png",
                 "pdf"  : "./img/pdf_icon.png",
                 "excel": "./img/exl_icon.png"
              }    
    
    
}
    
})();