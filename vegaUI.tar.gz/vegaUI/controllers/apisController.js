/**=========================================================
 * Module: dataLakeController
 * Setup options and data for flot chart 
 =========================================================*/
angular
    .module('experienceApp.apis', []).controller('apisController', ['$http', '$scope', '$timeout','ngDialog','dataFactory','$rootScope','$window', function($http, $scope, $timeout,ngDialog,dataFactory,$rootScope,$window) {
	dataFactory.setCurrentState("apis");
	$scope.fhir_swaggerUrl=api_fhir_SwaggerUrl;	
	$scope.integration_swaggerUrl=api_intgrationEngine_SwaggerUrl;
	$scope.openEmpi_swaggerURl=api_openEmpi_swaggerURl;
	$scope.vega_swaggerURl=api_vega_swaggerURl;
     $http.get('server/apis.json', {
            }).success(function(data) {
             $scope.allApis=data;
            }).error(function(data) {
               console.log(data);
            });
		
}]);
