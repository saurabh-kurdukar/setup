/**=========================================================
* Module: dataLakeController
* Setup options and data for flot chart 
=========================================================*/
angular
.module('experienceApp.connectors', ['ui.codemirror'])
.controller('connectorController', ['$http', '$scope', 'dataFactory','$rootScope','$window', function($http, $scope, dataFactory,$rootScope,$window) {
	$rootScope.accessToken=$window.localStorage.accesstoken;
	$scope.connectorView = 'list';
	$scope.loadingVisible = true;
	function getAllConnectors(){
		$scope.messages = 'list';
		$scope.loadingVisible = true;
		$http.get('server/connectors.json').success(function(data) {
			$scope.allConnectors=data;
			$scope.loadingVisible = false;
		}).error(function(data) {
			$scope.loadingVisible = false;
			if (data&&data.httpResponseCode == 401) {
				dataFactory.logout();
			}
			console.log(data);
		});
	};
	getAllConnectors();
}]);
