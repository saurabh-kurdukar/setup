/**=========================================================
* Module: dataLakeController
* Setup options and data for flot chart 
=========================================================*/
angular
.module('experienceApp.datatypes', ['ui.codemirror'])
.controller('dataTypeController', ['$http', '$scope', 'dataFactory','$rootScope','$window', function($http, $scope, dataFactory, $rootScope, $window) {
	$rootScope.accessToken=$window.localStorage.accesstoken;
	$scope.dataView = 'list';
	$scope.loadingVisible = true;
	function getAllDataTypes(){
		$scope.messages = 'list';
		$scope.loadingVisible = true;
		$http.get('server/datatypes.json').success(function(data) {
			$scope.allDataTypes=data;
			$scope.loadingVisible = false;
		}).error(function(data) {
			$scope.loadingVisible = false;
			if (data&&data.httpResponseCode == 401) {
				dataFactory.logout();
			}
			console.log(data);
		});
	};
	getAllDataTypes();
}]);
