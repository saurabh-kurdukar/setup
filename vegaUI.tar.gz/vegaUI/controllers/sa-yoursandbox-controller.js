(function(){
    angular
        .module('experienceApp.sa.yoursabdbox',['ngAnimate', 'ui.bootstrap'])
        .controller('saYourSandbox', saYourSandbox)
        .controller('modalPopUpCtrl1', modalPopUpCtrl1);
        /* .controller('userConfrimBoxCotroller', userConfrimBoxCotroller); */
    
    saYourSandbox.$injector = ['$scope', '$rootScope', 'dataFactory', '$uibModal', '$state'];
    modalPopUpCtrl1.$injector = ['$scope','$uibModalInstance', '$uibModal', 'dataFactory'];
    /* userConfrimBoxCotroller.$injector = ['$scope','$uibModalInstance', '$uibModal', 'dataFactory']; */
    
    function saYourSandbox($scope, $rootScope, dataFactory, $uibModal, $state) {
        
    var callErrorHandler = function (method, apiResponse, postApiDataSent) {
        errorObj = {
                controller: "saYourSandbox",
                method: method,
                postApiDataSent: postApiDataSent,
                apiResponse: apiResponse
            }
            $rootScope.handleErrors(errorObj);
    };
        
	provExpFailure = cartExpFailure = expFailure = compFailure = addCompanyFailure = cartRemoveError = getPlatformError = function saYourSandboxHandleError(error) {
            console.log("saYourSandboxHandleError",error);
			callErrorHandler("error", error, "");
        }        
        
        dataFactory.setCurrentState("sa-yourSandbox");
        dataFactory.hiddenNavbarFooter(false);
        console.log("super user yoursandbox controller.");
        var vm = this;
        
    //binded variables
        
        vm.users = [];
        vm.companies = [{companyName : 'fetching list...'}];
        vm.persistentUsers = [];
        vm.expMap = {};
        vm.deprovisionArray = [];
        vm.showSuccessAllocationMsg = false;
        vm.newSandboxName = "";
        vm.newSandboxImage = 'img/playsandbox.png';
        vm.webAppsMap = [];
        vm.persistentId = PERSISTENT_COMPANY_ID;
        vm.persistentName = PERSISTENT_COMPANY_NAME;
        
        vm.viewby = 3;
        vm.currentPage = 1;
        vm.currentPageInProvisioned = 1;
        vm.itemsPerPageInMediumDevice = $scope.viewby;
        vm.itemsPerPageInLargeDevice = 4;
        vm.itemsPerPageInSmallDevice = 2;
        vm.itemsPerPageInMobileDevice = 1;
        vm.maxSize = 5;
        vm.setPage = function (pageNo) {
            vm.currentPage = pageNo;
        };
        vm.pageChanged = function () {
            console.log('Page changed to: ' + $scope.currentPage);
        };
        vm.setItemsPerPage = function (num) {
           vm.itemsPerPage = num;
        vm.currentPage = 1;
        }
        
    //binded functions
        vm.onOrgChange = onOrgChange;
        vm.onCreateSanbox = onCreateSanbox;
        vm.provision = provision;
        vm.deProvision = deProvision;
        vm.allocate = allocate;
        vm.onCompanyChange = onCompanyChange;
        vm.onCreateCancel = onCreateCancel;
        vm.onPlatformUserChange = onPlatformUserChange;
        vm.addUsers = addUsers;
        vm.confirmationBox = confirmationBox;
        vm.removeFromCart = removeFromCart;
        vm.addRemoveDeprovision = addRemoveDeprovision;
        vm.disableAddUsers = disableAddUsers;
        vm.provisionButtonText = provisionButtonText;
        vm.allocateButtonText = allocateButtonText;
        vm.showExperiences = showExperiences;
        vm.filledCartTitle = filledCartTitle;
        vm.newSandboxTitle = newSandboxTitle;
        vm.goToExpDetails = goToExpDetails;		
		vm.disableDeprovisionButton = disableDeprovisionButton;
        vm.onExpInit = onExpInit;
		 $scope.healthcr={};
        $scope.healthcr.isHealthCareSandBoxFlag=true;   
		
        dataFactory.getExperiencesV2()
        .then(expSuccess)
        .catch(expFailure);
        
        var appMap = dataFactory.appMap();
		if (appMap.success || appMap.error) {
			appMap.success(function (response) {
                webAppMapSuccess(response);
			}).error(function (error) {
                webAppMapFailure(error);
			});
		} else {
			vm.webAppsMap = appMap;
		};
        
        
        function webAppMapSuccess(response){
            	dataFactory.appMap(response);
				vm.webAppsMap = dataFactory.appMap();
        }
        
        function webAppMapFailure(error){
            callErrorHandler("", error, "error frtching appMap");            
        }        
        
        function resetData( userType, companyId ) {   
            
           
            dataFactory.setOrgId(companyId);
            vm.companyCartExperiences = [];
            dataFactory.getExperienceFromCartByOrgIdV2(true, true)
            .then(cartExpSuccess)
            .catch(cartExpFailure);

            vm.provExps = [];
            dataFactory.getProvisionedExperiencesV2()
            .then(provExpSuccess)
            .catch(provExpFailure);
            
            
            
            if( userType != "platform" )
            {               
                vm.users = [];
                dataFactory.getCompanyUsersV2(companyId)
                .then(getUsersSuccess)
                .catch(getUsersError) ;                   
            }
            else
            {
           
            }
        }  
        
       //resetData();
        
        dataFactory.getCompaniesV2()
        .then(compSuccess)
        .catch(compFailure);
        
        function cartExpSuccess(cartExps) {
            
            cartExps.forEach(function(exp){
                populateDeviceFlags(exp);
            });
            
            vm.companyCartExperiences = cartExps;
            $rootScope.selectedExperiencesCount = cartExps.length;
            dataFactory.setCartExperiences(cartExps);
            vm.totalItems = vm.companyCartExperiences.length;
        }

        
        function provExpSuccess(provExps) {
            vm.provExps = provExps;
        }
        
        function expSuccess(experiences) {
            vm.experiences = experiences;
            vm.expMap = dataFactory.experiencesMap();

        }  
        
        function compSuccess(companies) {
            var temp1 = {"companyName" : "Select Sandbox"};
            var temp2 = {"companyName" : "Create Sandbox"};
            var temp3 = {"companyName" : "My Sandbox", "companyId" : dataFactory.extractOrgId(dataFactory.getLoggedInUser(), false)};
            
            companies.forEach(function(comp){
                comp.companyId = dataFactory.extractOrgId(comp, false);
            });
            
            //companies.unshift(temp1, temp2);   removed create sandbox
			companies.unshift(temp1);
            companies.push(temp3);
            
            vm.companies = companies;
            vm.selectedCompany =  vm.companies[0];
            
            var previouslySelected =  dataFactory.lastSandboxSelection();
            
            if(previouslySelected.type == "")
                return;
                
            if(previouslySelected.type && previouslySelected.company)
            {
                var type = previouslySelected.type;
                var company = previouslySelected.company;
                
                if( type == "Create Sandbox" ) 
                    return;
                   
                if ((type == "Select Sandbox") )
                {                
                    return;
                }  
                
                if ((type == "My Sandbox") )
                {        
                    vm.selectedCompany =  vm.companies[ vm.companies.length - 1 ];
                    company.companyName = "My Sandbox";
                    onCompanyChange(company);
                    return;
                }
                
                
                if( type == "platform" )
                {
                   vm.companies.forEach(function(comp, index){
                        if(comp.companyName == vm.persistentName)
                        {
                            vm.selectedCompany = vm.companies[index];
                            return;
                        }
                    });                    
                    fetchPlatformUsers (company);
                    return;
                }
                
               vm.companies.forEach(function(comp, index){
                    if(comp.companyName == company.companyName)
                    {
                        vm.selectedCompany = vm.companies[index];
                        return;
                    }
                });
                               
                resetData("other", company.companyId);
                
            }

        }
        

        
        function provExpFailure(error){
            console.log("prov exp fetch failure",error);
        }
                
        function cartExpFailure(error) {
            console.log("cart experiences fetch failure",error);
        }        
        
        function expFailure(error){
            console.log("all experiences fetch failure:",error);
        }
        
        function compFailure(error){
            console.log("error fetching companie:",error);
			
        }
        
        function onOrgChange() {
        }
        
        function onCreateSanbox( newSandboxName ) {
            
            if( ( !newSandboxName ) || ( newSandboxName == "" ) )
            {
                alert("sandbox name cant be empty");
                return;
            }
            else if( isExistingCompany(newSandboxName) )
            {
                alert("company name already exists");
                console.log("company name already exists", newSandboxName)
                return;
            }
            
            var obj = { companyName : newSandboxName };
          // add condition to check if flag is set. if flag is set then call new api comment by Nisar
		    if(isHealthCareSandBox && $scope.healthcr.isHealthCareSandBoxFlag)
			  {
			  console.log("flag for checkbx"+$scope.healthcr.isHealthCareSandBoxFlag);
		      // saveToLocal(newSandboxName);
			  
			   obj.companyAddress='healthCareBox';
			  }
            dataFactory.addNewCompanyV2(obj, true)
            .then(addCompanySuccess)
            .catch(addCompanyFailure);
            
        }
		
		function checkToLocal(company)
		{
		/* var data={};
		 if(!localStorage.healthCareBox)		
		{
		return false;
		} 
		data=JSON.parse(localStorage.healthCareBox);
		if(data.sandboxes.indexOf(name) !== -1)
		{
		  return true;
		}
		*/	
		if(company.companyAddress && company.companyAddress == 'healthCareBox')
		{
		console.log("got company",company.companyAddress);
		  return true;
		}		
		return false;
		}
		
		function saveToLocal(name){	
		var data={};
       if(localStorage.healthCareBox)		
		{data=JSON.parse(localStorage.healthCareBox);
		}
		else{
		data.sandboxes=[];
		data.sandboxes.push('company4');
		}
		data.sandboxes.push(name);
		localStorage.healthCareBox=JSON.stringify(data);
		}
		
		
        function isExistingCompany( companyName )
        {
            companyName = companyName.toLowerCase().split(" ").join("");
            var flag = false;
            
            vm.companies.forEach(function(company){
                if( (company.companyName).toLowerCase().split(" ").join("") == companyName)
                {
                    flag = true;
                    return;
                }
                    
            });
            
            return flag;
        }
        
        function addCompanySuccess(response) {
            vm.newSandboxName = "";
            vm.companies[ vm.companies.length ] = vm.companies[ vm.companies.length - 1 ];
            vm.companies[ vm.companies.length - 2 ] = response;
            vm.selectedCompany = vm.companies[ vm.companies.length - 2 ];
            $rootScope.currentCompanyName = vm.selectedCompany.companyName; 					
            dataFactory.lastSandboxSelection("other", response);
            resetData("other",vm.selectedCompany.companyId );
            console.log("add company success", response);
			 if(isHealthCareSandBox && checkToLocal(response))
				 {
				  $scope.isHealthCareSandBox=true;
				 }
				 else{
				  $scope.isHealthCareSandBox=false;
				 }
			
			
        }
        
        function addCompanyFailure(error) {
            alert('failed to add new company')
            console.log("failed add company", error);
        }
        
        
        function provision(){
            
            dataFactory.showLoading(true);
            var cartExperiences = JSON.parse(JSON.stringify(vm.companyCartExperiences));
            cartExperiences.forEach(function (exp) {
                exp.androidAppOffered = vm.expMap[exp.expId].androidAppOffered;
                exp.iOSAppOffered = vm.expMap[exp.expId].iOSAppOffered;
            });
            var len = 0;
            if (cartExperiences) {
                len = cartExperiences.length;
            }
            if (len > 1) {
                if ((cartExperiences[len - 1].androidAppOffered == "true") || (cartExperiences[len - 1].iOSAppOffered == "true")) {} else {
                    for (var x = 0; x < (len - 1); x++) {
                        if ((cartExperiences[x].androidAppOffered == "true") || (cartExperiences[x].iOSAppOffered == "true")) {
                            var temp = cartExperiences[len - 1];
                            cartExperiences[len - 1] = cartExperiences[x];
                            cartExperiences[x] = temp;
                            break;
                        }
                    }
                }
            }
            var provisionTimeOutCount = 0;
            function initateProvision (len) {
                var tOut = 5;
                if (provisionTimeOutCount == 1) {
                    tOut = provisionongApiInterval;
                }
                setTimeout(function () {
                    provisionTimeOutCount++;
                    --len;
                    provisionExperience(cartExperiences[len], len);
                    if (len != 0) {
                        initateProvision(len);
                    }
                }, tOut);
            };
            initateProvision(len);            
        }
        
        function provisionExperience(experience, remainingCount)
        {
                        
            var body = {
                "orgId": dataFactory.getOrgId(),
                "experienceId": parseInt(experience.expId),
                "createdBy": dataFactory.getLoggedInUser().mail
            }     
            
            dataFactory.provisionExperiencesV2(body)
            .then(function(response){
                provisionSuccess(experience, remainingCount)
            })
            .catch(function(error){
                provisonFailure(error, remainingCount)
            })
        }
        
        function provisionSuccess(experience, remainingCount)
        {
            removeFromCart(experience);
            if(remainingCount == 0 )
            {
                dataFactory.showLoading(false);
                $state.go('provisionStatus');
            }
        }
        
        function provisonFailure(error, remainingCount)
        {
            console.log("provisonFailure:",error);
            if(remainingCount == 0 )
            {
                dataFactory.showLoading(false);
                $state.go('provisionStatus');
            }            
        }
        
        function allocate()
        {
            
        }
        
        function allocateExperience(body)
        {
        }
        
        function onCompanyChange(company)
        {
		 $rootScope.currentCompanyName='Persistent Sandbox'; 
            if( !company)
            {
                return;
            }
            if( company.companyName == "Select Sandbox" )
            {
                vm.SelectedCompany = {companyName: "Select Sandbox", companyId : -1};      
                dataFactory.lastSandboxSelection("Select Sandbox", vm.SelectedCompany);  
                return;
            }
            if( company.companyName == "Create Sandbox" )
            {
                vm.SelectedCompany = {companyName: "Create Sandbox", companyId : -1};
                dataFactory.lastSandboxSelection("Create Sandbox", vm.SelectedCompany);
                return;
            }
            else if(company.companyName == "My Sandbox")
            {
                var currentUser = dataFactory.getLoggedInUser();
                dataFactory.lastSandboxSelection("My Sandbox", currentUser);                
                resetData("other", dataFactory.extractOrgId(currentUser, false) );
                return;
                
            }
            else if( company.companyName == vm.persistentName )
            {
			   $rootScope.currentCompanyName='Persistent Sandbox'; 
                fetchPlatformUsers();
                //resetData( "platform" ); 

            }
            else if( company.companyName == "Create Sandbox" )
            {
               
                //resetData( "platform" );   
            }    
            else
            {
                dataFactory.extractOrgId(company);
/*
                dataFactory.setOrgId(company.companyId);  
*/
                 if(isHealthCareSandBox && checkToLocal(company))
				 {
				  $scope.isHealthCareSandBox=true;
				 }
				 else{
				  $scope.isHealthCareSandBox=false;
				 }
                dataFactory.lastSandboxSelection("other", company); 
                $rootScope.currentCompanyName=company.companyName; 					
                resetData( "other", company.companyId );  
				
			
            }
        }
        
        function fetchPlatformUsers ( userToSelect ) {
                dataFactory.getPlatformUsersV2()
                .then(function(response){
                    getPlatformSuccess(response, userToSelect)
                })
                .catch(getPlatformError);          
        }
        
        function getPlatformSuccess(response, userToSelect) {
            //this is just a temprory fix
            response.forEach(function( puser ){
                puser.referenceCompanyId = dataFactory.extractOrgId(puser, false);
            });
            vm.users = response;
            if(userToSelect)
                selectPlatformUser(userToSelect);

            
        }
        
        function selectPlatformUser( pUser ) {
            
            vm.users.forEach(function(user, index){
                if( user.referenceCompanyId ==  pUser.referenceCompanyId )
                {
                    vm.selectedPlatformUser = vm.users[index];
                    resetData("platform", pUser.referenceCompanyId);
                    return;
                }
            });            
        }        
        
        function getPlatformError(error) {
            console.log("failed get all platform users",error);
        }
        
        function getUsersSuccess(response) {
            vm.users = response;
        }
        
        function getUsersError(error) {
            console.log("getUsersError",error);
			/* if((error.httpResponseCode=="500" || errorObj.httpResponseCode==500)&&((error.errorMessage!="Invalid company id")||(error.errorMessage!="company id not exist"))){
				console.log(error.errorMessage);
			callErrorHandler("error", error, "");} */
        }
        
        function onPlatformUserChange(pUser)
        {
            if(!pUser)
                return;
           // dataFactory.setOrgId(dataFactory.extractOrgId(pUser));
            pUser.companyName = pUser.username;
            dataFactory.lastSandboxSelection("platform", pUser);
            resetData( "platform", dataFactory.extractOrgId(pUser, false) );
        }
        
        function onCreateCancel() 
        {
            vm.newSandboxName = "";
            vm.selectedCompany=vm.companies[0];
            vm.onCompanyChange(vm.companies[0]);
        }
        
        function removeFromCart( experience,$index )
        {
            dataFactory.deleteExperienceFromCart(experience.cartItemId)
            .then(function(response){
                cartRemoveSuccess(experience)
            })
            .catch(cartRemoveError)
        }
        
        function cartRemoveSuccess( exp )
        {
            var index = -1;
            vm.companyCartExperiences.forEach(function(cExp, i){
                if(cExp.expId == exp.expId)
                {
                    $rootScope.selectedExperiencesCount--;                                                                            
                    index = i;
                    return;
                }
            });
            
            if(index != -1)
            {
                vm.companyCartExperiences.splice(index, 1);     
            }
			dataFactory.setCartExperiences(vm.companyCartExperiences);
			vm.totalItems = vm.companyCartExperiences.length;            
            
        }
        
        function cartRemoveError( error )
        {
            console.log("error removing from cart", error);
        }
        
        function addRemoveDeprovision(experience, isSelected) 
        {
            if(isSelected)
            {
				vm.deprovisionArray.push(experience["_id"]);
            }
            else
            {
				vm.deprovisionArray.forEach(function(exp, index){
                    if(exp == experience["_id"])
                    {
						vm.deprovisionArray.splice(index, 1);
                        return;
                    }
                })
            }
            
        }
        
        
        function deProvision(){
            
            dataFactory.showLoading(true);
            var deProvisionArray = (vm.deprovisionArray).slice();

            var len = 0;
            if (deProvisionArray) {
                len = deProvisionArray.length;
            }

            var provisionTimeOutCount = 0;
            function initateDeProvision (len) {
                var tOut = 5;
                if (provisionTimeOutCount == 1) {
                    tOut = provisionongApiInterval;
                }
                setTimeout(function () {
                    provisionTimeOutCount++;
                    --len;
                    deProvisionExperience(deProvisionArray[len], len);
                    if (len != 0) {
                        initateDeProvision(len);
                    }
                }, tOut);
            };
            initateDeProvision(len);            
        }
        
        function deProvisionExperience(experienceId, remainingCount)
        {
 
            
            dataFactory.deProvisionExperiencesV2(experienceId)
            .then(function(response){
                deProvisionSuccess(experienceId, remainingCount)
            })
            .catch(function(error){
                deProvisonFailure(error, remainingCount)
            })
        }
        
        function deProvisionSuccess(experienceId, remainingCount)
        {
            //removeProvExp(experience);
            removeProExpFromArray(experienceId);
            if(remainingCount == 0 )
            {
                dataFactory.showLoading(false);
                $state.go('provisionStatus');
            }
        }
        
        function deProvisonFailure(error, remainingCount)
        {
            console.log("deProvisonFailure:",error);
            if(remainingCount == 0 )
            {
                dataFactory.showLoading(false);
                $state.go('provisionStatus');
            }            
        }  

		function disableDeprovisionButton() {
			return vm.deprovisionArray.length <= 0;
		}	
        
        function removeProExpFromArray(experienceId)
        {
            vm.provExps.forEach(function(pExp, index){
                if(pExp["_id"] == experienceId)
                {
                    vm.provExps.slice(index, 1);
                    return;
                }
            });
            
            vm.deprovisionArray.forEach(function(expId, index){
                if(experienceId == expId)
                {
                    vm.deprovisionArray.splice(index, 1);
                    return;
                }
            });
        }
        
        function provisionButtonText() {
            if( (vm.selectedCompany.companyName == "My Sandbox") && (!(!vm.companyCartExperiences)) &&(vm.companyCartExperiences.length > 0) )
                return "Provision Experiences";
            return "Add Experiences";
        }
        
        function allocateButtonText() {

                if( vm.selectedCompany.companyName == "My Sandbox" )
                    return "Add Experiences";
                else if( (!(!vm.companyCartExperiences)) && vm.companyCartExperiences.length > 0 )
                        return "Allocate More Experiences";
                else
                return "Allocate Experiences"
        }
        
         function filledCartTitle(){
             
         return (vm.selectedCompany.companyName == 'My Sandbox') ? 'Provision Experiences' : ('Allocated Experiences for ' + vm.selectedCompany.companyName)
        }
        
        function showExperiences(){
            return ( !(!(vm.selectedCompany)) && (vm.selectedCompany.companyName != "Select Sandbox") && (vm.selectedCompany.companyName != "Create Sandbox") && (vm.selectedCompany.companyName != "fetching list...") && ((vm.selectedCompany.companyName !=  vm.persistentName) || ( !(!(vm.selectedPlatformUser)) && !(!(vm.selectedPlatformUser.companyId)) ) ));
        }
        
        function newSandboxTitle(){
            if( (!(!vm.SelectedCompany)) && (vm.SelectedCompany.companyName == 'Create Sandbox'))
            {
                vm.newSandboxImage = 'img/empty-box.png';
                return 'Please Create a New Sandbox.';
            }
            
            vm.newSandboxImage = 'img/playsandbox.png';
            return 'Please select a Sandbox to view allocated experiences';
        }

        
        
        function addUsers() {

            var modalInstance = $uibModal.open({
              templateUrl: 'addUsers.html',
              controller: 'modalPopUpCtrl1',
                scope : $scope
              });

            modalInstance.result.then(function () {
                    console.log('success');
                }, function () {
                    console.log('error');
                }
            );
          };

        function confirmationBox  ( ) {

              var modalInstance = $uibModal.open({
                templateUrl: 'confirm.html',
                controller: 'modalPopUpCtrl1',
                scope : "true"
                });

              modalInstance.result.then(function () {      }
               , function () {      }
               );
            };        
        
        
        function disableAddUsers() {
            return (vm.selectedCompany.companyName == "Select Sandbox") || (vm.selectedCompany.companyName == "Create Sandbox") || (vm.selectedCompany.companyName == "fetching list...");
        }
        
        function goToExpDetails (expId) {
            var exp = vm.expMap[ expId ];
            dataFactory.setSelectedExperience(exp);
            dataFactory.previousState(dataFactory.getCurrentState());
            $state.go('expDetails');
        }
        
        
       function onExpInit(experience){
        populateDeviceFlags(experience);
    }
         
    
        	 function populateDeviceFlags (cartExp) {
                 
                 var experience = vm.expMap[cartExp.expId];
                 cartExp.androidAppOffered = stringToBool(experience.androidAppOffered);
                 cartExp.webAppOffered = stringToBool(experience.webAppOffered);
                 cartExp.iOSAppOffered = stringToBool(experience.iOSAppOffered);
                 cartExp.wearableOffered = stringToBool(experience.wearableOffered);
                if (experience.deviceSupported && experience.deviceSupported.length > 0) experience.deviceSupported.forEach(function (device) {
                    if (device == "Both iPhone and iPad") {
                        cartExp.iphoneCompitable = true;
                        cartExp.ipadCompitable = true;
                    } else if (device == "iPhone Only") {
                        cartExp.iphoneCompitable = true;
                        cartExp.ipadCompitable = false;
                    } else if (device == "iPad Only") {
                        cartExp.ipadCompitable = true;
                        cartExp.iphoneCompitable = false;
                    }
                });
             
		};     
        
        function stringToBool( str ){
            if(!str)
                return false;
            if(typeof str == "boolean")
                return str;
            if(  str.toLowerCase() == "true" )
                return true;
            return false;
        }
  
    $scope.goToExperience=function(){
	filterData = {  
				"deviceSupported":[],
				"domains":[],
				"classification":[],
				"platforms":[]
			};
     dataFactory.experienceFilter(filterData);	
	 $state.go('experiences');	
	}

  

  $scope.isHealthCareSandBox=isHealthCareSandBox;
  $scope.isHealthCareSandBoxFlag=isHealthCareSandBox;
  
       $scope.componentDetailslist=[{
	'name': 'OpenEMR',
	'imageUrl': 'http://demo-vega.cloudapp.net/files/file_1468327442646.jpg',
	'url': 'http://vegahcare.cloudapp.net/openemr/interface/login/login_frame.php?site=default'
},{
	'name': 'OpenEMPI',
	'imageUrl': 'http://demo-vega.cloudapp.net/files/file_1468327466859.jpg',
	'url': 'http://vegahcare.cloudapp.net:8080/openempi-entity-webapp-web-3.1.0'
},
{
	'name': 'Connect Gateway',
	'imageUrl': 'http://demo-vega.cloudapp.net/files/file_1468491198180.PNG',
	'url': 'http://vegahcare.cloudapp.net:8080/CONNECTUniversalClientGUI/faces/Page2.jsp'
},
{
	'name': 'Data lake',
	'imageUrl': 'http://demo-vega.cloudapp.net/files/file_1468483908376.png',
	'url': 'http://10.46.34.35:8080/'
},
{
	'name': 'Mirth Connect',
	'imageUrl': 'http://demo-vega.cloudapp.net/files/file_1468327485397.png',
	'url': 'https://vegamirth.cloudapp.net/'
}]; 
$scope.datasetDetailslist=[{
	'name': 'HL7 v2',
	'imageUrl': 'http://demo-vega.cloudapp.net/files/file_1468484126106.jpg',
	'url': 'http://10.46.34.35:8080/#/main/views/ZEPPELIN/1.0.0/INSTANCE_1'
},{
	'name': 'FHIR',
	'imageUrl': 'http://demo-vega.cloudapp.net/files/file_1468484126106.jpg',
	'url': 'http://10.46.34.35:8080/#/main/views/ZEPPELIN/1.0.0/INSTANCE_1'
},
{
	'name': 'CCDA',
	'imageUrl': 'http://demo-vega.cloudapp.net/files/file_1468484126106.jpg',
	'url': 'http://10.46.34.35:8080/#/main/views/ZEPPELIN/1.0.0/INSTANCE_1'
},
{
	'name': 'Claims',
	'imageUrl': 'http://demo-vega.cloudapp.net/files/file_1468484126106.jpg',
	'url': 'http://10.46.34.35:8080/#/main/views/ZEPPELIN/1.0.0/INSTANCE_1'
}];
        
        return vm;
        
    }//end saYourSandbox
    
    
    function modalPopUpCtrl1 ($scope, $uibModalInstance, $uibModal, dataFactory,$rootScope){
		var callErrorHandler = function (method, apiResponse, postApiDataSent) {
		errorObj = {
			controller: "modalPopUpCtrl1",
			method: method,
			postApiDataSent: postApiDataSent,
			apiResponse: apiResponse
		}
		$rootScope.handleErrors(errorObj);
	};
     //  $scope.users = dataFactory.getUsersForSandbox();
        var parent = $scope.$parent.syb;
         var confirmModal;
        $scope.selectedCompany = parent.selectedCompany;
        $scope.newUser = {"fullname" : "", "username" : "", isAdmin : false};        
        $scope.users = parent.users;
        $scope.removeUser = removeUser;
        $scope.editUser = editUser;
        /* $scope.confirmAdd = confirmAdd; */
        $scope.addUser = addUser;
        $scope.closePopUp = closePopUp;
        $scope.addUserResponse = addUserResponse;
        
		 var parent = $scope.$parent;
        $scope.company = parent.company;
        $scope.addUserResponse = parent.addUserResponse; 
        
       /*  function confirmAdd() {
                confirmModal = $uibModal.open({
                templateUrl: 'confirm.html',
                controller: 'userConfrimBoxCotroller',
                scope : $scope
            });
        } */
        
        function closePopUp(reponse ) {
            console.log("closePopUp",response);
          };
        
        function addUserResponse(response){
            if(response)
                $scope.addUser();
            confirmModal.dismiss('cancel');
        }
        
        function closePopUp() {
            $uibModalInstance.dismiss('cancel');
          };
        
        function addUser( newUser ) {
            newUser = $scope.newUser;
            var companyId = $scope.selectedCompany.companyId;            
            
            if( (!newUser) || (!newUser.fullname) || (!newUser.username) || (!companyId) || (newUser.fullname == "") || ( newUser.username == "" ) )
            {
                return;
            }
            
            var nameSplit = newUser.fullname.split(" ");
            var firstname = "";
            var lastname = " ";//initialized with space
            
            if (nameSplit.length > 1)
            {
                lastname = nameSplit[nameSplit.length - 1];
                nameSplit.splice(nameSplit.length - 1, 1);
            }
            firstname = nameSplit.join(" ");
            
            
            var user =
            {
                "username": newUser.username,
                "type": "addUser",
                "firstname": firstname,
                "lastname": lastname
            }
            

            
            dataFactory.addCompanyUsersV2(companyId, user, true)
            .then(addCompnayUserSuccess)
            .catch(addCompanyUserFailure);
            //$scope.users.push( JSON.parse(JSON.stringify($scope.newUser)) );
          };
        
        function removeUser(user, index) {
            $scope.users.splice(index, 1);
          };
        
        function editUser(user, index)
        {
            console.log("$scope.editUser", user);
            $scope.newUser = user;
            $scope.users.splice(index, 1);
        }
        
        function addCompnayUserSuccess(response) 
        {
            $scope.newUser = {"fullname" : "", "username" : "", isAdmin : false};        
            $scope.users.push(response);
        }
        
        function addCompanyUserFailure(error) 
        {
            console.log("adding company user failure:",error);
			if((error.httpResponseCode=="500" || errorObj.httpResponseCode==500)&&(error.errorMessage!="Invalid company id")){
			callErrorHandler("error", error, "");}
        }

    };     
    
    /* function userConfrimBoxCotroller ($scope, $uibModalInstance, $uibModal, dataFactory){

        var parent = $scope.$parent;
        $scope.company = parent.company;
        $scope.addUserResponse = parent.addUserResponse; 
    };    */ 
    
	
	
	
})();