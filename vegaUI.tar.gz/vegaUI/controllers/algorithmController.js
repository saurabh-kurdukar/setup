/**=========================================================
 * Module: dataLakeController
 * Setup options and data for flot chart
 =========================================================*/
angular
.module('experienceApp.algorithm', ['ui.codemirror'])
.controller('algorithmController', ['$state','$http', '$scope', '$timeout','ngDialog','dataFactory','$rootScope','$window', '$filter', function($state,$http, $scope, $timeout,ngDialog,dataFactory,$rootScope,$window,$filter) {
	console.log("in algorithm controller");
	
	dataFactory.setCurrentState("algorithms");
	
	function initialiseScript(){
		$scope.algorithms = 'list';
		$scope.scriptForm={};
		$scope.scriptForm.name='';
		$scope.scriptForm.description='';
		$scope.scriptForm.version ='';
		$scope.scriptForm.tags = [];
		$scope.scriptForm.showCalc = false;
		$scope.deleteScripts=[];
		$("#dependantModule").val("");
	}
	$scope.editAlgorithmFlag=false;
	$scope.editInScript=true;
	initialiseScript();
	$scope.deleteScripts=[];
	$scope.filteredAlgorithms=[];
  	
	$scope.addNewScript=function(){
		$scope.editAlgorithmFlag=false;
		$scope.scriptAddForm=true;
		initialiseScript();
	};
	$scope.cancelScriptForm=function(){
		$scope.scriptAddForm=false;
		initialiseScript();
	};

	$scope.scriptForm_Script = function(element) {
		$scope.scriptForm.script = element.files;
    }
	
	$scope.checkUserExist = function(name){
			$http.get(baseApiUrl+'/algorithm?name='+name, {
				headers: {
					'Content-Type': 'application/json',
					'access-token': $rootScope.accessToken
				}
			}).success(function(data) {
				$scope.usernameExists = true;
			}).error(function(data) {
				$scope.usernameExists = false;
			});
	}
	$scope.submitScriptForm=function(){
	console.log($scope.scriptForm.name);
	var fd = new FormData();
             fd.append("name", $scope.scriptForm.name);
			 fd.append("description",$scope.scriptForm.description);
		     fd.append("version", $scope.scriptForm.version);
			 fd.append("type", $scope.scriptForm.type);
			 fd.append("mainClass", $scope.scriptForm.mainClass);
			 fd.append("showCalc", $scope.scriptForm.showCalc);
			 fd.append("inputType", $scope.scriptForm.inputType);
			 fd.append("inputMetadata", $scope.scriptForm.inputMetadata);
			 fd.append("outputMetadata", $scope.scriptForm.outputMetadata);
			 
			 if($scope.scriptForm.script)
			 {
				 for(var i=0;i<$scope.scriptForm.script.length;i++)
				 {
				 fd.append("dependency["+i+"]",$scope.scriptForm.script[i]);
				 }
		     }
			 if($scope.scriptForm.tags)
			 {
				 for(var i=0;i<$scope.scriptForm.tags.length;i++)
				 {
				 fd.append("tags["+i+"]",$scope.scriptForm.tags[i]['text']);
				 }
		     }
		     fd.append("createdBy",dataFactory.getLoggedInUser().mail);

            $scope.updateLoading = true;
            $http.post(baseApiUrl+'/algorithm', fd, {
                transformRequest: angular.identity,
                headers: {
                    'Content-Type': undefined,
                    'access-token': $rootScope.accessToken
                }
            }).success(function(data) {
                toastr.success("created script");
				$scope.scriptAddForm=false;
                $scope.updateLoading = false;
				//$scope.scriptForm.tags = 
				//$scope.allScripts.push($scope.scriptForm);
				getAllScript();
				initialiseScript();
            }).error(function(data) {
				
				console.log('error');
				if(data && data.httpResponseCode == 409) {
					
					windows.location.href(".myForm .name");
					$scope.algorithmName = true;
				}
			    $scope.updateLoading = false;
            });
	};
	
	function filterScripts(filter) {
		
		angular.forEach($scope.allScripts, function(script){
			
			if(script.contains(filter)) {
				$scope.filteredAlgorithms.push(script);
			}
			
		})
	}
	function getAllScript()
	{
		$scope.algorithms = 'list';
		$rootScope.accessToken=$window.localStorage.accesstoken;
		$scope.loadingVisible=true;
		$http.get(baseApiUrl+'/algorithm', {
                    headers: {
                        'Content-Type': 'application/json',
                        'access-token': $rootScope.accessToken
                    }
                }).success(function(data) {
				$scope.allScripts=data;
				
				var temp = $filter('unique')($scope.allScripts,'type');
				
				getAllScripts(temp[0].type);
				angular.forEach($scope.allScripts, function(record){
					var temp = [];
					if(record.algorithmFileLocation){
						angular.forEach(record.algorithmFileLocation, function(file){
							temp.push({'url':file,'name':file.substring(file.lastIndexOf('/')+1,file.length)});
						});
						record.algorithmFileLocation = temp;
					}
					if(record.tags) {
						var tags = [];
						angular.forEach(record.tags, function(tag){
							tags.push({'text':tag});
						});
						record.tags = tags;
					}
				});
				
				console.log($scope.allScripts);
				
                }).error(function(data) {
				if (data&&data.httpResponseCode == 401) {
                    dataFactory.logout();
                }
				$scope.loadingVisible=false;
                    console.log(data);
                });
	};
	getAllScript();
	
	function getAllScripts(type)
	{
	$scope.algorithms = 'list';
	$scope.selectedMenuItem=type;
	var data = $scope.allScripts;	
		
	 $scope.filteredAlgorithms=[];
	 console.log("type is"+type);
	for(var i=0;i<data.length;i++)
	{
	  if(type&&type==data[i].type)
	  {
	  $scope.filteredAlgorithms.push(data[i]);
	  }
	}

	$scope.loadingVisible=false;
	  //  console.log(data);
                

	};
	$scope.inboundload_Script = function(file) {
		
		$scope.algoFile = file.files;
	}
	$scope.displayCalculator = function(script) {
		$scope.calculated = false;
		console.log(JSON.stringify(script)+' '+script.inputMetadata.length);
		if(script.inputMetadata != 'TBD' && script.inputMetadata.length > 0 && script.inputMetadata != 'undefined') {
			try{
				var temp = JSON.parse(script.inputMetadata);
			}
			catch(e) {
				var temp = script.inputMetadata;
			}
			console.log(JSON.stringify(temp));
			$scope.algo = script;
			//$scope.algo.inputMetadata = temp;
			$scope.inputMetadata = temp;
			//$scope.link = script.apiLink;
			$scope.title = script.name+' Calculator';
			ngDialog.open({
				  template: 'showCalculator',
				  scope: $scope,
				  closeByDocument: false
			  });
		}
		else {
			toastr.error("No data available!");
		}

	}
	$scope.closeDetails = function(){
		$scope.algorithms = 'list';
	}
	$scope.displayDetails=function(script){
		$scope.detailsVisible = true;
		$scope.algorithms = 'details';
		$scope.detailsVisible = false;
		$scope.details = script;
		console.log(script);
	 /*$scope.scriptDetails=script;
	 $scope.scriptDetails.algorithmFileLocationNames=[];
	  angular.copy($scope.scriptDetails.algorithmFileLocation,$scope.scriptDetails.algorithmFileLocationNames);
	for(var ij=0;ij<script.algorithmFileLocation.length;ij++)
	{
	 var n = script.algorithmFileLocation[ij].lastIndexOf("/");
	 var res = script.algorithmFileLocation[ij].substring(n+1);
	 $scope.scriptDetails.algorithmFileLocation[ij]=res;
	}



	 $http.get($scope.scriptDetails.algorithmFileLocation[0], {
                    headers: {
                        'Content-Type': 'application/json'
                    }
                }).success(function(data) {
				$scope.scriptDetails.algorithmFileLocation[0]=data;
                   // console.log(data);

                }).error(function(data) {
                    console.log(data);
                });*
         	ngDialog.open({
                template: 'showDetails',
                scope: $scope,
                closeByDocument: false
            });*/

	};
	  $scope.closePopUp = function() {
            ngDialog.close();
        };


		$scope.openScripts=function(type){
				getAllScripts(type);


		};



    $scope.calculate = function(script,input) {
		console.log(script);
		
		if(script.inputType == 'json') {
		console.log('json')
			var algo = {};
			angular.forEach(input, function(param){
				/*if(param.type == 'file') {
					if($scope.algoFile)
					 {
						 for(var i=0;i<$scope.algoFile.length;i++)
						 {
							fd.append("dependency["+i+"]",$scope.algoFile[i]);
						 }
					 }
				}*/
				algo[param.code] = {'code':param.result};
			});
			algo = {'palliativeSurvey':algo}
			console.log(JSON.stringify(algo));
		} else if(script.inputType == 'csv') {
			console.log(JSON.stringify(input));
			var algo = '';
			angular.forEach(input, function(param){
				algo = algo+''+param.result+',';
			});
			algo = algo.substring(0,algo.lastIndexOf(','));
			console.log(algo);
		}
		$http({
		  method: 'POST',
		  url: baseApiUrl+'/algorithm/'+script.id+'/run',
		  data:{'inputData':algo},
		  headers: {
				'access-token': $rootScope.accessToken
			}
		}).then(function successCallback(response) {
			$scope.calculated = true;
			console.log(JSON.stringify(response));
			angular.forEach(response.data[0].columns, function(column){
				if(column.name == 'Score') {
					$scope.algoResult = column.value;
				}
			})
			
		  }, function errorCallback(response) {
			if (data&&data.httpResponseCode == 401) {
			dataFactory.logout();
		}
			$scope.calculated = true;
			$scope.algoResult = 'Error in calculation!'
		  });
		
		
		
		
      /*var Delirium = document.getElementById("Delirium").value;
      var Oedema = document.getElementById("Oedema").value;
      var Dyspnoea = document.getElementById("Dyspnoea").value;
      var OralIntake = document.getElementById("OralIntake").value;
      var PPS = document.getElementById("PPS").value;
      // var Ambulation = document.getElementById("Ambulation");
      // var ActivityDiseaseEvidence = document.getElementById("ActivityDiseaseEvidence");
      // var SelfCare = document.getElementById("SelfCare");
      // var Intake = document.getElementById("Intake");
      // var ConsciousnessLevel = document.getElementById("ConsciousnessLevel");

      $scope.ppi = parseFloat(Delirium) + parseFloat(Oedema) + parseFloat(Dyspnoea)
                        + parseFloat(OralIntake) + parseFloat(PPS);

      if($scope.ppi > 6) {
        $scope.calculated = "Survival shorter than 3 weeks";
      } else if ($scope.ppi > 4) {
        $scope.calculated = "Survival shorter than 6 weeks";
      } else if ($scope.ppi <= 4) {
        $scope.calculated = "Survival more than 6 weeks";
      }*/
    };
	
	
	 $scope.deleteAlgorithm=function(algorithm)
    {
	$scope.algorithmId=algorithm.id;
	ngDialog.open({
                template: 'deleteAlgorithmTemplete',
                scope: $scope,
                closeByDocument: false
            });
	
	};	
	
   $scope.deleteAlgorithmConfirm=function(){
   
     $scope.loadingVisible = true;
            $http.delete(baseApiUrl + '/algorithm/' + $scope.algorithmId, {
                headers: {
                    'Content-Type': 'application/json',
                    'access-token': $rootScope.accessToken
                }
            }).success(function(data) {
                toastr.success("Deleted Algorithm successfully");
				getAllScript();
                $scope.loadingVisible = false;
            }).error(function(data) {
                $scope.loadingVisible = false;
               if (data&&data.httpResponseCode == 401) {
                    dataFactory.logout();
                }
				else
				{
                toastr.error("Delete Algorithm Failed");
                 }
            });
            ngDialog.close();
   
   };
	$scope.editAlgorithm=function(algorithm) {

		$scope.scriptAddForm=true;
		angular.copy(algorithm,$scope.scriptForm);
		//$scope.scriptForm.tags = ["Sydney","Beijing","Cairo"];
		console.log(JSON.stringify($scope.scriptForm));
		$scope.editAlgorithmFlag=true;
		$scope.editInScript=true;
	};  
 $scope.showEditableField = function(type) {
                $scope.editInScript = false;
        };
	
  $scope.deleteScriptFile=function(url)
  {
	 console.log(url);
	 var i = 0;
	 angular.forEach($scope.scriptForm.algorithmFileLocation, function(algo){
		console.log(algo);
		var index = algo.url.indexOf(url.url);
		console.log(index);
		if(index > -1){
			 $scope.scriptForm.algorithmFileLocation.splice(i,1);
			 console.log("deleted");
		}
		i++;
	 });
	 //console.log(JSON.stringify($scope.scriptForm.algorithmFileLocation+' '+index);
     //var index=$scope.scriptForm.algorithmFileLocation.indexOf(url);
	 //if(index>-1)
	 //{
	 //$scope.scriptForm.algorithmFileLocation.splice(index,1);
	 //console.log("deleted");
	//}
  
     $scope.deleteScripts.push(url.url);
	 console.log($scope.deleteScripts);
  };
 
	
	$scope.editAlgorithmForm=function(id){
	console.log($scope.scriptForm.inputType);
	var fd = new FormData();
             fd.append("name", $scope.scriptForm.name);
			 fd.append("description",$scope.scriptForm.description);
		     fd.append("version", $scope.scriptForm.version);
			 fd.append("type", $scope.scriptForm.type);
			 fd.append("mainClass", $scope.scriptForm.mainClass);
			 fd.append("showCalc", $scope.scriptForm.showCalc);
			 fd.append("inputType", $scope.scriptForm.inputType);
			 fd.append("inputMetadata", $scope.scriptForm.inputMetadata);
			 fd.append("outputMetadata", $scope.scriptForm.outputMetadata);
			 //fd.append("deleteFiles",  $scope.deleteScripts);
			if($scope.scriptForm.tags)
			 {
				 for(var i=0;i<$scope.scriptForm.tags.length;i++)
				 {
				 fd.append("tags["+i+"]",$scope.scriptForm.tags[i]['text']);
				 }
		     }
			 if($scope.deleteScripts)
			 {
			 for(var i=0;i<$scope.deleteScripts.length;i++)
			 {
			 fd.append("deleteFiles["+i+"]",$scope.deleteScripts[i]);
			 }
		     }
			 console.log($scope.deleteScripts);
			 if($scope.scriptForm.script)
			 {
			 for(var i=0;i<$scope.scriptForm.script.length;i++)
			 {
			 fd.append("dependency["+i+"]",$scope.scriptForm.script[i]);
			 }
		     }
		     fd.append("updatedBy",dataFactory.getLoggedInUser().mail);
			console.log(JSON.stringify(fd));
            //$scope.loadingVisible = true;
			$scope.updateLoading = true;
            $http.put(baseApiUrl+'/algorithm/'+id, fd, {
                transformRequest: angular.identity,
                headers: {
                    'Content-Type': undefined,
                    'access-token': $rootScope.accessToken
                }
            }).success(function(data) {
                toastr.success("algorithm Updated");
				$scope.scriptAddForm=false;
                //$scope.loadingVisible = false;
				$scope.updateLoading = false;
				for(var i=0; i<$scope.allScripts.length; i++) {
					if($scope.allScripts[i].id == id) {
						$scope.allScripts[i] = $scope.scriptForm;
						break;
					}
				}
				//$scope.allScripts.push($scope.scriptForm);
				getAllScript();
				initialiseScript();
            }).error(function(data) {
			if (data&&data.httpResponseCode == 401) {
                    dataFactory.logout();
                }
			    //$scope.loadingVisible = false;
				$scope.updateLoading = false;
            });
	
	};	

}]);
