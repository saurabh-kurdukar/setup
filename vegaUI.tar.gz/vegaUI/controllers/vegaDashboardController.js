(function(){

angular
    .module('experienceApp.vegaDashboardController', [])
    .controller('vegaDashboardController', vegaDashboardController);

    vegaDashboardController.$injector = ['$scope', '$rootScope', 'dataFactory', '$location', '$state', '$filter'];

    function vegaDashboardController($scope ,$rootScope ,dataFactory ,$location ,$state ,$filter) {


        dataFactory.setCurrentState("dashboard");

    /*             $scope.$watch(function() {
                    return $location.path();
                }, function(newValue, oldValue) {

                    console.log("new value of location:-", newValue);

                }); */


    /*    
        if($rootScope.isActivation)
        {
             $state.go('activation');
        }

        $scope.onGetStartedClick = function(){

            if( dataFactory.getLoginStatus() )
            {
                $state.go('experiences');
            }
            else{
                $state.go('login');
            }

        };
        */
        var domains = dataFactory.getDomains(); 
        var selectedExp =  dataFactory.getTopExperiences(5);
        var totalUsers = dataFactory.getTotalUsers();
        var totalExp = dataFactory.getExperiences();
        var selectedPlatformUsers =  dataFactory.getTopPlatformUsers(5);
        var provisionedExp = dataFactory.getProvisionedExp();

        $scope.domainsMap = {};
        var init = function(){

            if( domains.success || domains.error )
            {
                domains.success( function( response ){

                    populateDomainsMap( response );

                })
                .error( function( error ){
                       console.log("error fetching domains",error);
                });
            }
            else
            {
                 populateDomainsMap( domains );
            }


            if( totalUsers.success || totalUsers.error )
            {	
                var foundUser = false;
                $scope.userRegistered = [];
                for(var i = 0 ; i < 52 ; i++){
                    $scope.userRegistered[i] = 0;
                }
                totalUsers.success( function( response ){
                    $scope.usersResponse = response;
                    console.log("$scope.usersResponse*****************",$scope.usersResponse);
                    $scope.totalUsersCount = $scope.usersResponse.length;
                    console.log("$scope.totalUsersCount*****",$scope.totalUsersCount);
                    for(var i = 0;i<$scope.totalUsersCount;i++){
                        var d = $scope.usersResponse[i].createdOn;
                        var date = new Date(d);
                        $scope.dayNumber = date.getDay();
                        date.setDate(date.getDate() + 4 - (date.getDay()||7));
                        // Get first day of year
                        var yearStart = new Date(date.getFullYear(),0,1);
                        var year = date.getFullYear();
                        // Calculate full weeks to nearest Thursday
                        var weekNo = Math.ceil(( ( (date - yearStart) / 86400000) + 1)/7);
                        console.log(d+"weekNumber ****"+weekNo+" "+typeof(weekNo));
                        console.log("year",year);

                        $scope.userRegistered[weekNo-1]++;





                    }

                    var curretDate = new Date();
                    var currentDay = curretDate.getDay();
                    curretDate.setDate(curretDate.getDate() + 4 - (curretDate.getDay()||7));
                    // Get first day of year
                    var year1 = new Date(curretDate.getFullYear(),0,1);
                    var year2 = curretDate.getFullYear();
                    // Calculate full weeks to nearest Thursday
                    var currentWeek = Math.ceil(( ( (curretDate - year1) / 86400000) + 1)/7);
                    console.log("currentWeek****",currentWeek)
                    console.log("user registered is  *******",$scope.userRegistered);
                    var new_array = $scope.userRegistered.concat();
                    for(var i = 1;i<$scope.userRegistered.length;i++){
                         new_array[i] = new_array[i-1] + $scope.userRegistered[i];
                    }
                    var weekArr = [];
                    var weeks = [];
                    for(var i = 0;i<currentWeek;i++){
                            if(!foundUser&&new_array[i]>0)
                            {
                            foundUser =true;


                            }
                            if(foundUser)
                                {

                                weekArr.push( [i+1 ,  new_array[i]]);
                                }

                    }
                    for(var i = 0;i<weekArr.length;i++){
                        console.log("entity in week of user ",weekArr[i][0]);

                        var d = getDateOfISOWeek(weekArr[i][0],year2);
                        d = $filter('date')(d, "MMM d,yyyy ");
                        weeks.push([ weekArr[i][0] ,d]);
                        //weeks.push(weekArr[i][0]);

                    }
                    plotChart( weekArr, weeks );
                    console.log("weekArr",weekArr);

                }).error( function( error ){
                       console.log("error fetching experiences",error);
                });
            }

            if( selectedExp.success || selectedExp.error )
            {
                selectedExp.success( function( response ){
                    $scope.expResponse = response;
                    $scope.expNames = [];
                    console.log("$scope.expResponse*****************",$scope.expResponse);
                    for(var i = 0;i<$scope.expResponse.length;i++){
                        $scope.expNames.push($scope.expResponse[i])
                    }
                    console.log("selected experiences top 5 ********",$scope.expNames);
                }).error( function( error ){
                       console.log("error fetching experiences",error);
                });
            }

            if( totalExp.success || totalExp.error )
            {

                totalExp.success( function( response ){
                    $scope.totalExpResponse = response;
                    console.log("$scope.totalExpResponse*****************",$scope.totalExpResponse);
                    $scope.totalExpCount = $scope.totalExpResponse.length;
                    console.log("$scope.totalExpCount*****",$scope.totalExpCount);
                }).error( function( error ){
                       console.log("error fetching experiences",error);
                });
            }
            else{
                $scope.totalExpCount = totalExp.length;
            }

            if( selectedPlatformUsers.success || selectedPlatformUsers.error )
            {
                selectedPlatformUsers.success( function( response ){
                    $scope.selectedUsersResponse = response;
                    $scope.userNames = [];
                    console.log("$scope.selectedUsersResponse*****************",$scope.selectedUsersResponse);
                    for(var i = 0;i<$scope.selectedUsersResponse.length;i++){
                        $scope.userNames.push($scope.selectedUsersResponse[i])
                    }
                    console.log("selected users top 5 ********",$scope.userNames);
                }).error( function( error ){
                       console.log("error fetching experiences",error);
                });
            }

            if( provisionedExp.success || provisionedExp.error )
            {
                var foundExp = false;
                $scope.expProvsioned = [];
                for(var i = 0 ; i < 52 ; i++){
                    $scope.expProvsioned[i] = 0;
                }
                provisionedExp.success( function( response ){
                    $scope.provisionedExpResponse = response;
                    console.log("$scope.provisionedExpResponse*****************",$scope.provisionedExpResponse);
                    for(var i = 0;i<$scope.provisionedExpResponse.length;i++){
                        var d = $scope.provisionedExpResponse[i].created;
                        var date = new Date(d);
                        console.log("date of provision", date);
                        $scope.dayNumber = date.getDay();
                        date.setDate(date.getDate() + 4 - (date.getDay()||7));
                        // Get first day of year
                        var yearStart = new Date(date.getFullYear(),0,1);
                        var year = date.getFullYear();
                        // Calculate full weeks to nearest Thursday
                        var weekNo = Math.ceil(( ( (date - yearStart) / 86400000) + 1)/7);
                        console.log(d+"weekNumber ****"+weekNo+" "+typeof(weekNo));
                        console.log("year",year);
                        $scope.expProvsioned[weekNo-1]++;


                    }
                    $scope.provisionedExpResponseCount = $scope.provisionedExpResponse.length;
                    console.log("$scope.provisionedExpResponseCount*****",$scope.provisionedExpResponseCount);

                    var curretDate = new Date();

                    curretDate.setDate(curretDate.getDate() + 4 - (curretDate.getDay()||7));
                    // Get first day of year
                    var year1 = new Date(curretDate.getFullYear(),0,1);
                    var year2 = curretDate.getFullYear();
                    // Calculate full weeks to nearest Thursday
                    var currentWeek = Math.ceil(( ( (curretDate - year1) / 86400000) + 1)/7);
                    console.log("currentWeek in provision****",currentWeek)

                    var new_array = $scope.expProvsioned.concat();
                    for(var i = 1;i<$scope.expProvsioned.length;i++){
                         new_array[i] = new_array[i-1] + $scope.expProvsioned[i];
                    }
                    var weekArr = [];
                    var weeks = [];
                    for(var i = 0;i<currentWeek;i++){
                            if(!foundExp&&new_array[i]>0)
                            {
                                foundExp =true;


                            }
                            if(foundExp)
                                {

                                weekArr.push( [i+1 ,  new_array[i]]);
                                }

                    }
                    for(var i = 0;i<weekArr.length;i++){
                        console.log("entity in week ",weekArr[i][0]);

                        var d = getDateOfISOWeek(weekArr[i][0],year2);
                        d = $filter('date')(d, "MMM d,yyyy ");
                        weeks.push([ weekArr[i][0] ,d]);
                        //weeks.push(weekArr[i][0]);

                    }

                    plotChartProvision( weekArr,weeks );
                    console.log("weekArr",weekArr);
                    console.log("weeks",weeks);

                }).error( function( error ){
                       console.log("error fetching experiences",error);
                });
            }

          };    

        var populateDomainsMap = function( domains ){

            domains.forEach( function( domain ,index ){

                domain.domainNameInLowerCase = domain.name.split(" ").join("").toLowerCase();
                domain.index = index;
                $scope.domainsMap[ domain.domainNameInLowerCase ] = domain;

            });

        };


        $scope.gotoExperiences = function( selectedDomain ){

            if( $scope.domainsMap[ selectedDomain ] )
            {
                dataFactory.setSelectedDomain( $scope.domainsMap[ selectedDomain ] );
                dataFactory.setSelectedDomainIndex( $scope.domainsMap[ selectedDomain ].index );
            }
            $scope.onGetStartedClick();

        };




        console.log("inside vegaDashboard controller", dataFactory.hasRequestedSandbox() );
        var plotChart = function ( chartData, weeks) {
            //var d1 = [[1,112],[2,102],[3,97]];
            var d1 = chartData;


        $.fn.UseTooltip = function () {
            var previousPoint = null;
            $(this).bind("plothover", function (event, pos, item) {
                if (item) {
                    if (previousPoint != item.dataIndex) {
                        previousPoint = item.dataIndex;

                        $("#tooltip").remove();

                        var x = item.datapoint[0];
                        var y = item.datapoint[1];
                         console.log("======="+weeks);
                        showTooltip(item.pageX, item.pageY,
                          weeks[x-1] + "<br/>" + "<strong>" + y + "</strong> (" + item.series.label + ")");
                    }
                }
                else {
                    $("#tooltip").remove();
                    previousPoint = null;
                }
            });
        };

        function showTooltip(x, y, contents) {
            $('<div id="tooltip">' + contents + '</div>').css({
                position: 'absolute',
                display: 'none',
                top: y + 5,
                left: x + 20,
                border: '2px solid #4572A7',
                padding: '2px',
                size: '10',
                'background-color': '#fff',
                opacity: 0.80
            }).appendTo("body").fadeIn(200);
        }

        $.plotAnimator($("#flot-placeholder"),
            [
                {
                    data:d1,
                    //label: "Mobile",
                    lines:
                        {
                            show: true
                        },
                    points:{show: true},
                    color: "#5ab1ef",
                    animator: 
                        { 
                            start: 1000, duration: 100, direction: "right" 
                        }
                }
            ],
            {
                grid: {
                    hoverable: true
                },
                xaxis: {
                    ticks: weeks
                }
            }
        );
        /* $("#flot-placeholder").UseTooltip(); */
         /* $("#flot-placeholder")
            $.plot($("#flot-placeholder"),
               [{data:d1,lines:{show: true},points:{show: true}}],
                {
                    xaxis: {
                        //ticks: [[1,'Jan 1, 2016'],[2,'Jan 8, 2016'],[3,'Jan 15, 2016']]
                        ticks: weeks
                    }
                }
            );  */
        }

        var plotChartProvision = function ( chartData,weeks ) {
            //var d1 = [[1,112],[2,102],[3,97]];
            var d1 = chartData;
            console.log("chartData2",chartData);
             $.fn.UseTooltip = function () {
            var previousPoint = null;
            $(this).bind("plothover", function (event, pos, item) {
                if (item) {
                    if (previousPoint != item.dataIndex) {
                        previousPoint = item.dataIndex;

                        $("#tooltip").remove();

                        var x = item.datapoint[0];
                        var y = item.datapoint[1];
                         console.log("======="+weeks);
                        showTooltip(item.pageX, item.pageY,
                          weeks[x-1] + "<br/>" + "<strong>" + y + "</strong> (" + item.series.label + ")");
                    }
                }
                else {
                    $("#tooltip").remove();
                    previousPoint = null;
                }
            });
        };

        function showTooltip(x, y, contents) {
            $('<div id="tooltip">' + contents + '</div>').css({
                position: 'absolute',
                display: 'none',
                top: y + 5,
                left: x + 20,
                border: '2px solid #4572A7',
                padding: '2px',
                size: '10',
                'background-color': '#fff',
                opacity: 0.80
            }).appendTo("body").fadeIn(200);
        }

        $.plotAnimator($("#flot-placeholder2"),
            [
                {
                    data:d1,
                    //label: "Mobile",
                    lines:
                        {
                            show: true
                        },
                    points:{show: true},
                    color: "#5ab1ef",
                    animator: 
                        { 
                            start: 1000, duration: 100, direction: "right" 
                        }
                }
            ],
            {
                grid: {
                    hoverable: true
                },
                xaxis: {
                    ticks: weeks
                }
            }
        );
        /* $("#flot-placeholder").UseTooltip(); */
         /* $("#flot-placeholder")
            $.plot($("#flot-placeholder"),
               [{data:d1,lines:{show: true},points:{show: true}}],
                {
                    xaxis: {
                        //ticks: [[1,'Jan 1, 2016'],[2,'Jan 8, 2016'],[3,'Jan 15, 2016']]
                        ticks: weeks
                    }
                }
            );  */
            /* $.plot($("#flot-placeholder2"),
               [{data:d1,lines:{show: true},points:{show: true}}],
                {
                    xaxis: {
                        //ticks: [[1,'Jan 1, 2016'],[2,'Jan 8, 2016'],[3,'Jan 15, 2016']]
                        ticks:weeks
                    }
                }
            ); */
        }

        function getDateOfISOWeek(week, year) {
            var simple = new Date(year, 0, 1 + (week - 1) * 7);
            var dow = simple.getDay();
            var ISOweekStart = simple;
            if (dow <= 4)
                ISOweekStart.setDate(simple.getDate() - simple.getDay() + 1);
            else
                ISOweekStart.setDate(simple.getDate() + 8 - simple.getDay());
            return ISOweekStart;
        }
        init();
    }
    
})();