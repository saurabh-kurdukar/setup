'use strict';
//var dev=true;
var app = angular.module('experienceApp',[
		'appRoutes',
		'ngStorage',
		'ngAnimate',
		'ui.bootstrap',
		'ngTagsInput',
		'ui.bootstrap.tpls',
		'experienceApp.appDataFactory',
		'experienceApp.dashboardController'	,	
		'experienceApp.experiencesController',
		'experienceApp.dashboradDirectives',
		'experienceApp.yoursandboxController',
		'experienceApp.galleryController',
		'experienceApp.loginController',
		'experienceApp.signupController',
		'experienceApp.expDetailsController',
		'experienceApp.activationController',
		'experienceApp.documentationController',
		'experienceApp.adminDocController',
		'experienceApp.developerDocController',
		'experienceApp.provisionStatusController',
		'experienceApp.expGuideController',
		'experienceApp.resetPasswordCtrl',
		'experienceApp.vegaDashboardController',
        'experienceApp.sa.yoursabdbox',
		'experienceApp.navbarController',
		'experienceApp.forgotPasswordController',
		'experienceApp.QRCodeCtrl',
		'experienceApp.FAQsCtrl',
		'experienceApp.healthcareData',
		'experienceApp.apiForm',
		'experienceApp.algorithm',
		'experienceApp.dataPipeline',
		'experienceApp.datasets',
		'experienceApp.apis',
		'ui.filters',
		'experienceApp.tryItvisualization',
		'experienceApp.forgotPassword',
		'experienceApp.connectors',
		'experienceApp.datatypes'
		
]);

app .filter('titleCase', function() {
    return function(input) {
      input = input || '';
      return input.replace(/\w\S*/g, function(txt){return txt.charAt(0).toUpperCase() + txt.substr(1).toLowerCase();});
    };
  });
app.run(['$rootScope', '$state', '$location', 'dataFactory', '$uibModal', '$anchorScroll','$templateCache',function($rootScope, $state ,$location ,dataFactory,$uibModal, $anchorScroll,$templateCache) {

   $templateCache.put("template/progressbar/progressbar.html",
    "<div class=\"progress\">\n" +
    "  <div class=\"progress-bar\" ng-class=\"type && 'progress-bar-' + type\" role=\"progressbar\" aria-valuenow=\"{{value}}\" aria-valuemin=\"0\" aria-valuemax=\"{{max}}\" ng-style=\"{width: percent + '%'}\" aria-valuetext=\"{{percent | number:0}}%\" ng-transclude></div>\n" +
    "</div>");


    $rootScope.$on('$stateChangeStart', function(evt, to, params) {
        //console.log("$location.search()",$location.search());
        if( $rootScope.isActivation == undefined )
        if( $location.path() == "/activation" )
        {
            $rootScope.activation = $location.search();
            $rootScope.isActivation = true;
        }
        
        $rootScope.selectedExperienceCount = 0;

    });

    $rootScope.$on('$stateChangeSuccess', function() {
        $anchorScroll('scroll-top');
     });

    $rootScope.handleErrors  = function ( errorObj ) {
		
        if( errorObj.apiResponse  )
        {
            if( errorObj.apiResponse.httpResponseCode=="401" || errorObj.apiResponse.httpResponseCode==401) 
            {
				
                    console.log("errorObj.apiResponse*************",errorObj.apiResponse);
					if(errorObj.apiResponse.errorMessage == "Invalid Token or Token expired")
					{
						$rootScope.showGlobalPopup = true;
						dataFactory.popupData("Your session has expired. Please log-in again");
						$rootScope.openGlobalPopup();						
						//$rootScope.alertMessage = "Your session has expired. Please log-in again";
						//console.log("$rootScope.alertMessage",$rootScope.alertMessage);
						dataFactory.logout();
					}
					else	{
						$rootScope.showGlobalPopup = true;
						dataFactory.popupData("Your session has expired. Please log-in again");
						$rootScope.openGlobalPopup();						
						//$rootScope.alertMessage = "Your session has expired. Please log-in again";	
						//console.log("$rootScope.alertMessage",$rootScope.alertMessage);	
						dataFactory.logout();	
					}
            }
			else if (errorObj.apiResponse.httpResponseCode=="500" || errorObj.apiResponse.httpResponseCode==500){
					if((errorObj.apiResponse.errorMessage=="Resource already exists")){
						$rootScope.showGlobalPopup = true;
						dataFactory.popupData("User already exists");
						$rootScope.openGlobalPopup();
					}
						else
						{
						$rootScope.showGlobalPopup = true;
						dataFactory.popupData("Please retry. Some error has occurred");
						$rootScope.openGlobalPopup();
						//$rootScope.alertMessage = "Please retry. Some error has occurred";	
						//console.log("$rootScope.alertMessage",$rootScope.alertMessage);	
			}
			}
            
         }
        /**    
          {
                    controller : "YOUR SANDBOX",
                    method : method,
                    postApiDataSent : postApiDataSent,
                    apiResponse : apiResponse
                }
        **/
        console.log( "error occured",errorObj );
    }; 
	
    $rootScope.openGlobalPopup =   function  (size) {

		var  modalInstance  =  $uibModal.open({      
			animation: $rootScope.animationsEnabled,
			      templateUrl:   'globalPopUpTemplate.html',
			      controller:   'modalControllerGlobal',
			      size: size,
			      resolve: {              }    
		});

		 
		modalInstance.result.then(function  (selectedItem) {      
			$rootScope.selected  =  selectedItem;    
		},  function  () {       //$log.info('Modal dismissed at: ' + new Date());
			    });

	}


}]);

//		'experienceApp.appDataFactory',
app.controller('appController', ['$scope','dataFactory', '$sessionStorage', '$rootScope', '$state',function DemoController($scope, dataFactory ,$localStorage ,$sessionStorage ,$rootScope ,$state) {
    
    
    
    var callErrorHandler = function ( method , apiResponse, postApiDataSent){

    var errorObj = {
                    controller : "appController",
                    method : method,
                    postApiDataSent : postApiDataSent,
                    apiResponse : apiResponse
                }
             //   $rootScope.handleErrors ( errorObj );
        };      
   
 /*   console.log("$rootScope.isActivation",$rootScope.isActivation);
    if( $rootScope.isActivation )
    {
         $state.go("activation");
     }
    */
     $scope.hiddenNavbarFooter = dataFactory.hiddenNavbarFooter();
    $scope.loadingText = dataFactory.loadingText();

            $scope.$watch(function() {
                return dataFactory.hiddenNavbarFooter();
            }, function(newValue, oldValue) {

              //  console.log("new value of loading text:-", newValue);
                 $scope.hiddenNavbarFooter = newValue;
            }); 

    
    //fetchAppMap();
    

    
    
   
//console.log("inside appController",$scope.$storage);

}]);
	

/* app.directive('onlyDigits', function () {
    return {
      require: 'ngModel',
      restrict: 'A',
      link: function (scope, element, attr, ctrl) {
        function inputValue(val) {
          if (val) {
            var digits = val.replace(/[^0-9]/g, '');

            if (digits !== val) {
              ctrl.$setViewValue(digits);
              ctrl.$render();
            }
            return parseInt(digits,10);
          }
          return undefined;
        }            
        ctrl.$parsers.push(inputValue);
      }
    };
});

 */
 
app.directive('tagsinput', tagsinput);
tagsinput.$inject = ['$timeout'];
function tagsinput ($timeout) {
	var directive = {
		link: link,
		require: 'ngModel',
		restrict: 'A'
	};
	return directive;

	function link(scope, element, attrs, ngModel) {
	  element.on('itemAdded itemRemoved', function(){
		// check if view value is not empty and is a string
		// and update the view from string to an array of tags
		if(ngModel.$viewValue && ngModel.$viewValue.split) {
		console.log('ngModel.$viewValue '+ngModel.$viewValue);
		  ngModel.$setViewValue( ngModel.$viewValue.split(',') );
		  ngModel.$render();
		}
	  });

	  $timeout(function(){
		element.tagsinput();
	  });
	}
};
app.controller("modalControllerGlobal",['$scope','$uibModalInstance', 'dataFactory',function($scope, $uibModalInstance, dataFactory){
    $scope.popupData = { alertMessage:"Your session has expired. Please log-in again"};
    
    $scope.$watch(function(){
        return dataFactory.popupData();
    },function( oldValue, newValue ){
         $scope.popupData.alertMessage = newValue;

    });
    
    $scope.closePopUp = function () {
        $uibModalInstance.dismiss('cancel');
      };
    
}]);