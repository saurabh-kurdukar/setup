var queryString="select Risklevel as Risklevel, count(PATIENTID) as count from RISK_ASSESSMENTS group by Risklevel order by Risklevel limit 50";

$.ajax({
url:'http://vega1fhir.centralindia.cloudapp.azure.com/fhir/Query/$execute',
data:"query="+queryString,
success: function(queryData) {

//**Transformation Script**/
var dataNames = [];
    var dataValues = [];
    queryData.forEach(function(Risklevel) {
      dataNames.push(Risklevel.Risklevel);
      dataValues.push({value: Risklevel.COUNT, name: Risklevel.Risklevel})
    })

//Graph script

var myChart = echarts.init(document.getElementById('bar'));

        option = {
            title : {
                text: 'Patients by Risklevel',
                subtext: 'Risklevel',
                x:'center'
            },
            tooltip : {
                trigger: 'item',
                formatter: "{a} <br/>{b} : {c} ({d}%)"
            },
            legend: {
                orient: 'vertical',
                left: 'left',
                data:dataNames
            },
            series : [
                {
                    name: 'Risklevel',
                    type: 'pie',
                    radius : '55%',
                    center: ['50%', '60%'],
                    data:dataValues,
                    itemStyle: {
                        emphasis: {
                            shadowBlur: 10,
                            shadowOffsetX: 0,
                            shadowColor: 'rgba(0, 0, 0, 0.5)'
                        }
                    }
                }
            ]
        };


        myChart.setOption(option);
}})