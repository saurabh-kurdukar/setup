var queryString="select patient.city as cityName, conditions.code as codeValue, count(PATIENT.patientid) as count from PATIENT as patient inner join CONDITIONS as condition on TO_CHAR(patient.patientid,'0')=condition.patientid group by patient.city, condition.code order by cityName asc, codeValue asc, count desc limit 100";

$.ajax({
url:'http://vega1fhir.centralindia.cloudapp.azure.com/fhir/Query/$execute',
data:"query="+queryString,
success: function(queryData) {

//**Transformation Script**/
dataNY = [];
dataSF = [];
dataLA = [];
  var cities = [];
  queryData.forEach(function(data) {
    if(cities.indexOf(data.CITYNAME) == -1) {
      cities.push(data.CITYNAME);
    }
  })
  var cityData = [];
  cities.forEach(function(city) {
    var temp = {};
    temp.count = 0;
    temp.pm25 = Math.round(Math.random() * 200);
    temp.pm10 = Math.round(Math.random() * 200);
    temp.city = city;
    temp.fields = [];
    cityData.push(temp);
  })
  queryData.forEach(function(data) {
    cityData.forEach(function(city) {
      if(city.city === data.CITYNAME) {
        var array = [];
        array.push(++city.count);
        array.push(parseInt(data.COUNT));
        array.push(city.pm25);
        array.push(city.pm10);
        array.push(data.CODEVALUE);
        city.fields.push(array);
      }
    })
  })
  dataNY = cityData[0].fields;
  dataSF = cityData[1].fields;
  dataLA = cityData[2].fields;

  var schema = [
      {name: 'City', index: 0, text: 'City'},
      {name: 'Count', index: 1, text: 'Count'},
      {name: 'PM25', index: 2, text: 'PM2.5'},
      {name: 'PM10', index: 3, text: 'PM10'},
      {name: 'Code', index: 4, text: 'Code'}
  ];
  console.log(JSON.stringify(dataNY));
  console.log(JSON.stringify(dataSF));
  console.log(JSON.stringify(dataLA));

//Graph script

var myChart = echarts.init(document.getElementById('bar'));

var itemStyle = {
    normal: {
        opacity: 0.8,
        shadowBlur: 10,
        shadowOffsetX: 0,
        shadowOffsetY: 0,
        shadowColor: 'rgba(0, 0, 0, 0.5)'
    }
};

var option = {
    backgroundColor: '#404a59',
    color: [
        '#dd4444', '#fec42c', '#80F1BE'
    ],
    legend: {
        y: 'top',
        data: ['New York', 'San Francisco', 'Los Angeles'],
        textStyle: {
            color: '#fff',
            fontSize: 16
        }
    },
    grid: {
        x: '10%',
        x2: 150,
        y: '18%',
        y2: '10%'
    },
    tooltip: {
        padding: 10,
        backgroundColor: '#222',
        borderColor: '#777',
        borderWidth: 1,
        formatter: function (obj) {
            var value = obj.value;
            return '<div style="border-bottom: 1px solid rgba(255,255,255,.3); font-size: 18px;padding-bottom: 7px;margin-bottom: 7px">'
                + obj.seriesName  + '</div>'
                + schema[4].text + '：' + value[4] + '<br>'
                + schema[1].text + '：' + value[1] + '<br>'
          		+ schema[2].text + '：' + value[2] + '<br>'
          		+ schema[3].text + '：' + value[3] + '<br>'
        }
    },
    xAxis: {
        type: 'value',
        name: 'City',
        nameGap: 16,
        nameTextStyle: {
            color: '#fff',
            fontSize: 14
        },
        max: 50,
        splitLine: {
            show: false
        },
        axisLine: {
            lineStyle: {
                color: '#eee'
            }
        }
    },
    yAxis: {
        type: 'value',
        name: 'Count',
        nameLocation: 'end',
        nameGap: 20,
        nameTextStyle: {
            color: '#fff',
            fontSize: 16
        },
        axisLine: {
            lineStyle: {
                color: '#eee'
            }
        },
        splitLine: {
            show: false
        }
    },
    visualMap: [
        {
            left: 'right',
            top: '10%',
            dimension: 2,
            min: 0,
            max: 250,
            itemWidth: 30,
            itemHeight: 120,
            calculable: true,
            precision: 0.1,
            text: ['Round Size：PM2.5'],
            textGap: 30,
            textStyle: {
                color: '#fff'
            },
            inRange: {
                symbolSize: [10, 70]
            },
            outOfRange: {
                symbolSize: [10, 70],
                color: ['rgba(255,255,255,.2)']
            },
            controller: {
                inRange: {
                    color: ['#c23531']
                },
                outOfRange: {
                    color: ['#444']
                }
            }
        },
        {
            left: 'right',
            bottom: '5%',
            dimension: 6,
            min: 0,
            max: 50,
            itemHeight: 120,
            calculable: true,
            precision: 0.1,
            text: ['Low - High : Condition'],
            textGap: 30,
            textStyle: {
                color: '#fff'
            },
            inRange: {
                colorLightness: [1, 0.5]
            },
            outOfRange: {
                color: ['rgba(255,255,255,.2)']
            },
            controller: {
                inRange: {
                    color: ['#c23531']
                },
                outOfRange: {
                    color: ['#444']
                }
            }
        }
    ],
    series: [
        {
            name: 'New York',
            type: 'scatter',
            itemStyle: itemStyle,
            data: dataNY
        },
        {
            name: 'San Francisco',
            type: 'scatter',
            itemStyle: itemStyle,
            data: dataSF
        },
        {
            name: 'Los Angeles',
            type: 'scatter',
            itemStyle: itemStyle,
            data: dataLA
        }
    ]
};

myChart.setOption(option);

}})
