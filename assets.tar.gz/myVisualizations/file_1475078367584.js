var queryString="select patient.city as cityName, conditions.code as codeValue, count(PATIENT.patientid) as count from PATIENT as patient inner join CONDITIONS as condition on TO_CHAR(patient.patientid,'0')=condition.patientid group by patient.city, condition.code order by cityName asc, codeValue asc, count desc limit 100";

$.ajax({
url:'http://vega1fhir.centralindia.cloudapp.azure.com/fhir/Query/$execute',
data:"query="+queryString,
success: function(queryData) {

//**Transformation Script**/

xAxisData=[];
yAxisData=[];
for(var i=0;i<queryData.length;i++)
{ 1
if(xAxisData.indexOf(queryData[i].CITYNAME)==-1)
  {
  xAxisData.push(queryData[i].CITYNAME);
  yAxisData.push(parseInt(queryData[i].COUNT));
  }
  else{
  yAxisData[xAxisData.indexOf(queryData[i].CITYNAME)]=yAxisData[xAxisData.indexOf(queryData[i].CITYNAME)]+parseInt(queryData[i].COUNT);
  }
}


//Graph script

var myChart = echarts.init(document.getElementById('bar'));

        var option = {
            title: {
                text: 'ECharts'
            },
            tooltip: {},
            legend: {
                data:['Months']
            },
            xAxis: {
                data: xAxisData
            },
            yAxis: {},
            series: [{
                name: 'sales',
                type: 'bar',
                data: yAxisData
            }]
        };

        myChart.setOption(option);
}})