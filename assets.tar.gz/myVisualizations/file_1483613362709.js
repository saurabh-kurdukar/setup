var queryString="select * from adidas";

$.ajax({
url:'http://vega1fhir.centralindia.cloudapp.azure.com/fhir/Query/$execute',
data:"query="+queryString,
success: function(queryData) {
console.log(queryData);
//**Transformation Script**/
  data={};
  data.labels=[];
  data.series=[];
  var tempArray=[];
for(var i=0;i<queryData.length;i++)
{
data.labels.push(queryData[i].X_VALUE);
tempArray.push(queryData[i].Y_TIME);
}
 data.series.push(tempArray);
//Graph script

// Create a new line chart object where as first parameter we pass in a selector
// that is resolving to our chart container element. The Second parameter
// is the actual data object.
new Chartist.Line('#bar', data);

}})