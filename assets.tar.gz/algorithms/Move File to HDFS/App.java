package com.google.zxing.core;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Hashtable;

import javax.imageio.ImageIO;
import javax.xml.bind.DatatypeConverter;

import com.google.zxing.BinaryBitmap;
import com.google.zxing.EncodeHintType;
import com.google.zxing.MultiFormatReader;
import com.google.zxing.Result;
import com.google.zxing.client.j2se.BufferedImageLuminanceSource;
import com.google.zxing.common.HybridBinarizer;
import com.google.zxing.qrcode.decoder.ErrorCorrectionLevel;

/**
 * Hello world!
 *
 */
public class App 
{
    public static void main( String[] args )
    {   
    	ExportToCsv();
        
    }
    	    
          	
    
    
    public static void ExportToCsv()
    {
    	  final String FILE_HEADER = "qrImageName,userName,password";
		  final String COMMA_DELIMITER = ",";		  
		  final String NEW_LINE_SEPARATOR = "\n";
		  FileWriter fileWriter = null;
	try {		
		 fileWriter = new FileWriter("qrInfo.csv");
		
		           //Write the CSV file header		
			            fileWriter.append(FILE_HEADER.toString());
		
			            //Add a new line separator after the header
		
		            fileWriter.append(NEW_LINE_SEPARATOR);
		
			            //Write a new student object list to the CSV file
		
		            
		            Result result = null;
		            BinaryBitmap binaryBitmap;
		            String basePath="/home/saurabh/Desktop/qrcodes/";

		            
		          //list all image files from directory
		        	File folder = new File(basePath);
		        	File[] listOfFiles = folder.listFiles();

		        	    for (int i = 0; i < listOfFiles.length; i++) {
		        	      if (listOfFiles[i].isFile()) {
		        	        System.out.println("File " + listOfFiles[i].getName());
		        	        try{    
		        	        	
		        	        	Hashtable<EncodeHintType, Object> hints = new
		        						Hashtable<EncodeHintType, Object>();
		        						hints.put(EncodeHintType.CHARACTER_SET, "ISO-8859-1");
		        						hints.put(EncodeHintType.ERROR_CORRECTION,
		        						ErrorCorrectionLevel.H);
		        						
		        	        	String qrImageName=basePath+listOfFiles[i].getName();
		        	        	binaryBitmap = new BinaryBitmap(new HybridBinarizer(new BufferedImageLuminanceSource(ImageIO.read(new FileInputStream(qrImageName)))));
		        	        	result = new MultiFormatReader().decode(binaryBitmap,hints);        	
		        	        	String url= result.getText();
		        	        	System.out.println("url"+url);
		        	        	String []arr= url.split(".jsp?");
		        	        	//decode Url
		        	        	String decoded = new String(DatatypeConverter.parseBase64Binary(arr[1]));
		        	            System.out.println("decoded value is \t" + decoded);
		        	            
		        	            String [] splitDecodedVal=decoded.split("&");    	            
		        	            
		        	            fileWriter.append(listOfFiles[i].getName());
				               fileWriter.append(COMMA_DELIMITER);
				                fileWriter.append(splitDecodedVal[0]);
				                fileWriter.append(COMMA_DELIMITER);
				                fileWriter.append(splitDecodedVal[1]);
				                fileWriter.append(NEW_LINE_SEPARATOR);	
		        	        	 
		        	        	}catch(Exception ex){
		        	        	ex.printStackTrace();
		        	        	}   
		        	      } 
		        	    }
		                    				             
			            System.out.println("CSV file was created successfully !!!");
		
			        } catch (Exception e) {
		
			            System.out.println("Error in CsvFileWriter !!!");
		
			            e.printStackTrace();
		
			        } finally {
			            try {		
			                fileWriter.flush();
		
			                fileWriter.close();
		
			            } catch (IOException e) {
		
			                System.out.println("Error while flushing/closing fileWriter !!!");
		
			                e.printStackTrace();
		
			            }					           		
			        }
		
			    }
		   	
    }

