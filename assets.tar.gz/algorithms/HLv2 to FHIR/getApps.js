var request = require('request');
var obj = {};

loginInRadia(obj);

function loginInRadia(obj) {

  console.log("Login to radia");
  var cookie = request.jar();

  var requestBody = {
    method: 'post',
    url: 'http://radia-core-api.cloudapp.net:3466/radiagw-server/tenant/j_security_check',
    jar: cookie,
    form: { j_username: 'radiaCustomer', j_password: 'secret' }
  };

  request(requestBody, function(err, res, body) {
    if(err) {
      cb(new Error("Error occurred while connecting to radia : " + err));
    }
    else {
      if(res.statusCode === 200 || res.statusCode === 302 || res.statusCode === 405) {
        console.log("Successfully logged in to radia!!!");
        obj.cookie = cookie;
        getAppsFromRadia(obj);
      }
      else {
        cb(new Error("Error occurred while logging to radia : " + body));
      }
    }
  })
}

function getAppsFromRadia(obj) {

  var requestBody = {
    method: 'get',
    url: 'http://radia-core-api.cloudapp.net:3466/radiagw-server/ws/radiaCustomer/services/MOBILE/apps',
    jar: obj.cookie,
    json: true
  };

  request(requestBody, function(err, res, body) {
    if(err) {
      cb(new Error("Error occurred while connecting to radia : " + err));
    }
    else {
      if(res.statusCode === 200) {
        console.log(body);
      }
      else {
        cb(new Error("Error occurred while fetching apps from radia : " + body));
      }
    }
  })
}
