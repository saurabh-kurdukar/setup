var myChart = echarts.init(document.getElementById('main'));

        var option = {
            title: {
                text: 'ECharts'
            },
            tooltip: {},
            legend: {
                data:['Months']
            },
            xAxis: {
                data: ["MedicationAdministration","AppointmentResponse","Mar","Apr","May","Jun"]
            },
            yAxis: {},
            series: [{
                name: 'sales',
                type: 'bar',
                data: [5, 20, 36, 10, 10, 20]
            }]
        };

        myChart.setOption(option);
