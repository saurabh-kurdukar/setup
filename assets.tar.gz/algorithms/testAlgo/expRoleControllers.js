App.controller('expRoleController', ['$rootScope', '$scope', '$http', '$state',
  function($rootScope, $scope, $http, $state) {

    $scope.arrayOfRoles = [];
	$scope.showRoleTable = false;
	
	
	
	//Add Roles
    $scope.addRole = function(roleName){
	var index = $scope.arrayOfRoles.indexOf(roleName);
	console.log("role is " + index);
	if(roleName == undefined || '' || (index >=0)){
	toastr.error("Please enter a logical Role ! ");
	}else {
	
	$scope.arrayOfRoles.push(roleName);
	$scope.showRoleTable = true;
	}
	};
    
  }
]);
