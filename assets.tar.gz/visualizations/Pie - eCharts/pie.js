var myChart = echarts.init(document.getElementById('bar'));

        option = {
            title : {
                text: 'Patients by city',
                subtext: 'city',
                x:'center'
            },
            tooltip : {
                trigger: 'item',
                formatter: "{a} <br/>{b} : {c} ({d}%)"
            },
            legend: {
                orient: 'vertical',
                left: 'left',
                data:dataNames
            },
            series : [
                {
                    name: 'Cities',
                    type: 'pie',
                    radius : '55%',
                    center: ['50%', '60%'],
                    data:dataValues,
                    itemStyle: {
                        emphasis: {
                            shadowBlur: 10,
                            shadowOffsetX: 0,
                            shadowColor: 'rgba(0, 0, 0, 0.5)'
                        }
                    }
                }
            ]
        };


        myChart.setOption(option);
