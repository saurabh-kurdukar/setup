var canvas = document.createElement('canvas');
$(canvas).attr("id","chart-area");  
var body = document.getElementById("bar");
body.appendChild(canvas);

var ctx = document.getElementById("chart-area").getContext("2d");

var data = {
    datasets: inputDatasets,
    labels: inputlabels
};

new Chart(ctx, {
    data: data,
    type: 'polarArea'
    
});