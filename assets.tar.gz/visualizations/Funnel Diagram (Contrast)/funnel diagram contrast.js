option = {
    title: {
        text: 'Funnel plot (Comparison)',
        subtext: 'Fictitious',
        left: 'left',
        top: 'bottom'
    },
    tooltip: {
        trigger: 'item',
        formatter: "{a} <br/>{b} : {c}%"
    },
    toolbox: {
        show: true,
        orient: 'vertical',
        top: 'center',
        feature: {
            dataView: {readOnly: false},
            restore: {},
            saveAsImage: {}
        }
    },
    legend: {
        orient: 'vertical',
        left: 'left',
        data: ['A','B','C','D','E']
    },
    calculable: true,
    series: [
        {
            name: 'Funnel plot',
            type: 'funnel',
            width: '40%',
            height: '45%',
            left: '5%',
            top: '50%',
            funnelAlign: 'right',

            center: ['25%', '25%'],  // for pie

            data:[
                {value:60, name:'C'},
                {value:30, name:'D'},
                {value:10, name:'E'},
                {value:80, name:'B'},
                {value:100, name:'A'}
            ]
        },
        {
            name: 'pyramid',
            type:'funnel',
            width: '40%',
            height: '45%',
            left: '5%',
            top: '5%',
            sort: 'ascending',
            funnelAlign: 'right',

            center: ['25%', '75%'],  // for pie

            data:[
                {value:60, name:'C'},
                {value:30, name:'D'},
                {value:10, name:'E'},
                {value:80, name:' B'},
                {value:100, name:'A'}
            ]
        },
        {
            name:'Funnel plot',
            type:'funnel',
            width: '40%',
            height: '45%',
            left: '55%',
            top: '5%',
            funnelAlign: 'left',

            center: ['75%', '25%'],  // for pie

            data: [
                {value: 60, name: 'C'},
                {value: 30, name: 'D'},
                {value: 10, name: 'E'},
                {value: 80, name: 'B'},
                {value: 100, name: 'A'}
            ]
        },
        {
            name: 'pyramid',
            type:'funnel',
            width: '40%',
            height: '45%',
            left: '55%',
            top: '50%',
            sort: 'ascending',
            funnelAlign: 'left',

            center: ['75%', '75%'],  // for pie

            data: [
                {value: 60, name: 'C'},
                {value: 30, name: 'D'},
                {value: 10, name: 'E'},
                {value: 80, name: 'B'},
                {value: 100, name: 'A'}
            ]
        }
    ]
};
var myChart = echarts.init(document.getElementById('bar'));
  myChart.setOption(option);