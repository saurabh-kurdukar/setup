var canvas = document.createElement('canvas');
$(canvas).attr("id","chart-area");
var body = document.getElementById("bar");
body.appendChild(canvas);

var ctx = document.getElementById("chart-area").getContext("2d");

var myRadarChart = new Chart(ctx, {
    type: 'radar',
    data: data
});
