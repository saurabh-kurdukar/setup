Plotly.d3.json(url, function(err, rawData) {
    if(err) throw err;

    plot(rawData);
});

function plot(rawData) {
    var data = Object.keys(rawData).map(function(k, i) {
        var pts = rawData[k];
        pts = pts.concat(pts[0]);

        return {
            type: 'scatterternary',
            mode: 'lines',
            name: k,
            a: pts.map(function(d) { return d.clay }),
            b: pts.map(function(d) { return d.sand }),
            c: pts.map(function(d) { return d.silt }),
            line: { color: '#444' },
            fill: 'toself',
            fillcolor: colors[i],
            hoveron:'fills+points'
        };
    });

    var layout = {
        ternary: {
            sum: 100,
            aaxis: makeAxis('Clay'),
            baxis: makeAxis('Sand'),
            caxis: makeAxis('Silt')
        },
        showlegend: false,
        width: 700,
        annotations: [{
            showarrow: false,
            text: 'Soil Types Fill Plot',
            x: 0.15,
            y: 1.1
        }]
    };

    Plotly.plot('bar', data, layout);
}

function makeAxis(title) {
  return {
      title: title,
      ticksuffix: '%',
      min: 0.01,
      linewidth: 2,
      ticks: 'outside',
      ticklen: 8,
      showgrid: true,
  };
}
