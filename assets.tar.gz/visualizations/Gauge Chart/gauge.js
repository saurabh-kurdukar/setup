

new Chartist.Pie('#bar', {
  series: data
}, {
  donut: true,
  donutWidth: 60,
  startAngle: 270,
  total: 200,
  showLabel: false
});