function getrandom(num , mul)
  {
    var value = [ ]
    for(i=0;i<=num;i++)
     {
     rand = Math.random() * mul;
     value.push(rand);
     }
    return value;
  }

var data = [trace1, trace2, trace3, trace4, trace5];

Plotly.plot('bar', data, layout);
