var fig = PlotlyFinance.createCandlestick(
    {
        open: [33.0, 33.3, 33.5, 33.0, 34.1],
        high: [33.1, 33.3, 33.6, 33.2, 34.8],
        low: [32.7, 32.7, 32.8, 32.6, 32.8],
        close: [33.0, 32.9, 33.3, 33.1, 33.1],
        dates: [
            [2013,10,10] ,[2013,11,10], [2013,12,10], [2014,1,10], [2014,2,10]
        ].map(function(d) { return new Date(d[0], d[1]-1, d[2]); })
    }
);
Plotly.newPlot('bar', fig.data, fig.layout);