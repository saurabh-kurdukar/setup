var myChart = echarts.init(document.getElementById('bar'));

        var option = {
            title: {
                text: 'ECharts'
            },
            tooltip: {},
            legend: {
                data:['Months']
            },
            xAxis: {
                data: xAxisData
            },
            yAxis: {},
            series: [{
                name: 'sales',
                type: 'bar',
                data: yAxisData
            }]
        };

        myChart.setOption(option);