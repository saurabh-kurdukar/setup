function ConvertToCSV(objArray) {
     var array = JSON.parse(objArray);
     var str = '';

     for (var i = 0; i < array.length; i++) {
         var line = '';
         for (var index in array[i]) {
             if (line != '') line += ','

             line += array[i][index];
         }

         str += line + '\n';
     }

     return str;
}

var result = ConvertToCSV(connectorMessage.getRawData());

connectorMap.put('result',result);
