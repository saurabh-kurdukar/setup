var logger = require('../../common/logger').log;
var radiaHelper = require('../../radia-adapter/client');
var request = require('request');
var config = require('../../common/Config');
var fs = require('fs');
const MODULE_NAME = 'radia-app';

function validateAndVerifyFiles(provisionRequest, cb) {
	logger.info(MODULE_NAME + ' : helpers : received request : validateAndVerifyFiles : ' + JSON.stringify(provisionRequest.newApp));

	var appExt = provisionRequest.newApp.distribution.split('.').pop();
	var logoExt = provisionRequest.newApp.logo.split('.').pop();
	var screenshotExt = provisionRequest.newApp.screenshots[0].split('.').pop();

	if(logoExt != "jpg" && logoExt != "jpeg" && logoExt != "png") {
		cb(new Error("Logo file should be jpg or png"), null);
		return;
	}
	else if(screenshotExt != "jpg" && screenshotExt != "jpeg" && screenshotExt != "png") {
		cb(new Error("Screenshot file should be jpg or png"), null);
		return;
	}
	else if(provisionRequest.oldApp.type == config.APPLICATION_TYPE.ANDROID && appExt != "apk") {
		cb(new Error("Distribution file should be apk"), null);
		return;
	}
	else if(provisionRequest.oldApp.type == config.APPLICATION_TYPE.IOS && appExt != "ipa") {
		cb(new Error("Distribution file should be ipa"), null);
		return;
	}
	else {

		var appFile = provisionRequest.newApp.distribution.split('/').pop();
		var logoFile = provisionRequest.newApp.logo.split('/').pop();
		var screenshotFile = provisionRequest.newApp.screenshots[0].split('/').pop();

		var appPath = config.MEDIA_DISTRIBUTION_LOCATION + appFile;
		var logoPath = config.MEDIA_DISTRIBUTION_LOCATION + logoFile;
		var screenshotPath = config.MEDIA_DISTRIBUTION_LOCATION + screenshotFile;

		provisionRequest.newApp.distribution = appPath;
		provisionRequest.newApp.logo = logoPath;
		provisionRequest.newApp.screenshots[0] = screenshotPath;

		if(!fs.existsSync(provisionRequest.newApp.distribution)) {
			cb(new Error(appFile + " file not found"), null);
			return;
		}
		else if(!fs.existsSync(provisionRequest.newApp.logo)) {
			cb(new Error(logoFile + " file not found"), null);
			return;
		}
		else if(!fs.existsSync(provisionRequest.newApp.screenshots[0])) {
			cb(new Error(screenshotFile + " file not found"), null);
			return;
		}
		else {
			logger.info(MODULE_NAME + ' : helpers : received request : validateAndVerifyFiles : Files validated and verified successfully');
			cb(null, provisionRequest);
		}
	}
}

function removeAppAssignments(provisionRequest, assignments, cb) {
	logger.info(MODULE_NAME + ' : helpers : received request : removeAppAssignments : ' + JSON.stringify(assignments));

	if(provisionRequest.noAssignedGroups == true) {
		cb(null, provisionRequest);
		return;
	}

	var appGroups = [];

	assignments.forEach(function(assignment) {
		appGroups.push(assignment.dn);
	});

	var unassignFromGroup = {
		dn: null,
		apps: [
		  {
		    instanceName: provisionRequest.radiaAppName,
		    domainname: "MOBILE"
		  }
		]
	}

	provisionRequest.appGroups = appGroups;

	appGroups.forEach(function(appGroup, index, array) {

		unassignFromGroup.dn = appGroup;

		var requestBody = {
			method: 'put',
			url: config.RADIA_BASE_URL + '/ws/radiaCustomer/policy?operation=delete',
			jar: provisionRequest.cookie,
			json: true,
			body: unassignFromGroup
		};

		request(requestBody, function (err, res, body) {
			if(err) {
				cb(err, null);
			}
			else if(res.statusCode === 200 && body) {
				if(index == array.length - 1) {
					cb(null, provisionRequest);
				}
			}
			else {
				cb(new Error("Error while unassigning app from group"), null);
			}
		});
	})
}


function assignAppToGroups(provisionRequest, cb) {

	logger.info(MODULE_NAME + ' : helpers : received request : assignAppToGroups : ' + JSON.stringify(provisionRequest));

  var processResponse = function (err, res, body) {
    if (err) {
      cb(new PlatformError('RDIA001', [], 500, err));
    } else if(res.statusCode === 200 && body) {
			// console.log("App assigned to groups");
      cb(null, provisionRequest);
    } else {
      cb(new PlatformError('RDIA004', [], 500, body));
    }
  };

	var assignToGroup = {
	  dn: null,
	  apps: [
	    {
	      instanceName: provisionRequest.radiaAppName,
	      domainname: "MOBILE"
	    }
	  ]
	}

	provisionRequest.appGroups.forEach(function(group, index, array) {
		assignToGroup.dn = group;

		var requestBody = {
			//  proxy:config.NETWORK_PROXY+":"+config.NETWORK_PROXY_PORT ,
			method: 'put',
			url: config.RADIA_BASE_URL + '/ws/radiaCustomer/policy?operation=add',
			jar: provisionRequest.cookie,
			json: true,
			body: assignToGroup
		};

		request(requestBody, function (err, res, body) {
			if(err) {
				cb(err, null);
			}
			else if(res.statusCode === 200 && body) {
				if(index == array.length - 1) {
					cb(null, provisionRequest);
				}
			}
			else {
				cb(new Error("Error while assigning app to group"), null);
			}
		});
	})
}


module.exports = {
	validateAndVerifyFiles: validateAndVerifyFiles,
  removeAppAssignments: removeAppAssignments,
  assignAppToGroups: assignAppToGroups
}
