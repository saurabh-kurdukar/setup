var logger = require('../../common/logger').log;
var async = require('async');
var App = require('../../application/models/App');
var UserCredential = require('../../radia-adapter/dto/user-credential');
var config = require('../../common/Config');
var PlatformError = require('../../common/platform-error');
var radiaHelper = require('../../radia-adapter/client');
var radiaAssignmentHelper = require('../helpers/RadiaAppAssignment');
var util = require('util');
var fs = require('fs');
var request = require('request');
const MODULE_NAME = 'radia-app';

/*
 * Edit/Update app
 */
var updateAppOnRadia = function(req, res, callback) {
	logger.info(MODULE_NAME + ' : controller : received request : updateAppOnRadia : (appId:'+req.params.id+', body:'+JSON.stringify(req.body)+')');

	var provisionRequest = {
		"oldApp": {
			"name": req.params.name
		},
		"newApp": req.body
	}

	App.findOne({
		"name": req.params.name.replace(/_/g,' ')
	}, function(err, data) {
		if(err) {
			logger.error(`Request # ${provisionRequest.oldApp.name} : Could not fetch application from mongodb`);
			cb(err,null);
		}
		else {

			if(data) {

				provisionRequest.oldApp.type = data.type;

				async.waterfall([
			     async.apply(validateAndVerifyFilesBeforeUpload, provisionRequest),
					 loginInRadia,
			     getAssignmentsForApp,
			     removeAppAssignmentsFromApp,
			     deleteAppFromRadia,
			     uploadAppToRadia,
			     assignAppToGroupsInRadia
				],
				function(err, result) {
					if(err) {
						return callback(err);
					}
					callback(null, 'App updated successfully.');
				});
			}
			else {
				callback(new Error("No App Found with name '" + req.params.name.replace('_',' ') + "'"), null);
			}
		}
	})
};


function validateAndVerifyFilesBeforeUpload(provisionRequest, cb) {
	radiaAssignmentHelper.validateAndVerifyFiles(provisionRequest, cb);
}

function loginInRadia(provisionRequest, cb) {
	radiaHelper.login(provisionRequest, cb);
}

function getAssignmentsForApp(provisionRequest, cb) {
	radiaHelper.getAppAssignments(provisionRequest, function(err, provisionRequest, bodyJson) {
		if(err) {
			logger.error(MODULE_NAME + ' : controller : received request : getAssignmentsForApp : Error getting assignments for app : ' + provisionRequest.oldApp.name);
			cb(err);
		}
		else {
			logger.info(MODULE_NAME + ' : controller : received request : getAssignmentsForApp : Writing file for app assignments');
			var folderPath = "./radiaAppAssignments/";
			if(!fs.existsSync(folderPath)) {
		    fs.mkdirSync(folderPath);
		  }
			var fileName = provisionRequest.oldApp.name + "_Assignments_" + new Date().getTime() + ".json";
			fs.writeFile(folderPath + fileName, JSON.stringify(bodyJson), 'utf8', function(error) {
				if(error) {
					logger.error(MODULE_NAME + ' : controller : received request : getAssignmentsForApp : Error while writing file for app assignments');
					cb(err);
				}
				else {
					logger.info(MODULE_NAME + ' : controller : received request : getAssignmentsForApp : Writing file for app assignments completed');
					cb(null, provisionRequest, bodyJson);
				}
			});
		}
	});
}

function removeAppAssignmentsFromApp(provisionRequest, appAssignments, cb) {
	radiaAssignmentHelper.removeAppAssignments(provisionRequest, appAssignments, cb);
}

function deleteAppFromRadia(provisionRequest, cb) {
	radiaHelper.deleteApp(provisionRequest, cb);
}


function uploadAppToRadia(provisionRequest, cb) {
	radiaHelper.uploadApplication(provisionRequest, cb);
}


function assignAppToGroupsInRadia(provisionRequest, cb) {
	if(provisionRequest.noAssignedGroups == true) {
		cb(null, provisionRequest);
		return;
	}
	else {
		radiaAssignmentHelper.assignAppToGroups(provisionRequest, cb);
	}
}



module.exports.updateAppOnRadia = updateAppOnRadia;
