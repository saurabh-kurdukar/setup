var express = require('express');
var logger = require('../common/logger').log;
var RadiaAppController = require('./controller/RadiaAppController');
var ErrorResponse = require('../common/ErrorResponse').ErrorResponse;
var router = express.Router();
const MODULE_NAME = 'radia-app';


/*
 * Update app on radia
 */
router.put('/:name', function(req, res) {
	logger.info(MODULE_NAME + ' : router : received request : updateAppOnRadia : (appName:'+req.params.name+', body:'+JSON.stringify(req.body)+')');
	RadiaAppController.updateAppOnRadia(req, res, function(err, data) {
		if (err) {
			logger.error(MODULE_NAME + ' : router : failed updateAppOnRadia : error : ' + err);
			var error = new ErrorResponse();
			error.setErrorMessage(err.message);
			error.setErrorCode("RA0001");
			error.setHttpResponseCode(500);
			res.status(500).end(JSON.stringify(error));
		} else {
			logger.info(MODULE_NAME + " : router : updateAppOnRadia successful !");
			res.status(200).end(JSON.stringify(data));
		}
	});
});


module.exports = router;
