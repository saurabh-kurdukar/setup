var express = require('express');
var documentController = require('./controller/DocumentController');
var experiencesEnrolledController = require('../experiencesenrolled/controller/ExperiencesEnrolledController');
var logger = require('../common/logger').log;
var ErrorResponse = require('../common/ErrorResponse').ErrorResponse;
var router = express.Router();
var ResourceBundle = require('./../common/resource-bundle.js'),
PlatformError = require('../common/platform-error'),
rsBundle = new ResourceBundle(['./../radia-adapter/resource/lang/']);
const MODULE_NAME = 'documents';
/*
* logging format followed: logger.info(<module_name>: <component name> : <description> : [<long_description>] : <data/params/errors>);
*/

/*
* Add new document
*/
router.post('/', function(req, res) {
	logger.info(MODULE_NAME + ' : router : received request : addNewDocument : body : '+JSON.stringify(req.body));
	documentController.addNewDocument(req, function(err, data) {
		if(err) {
			logger.error(MODULE_NAME + ' : router : failed addNewDocument : error : '+err);
			var error = new ErrorResponse();
			if(err.name == 'ValidationError'){
				error.setErrorMessage(err.errors[Object.keys(err.errors)[0]].message);
			} else {
				error.setErrorMessage(err.message);
			}
			error.setErrorCode("DOC0001");
			error.setHttpResponseCode(err.status);
			return res.status(err.status).end(JSON.stringify(error));
		}
		logger.info(MODULE_NAME + ' : router : addNewDocument successful !');
		res.status(200).end(JSON.stringify(data));	
	});
});

/*
* Get document by id
*/
router.get('/:id', function (req, res) {
	logger.info(MODULE_NAME + ' : router : received request : getDocumentById : id : '+req.params.id);
	documentController.getDocumentById(req, function(err, data) {
		if(err){
			logger.error(MODULE_NAME + ' : router : failed getDocumentById : error : '+err);
			var error = new ErrorResponse();
			error.setErrorCode("DOC0002");
			error.setErrorMessage(err.message);
			error.setHttpResponseCode(err.status);
			return res.status(err.status).end(JSON.stringify(error));
		}
		logger.info(MODULE_NAME + ' : router : getDocumentById successful !') ;
		res.status(200).end(JSON.stringify(data));		
	});
});

/*
* Update document
*/
router.put('/:id', function(req, res){
	logger.info(MODULE_NAME + ' : router : received request : updateDocumentById : (id: '+req.params.id+', body: '+JSON.stringify(req.body)+')');
	documentController.updateDocumentById(req, function(err, data) {
		if(err){
			logger.error(MODULE_NAME + ' : router : failed updateDocumentById : error : '+err);
			var error = new ErrorResponse();
			if(err.name == 'ValidationError'){
				error.setErrorMessage(err.errors[Object.keys(err.errors)[0]].message);
			} else {
				error.setErrorMessage(err.message);
			}
			error.setErrorCode("DOC0003");
			error.setHttpResponseCode(err.status);
			return res.status(err.status).end(JSON.stringify(error));
		}
		logger.info(MODULE_NAME + ' : router : updateDocumentById successful !');
		res.status(200).end(JSON.stringify(data));	
	});
});

/*
* Delete document
*/
router.delete('/:id', function(req, res){
	logger.info(MODULE_NAME + ' : router : received request : deleteDocumentById : (id: ' + req.params.id + ')');
	documentController.deleteDocumentById(req, function(err, data) {
		if(err){
			logger.error(MODULE_NAME + ' : router : failed deleteDocumentById : error : ' + err);
			var error = new ErrorResponse();			
			error.setErrorMessage(err.message);			
			error.setErrorCode("DOC0004");
			error.setHttpResponseCode(err.status);
			return res.status(err.status).end(JSON.stringify(error));
		}
		logger.info(MODULE_NAME + ' : router : deleteDocumentById successful !');
		res.status(200).end(JSON.stringify(data));	
	});
});

/*
* Get all documents
*/
router.get('/', function (req, res) {
	logger.info(MODULE_NAME + ' : router : received request : getAllDocuments ');
	documentController.getAllDocuments(req, res, function(err, data) {
		if(err){
			logger.error(MODULE_NAME + ' : router : failed getAllDocuments : error : '+err);
			var error = new ErrorResponse();
			error.setErrorCode("DOC0005");
			error.setErrorMessage(err.message);
			error.setHttpResponseCode(err.status);
			return res.status(err.status).end(JSON.stringify(error));
		}
		logger.info(MODULE_NAME + ' : router : getAllDocuments successful !') ;
		res.status(200).end(JSON.stringify(data));		
	});
});

module.exports = router;
