var async = require('async');
var documentDao = require('../dao/DocumentDAO');
var appDao = require('../../application/dao/AppDAO');
var serviceDao = require('../../service/dao/ServiceDAO');
var experienceDao = require('../../experience/dao/ExperienceDAO');
var logger = require('../../common/logger').log;
var audit = require('../../common/Audit').audit;
const MODULE_NAME = "documents";

/*
* logging format followed: logger.info(<module_name>: <component name> : <description> : [<long_description>] : <data/params/errors>);
*/


/*
* Add new document
*/
var addNewDocument = function(req, callback) {
	logger.info(MODULE_NAME + ' : controller : received request : addNewDocument : body : '+JSON.stringify(req.body));	
	var appId = req.body.appId;
	var serviceId = req.body.serviceId;
	var experienceId = req.body.experienceId;
	if(experienceId || experienceId && appId || experienceId && serviceId) {
		async.parallel([
		      function(cb) {
		    	  if(appId) {
				    	appDao.existAppId(appId, function(err){
				    		if(err) {
				    			return cb(err);
				    		}
				    		cb();
				    	});
		    	  } else {
		    		  cb();
		    	  }
		      },
		      function(cb) {
		    	  if(serviceId) {
			    	  serviceDao.existServiceId(serviceId, function(err){
			    		  if(err) {
				    			return cb(err);
				    	  }
				    	  cb();
			    	  });
		    	  } else {
		    		  cb();
		    	  }
		      },
		      function(cb) {	    	  
		    	  experienceDao.existExperienceId(experienceId, function(err){
		    		  if(err) {
			    			return cb(err);
			    	  }
			    	  cb();
		    	  });	    	  
		      }
		], 
		function(err, data){
			if(err) {
				err.status = 500;
				return callback(err);
			}
			documentDao.addNewDocument(req, callback);	
		});
	} else {
		var err = new Error('experienceId, appId or serviceId is not set');
		err.status = 200;
		callback(err);
	}
};

/*
* Get document by id
*/
var getDocumentById = function(req, callback) {
	logger.info(MODULE_NAME + ' : controller : received request : getDocumentById : id : '+req.params.id);
	documentDao.getDocumentById(req.params.id, callback);
};

/*
* Update document
*/
var updateDocumentById = function(req, callback) {
	logger.info(MODULE_NAME + ' : controller : received request : updateDocumentById : (id: ' + req.params.id + ', body: ' + JSON.stringify(req.body) + ')');
	/*
	 *  Get existing record from database to get existing values (will be used for audit)
	 *  If record exist, compare existing values with requested values.
	 *  Update values which are new.
	 */
	documentDao.getDocumentById(req.params.id, function(err, doc) {
		if(err) {
			logger.error(MODULE_NAME+' : controller : failed getDocumentById : error : ' + err);
			return callback(err);
		}
		var document = doc;
		var updatableFields = [
           "appId", "serviceId", "experienceId", "summary",  "description", 
           "logo",  "mediaFile", "ISBN", "version"
	    ];
		var updatedData = [];
		var json = {};
		var reqBodyKeys = Object.keys(req.body);
		for(var i = 0; i < reqBodyKeys.length; i++) {				
			if(updatableFields.indexOf(reqBodyKeys[i]) > -1 && document[reqBodyKeys[i]] != req.body[reqBodyKeys[i]]) {
				json[reqBodyKeys[i]] = req.body[reqBodyKeys[i]];
				var obj = {};
				obj.column = reqBodyKeys[i];
				obj.oldValue = document[reqBodyKeys[i]];
				obj.newValue = req.body[reqBodyKeys[i]];
				obj.identifier = 'Platform_document_'+req.params.id;
				obj.modifiedBy = req.header('username');
				obj.modifiedOn = new Date();
				updatedData.push(obj);
			}
		}	
		if(req.body.authors && req.body.authors.length) {				
			json.authors = req.body.authors;			
		}	
		if(req.body.publishers && req.body.publishers.length) {				
			json.publishers = req.body.publishers;					
		}
		if(req.body.tags && req.body.tags.length) {				
			json.tags = req.body.tags;					
		}
		var updateDoc = false;
		if(Object.keys(json).length != 0) {
			updateDoc = true;
		}		
		if (updateDoc) {
			json.updatedOn = new Date();
			json.updatedBy = req.header('username');
			logger.info(MODULE_NAME+' : controller : updateDocumentById : updating data : ' + JSON.stringify(json));
			documentDao.updateDocumentById(req.params.id, json, function(err, data){
				if(err) {
					return callback(err);
				}
				audit(req, null, updatedData);
				callback(null, data);
			});		
		} else {
			var err = new Error('Already up to date');
			err.status = 200;
			logger.error(MODULE_NAME+' : controller : failed updateDocumentById : error : ' + err);
			callback(err, null);
		}		
	});	
};

/*
* Delete document
*/
var deleteDocumentById = function(req, callback) {
	logger.info(MODULE_NAME + ' : controller : received request : deleteDocumentById : id : '+req.params.id);
	documentDao.getDocumentById(req.params.id, function(err, data) {
		if(err) {
			logger.error(MODULE_NAME + ' : controller : failed deleteDocumentById : error :' + err);
			return callback(err);
		}
		var document = data;
		var updatedData = [];
		if(document.status != 'ARCHIVED') {
			var json = {
				'status': 'ARCHIVED',
				'updatedBy': req.header('username'),
				'updatedOn': new Date()
			};
			documentDao.deleteDocumentById(req.params.id, json, function(err, data) {
				if (err) {
					logger.error(MODULE_NAME + ' : controller : failed deleteDocumentById : error :' + err);
					return callback(err);
				}
				logger.info(MODULE_NAME + ' : controller : deleteDocumentById successful !');
				var obj = {};
				obj.column = 'status';
				obj.oldValue = document['status'];
				obj.newValue = 'ARCHIVED';
				obj.identifier = 'Platform_documents_'+req.params.id;
				obj.modifiedBy = req.header('username');
				obj.modifiedOn = new Date();
				updatedData.push(obj);
				/*	Call audit function for changed data  */
				audit(req, null, updatedData);
				/*  Call function to send response to client  */
				callback(null, data);						
			});
		} else {
			var err = new Error('Already deleted');
			err.status = 200;
			logger.error(MODULE_NAME + ' : controller : failed deleteDocumentById : error :' + err);
			callback(err);
		}		
	});	
};

/*
* Get all documents
*/
var getAllDocuments = function(req, res , callback) {
	logger.info(MODULE_NAME + ' : controller : received request : getAllDocuments ');
	documentDao.getAllDocuments(req, res, callback);
};

module.exports.addNewDocument = addNewDocument;
module.exports.getDocumentById = getDocumentById;
module.exports.updateDocumentById = updateDocumentById;
module.exports.deleteDocumentById = deleteDocumentById;
module.exports.getAllDocuments= getAllDocuments;

