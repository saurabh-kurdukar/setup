var mongoose = require('../../common/MongoDbConnection').mongoose;
var autoIncrement = require('mongoose-auto-increment');
var logger = require('../../common/logger').log;
const MODULE_NAME = "documents";
var connection = mongoose.connection;
autoIncrement.initialize(connection);


/*
 * logging format followed: logger.info(<module_name>: <component name> :
 * <description> : <long_description> : <data/params/errors>);
 */


/*
 * Define schema
 */
var documentSchema = mongoose.Schema({
	
	id: Number,
	name: { type: String, required: 'Document name is required' },
	appId: Number, 
	serviceId: Number, 
	experienceId: { type:Number, required: 'field experienceId is required' },
	summary: { type: String },
	description: { type: String },
	logo: { type: String },
	mediaFile: { type: String },
	authors: [ ],
	publishers: [ ],
	ISBN: { type: String },	
	tags: [ ],
	version: { type: String },
	status: { type: String, default: 'ACTIVE' },
	createdOn: { type: Date, default: Date.now },
	createdBy: {type: String},
	updatedOn: { type: Date, default: Date.now },
	updatedBy: {type: String}
	
});


logger.info(MODULE_NAME + ' : model : created schema : Document :'+JSON.stringify(documentSchema.paths));


documentSchema.pre('findOneAndUpdate', function(next) {
	  this.options.runValidators = true;
	  next();
});

documentSchema.path('name').validate(function (v) {
	  return (v.length > 0 && v.length <= 100);
}, 'data too long/short for field name'); 



/*
 * Add Auto increment plugin
 */
documentSchema.plugin(autoIncrement.plugin, { model: 'Documents', field: 'id', startAt: 1 });


/*
 * Setters
 */
documentSchema.methods.setId = function(id) {	
	this.id = id;
};

documentSchema.methods.setName = function(name) {
	this.name = name;
};

documentSchema.methods.setAppId = function(appId) {
	this.appId = appId;
};

documentSchema.methods.setServiceId = function(serviceId) {
	this.serviceId = serviceId;
};

documentSchema.methods.setExperienceId = function(experienceId) {
	this.experienceId = experienceId;
};

documentSchema.methods.setSummary = function(summary) {
	this.summary = summary;
};

documentSchema.methods.setDescription = function(description) {
	this.description = description;
};

documentSchema.methods.setLogo = function(logo) {
	this.logo = logo;
};

documentSchema.methods.setMediaFile = function(mediaFile) {
	this.mediaFile = mediaFile;
};

documentSchema.methods.addAuthors = function(authors) {
	this.authors.apply(this.authors, authors);
};

documentSchema.methods.addPublisher = function(publishers) {
	this.publishers.apply(this.publishers, publishers);
};

documentSchema.methods.setISBN = function(ISBN) {
	this.ISBN = ISBN;
};

documentSchema.methods.addTag = function(tags) {
	this.tags.push(this.tags, tags);
};

documentSchema.methods.setVersion = function(version) {
	this.version = version;
};

documentSchema.methods.setCreatedOn = function(createdOn) {
	this.createdOn = createdOn;
};

documentSchema.methods.setCreatedBy = function(createdBy) {
	this.createdBy = createdBy;
};

documentSchema.methods.setUpdatedOn = function(updatedOn) {
	this.updatedOn = updatedOn;
};

documentSchema.methods.setUpdatedBy = function(updatedBy) {
	this.updatedBy = updatedBy;
};

/*
 * Create collection/model in mongo db using Schema
 */
var Document = mongoose.model('Documents', documentSchema);
logger.info(MODULE_NAME + ' : model : created model : Document : ' + Document);



module.exports = Document;