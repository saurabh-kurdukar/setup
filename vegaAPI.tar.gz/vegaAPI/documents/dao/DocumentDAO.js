var async = require('async');
var Document = require('../models/Document');
var logger = require('../../common/logger').log;
var audit = require('../../common/Audit').audit;
var config = require('../../common/Config');
const MODULE_NAME = "documents";

/*
 * logging format followed: logger.info(<module_name>: <component name> : <description> : [<long_description>] : <data/params/errors>);
 */


/*
 * Add new document
 */
var addNewDocument = function(req, callback) {
	logger.info(MODULE_NAME + ' : DAO : received request : addNewDocument : body : '
			+ JSON.stringify(req.body));	
	var document = new Document(req.body);
	document.setCreatedBy(req.header('username'));	
	document.setUpdatedBy(req.header('username'));
	document.save(function(err, data) {
		if (err) {
			err.status = 500;
			logger.error(MODULE_NAME + ' : DAO : failed addNewDocument : error : ' + err);
			return callback(err);
		}		
		logger.info(MODULE_NAME + ' : DAO : addNewDocument successful !');
		callback(null, data);				
	});
};

/*
 * Get document by id
 */
var getDocumentById = function(id, callback) {
	logger.info(MODULE_NAME + ' : DAO : received request : getDocumentById : id : ' + id);
	Document.findOne({
		'id' : id
	}, function(err, data) {
		if (err) {
			err.status = 500;
			logger.error(MODULE_NAME + ' : DAO : failed getDocumentById : error : ' + err);
			return callback(err);
		}
		if (data) {
			logger.info(MODULE_NAME + ' : DAO : getDocumentById successful !');
			return callback(null, data);
		}
		var err = new Error('no record exist for document id');
		err.status = 200;
		logger.error(MODULE_NAME + ' : DAO : failed getDocumentById : error : '+ err);
		callback(err);
	});
};

/*
 * Update document
 */
var updateDocumentById = function(id, json, callback) {
	logger.info(MODULE_NAME + ' : DAO : received request : updateDocumentById : (id:' + id + ', data:' + JSON.stringify(json) + ')');
	Document.findOneAndUpdate({
		'id' : id
	}, json, {
		'new' : true
	}, function(err, data) {
		if (err) {
			err.status = 500;
			logger.error(MODULE_NAME + ' : DAO : failed updateDocumentById : error : ' + err);
			return callback(err);
		}
		if(data) {
			logger.info(MODULE_NAME + ' : DAO : updateDocumentById successful !');	
			return callback(null, data);
		}
		var err = new Error('no record exist for document id');
		err.status = 200;
		logger.error(MODULE_NAME + ' : DAO : failed updateDocumentById : error : '+ err);
		callback(err);
	});	
};

/*
 * Delete document
 */
var deleteDocumentById = function(id, json, callback) {
	logger.info(MODULE_NAME + ' : DAO : received request : deleteDocumentById : (id:' + id + ')');
	Document.update({
		'id' : id
	}, json, {
		'new' : true
	}, function(err, data) {
		if (err) {
			err.status = 500;
			logger.error(MODULE_NAME + ' : DAO : failed deleteDocumentById : error : ' + err);
			return callback(err);
		}
		if(data) {
			logger.info(MODULE_NAME + ' : DAO : deleteDocumentById successful !');	
			return callback(null, data);
		}
		var err = new Error('no record exist for document id');
		err.status = 200;
		logger.error(MODULE_NAME + ' : DAO : failed updateDocumentById : error : '+ err);
		callback(err);
	});	
};

/*
 * Get documents by experience id
 */
var getDocumentsByExperienceId = function(id, callback) {
	logger.info(MODULE_NAME + ' : DAO : received request : getDocumentsByExperienceId : (experienceId:' + id + ')');
	Document.find({	'experienceId' : id }, function(err, data) {
		if (err) {
			err.status = 500;
			logger.error(MODULE_NAME + ' : DAO : failed getDocumentsByExperienceId : error : ' + err);
			return callback(err);
		}
		if(data.length) {
			logger.info(MODULE_NAME + ' : DAO : getDocumentsByExperienceId successful !');	
			return callback(null, data);	
		}
		var err = new Error('no documents exist for experience id');
		err.status = 200;
		logger.error(MODULE_NAME + ' : DAO : failed getDocumentById : error : '+ err);
		callback(err);
	});	
};

/*
 * Get documents by app id
 */
var getDocumentsByAppId = function(id, callback) {
	logger.info(MODULE_NAME + ' : DAO : received request : getDocumentsByAppId : (appId:' + id + ')');
	Document.find({	'appId' : id }, function(err, data) {
		if (err) {
			err.status = 500;
			logger.error(MODULE_NAME + ' : DAO : failed getDocumentsByAppId : error : ' + err);
			return callback(err);
		}
		if(data.length) {
			logger.info(MODULE_NAME + ' : DAO : getDocumentsByAppId successful !');	
			return callback(null, data);	
		}
		var err = new Error('no documents exist for app id');
		err.status = 200;
		logger.error(MODULE_NAME + ' : DAO : failed getDocumentsByAppId : error : '+ err);
		callback(err);
	});	
};


/*
 * Get documents by service id
 */
var getDocumentsByServiceId = function(id, callback) {
	logger.info(MODULE_NAME + ' : DAO : received request : getDocumentsByServiceId : (serviceId:' + id + ')');
	Document.find({	'serviceId' : id }, function(err, data) {
		if (err) {
			err.status = 500;
			logger.error(MODULE_NAME + ' : DAO : failed getDocumentsByServiceId : error : ' + err);
			return callback(err);
		}
		if(data.length) {
			logger.info(MODULE_NAME + ' : DAO : getDocumentsByServiceId successful !');	
			return callback(null, data);	
		}
		var err = new Error('no documents exist for service id');
		err.status = 200;
		logger.error(MODULE_NAME + ' : DAO : failed getDocumentsByServiceId : error : '+ err);
		callback(err);
	});	
};

/*
 * Get all documents
 */
var getAllDocuments = function(req, res, callback) {
	logger.info(MODULE_NAME + ': DAO : received request : getAllDocuments :');			
	Document.find(function(err, data) {
		if (err) {
			err.status = 500;
			logger.error(MODULE_NAME + ': DAO : failed getAllDocuments : error : ' + err);
			callback(err, null);
		} else {
			if (data.length != 0) {
				logger.info(MODULE_NAME + ': DAO : getAllDocuments successful !');
				callback(null, data);
			} else {
				var err = new Error('no documents exist');
				err.status = 200;
				logger.error(MODULE_NAME + ': DAO : failed getAllDocuments : error : ' + err);
				callback(err, null);
			}
		}
	});
};

module.exports.addNewDocument = addNewDocument;
module.exports.getDocumentById = getDocumentById;
module.exports.updateDocumentById = updateDocumentById;
module.exports.deleteDocumentById = deleteDocumentById;
module.exports.getDocumentsByExperienceId = getDocumentsByExperienceId;
module.exports.getDocumentsByAppId = getDocumentsByAppId;
module.exports.getDocumentsByServiceId = getDocumentsByServiceId;
module.exports.getAllDocuments= getAllDocuments;


