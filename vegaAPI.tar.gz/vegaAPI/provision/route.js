'use strict';

var express = require('express'),
controller = require('./controller/provision-experience'),
logger = require('../common/logger').log
.child({
  module: 'Experience Provisioning',
  type: 'router'
}),
PlatformError = require('../common/platform-error'),
ErrorResponse = require('../common/ErrorResponse').ErrorResponse,
router = express.Router(),
ResourceBundle = require('./../common/resource-bundle.js'),
rsBundle = new ResourceBundle(['./../provision/resource/lang/', './../radia-adapter/resource/lang/']);

function processResponse(res, failureLog, err, data) {
  if (err) {
    var error;
    if (err instanceof PlatformError) {
      logger.error(`${failureLog} Stack trace : \n ${JSON.stringify(err)}`);
      error = new ErrorResponse(err.code, rsBundle.getMessage(err.code, err.args), err.httpCode);
    } else {

      logger.error(`${failureLog} Root cause : \n ${JSON.stringify(err) }`);
      // any error that comes here will be mapped with internal server error as it's either programmatic error or server side issue and client shouldn't be aware about actual cause.
      error = new ErrorResponse("PRO001", rsBundle.getMessage("PRO001"), 500);
    }

    res.status(error.getHttpResponseCode()).json(error);
  } else {
    if (data) {
      res.json(data);
    } else {
      res.statusCode = 204;
      res.end();
    }
  }
}

router.post('/', function (req, res) {

  logger.info(`Experience provisioning request received. Request body : ${JSON.stringify(req.body) }`);

  controller.provision(req.body, function (err, data) {
    processResponse(res, 'Experience provisioning failed.', err, data);
  });
});

router.get('/:id', function (req, res) {

  logger.info(`Get experience provisioning request details for request id # ${req.params.id}`);

  controller.getById(req.params.id, function (err, data) {
    processResponse(res, 'Get experience provisioning request failed.', err, data);
  });
});

router.delete('/:id', function (req, res) {

  logger.info(`Experience deprovisioning request received for id # ${req.params.id}`);
  controller.deprovision(req.params.id, function (err, data) {
    processResponse(res, 'Experience de-provisioning failed.', err, data);
  });
});


router.put('/:id/renew', function (req, res) {

  logger.info(`Experience renew request received for id # ${req.params.id}`);
  controller.renew(req.params.id, function (err, data) {
    processResponse(res, 'Experience renew failed.', err, data);
  });
});


router.get('/companies/:id',function (req, res) {

  logger.info(`Get all Provisioned Experiences`);
  controller.getAllExp(req.params.id,  function (err, data) {

    if(err){
      logger.error('Failed to Get Experiences : '+err);
      var error = new ErrorResponse();
      error.setErrorCode("PU004");
      error.setErrorMessage(err.message);
      error.setHttpResponseCode(500);
      res.status(500).end(JSON.stringify(error));
    }else{
      logger.info("Successfully retrieved Experieces list !");
      res.status(200).end(JSON.stringify(data));
    }
  });
});

/* Get the experiences that are provisioned */
router.get('/experiences/all', function (req, res) {

  logger.info('provision : router : received request : getExperiencesProvisioned : Get the list of all experiences that are provisioned');

  controller.getExperiencesProvisioned(function (err, data) {

    if(err){
      logger.error('Failed to Get Experiences : '+err);
      var error = new ErrorResponse();
      error.setErrorCode("EP0001");
      error.setErrorMessage(err.message);
      error.setHttpResponseCode(500);
      res.status(500).end(JSON.stringify(error));
    }else{
      logger.info("Successfully retrieved Experieces Provisioned list !");
      res.status(200).end(JSON.stringify(data));
    }
  });
});


/* Get all the provisioned experiences */
router.get('/', function (req, res) {

  logger.info('provision : router : received request : getAllProvisionedExperiences : Get all the provisioned '+
		  'experiences : (query:'+JSON.stringify(req.query)+')');
  controller.getAllProvisionedExperiences(req, function (err, data) {

    if(err){
      logger.error('Failed to Get Provisioned Experiences : '+err);
      var error = new ErrorResponse();
      error.setErrorCode("EP0002");
      error.setErrorMessage(err.message);
      error.setHttpResponseCode(500);
      res.status(500).end(JSON.stringify(error));
    }else{
      logger.info("Successfully fetched Provisioned Experieces !");
      res.status(200).end(JSON.stringify(data));
    }
  });
});


/*
* Vishal: why do we need below for each router? Can't it be specified at root
* level? Can we use cors() library ?
*/
router.options('/', function (req, res) {
  logger.debug('Options call for experience provisioning APIs');
  res.header('Allow-Access-Allow-Origin', '*');
  res.header('Access-Control-Allow-Headers', '*');
  res.header('Access-Control-Allow-Methods', 'GET,POST,DELETE,PUT,OPTIONS');
  res.header('Connection', 'keep-alive');
  res.header('Content-Type', 'application/json;charset=UTF-8');
  res.end();
  logger.info('experience : router : Options call experience APIs processed !');
});

router.all('/*', function (req, res) {
  logger.error('No matching resource for URL : ' + req.originalUrl);
  var error = new ErrorResponse();
  error.setErrorCode("E0002");
  error.setErrorMessage('No matching resource for URL: ' + req.originalUrl);
  error.setHttpResponseCode(404);
  res.status(404).send(JSON.stringify(error));
});

module.exports = router;
