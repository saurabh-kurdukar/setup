'use strict';

var util = require('util');

const GROUP_TYPE = 'Department',
GROUP_CATEGORY = 'user',
DN_FORMAT = 'cn=U_%s,cn=radiaCustomer,cn=group,cn=hp,cn=radia';

function UserGroup(name) {

  let userGroup = {
    displayName : name,
    description : `Group created during experience provisioning`,
    groupType : GROUP_TYPE,
    cn : name,
    groupCategory: GROUP_CATEGORY,
    getDN : function() {
      return util.format(DN_FORMAT, this.displayName);
    }
  };

  return userGroup;
}

module.exports = UserGroup;
