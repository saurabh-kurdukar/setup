'use strict';

function UserCredential(username, password) {

  let userCredential = {
    j_username : username,
    j_password : password
  };

  return userCredential;
}

module.exports = UserCredential;
