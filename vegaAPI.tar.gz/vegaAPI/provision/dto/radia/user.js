'use strict';

var util = require('util');

const DESIGNATION = 'developer',
DN_FORMAT = 'uid=%s,cn=radiaCustomer,cn=user,cn=hp,cn=radia';

function User(userObj) {

  let user = {
    fullName: userObj.name,
    sn: userObj.name,
    userCorporateEmailID: userObj.email,
    uid: userObj.email,
    userPersonalEmailID: userObj.email,
    generateAutoPassword: false,
    userPassword: userObj.password,
    designation: DESIGNATION,
    getDN : function() {
      return util.format(DN_FORMAT, this.userCorporateEmailID);
    }
  };

  return user;
}

module.exports = User;
