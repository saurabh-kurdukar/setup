'use strict';

const DOMAIN_NAME = 'MOBILE';
const ANDROID_APP = 'ANDROID';
const ANDROID_PREFIX = 'AA_AA_';
const IOS_APP = 'IOS';
const IOS_PREFIX = 'IA_IA_';

function GroupApplicationAssociation(user, experience) {

  let groupApplicationAssociation = {
    dn: user.groupDN,
    apps: []
  };
  groupApplicationAssociation.initialize = function() {

    experience.mobileApplications.forEach(function(application) {
      let appInstance = {
        instanceName:`${application.type === ANDROID_APP ? ANDROID_PREFIX : IOS_PREFIX}${prepareApplicationName(application.name)}`,
        domainname : DOMAIN_NAME
      };
      groupApplicationAssociation.apps.push(appInstance);
    });
  };

  function prepareApplicationName(name) {
    let appName = name.toUpperCase();
    return appName.replace(' ', '');
  }

  groupApplicationAssociation.initialize();
  return groupApplicationAssociation;
}

module.exports = GroupApplicationAssociation;
