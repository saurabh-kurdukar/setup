'use strict';

var fs = require('fs'),
  util = require('util');

const APPLICATION_TYPE = 'Enterprise',
 VENDOR = 'Persistent Systems',
 ASSIGN_TO_USER = 'Mandatory',
 UPDATE = 'Automatic',
 PUBLISH_TYPE = 'application',
 ANDROID_APP = 'ANDROID',
 OS_ANDROID = 'AND',
 OS_IOS = 'IOS',
 CHECKSUM = '{"%s":"48899286E171D16A15D13909048F63BA","icon.jpg":"48899286E171D16A15D13909048F63BA"}';

function Application(app) {

  var application = {
    applicationName : app.name,
    applicationType : APPLICATION_TYPE,
    vendor :VENDOR,
    description : app.description,
    category : APPLICATION_TYPE,
    assignmentToUser :  ASSIGN_TO_USER,
    appUpdate : UPDATE,
    publishType : PUBLISH_TYPE,
    osList : app.type === ANDROID_APP ? OS_ANDROID : OS_IOS,
    checksum : util.format(CHECKSUM, app.fileName),
    binary : fs.createReadStream(app.relativePath + app.fileName),
    icon : fs.createReadStream(app.relativePath + app.icon),
    screenshot : fs.createReadStream(app.relativePath + app.screenshots[0])
  };

  return application;
}

module.exports = Application;
