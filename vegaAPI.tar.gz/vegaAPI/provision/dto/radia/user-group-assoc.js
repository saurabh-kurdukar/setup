'use strict';

function UserGroupAssociation(userObj) {

  let userGroupAssociation = {
    userDN: [
      userObj.userDN
    ],
    listOfGroups: [
      userObj.groupDN
    ]
  };

  return userGroupAssociation;
}

module.exports = UserGroupAssociation;
