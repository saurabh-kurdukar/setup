'use strict';

var Enum = require('enum');

var deProvisioningState = new Enum({
  'START': 0,
  'VM_DEPROVISIONED': 1,
  'RADIA_DEPROVISIONED': 2,
  'DEPROVISIONED': 3
});

module.exports = deProvisioningState;
