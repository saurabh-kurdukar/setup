'use strict';

var config = require('./../../common/Config'),
os = require('os');

function PlatformEndPointConfiguration(provisionReqeustId) {

  let platformEndPointConfiguration = {
    platformIPAddress : config.PLATFORM_API_TARGET,
    platformPort : config.SERVER.PORT,
    provisionId : provisionReqeustId,
    protocol: config.SERVER.PROTOCOL
  };

  return platformEndPointConfiguration;
}

module.exports = PlatformEndPointConfiguration;
