'use strict';

var Enum = require('enum');

var provisionState = new Enum({
  'START': 0,
  'VM_PROVISIONED': 1,
  'SERVICE_PROVISIONED': 2,
  'RADIA_PROVISIONED': 3,
  'PROVISIONED': 4,
  'RADIA_DEPROVISIONED': 5,
  'FAILED': 6
});

module.exports = provisionState;
