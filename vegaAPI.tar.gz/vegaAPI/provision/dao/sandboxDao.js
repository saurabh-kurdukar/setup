var async = require('async'),
  Sandbox = require('../models/sandbox').Sandbox,
  SandboxItem = require('../models/sandbox').SandboxItem,
  logger = require('../../common/logger').log
  .child({
    module: 'sandbox',
    type: 'dao'
  });

var addSandbox = function(sandboxRequest, cb) {

  async.waterfall([
    async.apply(createSandbox, sandboxRequest),
    createSandboxItems
  ], function(err) {
    if (err) {
      logger.error(`Could not save Sandbox for user : ${sandboxRequest.username}`);
      cb(err);
      return;
    }

    logger.info(`Sandbox request # ${sandboxRequest.id} : Sandbox saved for user : ${sandboxRequest.username}`);
    cb(null, sandboxRequest);
  });
}

function createSandbox(sandboxRequest, cb) {
  var sandbox = new Sandbox({
    userId: sandboxRequest.username
  });
  sandbox.save(function(err, data) {
    if (err) {
      cb(err);
      return;
    }
    sandboxRequest.id = data._id;
    cb(null, sandboxRequest);
  });
}

function createSandboxItem(sandboxRequest, experienceId, cb) {
  var sandboxItem = new SandboxItem({
    experienceId: experienceId,
    sandboxId: sandboxRequest.id
  });

  sandboxItem.save(function(err, data) {
    if (err) {
      cb(err);
      return;
    }
    cb();
  });
}

function updateSandboxItem(sandboxRequest, experience, cb) {

  getSandboxItemBySandboxIdAndExperienceId(sandboxRequest.id, experience.id, function(err, result) {
    if (err) {
      cb(err);
      return;
    }

    var sandboxItem = result;
    sandboxItem.host = experience.service.hostname;
    sandboxItem.port = experience.service.port;

    sandboxItem.save(function(err, data) {
      if (err) {
        cb(err);
        return;
      }
      cb(null, sandboxRequest, experience);
    });
  });
}

function createSandboxItems(sandboxRequest, cb) {
  async.each(
    sandboxRequest.experienceIds,
    async.apply(createSandboxItem, sandboxRequest),
    function(err) {
      if (err) {
        cb(err);
        return;
      }
      cb(null);
    }
  );
}

function updateSandboxItemsState(sandboxRequest, newState, cb) {
  getSandboxItemBySandboxId(sandboxRequest.id, function(err, result) {
    if (err) {
      cb(err);
      return;
    }
    async.each(
      result,
      function(sandboxItem, callback) {
        sandboxItem.state = newState;
        sandboxItem.save(function(err, data) {
          if (err) {
            callback(err);
            return;
          }
          logger.info("sandbox item " + sandboxItem.id + " State is updated successfully to " + newState);
          callback(null, data);
        });

      },

      function(err) {
        if (err) {
          cb(err);
          return;
        }
        cb(null);
      }
    );

  });
}


/*
 * Update
 */
var updateSandboxState = function(sandboxRequest, newState, cb) {

  Sandbox.findOneAndUpdate({
      '_id': sandboxRequest.id
    }, {
      $set: {
        state: newState
      }
    }, {
      new: true
    },
    function(err, doc) {
      if (err) {
        cb(err);
        return;
      }

      cb(null, sandboxRequest);
    });
}

var updateSandboxItemState = function(sandboxRequestId, experienceId, newState, cb) {

  SandboxItem.findOneAndUpdate({
      deleted: false,
      sandboxId: {
        $in: sandboxRequestId
      },
      experienceId: {
        $in: experienceId
      }
    }, {
      $set: {
        state: newState
      }
    }, {
      new: true
    },
    function(err, doc) {
      if (err) {
        cb(err);
        return;
      }

      cb(null);
    });
}

var getSandboxItemsByUserIdAndExperienceId = function(sandboxRequest, cb) {

  async.waterfall([
    async.apply(getSandboxByUserId, sandboxRequest),
    getSandboxItemsByExperienceIds
  ], function(err, sandboxRequest, data) {
    if (err) {
      cb(err);
      return;
    }
    cb(null, sandboxRequest, data);
  });
};

function getSandboxByUserId(sandboxRequest, cb) {
  Sandbox.find({
      userId: sandboxRequest.username,
      deleted: false
    },
    '_id',
    function(err, data) {
      if (err) {
        cb(err);
        return;
      }
      cb(null, sandboxRequest, data);
    });
}

function getSandboxItemsByExperienceIds(sandboxRequest, sandboxDetails, cb) {
  if (sandboxDetails.length) {

    var sandboxIds = [];
    for (var loopIndex = 0; loopIndex < sandboxDetails.length; loopIndex++) {
      sandboxIds.push(sandboxDetails[loopIndex]._id);
    }

    SandboxItem.find({
      deleted: false,
      sandboxId: {
        $in: sandboxIds
      },
      experienceId: {
        $in: sandboxRequest.experienceIds
      }
    }, function(err, data) {
      if (err) {
        cb(err);
        return;
      }
      cb(null, sandboxRequest, data);
    });
  } else {
    cb(null, sandboxRequest, sandboxDetails);
  }
}

function getSandboxItemBySandboxId(sandboxId, callback) {
  SandboxItem.find({
    deleted: false,
    sandboxId: {
      $in: sandboxId
    }
  }, function(err, data) {
    if (err) {
      logger.info(err);
      callback(null);
    }
    callback(null, data);
  });

}

function getSandboxItemState(sandboxRequestId, experienceId, callback) {
  SandboxItem.find({
    deleted: false,
    sandboxId: {
      $in: sandboxRequestId
    },
    experienceId: {
      $in: experienceId
    }
  }, function(err, data) {
    if (err) {
      logger.info(err);
      callback(null);
    }
    callback(null, data[0].state);
  });
}

function getSandboxItemBySandboxIdAndExperienceId(sandboxRequestId, experienceId, callback) {
  SandboxItem.find({
    deleted: false,
    sandboxId: {
      $in: sandboxRequestId
    },
    experienceId: {
      $in: experienceId
    }
  }, function(err, data) {
    if (err) {
      logger.info(err);
      callback(null);
    }
    callback(null, data[0]);
  });
}

module.exports.addSandbox = addSandbox;
module.exports.updateSandboxState = updateSandboxState;
module.exports.updateSandboxItem = updateSandboxItem;
module.exports.getSandboxItemState = getSandboxItemState;
module.exports.updateSandboxItemState = updateSandboxItemState;
module.exports.getSandboxItemsByUserIdAndExperienceId = getSandboxItemsByUserIdAndExperienceId;
