'use strict';
var moment = require('moment'),
util = require('util'),
provisionState = require('../dto/provision-state'),
ProvisionedExperience = require('../models/provisioned-experience').ProvisionedExperience,
ProvisionedVM = require('../models/provisioned-vm').ProvisionedVM,
PlatformError = require('../../common/platform-error');
var logger = require('../../common/logger').log;
var vmdetails= require('../../provision/models/vmdetails').VMDetails;
var azuredao= require('../../vmDetails/dao/AzureVmdetailsDao');
var async = require("async");
var config = require('./../../common/Config');
var SSH = require('simple-ssh');
var client = require('scp2');
var path = require('path');

/*
getAllExpiredProvisionedRequests
*/

var getAllExpiredProvisionedRequests = function(cb) {

  ProvisionedExperience.find({
    expiry: { $lt: new Date() },
    deleted: false
  }, function(err, data) {
    if (err) {
      cb(new PlatformError('PROV001', [], 500, err));
      return;
    }
    cb(null, data);
  });
};
var add = function (provisionRequest, cb) {
  var provisionedExperience = new ProvisionedExperience({
    orgId: provisionRequest.orgId,
    experienceId: provisionRequest.experienceId,
    createdBy: provisionRequest.createdBy,
    expiry: provisionRequest.expiry,
    ownerId: provisionRequest.ownerId
  });

  provisionedExperience.save(function (err, data) {
    if (err) {
      cb(new PlatformError('PROV001', [], 500, err));
      return;
    }
    provisionRequest.id = data._id;
    provisionRequest.state = data.state;
    provisionRequest.status = data.status;
    cb(null, provisionRequest);
  });
};

var associateVM = function (provisionRequest, cb) {

  var provisionedVM = new ProvisionedVM({
    orgId: provisionRequest.orgId,
    experienceId: provisionRequest.experienceId,
    provisionId: provisionRequest.id,
    vmId: provisionRequest.vmDetails.vmId
  });

  provisionedVM.save(function (err, data) {
    if (err) {
      cb(new PlatformError('PROV001', [], 500, err));
      return;
    }
    cb(null, provisionRequest);
  });
};

var getByOrgIdAndExperienceId = function (provisionRequest, cb) {
  ProvisionedExperience.find({
    deleted: false,
    orgId: provisionRequest.orgId,
    experienceId: provisionRequest.experienceId
  }, function (err, data) {
    if (err) {
      cb(new PlatformError('PROV001', [], 500, err));
      return;
    }
    cb(null, provisionRequest, data);
  });
};

var getCountByOrgId = function (provisionRequest, cb) {
  ProvisionedExperience.count({
    deleted: false,
    orgId: provisionRequest.orgId
  }, function (err, count) {
    if (err) {
      cb(new PlatformError('PROV001', [], 500, err));
      return;
    }
    cb(null, provisionRequest, count);
  });
};

var getProvisionedCountByOrgId = function (provisionRequest, cb) {
  ProvisionedExperience.count({
    deleted: false,
    orgId: provisionRequest.orgId,
    state: provisionState.PROVISIONED.key
  }, function (err, count) {
    if (err) {
      cb(new PlatformError('PROV001', [], 500, err));
      return;
    }
    cb(null, provisionRequest, count);
  });
};

var updateState = function (provisionRequest, cb) {
  ProvisionedExperience.findOneAndUpdate({
    '_id': provisionRequest.id
  }, {
    $set: {
      state: provisionRequest.state,
      deprovisionState : provisionRequest.deprovisionState,
      status: provisionRequest.status,
      errorCode: provisionRequest.errorCode,
      updated: new Date()
    }
  },
  function (err, updated) {
    if (err) {
      cb(new PlatformError('PROV001', [], 500, err));
      return;
    }
    cb(null, provisionRequest);
  });
};

var updateHostDetails = function (provisionRequest, cb) {

  get(provisionRequest.id, function(err, provisionedExperience) {
    provisionRequest.experience.services.forEach(function(service) {

      let serviceConf = {
        name: service.name,
        applications : []
      };

      let applicationConf = {
        name: service.imageType,
        port: service.boundToPort,
        hostname: provisionRequest.vmDetails.name,
        fqdn: provisionRequest.vmDetails.hostname,
        isPrimary: true
      };

      serviceConf.applications.push(applicationConf);
      service.subImages.forEach(function(subImage) {
        let applicationConf = {
          name: subImage.imageType,
          port: subImage.boundToPort,
          hostname: provisionRequest.vmDetails.name,
          fqdn: provisionRequest.vmDetails.hostname
        };
        serviceConf.applications.push(applicationConf);
      });
      provisionedExperience.services.push(serviceConf);
    });

    provisionedExperience.state = provisionRequest.state;

    provisionedExperience.save(function (err, updated) {
      if (err) {
        cb(new PlatformError('PROV001', [], 500, err));
        return;
      }
      cb(null, provisionRequest);
    });
  });

  // get(id, function(err, provisionedRequest) {
  //   var applicationConf = provisionedRequest.services.id(serviceId).applications.id(applicationId);
  //   applicationConf.hostname = vmDetails.name;
  //   applicationConf.fqdn = vmDetails.hostname;
  //
  //   provisionedRequest.save(function (err) {
  //     if (err) {
  //       cb(new PlatformError('PROV001', [], 500, err));
  //       return;
  //     }
  //     cb(null);
  //   });
  // });
};

var get = function (id, cb) {
  ProvisionedExperience.findOne({
    '_id': id,
    deleted: false
  },
  function (err, provisionRequest) {
    if (err) {
      cb(new PlatformError('PROV001', [], 500, err));
      return;
    }
    cb(null, provisionRequest);
  });
};

var getVMByRequestId = function(provisionId, cb) {
  ProvisionedVM.findOne({
    'provisionId': provisionId,
    deleted: false
  },
  function (err, provisionedVM) {
    if (err) {
      cb(new PlatformError('PROV001', [], 500, err));
      return;
    }

    cb(null, provisionedVM);
  });
}

var softDelete = function (id, cb) {
  ProvisionedExperience.findOneAndUpdate({
    '_id': id
  }, {
    $set: {
      deleted: true,
      updated: new Date()
    }
  },
  function (err, provisionRequest) {
    if (err) {
      cb(new PlatformError('PROV001', [], 500, err));
      return;
    }
    cb(null, provisionRequest);
  });
};

var dissociateVM = function(provisionRequest, cb) {
  ProvisionedVM.findOneAndUpdate({
    'provisionId': provisionRequest.id
  }, {
    $set: {
      deleted: true,
      updated: new Date()
    }
  },
  function (err, provisionVM) {
    if (err) {
      cb(new PlatformError('PROV001', [], 500, err));
      return;
    }
    cb(null, provisionRequest);
  });
}

var renew = function (id, cb) {
  var newDate = moment().add(7, 'd').toDate();

  ProvisionedExperience.findOneAndUpdate({
    '_id': id
  }, {
    $set: {
      expiry: newDate,
      updated: new Date()
    }
  },
  function (err, provisionRequest) {
    if (err) {
      cb(new PlatformError('PROV001', [], 500, err));
      return;
    }
    cb(null, provisionRequest);
  });
}

var getAll = function (id, cb) {

  ProvisionedExperience.find({
    orgId: id,
    deleted: false
  },
  function (err, provisionRequest) {
    if (err) {
      cb(new PlatformError('PROV001', [], 500, err));
      return;
    }
    cb(null, provisionRequest);
  });
};

/*
*	Get provisioned experiences for user
*/
var getProvisionedExperiencesByUserName = function (provisionRequest, callback) {
  ProvisionedExperience.find({
    createdBy: provisionRequest.params.username,
    deleted: false
  },
  function (err, data) {
    if (err) {
    	err.status = 500;
      callback(err);
    } else if (data.length) {
      callback(null, data);
    } else {
      var err = new Error('no experiences provisioned for username');
      err.status = 200;
      callback(err);
    }
  });
};

/*
 * Update details
 */
var updateFields = function (provisionRequest, json, cb) {
	  ProvisionedExperience.findOneAndUpdate({
		  '_id': provisionRequest.id
	  }, json,  function (err, data) {
		    if (err) {
		      cb(new PlatformError('PROV001', [], 500, err));
		      return;
		    }
		    cb(null, provisionRequest);
	  });
};

/*
 * Get vm details by vm id
 */
var getVmDetailsById = function(vmid,req, res, callback) {

	vmdetails.find({
		'_id' : vmid ,
	}, function(err, data) {
		if (err) {
			callback(err, null);
		} else {
			if (data.length != 0) {
				callback(null, data);
			} else {
				var err = new Error('No record found');
				err.status = 404;
				callback(err, null);
			}
		}
	});
};

/*
 *Get vm details by vm  userName (createdBy)
 */
 var getVmDetailsByUserName = function(vmDetailsreq, res, callback) {
 logger.info('provisioned-experience : dao : received request : getVmDetailsByUserName : req recived  : ' + vmDetailsreq.params.username);
 var userName = vmDetailsreq.params.username;
 var vmDetailsResponse=[];
 var vmNames=[];
 ProvisionedExperience.find({
		'createdBy' : vmDetailsreq.params.username ,
	}, function(err, data) {
		if (err) {
			callback(err, null);
		} else {
			if (data.length != 0) {
            async.each(data,function(item, callback){
                             logger.info('provisioned-experience : dao : received request : getVmDetailsByUserName : experienceId : ' + item._id);
                             getVMByRequestId(item._id,function(err,vmsDetails){
								if(err)
									callback(err,null);
								else
								{
                                   if (vmsDetails!= null){
                                       logger.info('provisioned-experience : dao : received request : getVmDetailsByUserName : vmsDetails : ' + vmsDetails);
									   getVmDetailsById(vmsDetails.vmId,null, res, function(err,testdata){
                                          if(err)
                                          callback(err,null);
                                          else {
                                              var response={};
                                              for(var j =0 ;j< testdata.length;j++){

												  var usageData= testdata[j].usageData;
												  var totalCost = 0;
											//iterate over usageData to get total cost of VM
												var jsonData=JSON.stringify(usageData);
												if(jsonData!= undefined || jsonData!= null)
													{
													var jsonUsage = JSON.parse(jsonData);
														for (var key in jsonUsage) {
															var val = jsonUsage[key];
															totalCost= totalCost+ val;
														}
													}
												response.vmId=testdata[j]._id;
												response.status= testdata[j].status;
                                                response.fqdn=testdata[j].fqdn;
                                                response.hostname= testdata[j].hostname;
                                                response.username= userName;
                                                response.osType= testdata[j].osType;
                                                response.osVersion= testdata[j].osVersion;
                                                response.type= testdata[j].type;
                                                response.diskSize= testdata[j].diskSize;
                                                response.dateCreated=testdata[j].dateCreated;
                                                response.tcpPorts=testdata[j].tcpPorts;
                                                response.runningCost= totalCost;
                                                response.currency="$";
												vmNames.push(testdata[j].hostname);
                                                vmDetailsResponse.push(response);
                                               }
                                            callback();
                                            }
                                          });
                                    }else{
                                         var err = new Error('No record found');
                                         err.status = 404;
                                         logger.error("provisioned-experience : dao :"+err);
                                         callback(err, null);
                                         }
                                 }
							});
                   },
				function(err){
					azuredao.getVmUsage(vmNames,{},res,function(err,data){
				if(err)
					callback(err,null);
				else{
					for(var j=0;j<data.length;j++)
					{
						for(var k=0;k<vmDetailsResponse.length;k++)
						{
						   if(data[j].vmName== vmDetailsResponse[k].hostname)
						   {
							   vmDetailsResponse[k].currentCPUUsage=data[j].cpuUsage+' %';
							   vmDetailsResponse[k].currentDiskUsage= data[j].diskUsage+' %';
							   vmDetailsResponse[k].currentNetworkUsage= data[j].networkUsage+' bytes';
							   logger.info('Azure VM Details : DAO : getVMsByExperienceId successful !');
						   }
						}
					}
					callback(null,vmDetailsResponse);
				}
			})
					//callback(err,vmDetailsResponse);
			}
                );   //end of each loop
			} else {
				var err = new Error('No record found');
				err.status = 404;
                logger.error("provisioned-experience : dao :"+err);
				callback(err, null);
			      }
		}
	});
 };

 var getAllExperiencesProvisioned = function (cb) {

  logger.info('provision : dao : received request : getAllExperiencesProvisioned : Get the list of all provisioned experiences');

  ProvisionedExperience.find({
    state: 'PROVISIONED',
    status: 'PROVISIONED',
    deleted: false
  },
  function (err, provisionRequest) {
    if (err) {
      cb(new PlatformError('PROV001', [], 500, err));
      return;
    }
    else if(provisionRequest.length == 0) {
      cb(new Error("No Provisioned Experiences Found"), null);
    }
    else {
      cb(null, provisionRequest);
    }
  });
};

var getAllExperiencesProvisionedByStatus = function (req, cb) {
	  logger.info('provision : dao : received request : getAllExperiencesProvisioned : Get the list of all provisioned experiences');
	  var json = {
		    state: 'PROVISIONED',
		    status: 'PROVISIONED',
		    deleted: false
	  };
	  if(req.query.status && req.query.status.trim().length) {
		  json.state = req.query.status;
		  json.status = req.query.status;
		  json.deleted = true;
	  }
	  ProvisionedExperience.find(json, function (err, provisionRequest) {
	    if (err) {
	      cb(new PlatformError('PROV001', [], 500, err));
	      return;
	    }
	    else if(provisionRequest.length == 0) {
	      cb(new Error("No Provisioned Experiences Found"), null);
	    }
	    else {
	      cb(null, provisionRequest);
	    }
	  });
};

/*
*	Get provisioned experiences by username
*/
var getAllProvisionedExperiencesByUserName = function (username, callback) {
  ProvisionedExperience.find({
    createdBy: username,
    status : "PROVISIONED",
    state : "PROVISIONED",
    deleted: false
  },
  function (err, data) {
    if (err) {
    	err.status = 500;
      callback(err);
    } else if (data.length) {
      callback(null, data);
    } else {
      var err = new Error('no experiences provisioned for username');
      err.status = 200;
      callback(err);
    }
  });
};

/*
 * Update the download links for direct-provisioned apps
 */
function updateDownloadLinkForDirectProvisioning(provisionRequest, cb) {

  logger.info('provision : dao : received request : updateDownloadLinkForDirectProvisioning : Update the download links for apps in experience : ' + provisionRequest.experience.name);
  var appLinks = [];
  if(provisionRequest.experience.applications.length != 0) {
    provisionRequest.experience.applications.forEach(function(app) {
if(app.type != config.APPLICATION_TYPE.WEBAPP) {
      var dlink = config.APP_BLOB_LOCATION.PROTOCOL + config.APP_BLOB_LOCATION.HOSTNAME + config.APP_BLOB_LOCATION.DIRECTDEPLOY;
      dlink += provisionRequest.experience.experienceId + '/';
      dlink += app.type + '/' + app.id + '/' + app.version + '/' + app.name.replace(/ /g, '_') + '/';
      dlink += app.name.replace(/ /g, '_') + (app.type === config.APPLICATION_TYPE.ANDROID ? '.apk' : '.ipa');

      appLinks.push({ appId: app.id, appName: app.name, appLogo: app.logo, appType: app.type, downloadLink: dlink });
}
    })
    // console.log(JSON.stringify(appLinks));

if(appLinks.length > 0) {
    ProvisionedExperience.findOneAndUpdate({
      '_id': provisionRequest.id
    }, {
      $set: { 'appLinks': appLinks }
    }, {
      'new': true
    }, function(err, data) {
      if(err) {
        logger.error('provision : dao : received request : updateDownloadLinkForDirectProvisioning : Error : Failed to update the download links for apps in experience : ' + err);
        cb(new Error('Failed to update download links for apps in experience : ' + provisionRequest.experience.name));
        return;
      }
      logger.info('provision : dao : received request : updateDownloadLinkForDirectProvisioning : Successfully updated download links for apps in experience!!!');
      cb(null, provisionRequest);
    });
}
    else {
      logger.info('provision : dao : received request : updateDownloadLinkForDirectProvisioning : No download links found to update for apps in experience!!!');
      cb(null, provisionRequest);
    }
  }
  else {
    logger.info('provision : dao : received request : updateDownloadLinkForDirectProvisioning : Skipping update download links for apps');
    cb(null, provisionRequest);
  }
}

/*
 * Update the download links for indirect-provisioned apps
 */
function updateDownloadLinkForIndirectProvisioning(provisionRequest, cb) {
  logger.info('provision : dao : received request : updateDownloadLinkForIndirectProvisioning : Update the download links for apps in experience : ' + provisionRequest.experience.name);

  async.eachSeries(provisionRequest.experience.applications, function(app, callback) {
    if(app.type === config.APPLICATION_TYPE.IOS) {
      logger.info('provision : dao : received request : updateDownloadLinkForIndirectProvisioning : Skipping as IOS app found : ' + app.name);
      callback();
    }
    else {
      async.waterfall([
        async.apply(createFolderStructure, provisionRequest, app),
        uploadAppToServer,
        updateProvisionDownloadLink
      ], function(err, provisionRequest) {
        if(err) {
          logger.error('provision : dao : received request : updateDownloadLinkForIndirectProvisioning : Error : Failed to update the download links for apps in experience : ' + err);
          callback(new Error('Failed to update download links for app : ' + app.name));
          return;
        }
        logger.info('provision : dao : received request : updateDownloadLinkForIndirectProvisioning : Updated the download link for app : ' + app.name);
        callback();
      })
    }
  }, function(err) {
    if(err) {
      cb(err);
      return;
    }
    logger.info('provision : dao : received request : updateDownloadLinkForIndirectProvisioning : Successfully updated download links for apps in experience!!!');
    cb(null, provisionRequest);
  });
}

function createFolderStructure(provisionRequest, app, callback) {

  logger.info('provision : dao : received request : createFolderStructure : Create folder structure for download link');
  var ssh = new SSH({
      host: config.APP_BLOB_LOCATION.HOSTNAME,
      user: config.APP_BLOB_LOCATION.USERNAME,
      pass: config.APP_BLOB_LOCATION.PASSWORD,
      baseDir: config.APP_BLOB_LOCATION.BASEDIR
  });

  var dlink = provisionRequest.organization.id + '/' + provisionRequest.experience.experienceId + '/';
  dlink += app.type + '/' + app.id + '/' + app.version + '/' + app.name.replace(/ /g, '_') + '/';
  // console.log("dlink : " + dlink);

  ssh.exec('sudo mkdir -p ' + dlink, {
    err: function(stderr) {
      logger.error('provision : dao : received request : createFolderStructure : Error : Failed to create folder structure for download link : ' + stderr);
      callback(new Error("Error while creating folder structure for download link"));
      return;
    },
    out: function(stdout) {
      logger.info('provision : dao : received request : createFolderStructure : Folder structure created successfully : ' + dlink);
    }
  }).exec('sudo chmod 757 ' + dlink, {
    err: function(stderr) {
      logger.error('provision : dao : received request : createFolderStructure : Error : Failed to change folder permissions : ' + stderr);
      callback(new Error("Error while creating folder structure for download link"));
      return;
    },
    out: function(stdout) {
      logger.info('provision : dao : received request : createFolderStructure : Folder permissions changed successfully : ' + dlink);
    },
    exit: function(count, stdout, stderr) {
      app.downloadPath = dlink;
      callback(null, provisionRequest, app);
    }
  }).start({
    success: function() {
      logger.info('provision : dao : received request : createFolderStructure : SSH connection successfully established');
    },
    fail: function(err) {
      logger.error('provision : dao : received request : createFolderStructure : Error : Failed to establish SSH connection : ' + err);
      callback(new Error("Failed to establish SSH connection"));
      return;
    }
  });
}

function uploadAppToServer(provisionRequest, app, callback) {
  logger.info('provision : dao : received request : uploadAppToServer : Upload app file to server');
  var fileObject = path.parse(app.distribution);
  var appPath = provisionRequest.artifactsPath + fileObject.name + path.sep + config.CORDOVA_PROJECT.ANDROID.ARTIFACT_LOCATION
                + path.sep + app.fileName + '.' + config.CORDOVA_PROJECT.ANDROID.ARTIFACT_TYPE;
  // console.log("appPath : " + appPath)
  // console.log(config.APP_BLOB_LOCATION.BASEDIR + app.downloadPath);
  client.scp(appPath, {
      host: config.APP_BLOB_LOCATION.HOSTNAME,
      username: config.APP_BLOB_LOCATION.USERNAME,
      password: config.APP_BLOB_LOCATION.PASSWORD,
      path: config.APP_BLOB_LOCATION.BASEDIR + app.downloadPath + app.name.replace(/ /g, '_') + '.' + config.CORDOVA_PROJECT.ANDROID.ARTIFACT_TYPE
  }, function(err) {
    if(err) {
      logger.error('provision : dao : received request : uploadAppToServer : Error : Failed to uplaod app : ' + app.name + ' : ' + err);
      callback(err);
      return;
    }
    logger.info('provision : dao : received request : uploadAppToServer : App uploaded successfully : ' + app.name);
    callback(null, provisionRequest, app);
  })
}

function updateProvisionDownloadLink(provisionRequest, app, callback) {

  logger.info('provision : dao : received request : updateProvisionDownloadLink : Update provision record with app download link');
  var dlink = config.APP_BLOB_LOCATION.PROTOCOL + config.APP_BLOB_LOCATION.HOSTNAME + config.APP_BLOB_LOCATION.OTHER;
  dlink += app.downloadPath;
  dlink += app.name.replace(/ /g, '_') + '.' + config.CORDOVA_PROJECT.ANDROID.ARTIFACT_TYPE;

  var appLinks = {
    appId: app.id,
    appName: app.name,
    appLogo: app.logo,
    appType: app.type,
    downloadLink: dlink
  };

    // console.log(JSON.stringify(appLinks));

    ProvisionedExperience.findOneAndUpdate({
      '_id': provisionRequest.id
    }, {
      $addToSet: { 'appLinks': appLinks }
    }, {
      'new': true
    }, function(err, data) {
      if(err) {
        logger.error('provision : dao : received request : updateDownloadLinkForIndirectProvisioning : Error : Failed to update the download links for apps in experience');
        callback(new Error('Failed to update download links for apps in experience : ' + provisionRequest.experience.name));
        return;
      }
      logger.info('provision : dao : received request : updateDownloadLinkForIndirectProvisioning : Successfully updated download links for apps in experience!!!');
      callback(null, provisionRequest);
    });
}


module.exports = {
  addProvisioningRequest: add,
  associateVMWithRequest: associateVM,
  dissociateVMFromRequest : dissociateVM,
  getProvisionedExperienceByOrgIdAndExperienceId: getByOrgIdAndExperienceId,
  getCountOfProvisionedExperiencesByOrgId: getCountByOrgId,
  getSuccessfullyProvisionedExperiencesCountByOrgId: getProvisionedCountByOrgId,
  updateRequestState: updateState,
  updateProvisionedVMDetails: updateHostDetails,
  getProvisioningRequestById: get,
  getProvisionedVMByRequestId: getVMByRequestId,
  deleteProvisioningRequest: softDelete,
  renewProvisioningRequest: renew,
  getAllExperiences: getAll,
  getAllExpiredProvisionedRequests: getAllExpiredProvisionedRequests,
  getProvisionedExperiencesByUserName: getProvisionedExperiencesByUserName,
  updateFields: updateFields ,
  getVmDetailsById: getVmDetailsById,
  getVmDetailsByUserName:getVmDetailsByUserName,
  getAllExperiencesProvisioned: getAllExperiencesProvisioned,
  getAllExperiencesProvisionedByStatus: getAllExperiencesProvisionedByStatus,
  getAllProvisionedExperiencesByUserName: getAllProvisionedExperiencesByUserName,
  updateDownloadLinkForDirectProvisioning: updateDownloadLinkForDirectProvisioning,
  updateDownloadLinkForIndirectProvisioning: updateDownloadLinkForIndirectProvisioning
};
