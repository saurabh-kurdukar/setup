var amqp = require('amqplib/callback_api');
var RabbitMQ = require('../../common/RabbitMQ');
var logger = require('../../common/logger').log;
var provisionExperienceController = require('../controller/provision-experience');
const queueName = 'ProvisionQueue';
var async = require('async');

RabbitMQ.getConnection(function(connection) {
	connection.createChannel(function(err, ch) {
		if(err) {
			logger.error(`provision : delegate : listener error : Stack trace : \n ${JSON.stringify(err)}`);
		} else {
			ch.prefetch(1);
			ch.assertQueue(queueName, {
				durable : false
			});
			console.log(" [*] Waiting for messages in ProvisionQueue");
			ch.consume(queueName, function(msg) {
				  logger.info(`provision : delegate : listener : received request : \n ${msg.content.toString()}`);
				  console.log(" [x] Received %s", msg.content.toString());			  
				  provision(JSON.parse(msg.content), ch, msg);	  
			}, {
				noAck: false
			});
		}
	});
});


var provision = function (provisionRequest, ch, msg) {
	
	console.log('inside provision..');
	async.waterfall([
	 	    async.apply(provisionExperienceController.validateProvisioningRequest, JSON.parse(msg.content)),
	 	    provisionExperienceController.createRequestInPendingState,
	 	    provisionExperienceController.updateRequestDetails,
	 	    provisionExperienceController.initiateProvisioning
 	    ], 
 	    function (err, provisionRequest) {		
 	    if (err) {	      
	 	      logger.error(`Experience provisioning failed : Stack trace : \n ${JSON.stringify(err)}`);
	 	      console.log('sending ack with provision  err..');
	 	      return ch.ack(msg);
 	    }
 	    logger.info(`Request # ${provisionRequest.id} : Experience provisioning initiated.`);
 	    console.log('Req: # '+provisionRequest.id+' sending ack with provision success..');
 	    ch.ack(msg);				
	 });	 
}