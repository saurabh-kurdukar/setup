var amqp = require('amqplib/callback_api');
var RabbitMQ = require('../../common/RabbitMQ');
var logger = require('../../common/logger').log;
var provisionExperienceController = require('../controller/provision-experience');
const queueName = 'DeProvisionQueue';
var async = require('async');
var adapterConfig = require('../../common/adapterConfig');
var allocatePostDeprovisionAdapter = require('../../'+adapterConfig.allocatePostDeprovision);

RabbitMQ.getConnection(function(connection) {
	connection.createChannel(function(err, ch) {
		if(err) {
			logger.error(`provision : delegate : listener error : Stack trace : \n ${JSON.stringify(err)}`);
		} else {
			ch.prefetch(1);
			ch.assertQueue(queueName, {
				durable : false
			});
			console.log(" [*] Waiting for messages in DeProvisionQueue");
			ch.consume(queueName, function(msg) {
				logger.info(`de provision : delegate : listener : received request : \n ${msg.content.toString()}`);
				console.log(" [x] Received %s", msg.content.toString());		
				console.log(JSON.stringify(msg));
				deProvision(msg.content, ch, msg);	  
			}, {
				noAck: false
			});
		}
	});
});


var deProvision = function (id, ch, msg) {
	console.log('inside de-provision..');

	async.waterfall([
	                 async.apply(provisionExperienceController.validateDeprovisioningRequest, msg.content),
	                 provisionExperienceController.initiateDeprovisioning,
	                 provisionExperienceController.deleteProvisioningRequest
	], function (err, provisionRequest) {
		if (err) {
			logger.error(`Experience de-provisioning failed : Stack trace : \n ${JSON.stringify(err)}`);
			console.log('sending ack with de-provision  err..');
			return ch.ack(msg);
		}		
		
		allocatePostDeprovisionAdapter.processMethod(provisionRequest, function(err, allocRes) {			
			logger.info(`Request # ${provisionRequest.id} : Experience de-provisioning initiated.`);
			console.log('Req: # '+provisionRequest.id+' sending ack with de-provision success..');
			ch.ack(msg);
		});		
	});
	
}








