var amqp = require('amqplib/callback_api');
var RabbitMQ= require('../../common/RabbitMQ');
var logger = require('../../common/logger').log;
const queueName = 'ProvisionQueue';

var addProvisionReqToQueue = function(provisionRequest, callback) {		
	logger.info('provision : delegate : received request : addProvisionReqToQueue : body : '+ JSON.stringify(provisionRequest));		
 	RabbitMQ.getConnection(function(connection) {
		  connection.createChannel(function(err, ch) {
				if(err) {
					logger.error('provision : delegate : error while creating provision queue. : error : '+ JSON.stringify(err));				
				} else {
				    ch.assertQueue(queueName, {durable: false});
				    ch.sendToQueue(queueName, new Buffer(JSON.stringify(provisionRequest)));
				    logger.info('provision : delegate : Added provisioning request to queue : body : '+ JSON.stringify(provisionRequest));
				    console.log(" [x] Added provisioning request to queue.");
					callback(err, {	"message": "Experience provisioning initiated."});
					setTimeout(function() { connection.close(); }, 500);
				}
		  });
	});
};


module.exports.addProvisionReqToQueue = addProvisionReqToQueue;