var amqp = require('amqplib/callback_api');
var RabbitMQ= require('../../common/RabbitMQ');
var logger = require('../../common/logger').log;
const queueName = 'DeProvisionQueue';

var addDeProvisionReqToQueue = function(id, callback) {		
	logger.info('de-provision : delegate : received request : addDeProvisionReqToQueue : body : '+ id);		
 	RabbitMQ.getConnection(function(connection) {
		  connection.createChannel(function(err, ch) {
				if(err) {
					logger.error('de-provision : delegate : error while creating de-provision queue. : error : '+ JSON.stringify(err));				
				} else {
				    ch.assertQueue(queueName, {durable: false});
				    ch.sendToQueue(queueName, new Buffer(id));
				    logger.info('provision : delegate : Added de-provisioning request to queue : body : '+ id);
				    console.log(" [x] Added de-provisioning request to queue.");
					callback(err, {	"message": "Experience de-provisioning initiated."});
					setTimeout(function() { connection.close(); }, 500);
				}
		  });
	});
};


module.exports.addDeProvisionReqToQueue = addDeProvisionReqToQueue;