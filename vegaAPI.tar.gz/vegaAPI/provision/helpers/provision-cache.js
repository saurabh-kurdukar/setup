'use strict';

var orgCache = {};

var lock = function (orgId) {
  if(!orgCache[orgId]) {
    orgCache[orgId] = orgId;
    return true;
  } else {
    return false;
  }
}

var release = function (orgId) {
  delete orgCache[orgId];
}

module.exports.lock = lock;
module.exports.release = release;
