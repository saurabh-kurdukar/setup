'use strict';

var config = require('./../../common/Config'),
fs = require('fs'),
path = require('path'),
async = require('async'),
PlatformError = require('./../../common/platform-error'),
sendgrid  = require('sendgrid')(config.SENDGRID_API_KEY
	//	,
  //{'proxy': "http://ptproxy.persistent.co.in:8080",
  //'https-proxy': "http://ptproxy.persistent.co.in:8080" }
),
logger = require('../../common/logger').log
.child({module : 'Provisioning', type : 'Email Helper'});

function loadEmailTemplate(userRequest, cb) {
  var templateFilePath = path.resolve(__dirname,
    './../../' + config.USER_EMAIL_TEMPLATE_PATH
  );

  fs.readFile(templateFilePath,
    "utf-8", function (err, emailContent) {
      if (err) {
        cb(new PlatformError('PROV011', [], 500, err));
        return;
      }
      cb(null, userRequest, emailContent);
    }
  );
}

function sendEmail(userRequest, emailContent, cb) {

  var email = new sendgrid.Email({
    to: userRequest.username,
    from: 'noreplyEDT@persistent.com',
    subject: "Welcome to Vega - Accelerating Digital Transformation",
    html: emailContent,
    files: [
      {
        filename: 'image.png',
        cid: 'qrcode_image',
        content: (userRequest.qrImage)
      }
    ]
  });

  email.addSubstitution('--company--', userRequest.company.companyName);
  email.addSubstitution('--email--', userRequest.username);
  email.addSubstitution('--password--', userRequest.userpassword);
  email.addSubstitution('--radiaServer--', config.RADIA.HOSTNAME);
  email.addSubstitution('--radiaPort--', config.RADIA.PORT);

  sendgrid.send(email, function(err, json) {
    if (err) {
      cb(new PlatformError('PROV012', [], 500, err));
      return;
    }

    logger.info(`Onboarding email along with QR-Code sent to user : ${email.to}`);
    cb(null, userRequest);
  });
}

var sendProvisioningEmail = function(userRequest, cb) {

  async.waterfall([
    async.apply(loadEmailTemplate, userRequest),
    sendEmail,
  ], function (err, userRequest) {
    if (err) {
      cb(err);
      return;
    }
    cb(null, userRequest);
  });
}

module.exports.sendProvisioningEmail = sendProvisioningEmail;
