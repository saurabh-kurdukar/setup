'use strict';

var logger = require('./../../common/logger').log
.child({module : 'sandbox', type : 'radia helper'}),
async = require('async'),
fs = require('fs'),
path = require('path'),
cp = require('child_process'),
config = require('./../../common/Config'),
radiaConfig = require('./../../common/radiaConfig'),
PlatformError = require('../../common/platform-error'),
commandPrefix = config.JAVA_COMMAND_LINE + ' ' + path.resolve(__dirname, './../../' + config.RADIA_JAR_PATH);

function uploadApplications(sandboxRequest, cb) {
  logger.debug(`Sandbox request # ${sandboxRequest.id} : Upload mobile applications in radia.`);

  async.each(
    sandboxRequest.experiences,
    async.apply(uploadExperienceApplications, sandboxRequest),
    function(err) {
      if (err) {
        logger.error(`Sandbox request # ${sandboxRequest.id} : Mobile applications upload failed.`);
        // TODO: @vishal
        // rollbackProvisioning();
        cb(err);
        return;
      }
      cb(null, sandboxRequest);
    }
  );
}

function createTempFile(sandboxRequest, commandConfiguration, cb) {

  logger.debug(`Sandbox request # ${sandboxRequest.id} : Create temporary file at ${commandConfiguration.filePath} with content : ${JSON.stringify(commandConfiguration.inputObject)}`);

  fs.writeFile(commandConfiguration.filePath, (commandConfiguration.inputObject ? JSON.stringify(commandConfiguration.inputObject) : commandConfiguration.inputObject), function(err, data) {
    if(err) {
      logger.error(`Sandbox request # ${sandboxRequest.id} : Could not create temporary file : ${commandConfiguration.filePath}.`);
      cb(err);
      return;
    }
    cb(null, sandboxRequest, commandConfiguration);
  });
}

function executeCommand(sandboxRequest, commandConfiguration, cb) {

  var cmd = commandPrefix + ' ' + commandConfiguration.command + ' ' + path.resolve(__dirname, './../../' + config.RADIA_CONFIG_PATH) + ' ' + commandConfiguration.filePath;

  logger.debug(`Sandbox request # ${sandboxRequest.id} : Executing radia command : ${cmd}`);

  //  cb(null, sandboxRequest, commandConfiguration);
  cp.exec(cmd, function(err, data, stderr) {

    if (err != null) {
      logger.error(`Sandbox request # ${sandboxRequest.id} : Command execution failed : ${cmd}`);
      logger.error(err);
      logger.error(data);
      if(data) {
        cb(data);
      } else {
        cb(err);
      }
      return;
    } else {
      commandConfiguration.response = data;
      logger.debug(`Sandbox request # ${sandboxRequest.id} : Command executed successfully : ${cmd}`);
    }
    cb(null, sandboxRequest, commandConfiguration);
  });
}

function deleteTempFile(sandboxRequest, commandConfiguration, cb) {

  logger.debug(`Sandbox request # ${sandboxRequest.id} : Deleting temporary file : ${commandConfiguration.filePath}`);

  fs.unlink(commandConfiguration.filePath, function(err) {
    if(err) {
      logger.error(`Sandbox request # ${sandboxRequest.id} : Could not delete temporary file : ${commandConfiguration.filePath}.`);
      cb(err);
      return;
    }
    cb(null, sandboxRequest, commandConfiguration);
  });
}

function executeRadiaCommand(sandboxRequest, commandConfiguration, cb) {

  async.waterfall([
    async.apply(createTempFile, sandboxRequest, commandConfiguration),
    executeCommand,
    deleteTempFile
  ], function (err, oSandboxRequest, oCommandConfiguration) {

    if (err) {
      logger.error(`Sandbox request # ${sandboxRequest.id} : Command type : ${commandConfiguration.command} execution flow failed.`);
      cb(err);
      return;
    }

    logger.info(`Sandbox request # ${oSandboxRequest.id} : Command type : ${oCommandConfiguration.command} execution flow completed.`);

    if(commandConfiguration.propagateOutput) {
      cb(null, oSandboxRequest, oCommandConfiguration);
    } else {
      cb(null, oSandboxRequest);
    }
  });
}

function checkIfUserAlreadyPresent(sandboxRequest, cb) {
  var commandConfiguration = {
    filePath : path.resolve(__dirname, `./../../temp/radia/${sandboxRequest.user.name}.json`),
    command: radiaConfig.USER_LIST,
    inputObject : '',
    propagateOutput : true
  };
  executeRadiaCommand(sandboxRequest, commandConfiguration, cb);
}

function createUserInRadia(sandboxRequest, commandConfiguration, cb) {

  var userExists = false;

  if(commandConfiguration.response) {

    commandConfiguration.response = JSON.parse(commandConfiguration.response);

    for(var loopIndex=0; loopIndex < commandConfiguration.response.length; loopIndex++) {
      if(commandConfiguration.response[loopIndex].uid === sandboxRequest.user.email) {
        userExists = true;
        break;
      }
    }
  }

  if(userExists) {

    logger.info(`Sandbox request # ${sandboxRequest.id} : User ${sandboxRequest.user.email} already exists in Radia.`);
    cb(null);
    return;
  }

  var commandConfiguration = {
    filePath : path.resolve(__dirname, `./../../temp/radia/${sandboxRequest.user.name}.json`),
    command: radiaConfig.CREATE_USER,
    inputObject : [{
      "firstName": sandboxRequest.user.name,
      "lastName": sandboxRequest.user.name,
      "designation": sandboxRequest.user.name,
      "emailId": sandboxRequest.user.email,
      "mobileNumber": "1234567890",
      "userGroupNames": [sandboxRequest.user.company],
      "defaultPassword": sandboxRequest.user.password
    }]
  };

  executeRadiaCommand(sandboxRequest, commandConfiguration, cb);
}

function createUser(sandboxRequest, cb) {

  logger.debug(`Sandbox request # ${sandboxRequest.id} : Create user account in radia for user : ${sandboxRequest.user.name}`);

  async.waterfall([
    async.apply(checkIfUserAlreadyPresent, sandboxRequest),
    createUserInRadia
  ], function (err) {
    if (err) {
      logger.error(`Sandbox request # ${sandboxRequest.id} : User account creation failed for username : ${sandboxRequest.user.name}`);
      cb(err);
      return;
    }
    cb(null, sandboxRequest);
  });
}

function checkIfGroupAlreadyPresent(sandboxRequest, cb) {
  var commandConfiguration = {
    filePath : path.resolve(__dirname, `./../../temp/radia/${sandboxRequest.user.name}.json`),
    command: radiaConfig.GROUP_LIST,
    inputObject : '',
    propagateOutput : true
  };
  executeRadiaCommand(sandboxRequest, commandConfiguration, cb);
}

function createGroupInRadia(sandboxRequest, commandConfiguration, cb) {

  var groupExists = false;

  if(commandConfiguration.response) {

    commandConfiguration.response = JSON.parse(commandConfiguration.response);

    for(var loopIndex=0; loopIndex < commandConfiguration.response.length; loopIndex++) {
      if(commandConfiguration.response[loopIndex].displayName === sandboxRequest.user.company) {
        groupExists = true;
        break;
      }
    }
  }

  if(groupExists) {
    logger.info(`Sandbox request # ${sandboxRequest.id} : Group ${sandboxRequest.user.company} already exists in Radia.`);
    cb(null);
    return;
  }

  var commandConfiguration = {
    filePath : path.resolve(__dirname, `./../../temp/radia/${sandboxRequest.user.name}.json`),
    command: radiaConfig.CREATE_GROUP,
    inputObject : [{
      groupType: config.RADIA_GROUP_TYPE,
      groupName: sandboxRequest.user.company,
      description: "group for customer " + sandboxRequest.user.company
    }]
  };
  executeRadiaCommand(sandboxRequest, commandConfiguration, cb);
}

function createGroup(sandboxRequest, cb) {

  logger.debug(`Sandbox request # ${sandboxRequest.id} : Create group in radia with name : ${sandboxRequest.user.company}`);

  async.waterfall([
    async.apply(checkIfGroupAlreadyPresent, sandboxRequest),
    createGroupInRadia
  ], function (err) {
    if (err) {
      logger.error(`Sandbox request # ${sandboxRequest.id} : Group creation failed with name : ${sandboxRequest.user.company}`);
      cb(err);
      return;
    }
    cb(null, sandboxRequest);
  });
}

function associateApplicationsWithGroup(sandboxRequest, cb) {

  logger.debug(`Sandbox request # ${sandboxRequest.id} : Associate mobile applications with group : ${sandboxRequest.user.company}`);

  var commandConfiguration = {
    filePath : path.resolve(__dirname, `./../../temp/radia/${sandboxRequest.user.name}.json`),
    command: radiaConfig.ASSIGN_APP_TO_GROUP,
    inputObject : [{
      "groupName": sandboxRequest.user.company,
      "appsInstanceName":[]
    }]
  };

  for(var outerIndex = 0; outerIndex < sandboxRequest.experiences.length; outerIndex++){
    var experience = sandboxRequest.experiences[outerIndex];
    for(var innerIndex = 0; innerIndex < experience.mobileApplications.length; innerIndex++) {
      commandConfiguration.inputObject[0].appsInstanceName.push(`AA_AA_${sandboxRequest.user.name}_${experience.mobileApplications[innerIndex].name}`);
    }
  }
  executeRadiaCommand(sandboxRequest, commandConfiguration, cb);
}

function uploadExperienceApplications(sandboxRequest, experience, cb) {

  async.each(
    experience.mobileApplications,
    async.apply(uploadApplicationInRadia, sandboxRequest, experience),
    function(err) {
      if (err) {
        logger.error(`Sandbox request # ${sandboxRequest.id} : Mobile application upload failed.`);
        cb(err);
        return;
      }
      cb(null, sandboxRequest);
    }
  );
}

function uploadApplicationInRadia(sandboxRequest, experience, application, cb) {

  logger.debug(`Sandbox request # ${sandboxRequest.id} : Upload application : ${application.name} in radia.`);

  var commandConfiguration = {
    filePath : path.resolve(__dirname, `./../../temp/radia/${sandboxRequest.user.name}_${experience.name}_${application.name}.json`),
    command: radiaConfig.ADD_APP,
    inputObject : [{
      "type": "Enterprise",
      "appFile": {
        "path": path.resolve(__dirname, `./../../temp/experience/${sandboxRequest.id}/${experience.name}/${application.name}/${application.fileName}`)
      },
      "appName": sandboxRequest.user.name + '_' + application.name,
      "vendor": "Persistent",
      "description": application.description,
      "category": "Enterprise",
      "iconFile": {
        "path": path.resolve(__dirname, `./../../temp/experience/${sandboxRequest.id}/${experience.name}/${application.name}/${application.icon}`)
      },
      "screens": [
      ],
      "osList": application.type,
      "isMendatory": true
    }]
  };

  for(var loopIndex = 0; loopIndex < application.screenshots.length; loopIndex++) {
    commandConfiguration.inputObject[0].screens[loopIndex] = {
      path : path.resolve(__dirname, `./../../temp/experience/${sandboxRequest.id}/${experience.name}/${application.name}/${application.screenshots[loopIndex]}`)
    };
  }

  executeRadiaCommand(sandboxRequest, commandConfiguration, cb);
}

var provisionExperiencesInRadia = function(sandboxRequest, cb) {

  logger.info(`Sandbox request # ${sandboxRequest.id} : Provision user account, group and mobile applications in radia.`);

  async.waterfall([
    async.apply(createGroup, sandboxRequest),
    createUser,
    uploadApplications,
    associateApplicationsWithGroup
  ], function (err) {

    if (err) {
      logger.error(`Sandbox request # ${sandboxRequest.id} : Provisioning failed in radia.`);
      // TODO: @vishal
      // rollbackProvisioning();
      cb(err);
      return;
    }

    logger.info(`Sandbox request # ${sandboxRequest.id} : Successfully provisioned user account, group and applications in radia.`);
    cb(null, sandboxRequest);
  });
}

function dissociateApplicationsFromGroup(sandboxRequest, cb) {

  logger.debug(`Sandbox request # ${sandboxRequest.id} : Dissociate mobile applications from group : ${sandboxRequest.user.company}`);

  var commandConfiguration = {
    filePath : path.resolve(__dirname, `./../../temp/radia/${sandboxRequest.id}.json`),
    command: radiaConfig.UNASSIGN_APP_FROM_GROUP,
    inputObject : [{
      "groupName": sandboxRequest.user.company,
      "appsInstanceName":[]
    }]
  };

  for(var outerIndex = 0; outerIndex < sandboxRequest.experiences.length; outerIndex++){
    var experience = sandboxRequest.experiences[outerIndex];
    for(var innerIndex = 0; innerIndex < experience.mobileApplications.length; innerIndex++) {
      commandConfiguration.inputObject[0].appsInstanceName.push(`AA_AA_${sandboxRequest.user.name}_${experience.mobileApplications[innerIndex].name}`);
    }
  }
  executeRadiaCommand(sandboxRequest, commandConfiguration, cb);
}

function deleteApplications(sandboxRequest, cb) {
  logger.debug(`Sandbox request # ${sandboxRequest.id} : Delete provsioned mobile applications from Radia.`);

  var commandConfiguration = {
    filePath: path.resolve(__dirname, `./../../temp/radia/${sandboxRequest.id}.json`),
    command: radiaConfig.DELETE_APP,
    inputObject : [
    ]
  };

  for(var outerIndex = 0; outerIndex < sandboxRequest.experiences.length; outerIndex++) {
    var experience = sandboxRequest.experiences[outerIndex];
    for(var innerIndex = 0; innerIndex < experience.mobileApplications.length; innerIndex++) {
      commandConfiguration.inputObject.push(`PRIMARY.MOBILE.ZSERVICE.AA_AA_${sandboxRequest.user.name}_${experience.mobileApplications[innerIndex].name}`);
    }
  }

  executeRadiaCommand(sandboxRequest, commandConfiguration, cb);
}

function deleteGroup(sandboxRequest, cb) {

  logger.debug(`Sandbox request # ${sandboxRequest.id} : Delete Group from radia with name : ${sandboxRequest.user.company}`);
  cb(null, sandboxRequest);
}

function deleteUser(sandboxRequest, cb) {

  logger.debug(`Sandbox request # ${sandboxRequest.id} : Delete user account from radia for user : ${sandboxRequest.user.name}`);
  cb(null, sandboxRequest);
}

var deprovisionExperiencesFromRadia = function(sandboxRequest, cb) {

  logger.info(`Sandbox request # ${sandboxRequest.id} : Deprovision user account, group and mobile applications from radia.`);

  async.waterfall([
    async.apply(dissociateApplicationsFromGroup, sandboxRequest),
    deleteApplications,
    deleteGroup,
    deleteUser
  ], function (err) {

    if (err) {
      cb(new PlatformError('SBX003', 500, err));
      return;
    }

    logger.info(`Sandbox request # ${sandboxRequest.id} : Successfully deprovisioned user account, group and applications from radia.`);
    cb(null, sandboxRequest);
  });
}

module.exports.provisionExperiencesInRadia = provisionExperiencesInRadia;
module.exports.deprovisionExperiencesFromRadia = deprovisionExperiencesFromRadia;
