var async = require('async');
var exec = require('child_process').exec;
var config = require('../../common/Config');
var logger = require('../../common/logger').log;
const MODULE_NAME = "provisionV2";


var processServices = function(provisionRequest, cb) {
	async.eachSeries(provisionRequest.experience.services, function processService(service, callback) {
		if (service.serviceDeployOption == 'SCRIPT') {
			exec('node ' + service.execScriptLocation + ' ' + provisionRequest.id, function(error, stdout, stderr) {
				if (error || stderr) {
					logger.error(MODULE_NAME + ' : services: ServicesProcessing : processServices failed : error : ' + error + ' for service : ' + JSON.stringify(service));
					logger.error(MODULE_NAME + ' : services: ServicesProcessing : processServices failed : stderr : ' + stderr + ' for service : ' + JSON.stringify(service));
					callback();
				} else {
					logger.info(MODULE_NAME + ' : services: ServicesProcessing : processServices successful !: stdout : ' + stdout + ' for service : ' + JSON.stringify(service));
					callback();
				}
			});
		} else {
			callback();
		}
	}, function done() {
		logger.info(MODULE_NAME + ' : services: ServicesProcessing : processServices completed.');
		cb(null, provisionRequest);
	});
};

module.exports.processServices = processServices;
