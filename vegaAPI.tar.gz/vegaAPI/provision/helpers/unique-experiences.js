var logger = require('../../common/logger').log;

function getUniqueExperiences(provisionRequest, cb) {
  
  logger.info('provision : helpers : received request : getUniqueExperiences : Get the unique provisioned experiences');

  var uniqueExp = [];
  var uniqueExpIdStr = "";
  provisionRequest.forEach(function(provision, index, array) {
    var expExists = false;
    if(uniqueExp.length == 0) {
      uniqueExp.push(provision);
      uniqueExpIdStr += provision.experienceId + ',';
    }
    else {
      uniqueExp.forEach(function(exp) {
        if(provision.experienceId == exp.experienceId) {
          expExists = true;
          return;
        }
      })
      if(!expExists) {
        uniqueExp.push(provision);
        uniqueExpIdStr += provision.experienceId + ',';
      }
      if(index == array.length - 1) {
        var callbackResponse = {};
        callbackResponse.provisionRequest = provisionRequest;
        callbackResponse.query = {};
        callbackResponse.query.experiences = uniqueExpIdStr;
        cb(null, callbackResponse, null);
      }
    }
  })
}

module.exports = {
  getUniqueExperiences: getUniqueExperiences
}
