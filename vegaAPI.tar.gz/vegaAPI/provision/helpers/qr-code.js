'use strict';

var qr = require('qr-image'),
config = require('./../../common/Config'),
logger = require('../../common/logger').log
.child({module : 'Provisioning', type : 'Qrcode Helper'});

var generateRadiaClientQRCode = function(userRequest, cb) {

  var queryString = `name=${userRequest.username}&password=${userRequest.userpassword}&server=${config.RADIA.HOSTNAME}&port=${config.RADIA.PORT}`,
  url = `${config.RADIA.AGENT_URL}?${new Buffer(queryString).toString('base64')}`;

  logger.debug(`QR-Code query string : ${queryString}`);
  logger.info(`Generating QR-Code for data : ${url}`);

  userRequest.qrImage = qr.imageSync(url);
  logger.info(`Successfully generated QR-Code.`);
  cb(null, userRequest);
}

module.exports.generateRadiaClientQRCode = generateRadiaClientQRCode;
