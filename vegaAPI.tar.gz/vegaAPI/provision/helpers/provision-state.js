var Enum = require('enum'),
dao = require('./../dao/provision-experience-dao'),
PlatformError = require('../../common/platform-error'),
provisionState = require('../dto/provision-state'),
deProvisionState = require('../dto/deprovision-state'),
logger = require('../../common/logger').log
.child({
  module: 'State Manager',
  type: 'provisioning service'
});

function moveToNextProvisionState(provisionRequest, cb) {

  var currentState = provisionState.get(provisionRequest.state);
  if(!currentState) {
    cb(new PlatformError('PROV009', [], 500));
    return;
  }
  var nextState = provisionState.get(currentState.valueOf() + 1);
  if(!nextState) {
    cb(new PlatformError('PROV009', [], 500));
    return;
  }

  provisionRequest.state = nextState.key;

  if(provisionRequest.state === 'PROVISIONED') {
    provisionRequest.status = 'PROVISIONED';
  }

  logger.info(`Request # ${provisionRequest.id} : Change state from ${currentState.key} to ${nextState.key}`);
  dao.updateRequestState(provisionRequest, cb);
}

function moveToNextDeProvisionState(provisionRequest, cb) {

  var currentState = deProvisionState.get(provisionRequest.deprovisionState);
  if(!currentState) {
    cb(new PlatformError('PROV017', [], 500));
    return;
  }
  var nextState = deProvisionState.get(currentState.valueOf() + 1);
  if(!nextState) {
    cb(new PlatformError('PROV017', [], 500));
    return;
  }

  provisionRequest.deprovisionState = nextState.key;

  if(provisionRequest.deprovisionState === 'DEPROVISIONED') {
    provisionRequest.state = 'DEPROVISIONED';
    provisionRequest.status = 'DEPROVISIONED';
  }

  logger.info(`Request # ${provisionRequest.id} : Change state from ${currentState.key} to ${nextState.key}`);
  dao.updateRequestState(provisionRequest, cb);
}

var populateVMProvisioningDetails = function(provisionRequest, cb) {

  var currentState = provisionState.get(provisionRequest.state);
  if(!currentState) {
    cb(new PlatformError('PROV009', [], 500));
    return;
  }

  if(currentState.valueOf() >= provisionState.VM_PROVISIONED.valueOf()) {
    logger.info(`Request # ${provisionRequest.id} : VM provisioned for request. Get provisioned VM details.`);

    dao.getProvisionedVMByRequestId(provisionRequest.id, function(err, provisionedVM) {
      if(err) {
        cb(err);
        return;
      }

      if(provisionedVM && provisionedVM.vmId) {
        provisionRequest.vm = provisionedVM;
      }

      cb(null, provisionRequest);
    });

  } else {
    logger.info(`Request # ${provisionRequest.id} : VM has not been provisioned for request.`);
    cb(null, provisionRequest);
  }
}

module.exports = {
  moveToNextProvisionState : moveToNextProvisionState,
  moveToNextDeProvisionState : moveToNextDeProvisionState,
  populateVMProvisioningDetails : populateVMProvisioningDetails
};
