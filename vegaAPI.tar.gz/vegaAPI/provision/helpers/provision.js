'use strict';

var async = require('async'),
path = require('path'),
os = require('os'),
fs = require('fs'),
radiaHelper = require('./../../radia-adapter/client'),
request = require('request'),
SSH = require('simple-ssh'),
scpClient = require('scp2'),
dao = require('./../dao/provision-experience-dao'),
util = require('util'),
config = require('./../../common/Config'),
PlatformError = require('../../common/platform-error'),
manifestHelper = require('./experience-manifest'),
cacheHelper = require('./provision-cache'),
serviceHelper = require('./services-processing'),
stateHelper = require('./provision-state'),
experienceDao = require('../../experience/dao/ExperienceDAO'),
deProvisionState = require('../dto/deprovision-state'),
logger = require('../../common/logger').log
.child({
  module: 'Experience Provisioning',
  type: 'provisioning service'
});
var platformUserDao = require('../../platformUser/dao/PlatformUserDAO');
// Varsha to add later auditLogger = require('../../common/logger').auditEventLog,

function spawnVirtualMachine(provisionRequest, cb) {

  logger.info(`Request # ${provisionRequest.id} : Spawn Virtual Machine.`);

  var ports = [],
  portsAsString = '';

  provisionRequest.experience.services.forEach(function(service) {
    ports.push(service.boundToPort);
  });

  provisionRequest.experience.applications.forEach(function(application) {
    if(application.type === config.APPLICATION_TYPE.WEBAPP) {
      ports.push(application.boundToPort);
    }
  });

  portsAsString = JSON.stringify(ports).replace(/\[/g, '');
  portsAsString = portsAsString.replace(/\]/g, '');

  var requestOptions = {
    method: 'post',
    body: {
      'nameHint': provisionRequest.experience.name,
      'username': config.DOCKER_VM_USER,
      'password': config.DOCKER_VM_PASSWORD,
      'osType': provisionRequest.experience.vmDetails.osFamily,
      'osVersion': provisionRequest.experience.vmDetails.osVersion,
      'provisionType': 'EXPERIENCE',
      'size': provisionRequest.experience.vmDetails.size,
      //'imageName' : provisionRequest.experience.vmDetails.imageName,  // should be uncommented after manifest change
      'ports': portsAsString
    },
    json: true,
    url: `http://${config.COMPONENT_SERVER_HOST}:${config.COMPONENT_SERVER_PORT}/api/vm/docker`,
    headers: {
      'Content-Type': 'application/json'
    }
  };

  request(requestOptions, function (err, res, body) {
    if (err) {
      cb(new PlatformError('PROV001', [], 500, err));
      return;
    }

    if(res.statusCode != 200) {
      cb(new PlatformError('PROV006', [], 500, body));
      return;
    }

    provisionRequest.vmDetails = body;
    cb(null, provisionRequest);
  });
}

function pollToCheckSpawnedVMStatus(provisionRequest, cb) {
  logger.debug(`Request # ${provisionRequest.id} : Check VM provisioning status for hostname : ${provisionRequest.vmDetails.hostname}`);

  var data = {
    provisioned : false,
    attempts : 0
  },
  url = `http://${config.COMPONENT_SERVER_HOST}:${config.COMPONENT_SERVER_PORT}/api/vm/docker/${provisionRequest.vmDetails.vmId}`;
  logger.debug(`Request # ${provisionRequest.id} : URL to check VM provisioning status: ${url}`);
  async.until(
    function () { return data.provisioned || data.attempts > config.VM_PROVISION_CHECK_ATTEMPTS },
    function (cb2) {
      data.attempts = data.attempts + 1;
      logger.debug(`Request # ${provisionRequest.id} : Get call to check VM provisioning status. Attempt no # ${data.attempts}`);

      request(url, function (error, response, body) {

        var output;

        if(error) {
          cb2(new PlatformError('PROV001', [], 500, error));
          return;
        }

        if(response.statusCode !== 200) {
          cb2(new PlatformError('PROV001', [], 500, error));
          return;
        }

        output = JSON.parse(body);

        if (output.status === 'RUNNING') {
          data.provisioned = true;
        } else if (output.status === 'FAILED') {
          cb2(new PlatformError('PROV014', [], 500, output));
          return;
        } else {
          logger.trace(`Request # ${provisionRequest.id} : VM provisioning in progress. Response body : ${JSON.stringify(output)}`);
        }
        setTimeout(function () {
          cb2(null, data);
        }, config.VM_PROVISION_CHECK_INTERVAL);
      });
    },
    function (err, response) {

      if(err) {
        cb(err);
        return;
      }

      if(data.provisioned) {
        logger.info(`Request # ${provisionRequest.id} : Virtual Machine successfully provisioned and ready to accept provisioning commands.`);
        cb(null, provisionRequest);
      } else {
        cb(new PlatformError('PROV007', [config.VM_PROVISION_CHECK_ATTEMPTS * config.VM_PROVISION_CHECK_INTERVAL], 500));
      }
    }
  );
}

function createPlatformConfigurationsFile(provisionRequest, cb) {

  var fileContent = `
  platformIPAddress = ${config.PLATFORM_API_TARGET}
  platformPort = ${config.SERVER.PORT}
  provisionId = ${provisionRequest.id}
  protocol = ${config.SERVER.PROTOCOL}`;

  provisionRequest.platformProperties = provisionRequest.artifactsPath + 'platform.properties';

  fs.writeFile(
    provisionRequest.platformProperties,
    fileContent,
    function(err, data) {
      if(err) {
        cb(new PlatformError('PROV001', [], 500, err));
        return;
      }
      logger.debug(`Request # ${provisionRequest.id} : Successfully created intermediate platform.properties file at : ${provisionRequest.platformProperties}`);
      cb(null, provisionRequest);
    }
  );
}

function copyPlatformConfigurationsFile(provisionRequest, cb) {
  logger.debug(`Request # ${provisionRequest.id} : copy platform configuration file on remote machine.`);

  scpClient.scp(
    provisionRequest.platformProperties,
    {
      host: provisionRequest.vmDetails.fqdn,
      username: provisionRequest.vmDetails.username,
      password: provisionRequest.vmDetails.password,
      path: '/tmp/'
    }, function(err) {
      if(err) {
        cb(new PlatformError('PROV001', [], 500, err));
        return;
      }
      logger.debug(`Request # ${provisionRequest.id} : Successfully copied platform.properties file to remote machine.`);
      cb(null, provisionRequest);
    }
  );
}

function generateCodeToExecuteRemoteCommands(provisionRequest, cb) {

  var sortedServices = provisionRequest.experience.services.sort(function (thisObj, thatObj) {
    if (thisObj.order > thatObj.order) {
      return 1;
    }
    if (thisObj.order < thatObj.order) {
      return -1;
    }
    return 0;
  }),
  commands = [];

  commands.push(`sudo docker login --username="${config.DOCKER.ADMIN_USERNAME}" --password="${config.DOCKER.ADMIN_PASSWORD}" --email="${config.DOCKER.ADMIN_EMAIL}"`);

  sortedServices.forEach(function(service) {
    commands.push(`sudo docker run -idt -v /tmp:/data -p ${service.boundToPort}:${service.boundFromPort} ${service.fileName}`);
  });

  provisionRequest.experience.applications.forEach(function(application) {
    if(application.type === config.APPLICATION_TYPE.WEBAPP) {
      commands.push(`sudo docker run -idt -v /tmp:/data -p ${application.boundToPort}:${application.boundFromPort} ${application.fileName}`);
    }
  });

  logger.trace(`Docker commands to execute in below order : ${JSON.stringify(commands)}`);

  var fileContent = `
  'use strict';
  var logger = require('./../../../common/logger').log
  .child({
    module: 'Docker provisioning',
    type: 'provisioning service'
  }),
  PlatformError = require('./../../../common/platform-error');
  function executeCommands(provisionRequest, ssh, cb) {
    logger.info(\`Request # ${provisionRequest.id} : Provision docker images.\`);
    ssh`;
    for(var cmdIndex=0; cmdIndex < commands.length; cmdIndex++) {
      fileContent += `
      .exec('${commands[cmdIndex]}', {
        out: function(stdout) {
          logger.trace(\`Request # \${provisionRequest.id} : Command stdout log : \${stdout}\`);
        },
        err: function(stderr) {
          logger.trace(\`Request # \${provisionRequest.id} : Command stderr log : \${stderr}\`);
        },
        exit: function(code, stdout, stderr) {
          logger.debug(\`Request # \${provisionRequest.id} : Command exit code : \${code}\`);
          if (code > 0) {
            cb(new PlatformError('PROV001', [], 500, stderr));
            return false;
          }`;

          if(cmdIndex === commands.length-1) {
            fileContent += `else {
              cb(null, provisionRequest);
            }`;
          }
          fileContent += `
        }
      })`;
    }

    fileContent += `
    .start();
  }
  module.exports.executeCommands = executeCommands;
  `;

  fs.writeFile(
    provisionRequest.artifactsPath + config.DOCKER.INTERMEDIATE_FILENAME,
    fileContent,
    function(err, data) {
      if(err) {
        cb(new PlatformError('PROV001', [], 500, err));
        return;
      }
      logger.debug(`Request # ${provisionRequest.id} : Successfully created intermediate docker commands module : ${provisionRequest.artifactsPath + config.DOCKER.INTERMEDIATE_FILENAME}`);
      cb(null, provisionRequest);
    }
  );
}

function executeGeneratedCommands(provisionRequest, cb) {

  var ssh = new SSH({
    host: provisionRequest.vmDetails.fqdn,
    user: provisionRequest.vmDetails.username,
    pass: provisionRequest.vmDetails.password
  });

  require(provisionRequest.artifactsPath + config.DOCKER.INTERMEDIATE_FILENAME).executeCommands(provisionRequest, ssh, cb);
}

function provisionDockerServices(provisionRequest, cb) {
  async.waterfall([
    async.apply(createPlatformConfigurationsFile, provisionRequest),
    copyPlatformConfigurationsFile,
    generateCodeToExecuteRemoteCommands,
    executeGeneratedCommands
  ], function(err, provisionRequest) {
    if (err) {
      cb(err);
      return;
    }

    logger.info(`Request # ${provisionRequest.id} : Successfully provisioned experience backend services.`);
    cb(null, provisionRequest);
  });
}

// function verifyDockerContainerStatus(sandboxRequest, experience, cb) {
//   logger.debug(`Sandbox request # ${sandboxRequest.id} : Check application backend connectivity on remote VM ${experience.service.hostname}`);
//
//   var data = {
//     found : false,
//     attempts : 0
//   },
//   url = util.format(experience.docker.test.url, experience.service.hostname, experience.service.port);
//   logger.debug(`Sandbox request # ${sandboxRequest.id} : URL to hit to check docker image connectivity : ${url}`);
//   async.until(
//     function () { return data.found || data.attempts > config.DOCKER_IMAGE_CONNECTIVITY_CHECK_ATTEMPTS },
//     function (cb2) {
//       data.attempts = data.attempts + 1;
//       logger.debug(`Sandbox request # ${sandboxRequest.id} : Check docker backed application start status. Attempt no # ${data.attempts}`);
//
//       request(url, function (error, response, body) {
//         if (!error && response.statusCode === experience.docker.test.statusCode) {
//
//           if(experience.docker.test.response.matchType === 'CONTAINS') {
//             if(body.indexOf(experience.docker.test.response.text) > -1) {
//               data.found = true;
//             }
//           }
//         }
//         setTimeout(function () {
//           cb2(null, data);
//         }, config.DOCKER_IMAGE_CONNECTIVITY_CHECK_INTERVAL);
//       });
//     },
//     function (err, response) {
//
//       if(data.found) {
//         logger.info(`Sandbox request # ${sandboxRequest.id} : Verified connectivity to experience backend.`);
//         cb(null, sandboxRequest, experience);
//       } else {
//         var err = new Error('Aborted sandbox provisioning. Connection to experience backend could not be established in the configured time.');
//         err.status = 500;
//         cb(err);
//         return;
//       }
//     }
//   );
// }
//

function associateVMWithRequest(provisionRequest, cb) {
  dao.associateVMWithRequest(provisionRequest, cb);
}

function updateRequestState(provisionRequest, cb) {
  stateHelper.moveToNextProvisionState(provisionRequest, cb);
}

function provisionServices(provisionRequest, cb) {
  async.waterfall([
    async.apply(spawnVirtualMachine, provisionRequest),
    // async.apply(updateRequestState, provisionRequest),
    associateVMWithRequest,
    updateRequestState,
    pollToCheckSpawnedVMStatus,
    provisionDockerServices,
    updateRequestState
  ], function(err, provisionRequest) {
    if (err) {
      cb(err);
      return;
    }

    logger.info(`Request # ${provisionRequest.id} : Virtual machine provisioning successfully completed.`);
    cb(null, provisionRequest);
  });
}

function prepareMobileArtifacts(provisionRequest, cb) {
  logger.info(`Request # ${provisionRequest.id} : Read manifest, download source code and build artifacts.`);
  manifestHelper.prepareExperienceArtifacts(provisionRequest, cb);
}

function provisionExperienceBackend(provisionRequest, cb) {

  async.waterfall([
    async.apply(provisionServices, provisionRequest),
    prepareMobileArtifacts
  ], function(err, provisionRequest) {
    // var output;
    if (err) {
      cb(err);
      return;
    }
    // output = results[1];
    // output.vmDetails = results[0].vmDetails;
    // output.state = results[0].state;

    logger.debug(`Request # ${provisionRequest.id} : Experience backend services provisioned and mobile artifacts prepared.`);
    cb(null, provisionRequest);
  });
}

function loginInRadia(provisionRequest, cb) {
	radiaHelper.login(provisionRequest, cb);
}

function uploadApplicationsInRadia(provisionRequest, cb) {
  radiaHelper.provisionApplications(provisionRequest, cb);
}

function checkIfApplicationsAlreadyAssociatedWithRadia(provisionRequest, cb) {

  var data = {
    lock : false
  };

  logger.debug(`Request # ${provisionRequest.id} : Check if lock available for organization: ${provisionRequest.orgId}`);
  async.until(
    function () { return data.lock},
    function (cb2) {

      data.lock = cacheHelper.lock(provisionRequest.orgId);

      setTimeout(function () {
        cb2(null, data);
      }, 1000);
    },
    function (err, response) {

      if(err) {
        cb(err);
        return;
      }

      logger.debug(`Request # ${provisionRequest.id} : Lock available for organization: ${provisionRequest.orgId}`);

      dao.getSuccessfullyProvisionedExperiencesCountByOrgId(provisionRequest,
        function (err, provisionRequest, provisionedCount) {
          if (err) {
            cb(err);
            return;
          }
          logger.debug(`${provisionedCount} # of experiences already provisioned for Organization : ${provisionRequest.orgId}`);

          if (provisionedCount) {
            provisionRequest.isFirstAssociation = false;
          } else {
            provisionRequest.isFirstAssociation = true;
          }
          cb(null, provisionRequest);
        }
      );
    }
  );
}

function associateApplicationsInRadia(provisionRequest, cb) {
  radiaHelper.associateApplicationsWithGroup(provisionRequest, cb);
}

function releaseOrganizationLock(provisionRequest, cb) {

  logger.debug(`Request # ${provisionRequest.id} : Lock released for organization Id : ${provisionRequest.orgId}`);

  cacheHelper.release(provisionRequest.orgId);
  if(cb) {
    cb(null, provisionRequest);
  }
}

function provisionExperienceInRadia(provisionRequest, cb) {
  //console.log('in provisionExperienceInRadia');
  async.waterfall([
    async.apply(loginInRadia, provisionRequest),
    uploadApplicationsInRadia,
    updateRequestState,
    checkIfApplicationsAlreadyAssociatedWithRadia,
    associateApplicationsInRadia,
    releaseOrganizationLock
  ], function(err, provisionRequest) {
    if (err) {
      cb(err);
      return;
    }

    logger.info(`Request # ${provisionRequest.id} : Successfully provisioned experience artifacts in Radia.`);
    cb(null, provisionRequest);
  });
}

function associateApplicationsInRadiaDirect(provisionRequest, cb) {
  radiaHelper.associateApplicationsWithGroupDirect(provisionRequest, cb);
}


function directProvisionInRadia(provisionRequest, cb) {

  async.waterfall([
    async.apply(loginInRadia, provisionRequest),
    //checkIfApplicationsAlreadyAssociatedWithRadia,
    associateApplicationsInRadiaDirect,
    //releaseOrganizationLock
  ], function(err, provisionRequest) {
    if (err) {
      cb(err);
      return;
    }

    logger.info(`Request # ${provisionRequest.id} : Successfully provisioned experience artifacts in Radia.`);
    cb(null, provisionRequest);
  });
}

function cleanUp(provisionRequest, cb) {
  // execute cleanup in background
  manifestHelper.removeTempDirectory(provisionRequest);
  cb(null, provisionRequest);
}

function createTempDirectory(provisionRequest, cb) {
  logger.debug(`Request # ${provisionRequest.id} : Create temporary file at ${provisionRequest.artifactsPath}`);

  fs.mkdir(provisionRequest.artifactsPath, function(err) {
    if(err) {
      cb(new PlatformError('PROV001', [], 500, err));
      return;
    }
    cb(null, provisionRequest);
  });
}

var startDirectWebProvisioning = function(provisionRequest) {

  provisionRequest.artifactsPath = path.resolve(__dirname, `./../../temp/provision/${provisionRequest.id}`);
  provisionRequest.artifactsPath = provisionRequest.artifactsPath + path.sep;


  async.waterfall([
    async.apply(createTempDirectory, provisionRequest),
    updateRequestState,
    updateRequestState,
    updateRequestState,
    updateRequestState,
    cleanUp
  ], function(err, oProvisionRequest) {
    if (err) {
      logger.error(`Request # ${provisionRequest.id} : Experience provisioning failed. Stack trace : \n ${err.stack}`);
      manifestHelper.removeTempDirectory(provisionRequest);
      return;
    }

    logger.info(`Request # ${provisionRequest.id} : Successfully provisioned experience.`);
  });
}


var startDirectProvisioning = function(provisionRequest) {

  provisionRequest.artifactsPath = path.resolve(__dirname, `./../../temp/provision/${provisionRequest.id}`);
  provisionRequest.artifactsPath = provisionRequest.artifactsPath + path.sep;


  async.waterfall([
    async.apply(createTempDirectory, provisionRequest),
    updateRequestState,
    updateRequestState,
    provisionExperienceInRadia,
    updateRequestState,
    cleanUp
  ], function(err, oProvisionRequest) {
    if (err) {
      logger.error(`Request # ${provisionRequest.id} : Experience provisioning failed. Stack trace : \n ${err.stack}`);
      manifestHelper.removeTempDirectory(provisionRequest);
      return;
    }

    logger.info(`Request # ${provisionRequest.id} : Successfully provisioned experience.`);
  });
}

function markRequestAsFailed(provisionRequest, cb) {

  provisionRequest.status = 'FAILED';
  dao.updateRequestState(provisionRequest, cb);
}

function handleProvisioningFailure(provisionRequest) {
  async.waterfall([
    async.apply(markRequestAsFailed, provisionRequest),
    cleanUp,
    releaseOrganizationLock
  ], function(err) {
    if (err) {
      logger.error(`Request # ${provisionRequest.id} : Experience provisioning rollback failed. Stack trace : \n ${JSON.stringify(err)}`);
      return;
    }

    logger.info(`Request # ${provisionRequest.id} : Successfully handled provisioning failure.`);
  });
}

var startProvisioning = function(provisionRequest) {

  provisionRequest.artifactsPath = path.resolve(__dirname, `./../../temp/provision/${provisionRequest.id}`);
  provisionRequest.artifactsPath = provisionRequest.artifactsPath + path.sep;

  async.waterfall([
    async.apply(createTempDirectory, provisionRequest),
    provisionExperienceBackend,
    provisionExperienceInRadia,
    updateDownloadLinkForIndirectProvisioning,
    updateRequestState,
    cleanUp
  ], function(err, oProvisionRequest) {
    if (err) {
      logger.error(`Request # ${provisionRequest.id} : Experience provisioning failed. Stack trace : \n ${JSON.stringify(err)}`);

      provisionRequest.errorCode = err.code;
      handleProvisioningFailure(provisionRequest);
      return;
    }
    experienceDao.updateProvisioningInfo(provisionRequest.experienceId, 1, 1);
    console.log("Updating Platform User");
    platformUserDao.updateProvisioningInfo(provisionRequest.orgId, 1, 1);
    logger.info(`Request # ${provisionRequest.id} : Successfully provisioned experience.`);
  });
}

function updateDownloadLinkForIndirectProvisioning(provisionRequest, cb) {
  dao.updateDownloadLinkForIndirectProvisioning(provisionRequest, cb);
}

var directProvisioning = function(provisionRequest, cb) {
  async.waterfall([
    async.apply(serviceHelper.processServices, provisionRequest),
    // directProvisionInRadia,
    updateDownloadLinkForDirectProvisioning,
    updateRequestStateForDirectProvisioning
  ], function(err) {
    if (err) {

      releaseOrganizationLock(provisionRequest);
      cb(err);
      return;
    }
    experienceDao.updateProvisioningInfo(provisionRequest.experienceId, 0, 1);
    console.log("Updating Platform User");
    platformUserDao.updateProvisioningInfo(provisionRequest.orgId, 1, 0);
    logger.info(`Request # ${provisionRequest.id} : Successfully provisioned experience.`);
    cb(null, provisionRequest);
  });
}

function updateDownloadLinkForDirectProvisioning(provisionRequest, cb) {
  dao.updateDownloadLinkForDirectProvisioning(provisionRequest, cb);
}

function updateRequestStateForDirectProvisioning(provisionRequest, cb) {
  if(config.SKIP_RADIA) {
    provisionRequest.state = 'PROVISIONED';
    provisionRequest.status = 'PROVISIONED';
  }
	dao.updateRequestState(provisionRequest, cb);
}

function deProvisionExperienceFromRadia(provisionRequest, cb) {
  radiaHelper.deassociateApplicationsWithGroup(provisionRequest, cb);
}

function deProvisionVirtualMachine(provisionRequest, cb) {

  if(!provisionRequest.vm) {
    cb(null, provisionRequest);
    return;
  }

  logger.info(`Request # ${provisionRequest.id} : De-provision Virtual Machine : ${provisionRequest.vm.vmId} associated with provisioned experience instance.`);

  var requestOptions = {
    timeout: 30000,
    headers: {
      'Content-type': 'application/json'
    },
    method: 'delete',
    url: `http://${config.COMPONENT_SERVER_HOST}:${config.COMPONENT_SERVER_PORT}/api/vm/docker/${provisionRequest.vm.vmId}`
  };

  request(requestOptions, function (err, res, body) {
    if (err) {
      cb(new PlatformError('PROV001', [], 500, err));
      return;
    }

    if(res.statusCode != 200) {
      cb(new PlatformError('PROV008', [], 500, body));
      return;
    }

    cb(null, provisionRequest);
  });
}

function getProvisionedVMDetails(provisionRequest, cb) {
  stateHelper.populateVMProvisioningDetails(provisionRequest, cb);
}

function updateDeprovisioningRequestState(provisionRequest, cb) {
  stateHelper.moveToNextDeProvisionState(provisionRequest, cb);
}

function dissociateVMFromRequest(provisionRequest, cb) {
  if(!provisionRequest.vm) {
    cb(null, provisionRequest);
    return;
  }
  dao.dissociateVMFromRequest(provisionRequest, cb);
}

function updateRequestToDeprovisioningState(provisionRequest, cb) {
  logger.debug(`Request # ${provisionRequest.id} : Set deprovision state to START.`);

  provisionRequest.deprovisionState = deProvisionState.START.key;
  provisionRequest.status = 'DE-PROVISIONING';

  dao.updateRequestState(provisionRequest, cb);
}

function deProvisionExperienceBackend(provisionRequest, cb) {

  async.waterfall([
    async.apply(updateRequestToDeprovisioningState, provisionRequest),
    getProvisionedVMDetails,
    deProvisionVirtualMachine,
    dissociateVMFromRequest,
    updateDeprovisioningRequestState
  ], function(err) {
    if (err) {
      cb(err);
      return;
    }

    logger.info(`Request # ${provisionRequest.id} : Successfully de-provisioned experience backend.`);
    cb(null, provisionRequest);
  });
}

var startDeprovisioning = function(provisionRequest, cb) {

  async.waterfall([
    async.apply(deProvisionExperienceBackend, provisionRequest),
    // deProvisionExperienceFromRadia,
    updateDeprovisioningRequestState,
    updateDeprovisioningRequestState
  ], function(err) {
    if (err) {
      cb(err);
      return;
    }

    logger.info(`Request # ${provisionRequest.id} : Successfully de-provisioned experience.`);
    // log audit event
    // Varsha update following to logged in user
    /*
    var auditEvent = {};
    auditEvent.username = config.DOCKER_VM_USER;
    auditEvent.payload = provisionRequest.experience.name;
    auditEvent.event = provisionRequest.state;
    auditEvent.status = provisionRequest.status;
    auditEvent.date = new Date();
    auditLogger.info(auditEvent, "DEPROVISIONED " + provisionRequest.id);
    */
    if(!provisionRequest.vm) {
      console.log("Updating Platform User : No VM Provisioned");
      experienceDao.updateProvisioningInfo(provisionRequest.experienceId, 0, -1);
      platformUserDao.updateProvisioningInfo(provisionRequest.orgId, -1, 0);
    }
    else {
      console.log("Updating Platform User : VM Provisioned");
      experienceDao.updateProvisioningInfo(provisionRequest.experienceId, -1, -1);
      platformUserDao.updateProvisioningInfo(provisionRequest.orgId, -1, -1);
    }
    cb(null, provisionRequest);
  });
}

module.exports = {
  startProvisioning : startProvisioning,
  startDeprovisioning : startDeprovisioning,
  startDirectWebProvisioning : startDirectWebProvisioning,
  startDirectProvisioning : startDirectProvisioning,
  directProvisioning : directProvisioning
};
