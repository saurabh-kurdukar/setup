var Enum = require('enum');
var dao = require('../dao/sandboxDao');
var logger = require('../../common/logger').log;

//sandbox item states
var SIState = new Enum({
  'PROVISIONING': 0,
  'VM_PROVISIONED': 1,
  'API_PROVISIONED': 2,
  'RADIA_PROVISIONED': 3,
  'EMAIL': 4,
  'PROVISIONED': 5,
  'DEPROVISIONED': 6
});

// return  the string representation of state
function getCurrentState(sandboxRequestId, experienceId, cb) {
  logger.info("getCurrentState started ....");
  dao.getSandboxItemState(sandboxRequestId, experienceId, function(err, data) {
    if (err) {
      logger.info("Error occurred while retrieving the current state for sandboxrequest " + sandboxRequestId + " for experience " + experienceId)
      cb(null);
    }
    cb(null, data); //returning string value
    return;
  });
}

function setNextState(sandboxRequestId, experienceId, cb) {
  logger.info("setNextState started ....");
  var currentState = "";
  getCurrentState(sandboxRequestId, experienceId, function(err, data) {
    if (err) {
      logger.info("Error occurred while retrieving the current state for sandboxrequest " + sandboxRequestId + " for experience " + experienceId)
      cb(null);
    }
 
    currentState = data;
    var curState = SIState.get(currentState);
    var nextState = SIState.get(curState.valueOf() + 1);
    dao.updateSandboxItemState(sandboxRequestId, experienceId, nextState.key, function(err) {
      if (err) {
        logger.info("Error occurred while setting the next state for sandboxrequest " + sandboxRequestId + " for experience " + experienceId)
        cb(null);
      }

      cb(null, sandboxRequestId, experienceId, data); //returning updated experienceId and new state 
    });


  });
}

function setPreviousState() {

}


module.exports.getCurrentState = getCurrentState;
module.exports.setNextState = setNextState;
module.exports.setPreviousState = setPreviousState;
