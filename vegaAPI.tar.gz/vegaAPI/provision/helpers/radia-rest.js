'use strict';

var logger = require('./../../common/logger').log
.child({module : 'sandbox', type : 'radia client'}),
async = require('async'),
config = require('./../../common/Config'),
PlatformError = require('../../common/platform-error'),
UserCredential = require('../dto/radia/user-credential'),
UserGroup = require('../dto/radia/user-group'),
User = require('../dto/radia/user'),
UserGroupAssociation = require('../dto/radia/user-group-assoc'),
Application = require('../dto/radia/application'),
GroupApplicationAssociation = require('../dto/radia/group-application-assoc'),
request = require('request');

const FORM_DATA = 'form',
MULTIPART_FORM = 'multipart',
JSON = 'json';

function sendRequestToRadia(httpMethod, relativeUrl, cookie, dataType, content, cb) {

  console.log(httpMethod);
  console.log(relativeUrl);
  console.log(cookie);
  console.log(dataType);
  console.log(content);
  console.log(cb);

  var requestOptions = {
    method: httpMethod,
    url: `${config.RADIA_BASE_URL}${relativeUrl}`,
    jar: cookie
  };

  if(dataType === FORM_DATA) {
    requestOptions.form = content;
  } else if(dataType === JSON) {
    requestOptions.json = true;
    requestOptions.body = content;
  } else if(dataType === MULTIPART_FORM) {
    requestOptions.formData = content;
  }

  request(requestOptions, function (err, res, body) {
    cb(err, res, body);
  });
}

function login(sandboxRequest, cookie, cb) {

  var processResponse = function (err, res, body) {
    if (err) {
      cb(new PlatformError('SBX010', 500, err));
    } else if(res.statusCode === 200 && body) {
      cb(new PlatformError('SBX011', 500, body));
    } else if (res.statusCode === 200 || res.statusCode === 302 || res.statusCode === 405) {
      cb(null, sandboxRequest, cookie);
    } else {
      cb(new PlatformError('SBX010', 500, body));
    }
  };

  sendRequestToRadia(
    'post',
    '/tenant/j_security_check',
    cookie,
    FORM_DATA,
    new UserCredential(config.RADIA_ADMIN_USERNAME, config.RADIA_ADMIN_PASSWORD),
    processResponse
  );
}

function createGroup(sandboxRequest, cookie, cb) {

  logger.debug(`Sandbox request # ${sandboxRequest.id} : Create group in radia with name : ${sandboxRequest.user.company}`);

  var userGroup = new UserGroup(sandboxRequest.user.company),
  processResponse = function (err, res, body) {
    if (err) {
      console.log(err);
      cb(new PlatformError('SBX012', 500, err));
    } else if(res.statusCode === 201 && body) {
      logger.debug(`Sandbox request # ${sandboxRequest.id} : Group successfully created in radia with name : ${sandboxRequest.user.company}`);
      console.log('success....');
      console.log(body);
      sandboxRequest.user.newGroup = true;
      sandboxRequest.user.groupDN = userGroup.getDN();
      cb(null, sandboxRequest, cookie);
    } else if (res.statusCode === 409) {
      logger.debug(`Sandbox request # ${sandboxRequest.id} : Group already exists in radia with name : ${sandboxRequest.user.company}`);
      console.log('conflict...');
      console.log(body);
      sandboxRequest.user.groupDN = userGroup.getDN();
      cb(null, sandboxRequest, cookie);
    } else {
      console.log('generic error...');
      console.log(body);
      cb(new PlatformError('SBX012', 500, body));
    }
  };

  sendRequestToRadia(
    'post',
    '/ws/radiaCustomer/groups',
    cookie,
    JSON,
    userGroup,
    processResponse
  );
}

function createUser(sandboxRequest, cookie, cb) {

  logger.debug(`Sandbox request # ${sandboxRequest.id} : Create user in radia with email : ${sandboxRequest.user.email}`);

  var user = new User(sandboxRequest.user),
  processResponse = function (err, res, body) {
    if (err) {
      console.log(err);
      cb(new PlatformError('SBX013', 500, err));
    } else if(res.statusCode === 201 && body) {

      logger.debug(`Sandbox request # ${sandboxRequest.id} : User successfully created in radia with email : ${sandboxRequest.user.email}`);
      console.log('success....');
      console.log(body);
      sandboxRequest.user.newUser = true;
      sandboxRequest.user.userDN = user.getDN();
      cb(null, sandboxRequest, cookie);
    } else if (res.statusCode === 409) {
      logger.debug(`Sandbox request # ${sandboxRequest.id} : User already exists in radia with email : ${sandboxRequest.user.email}`);
      console.log('conflict...');
      console.log(body);

      sandboxRequest.user.userDN = user.getDN();
      cb(null, sandboxRequest, cookie);
    } else {
      console.log('generic error...');
      console.log(body);
      cb(new PlatformError('SBX013', 500, body));
    }
  };

  sendRequestToRadia(
    'post',
    '/ws/radiaCustomer/users',
    cookie,
    JSON,
    user,
    processResponse
  );
}

function associateUserWithGroup(sandboxRequest, cookie, cb) {

  logger.debug(`Sandbox request # ${sandboxRequest.id} : Associate user : ${sandboxRequest.user.email} with group : ${sandboxRequest.user.company} in radia.`);

  /* this check should be removed if we ever hit any scenario where user and
  group both exists and doesn't have association between them.
  */
  if(!(sandboxRequest.user.newUser || sandboxRequest.user.newGroup)) {
    console.log('skipped');
    logger.debug(`Sandbox request # ${sandboxRequest.id} : Skip association as user : ${sandboxRequest.user.email} and group : ${sandboxRequest.user.company} already present in radia.`);
    cb(null, sandboxRequest, cookie);
    return;
  }

  var processResponse = function (err, res, body) {
    if (err) {
      console.log(err);
      cb(new PlatformError('SBX014', 500, err));
    } else if(res.statusCode === 200 && body) {

      logger.debug(`Sandbox request # ${sandboxRequest.id} : User : ${sandboxRequest.user.email} successfully associated with Group : ${sandboxRequest.user.company} in radia.`);
      console.log('success....');
      console.log(body);
      cb(null, sandboxRequest, cookie);
    } else {
      console.log('generic error...');
      console.log(body);
      logger.warn(`Sandbox request # ${sandboxRequest.id} : Could not associate user : ${sandboxRequest.user.email} with group : ${sandboxRequest.user.company} in radia. User might be already associated.`);
      // ignore this error as in case of concurrent provisioning requests, this can arise
      cb(null, sandboxRequest, cookie);
      //cb(new PlatformError('SBX014', 500, body));
    }
  };

  sendRequestToRadia(
    'put',
    '/ws/radiaCustomer/users/changeusermembership/addUsersToGroups',
    cookie,
    JSON,
    new UserGroupAssociation(sandboxRequest.user),
    processResponse
  );
}

function uploadApplicationInRadia(sandboxRequest, cookie, application, cb) {

  logger.debug(`Sandbox request # ${sandboxRequest.id} : Upload application : ${application.name} to radia.`);

  var processResponse = function (err, res, body) {
    if (err) {
      console.log(err);
      cb(new PlatformError('SBX015', 500, err));
    } else if(res.statusCode === 202 && body) {

      logger.debug(`Sandbox request # ${sandboxRequest.id} : Application : ${application.name} successfully uploaded to radia.`);
      console.log('success....');
      console.log(body);
      cb(null, sandboxRequest, cookie);
    } else {
      console.log('generic error...');
      console.log(body);
      cb(new PlatformError('SBX016', 500, body));
    }
  };

  sendRequestToRadia(
    'post',
    '/ws/radiaCustomer/job/publish',
    cookie,
    MULTIPART_FORM,
    new Application(application),
    processResponse
  );
}

function uploadApplications(sandboxRequest, cookie, cb) {

  async.each(
    sandboxRequest.experience.mobileApplications,
    async.apply(uploadApplicationInRadia, sandboxRequest, cookie),
    function(err) {
      if (err) {
        cb(err);
        return;
      }

//      setTimeout(cb, 15000, null, sandboxRequest, cookie);

      cb(null, sandboxRequest, cookie);
    }
  );
}

function associateGroupWithApplication(sandboxRequest, cookie, cb) {

  logger.debug(`Sandbox request # ${sandboxRequest.id} : Associate group : ${sandboxRequest.user.company} with mobile applications from experience : ${sandboxRequest.experience.name} in radia.`);

  var processResponse = function (err, res, body) {
    if (err) {
      console.log(err);
      cb(new PlatformError('SBX017', 500, err));
    } else if(res.statusCode === 200 && body) {

      logger.debug(`Sandbox request # ${sandboxRequest.id} : Group : ${sandboxRequest.user.company} successfully associated with mobile applications from experience : ${sandboxRequest.experience.name} in radia.`);
      console.log('success....');
      console.log(body);
      cb(null, sandboxRequest, cookie);
    } else {
      console.log('generic error...');
      console.log(body);
      logger.warn(`Sandbox request # ${sandboxRequest.id} : Could not associate group : ${sandboxRequest.user.company} with mobile applications from experience : ${sandboxRequest.experience.name} in radia.`);
      // ignore this error as in case of concurrent provisioning requests, this can arise
      cb(null, sandboxRequest, cookie);
      //cb(new PlatformError('SBX014', 500, body));
    }
  };

  // @vishal, check if mobile applications are already associated in database, because then, we have to change method type to put.

  sendRequestToRadia(
    'post',
    '/ws/radiaCustomer/policy?operation=add',
    cookie,
    JSON,
    new GroupApplicationAssociation(sandboxRequest.user, sandboxRequest.experience),
    processResponse
  );
}

var provisionExperiencesInRadia = function(sandboxRequest) {

  logger.info(`Sandbox request # ${sandboxRequest.id} : Provision user account, group and mobile applications in radia.`);

  var cookie = request.jar();

  async.waterfall([
    async.apply(login, sandboxRequest, cookie),
    createGroup,
    createUser,
    associateUserWithGroup,
    uploadApplications,
    associateGroupWithApplication
  ], function (err) {

    if (err) {
      logger.error(`Sandbox request # ${sandboxRequest.id} : Provisioning failed in radia.`);
      console.log(err);
      //    cb(err);
      return;
    }

    logger.info(`Sandbox request # ${sandboxRequest.id} : Successfully provisioned user account, group and applications in radia.`);
    //    cb(null, sandboxRequest);
  });
};

provisionExperiencesInRadia({
  id: 12,
  user : {
    company : 'Persistent Systems Private Limited', name : 'Vishal Mahajan', email : 'vishal_mahajan@persistent.co.in', password: 12345
  },
  experience: {
    name : 'LogiPlus',
    mobileApplications: [
      {
        "id": "1",
        "name": "OT Checklist",
        "type" : "ANDROID",
        "description": "OT checklist application.",
        "version": "0.0.2",
        "fileName": "OTChecklist.apk",
        "icon" : "ot_logo.png",
        "screenshots" : [
          "ot_logo.png"
        ],
        "dist": "otchecklist.zip",
        "relativePath" : '/home/vishal/Downloads/'
      },
      {
        "id": "2",
        "name": "Shipper",
        "type" : "ANDROID",
        "description": "Shipper application as part of Logi+.",
        "version": "0.0.2",
        "fileName": "Shipper_0.0.2.apk",
        "icon" : "icon.png",
        "screenshots" : [
          "Screenshot1.png"
        ],
        "dist": "shipper.zip",
        "relativePath" : '/home/vishal/Downloads/shipper/'
      }
    ]
  }
});
module.exports.provisionExperiencesInRadia = provisionExperiencesInRadia;
