'use strict';

var async = require('async'),
fs = require('fs'),
util = require('util'),
cp = require('child_process'),
path = require('path'),
unzip = require('unzip'),
safecopy = require('scp2'),
rimraf = require('rimraf'),
request = require('request'),
config = require('./../../common/Config'),
PlatformError = require('../../common/platform-error'),
PlatformEndPointConfiguration = require('../dto/platform-endpoint-conf'),
logger = require('../../common/logger').log
.child({
  module: 'Experience Provisioning',
  type: 'manifest service'
});

function downloadApplicationArtifact(provisionRequest, application, cb) {

  var scpDetails = {
    host: config.EXPERIENCE_DISTRIBUTION.HOSTNAME,
    username: config.EXPERIENCE_DISTRIBUTION.USERNAME,
    password: config.EXPERIENCE_DISTRIBUTION.PASSWORD,
    path: application.distribution
  };

  logger.debug(`Request # ${provisionRequest.id} : Downloading cordova project from path : ${application.distribution}`);
  safecopy.scp(scpDetails, provisionRequest.artifactsPath, function(err) {

    safecopy.close();
    if (err) {
      cb(new PlatformError('PROV001', [], 500, err));
      return;
    }

    logger.debug(`Request # ${provisionRequest.id} : Application artifact ${application.distribution} successfully downloaded.`);
    cb(null, provisionRequest, application);
  });
}

function unzipArtifact(provisionRequest, application, cb) {

  var fileObject = path.parse(application.distribution);

  var artifactPath = provisionRequest.artifactsPath + fileObject.base,
  extracter = unzip.Extract({
    path: provisionRequest.artifactsPath
  });

  logger.debug(`Request # ${provisionRequest.id} : Unzip cordova project : ${artifactPath}`);

  extracter.on('error', function(err) {
    cb(new PlatformError('PROV001', [], 500, err));
  });

  extracter.on('close', function() {
    logger.debug(`Request # ${provisionRequest.id} : Unzip completed for cordova project : ${artifactPath}`);
    cb(null, provisionRequest, application);
  });
  fs.createReadStream(artifactPath).pipe(extracter);
}

function getLogoImagePath(provisionRequest, application, cb) {
  var fileObject = path.parse(application.distribution),
  logoPath = provisionRequest.artifactsPath + fileObject.name + path.sep + config.EXPERIENCE_DISTRIBUTION.LOGO_PATH;
  fs.readdir(logoPath, function(err, files) {
    if(err) {
      cb(new PlatformError('PROV015', [], 500, err));
      return;
    }

    if(!files.length) {
      cb(new PlatformError('PROV015', [], 500));
      return;
    }

    application.logoPath = logoPath + path.sep + files[0];
    cb(null, provisionRequest, application);
  });
}

function getScreenshotsPath(provisionRequest, application, cb) {
  var fileObject = path.parse(application.distribution),
  screenshotsPath = provisionRequest.artifactsPath + fileObject.name + path.sep + config.EXPERIENCE_DISTRIBUTION.SCREENSHOTS_PATH;
  fs.readdir(screenshotsPath, function(err, files) {
    if(err) {
      cb(new PlatformError('PROV015', [], 500, err));
      return;
    }

    if(!files.length) {
      cb(new PlatformError('PROV015', [], 500));
      return;
    }

    application.screenshotsPath = [];
    files.forEach(function(fileName) {
      application.screenshotsPath.push(screenshotsPath + path.sep + fileName);
    });

    cb(null, provisionRequest, application);
  });
}

function generateEndPointConfigurationFile(provisionRequest, application, cb) {

  var platformEndPointConfiguration = new PlatformEndPointConfiguration(provisionRequest.id),
  fileObject = path.parse(application.distribution),
  endPointFilePath = `${provisionRequest.artifactsPath}${fileObject.name}${path.sep}${config.CORDOVA_PROJECT.ENDPOINT_LOCATION}${path.sep}${config.CORDOVA_PROJECT.ENDPOINT_FILE}`,
  fileContents = 'var platformDetails = ' + JSON.stringify(platformEndPointConfiguration);

  logger.debug(`Request # ${provisionRequest.id} : Create platform endpoint configuration file : ${endPointFilePath}`);
  logger.trace(`Request # ${provisionRequest.id} : Endpoint configuration file contents : ${fileContents}`);
  fs.writeFile(
    endPointFilePath,
    fileContents,
    function(err, data) {
      if(err) {
        cb(new PlatformError('PROV001', [], 500, err));
        return;
      }
      logger.debug(`Request # ${provisionRequest.id} : Successfully created platform endpoint configuration file : ${endPointFilePath}`);
      cb(null, provisionRequest, application);
    }
  );
}

function generateDeployable(provisionRequest, application, cb) {
  var fileObject = path.parse(application.distribution),
  platformConf = (application.type === config.APPLICATION_TYPE.ANDROID ? config.CORDOVA_PROJECT.ANDROID : config.CORDOVA_PROJECT.IOS),
  buildCommand = `cordova build ${platformConf.BUILD_CMD}`,
  projectPath = provisionRequest.artifactsPath + fileObject.name;
  logger.debug(`Request # ${provisionRequest.id} : Executing cordova build command : '${buildCommand}' from directory : ${projectPath}`);

  var env = Object.create( process.env );

  if(application.type === config.APPLICATION_TYPE.ANDROID) {
    if(!env.ANDROID_HOME) {
      logger.info(`Request # ${provisionRequest.id} : Could not read ANDROID_HOME environment variable from process. Set ANDROID_HOME to ${config.CORDOVA_PROJECT.ANDROID.SDK_HOME}`);
      env.ANDROID_HOME = config.CORDOVA_PROJECT.ANDROID.SDK_HOME;
    }
  }

  cp.exec(
    buildCommand,
    {
      cwd : projectPath,
      env : env
    },
    function(err, data, stderr) {

      if (err != null) {
        logger.error(`Request # ${provisionRequest.id} : Cordova build failed : ${buildCommand}`);
        cb(new PlatformError('PROV001', [], 500, err));
        return;
      }

      application.basePath = projectPath;
      application.artifactPath = platformConf.ARTIFACT_LOCATION + path.sep + application.fileName + '.' + platformConf.ARTIFACT_TYPE;
      provisionRequest.artifactsPath + fileObject.name

      logger.debug(`Request # ${provisionRequest.id} : Built artifact location : ${application.artifactPath}`);
      logger.debug(`Request # ${provisionRequest.id} : Successfully completed cordova build command.`);
      logger.trace(`Request # ${provisionRequest.id} : Cordova build logs : ${data}`);
      cb(null, provisionRequest);
    }
  );
}

// Comment below function to allow ipa provisioning flow
function prepareApplicationArtifact(provisionRequest, application, cb) {

  if(application.type === 'WEBAPP') {
    cb(null, provisionRequest);
    return;
  }

  async.waterfall([
    async.apply(downloadApplicationArtifact, provisionRequest, application),
    unzipArtifact,
    getLogoImagePath,
    getScreenshotsPath,
    generateEndPointConfigurationFile,
    generateDeployable,
  ], function(err, provisionRequest) {
    if (err) {
      cb(err);
      return;
    }
    cb(null, provisionRequest);
  });
}


// Uncomment below function to allow ipa provisioning flow
/*
function prepareApplicationArtifact(provisionRequest, application, cb) {

  if(application.type === 'WEBAPP') {
    cb(null, provisionRequest);
    return;
  }

  if(application.type === 'ANDROID') {

    logger.debug(`Request # ${provisionRequest.id} : Building Android App : ${application.name}`);
    async.waterfall([
      async.apply(downloadApplicationArtifact, provisionRequest, application),
      unzipArtifact,
      getLogoImagePath,
      getScreenshotsPath,
      generateEndPointConfigurationFile,
      generateDeployable,
    ], function(err, provisionRequest) {
      if (err) {
        cb(err);
        return;
      }
      cb(null, provisionRequest);
    });
  }
  else if(application.type === 'IOS') {

    logger.debug(`Request # ${provisionRequest.id} : Build and uploading IOS App : ${application.name}`);
    var requestObj = {
      provisionRequest: provisionRequest,
      application: application
    }

    var requestBody = {
      method: 'POST',
      url: config.CORDOVA_PROJECT.IOS.BUILD_URL,
      json: true,
      body: requestObj
    }

    request(requestBody, function(err, res, body) {
      if(err) {
        logger.error(`Request # ${provisionRequest.id} : Cannot connect to build url : ${err}`);
        cb(err);
        return;
      }
      if(res.statusCode == 200 && body) {
        logger.debug(`Request # ${provisionRequest.id} : Application : ${application.name} successfully uploaded to radia.`);
        cb(null, provisionRequest);
      }
      else {
        logger.error(`Request # ${provisionRequest.id} : Error occurred while build/upload IOS app : ${body}`);
        cb(new Error(body));
        return;
      }
    })
  }
}
*/

function prepareExperienceArtifacts(provisionRequest, cb) {
  async.eachSeries(
    provisionRequest.experience.applications,
    async.apply(prepareApplicationArtifact, provisionRequest),
    function(err) {
      if (err) {
        cb(new PlatformError('PROV001', [], 500, err));
        return;
      }
      cb(null, provisionRequest);
    }
  );
}

function removeTempDirectory(provisionRequest) {
  logger.debug(`Request # ${provisionRequest.id} : Remove temporary directory : ${provisionRequest.artifactsPath}`);
  rimraf(
    provisionRequest.artifactsPath,
    { maxBusyTries: 3 },
    function (err) {
      if (err) {
        // just log, don't propagate
        logger.warn(`An error occurred while removing temporary directory : ${provisionRequest.artifactsPath}`);
      }
    }
  );
}

module.exports = {
  prepareExperienceArtifacts : prepareExperienceArtifacts,
  removeTempDirectory : removeTempDirectory
};
