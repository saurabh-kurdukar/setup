var async = require('async');
var fs = require('fs');
var request = require('request');
var unzip = require('unzip');
var safecopy = require('scp2');
var rimraf = require('rimraf');
var logger = require('../../common/logger').log;
var path;
var disthost;
var distport;
var username;
var password;
var DOWNLOAD_BASE_DIR;

function processManifestFile(experience, cb) {
  var experienceMetadata = experience;
  var dist = experienceMetadata.dist;
  var experiences = experienceMetadata.mobileApplications;
  path = dist.path;
  disthost = dist.host;
  distport = dist.port;
  username = dist.username;
  password = dist.password;
  var downloadDir = DOWNLOAD_BASE_DIR + experience.name + '/';

  if (!fs.existsSync(downloadDir)) {
    fs.mkdirSync(downloadDir);
  }
  // update downloaddir
  for (var index = 0; index < experiences.length; index++) {
    experiences[index]["downloadpath"] = downloadDir;
  };

  async.each(
    experiences,
    downloadAndUnzip,
    function(err) {
      if (err) {
        // TODO: @vishal
      } else {
        // TODO: @vishal
      }
      cb(null);
    }
  );
}

function downloadAndUnzip(experience, cb) {
  async.waterfall([
    async.apply(download, experience),
    unzipfile
  ], function(err) {

    if (err) {
      logger.error(err);
      // TODO: @vishal
    } else {
      logger.info('download and unzip completed for ' + experience.id + ' ' + experience.dist);
      cb(null);
      // TODO: @vishal
    }
  });
}

function getManifest(sandboxRequest, cb) {
  // get manifest by experience id
  for (var index = 0; index < sandboxRequest.experienceIds.length; index++) {
    sandboxRequest.experiences[index] = require('./../../common/' + sandboxRequest.experienceIds[index]);
  }
  cb(null, sandboxRequest);
}

function process(sandboxRequest, cb) {
  if (!fs.existsSync('./temp')) {
    fs.mkdirSync('./temp');
  }

  if (!fs.existsSync('./temp/experience')) {
    fs.mkdirSync('./temp/experience');
  }

  if (!fs.existsSync('./temp/experience/' + sandboxRequest.id)) {
    fs.mkdirSync('./temp/experience/' + sandboxRequest.id );
  }

  DOWNLOAD_BASE_DIR = './temp/experience/' + sandboxRequest.id + '/';
  
  async.each(
    sandboxRequest.experiences,
    processManifestFile,
    function(err) {
      if (err) {
        logger.info(err);
        // TODO: @vishal
      } else {
        // TODO: @vishal
      }
      cb(null, sandboxRequest);
    }
  );
};

// download all apks/ipas path
function download(experience, cb) {
  logger.info("downloading for experience id = " + experience.id + " " + experience.dist);
  var dir = experience.downloadpath;
  safecopy.scp({
    host: disthost,
    username: username,
    password: password,
    path: path + experience.dist
  }, dir, function(err) {
   if (err)
   {
   logger.info(err);
     cb(err);
   }
    logger.info("download complete for " + experience.id + " " + experience.dist + " downloaded successfully to " + dir);
    cb(null, experience);
  });
};

function unzipfile(experience, cb) {
  logger.info("unzip started for experience id = " + experience.id + " " + experience.dist);
  var dir = experience.downloadpath;
  //file is downloaded
  fs.createReadStream(dir + '' + experience.dist).pipe(unzip.Extract({
    path: dir
  }));
  logger.info("unzip complete for " + experience.id + " " + experience.dist + " unzipped successfully in " + dir);
  cb(null);
};

function deleteSandboxDownloadDir(sandboxRequest, cb) {
  logger.debug("deleting dir for sandboxRequest" + DOWNLOAD_BASE_DIR)
  if (fs.existsSync(DOWNLOAD_BASE_DIR)) {
    rimraf(DOWNLOAD_BASE_DIR, {"maxBusyTries":3}, function (err)
    {
      if (err)
      {
        logger.info("error occurred while deleting " + DOWNLOAD_BASE_DIR);
      }
    });
  }
}

module.exports.process = process;
module.exports.getManifest = getManifest;
module.exports.deleteSandboxDownloadDir = deleteSandboxDownloadDir;

