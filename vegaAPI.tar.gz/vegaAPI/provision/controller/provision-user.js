'use strict';

var logger = require('../../common/logger').log
.child({
  module: 'User Provisioning',
  type: 'controller'
}),
async = require('async'),
radiaHelper = require('./../../radia-adapter/client'),
PlatformError = require('../../common/platform-error'),
qrHelper = require('../helpers/qr-code'),
emailHelper = require('../helpers/email'),
companyDao= require('../../company/dao/CompanyDAO');

function getCompanyDetails(user, cb) {

  logger.debug(`Get company details for company Id : ${user.companyId}`);

  companyDao.getCompanyByOrgId(user.companyId, function(err, company) {

    if(err){
      // image code is temporary placed in radia messages file
      cb(new PlatformError('COMP001', [user.companyId], 404, err));
      return;
    }

    user.company = company;
    logger.debug(`Fetched company details :  ${JSON.stringify(company)}`);
    cb(null, user);
  });
}

function loginInRadia(user, cb) {
  radiaHelper.login(user, cb);
}

function createUserInRadia(user, cb) {
  radiaHelper.createUser(user, cb);
}

function associateUserWithGroupInRadia(user, cb) {
  radiaHelper.associateUserWithGroup(user, cb);
}

function generateQRCode(user, cb) {
  qrHelper.generateRadiaClientQRCode(user, cb);
}

function sendEmail(user, cb) {
  emailHelper.sendProvisioningEmail(user, cb);
}

function provisionUser(user, cb) {

  logger.info(`Start user provisioning in Radia.`);

  async.waterfall([
    async.apply(getCompanyDetails, user),
    loginInRadia,
    createUserInRadia,
    associateUserWithGroupInRadia,
    generateQRCode
  ], function(err, user) {
    if (err) {
      cb(err);
      return;
    }

    logger.info(`Successfully provisioned user account in Radia.`);
    cb(null, user);
  });
}

module.exports = {
  provisionUser: provisionUser
};
