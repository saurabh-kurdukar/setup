'use strict';

var logger = require('../../common/logger').log
.child({
  module: 'Group Provisioning',
  type: 'controller'
}),
async = require('async'),
radiaHelper = require('./../../radia-adapter/client'),
PlatformError = require('../../common/platform-error');

function loginInRadia(company, cb) {
  radiaHelper.login(company, cb);
}

function createGroupInRadia(company, cb) {
  radiaHelper.createGroup(company, cb);
}

function provisionGroup(company, cb) {

  logger.info(`Start user group provisioning in Radia.`);

  async.waterfall([
    async.apply(loginInRadia, company),
    createGroupInRadia
  ], function(err, company) {
    if (err) {
      cb(err);
      return;
    }

    logger.info(`Successfully provisioned user group in Radia.`);
    cb(null, company);
  });
}

module.exports = {
  provisionGroup: provisionGroup
};
