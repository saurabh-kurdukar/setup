'use strict';

var logger = require('../../common/logger').log
.child({
  module: 'Experience Provisioning',
  type: 'controller'
}),
async = require('async'),
moment = require('moment'),
PlatformError = require('../../common/platform-error'),
config = require('./../../common/Config'),
provisionHelper = require('../helpers/provision'),
dao = require('../dao/provision-experience-dao'),
companyDao= require('../../company/dao/CompanyDAO'),
manifestDao= require('../../manifest/dao/ManifestDAO'),
deProvisionState = require('../dto/deprovision-state');
var provisionV2Controller = require('../../provisionV2/controller/ProvisionController');
var uniqueExpHelper = require('../helpers/unique-experiences');
var expDAO = require('../../experience/dao/ExperienceDAO');
var provisionDelegate = require('../delegate/client');
var deProvisionDelegate = require('../delegate/deProvisioningQueue');

function validateRequestParams(provisionRequest, cb) {

  logger.debug(`Validate provisioning request parameters : ${JSON.stringify(provisionRequest)}`);

  if (!provisionRequest.orgId) {
    cb(new PlatformError('PROV004', ['orgId'], 400));
  } else if (!provisionRequest.experienceId) {
    cb(new PlatformError('PROV004', ['experienceId'], 400));
  } else {
    cb(null, provisionRequest);
  }
}

function getOrganizationDetails(provisionRequest, cb) {

  logger.debug(`Get Organization Details For Organization Id : ${provisionRequest.orgId}`);

  companyDao.getCompanyByOrgId(provisionRequest.orgId,function(err,data){

    if(err){
      cb(new PlatformError('PROV013', [provisionRequest.orgId], 404, err));
      return;
    }

    var organization = {
      id: data.companyId,
      name: data.companyName,
      abbreviation : data.companyName
    };
    provisionRequest.organization = organization;
    logger.debug(`Found Company Record :  ${JSON.stringify(organization)}`);
    cb(null, provisionRequest);
  });
}


function getExperienceManifest(provisionRequest, cb) {

  logger.debug(`Get experience manifest details for experience id : ${provisionRequest.experienceId}`);

  manifestDao.getManifestByExpId(provisionRequest.experienceId, function(err, manifest) {

    if(err){
      cb(new PlatformError('PROV016', [provisionRequest.experienceId], 404, err));
      return;
    }

    provisionRequest.experience = manifest;
    cb(null, provisionRequest);
  });
}

function checkAllowedProvisioningLimit(provisionRequest, cb) {

  logger.debug(`Check if provisioning request within allowed provisioning limit of ${config.EXPERIENCE_PROVISION_LIMIT_PER_ORG}`);

  dao.getCountOfProvisionedExperiencesByOrgId(provisionRequest,
    function (err, provisionRequest, alreadyProvisionedExperiencesCount) {
      if (err) {
        cb(err);
        return;
      }
      logger.debug(`${alreadyProvisionedExperiencesCount} # of provisioned experiences for Organization : ${provisionRequest.orgId}`);

      if (alreadyProvisionedExperiencesCount && alreadyProvisionedExperiencesCount >= config.EXPERIENCE_PROVISION_LIMIT_PER_ORG) {
        cb(new PlatformError('PROV003', [alreadyProvisionedExperiencesCount], 400));
        return;
      }
      cb(null, provisionRequest);
    }
  );
}

function checkIfExperienceAlreadyProvisioned(provisionRequest, cb) {

  logger.debug(`Check if experience already provisioned or provisioning in progress for organization : ${provisionRequest.orgId} and experience : ${provisionRequest.experienceId}`);

  dao.getProvisionedExperienceByOrgIdAndExperienceId(provisionRequest,
    function (err, provisionRequest, alreadyProvisionedExperience) {
      if (err) {
        cb(err);
        return;
      }

      if (alreadyProvisionedExperience && alreadyProvisionedExperience.length) {
        cb(new PlatformError('PROV002', [provisionRequest.experienceId], 409));
        return;
      }
      cb(null, provisionRequest);
    }
  );
}

function validateProvisioningRequest(provisionRequest, cb) {
  //console.log('in validateProvisioningRequest');
  logger.debug(`Validate provisioning request input : ${JSON.stringify(provisionRequest) }`);

  async.waterfall([
    async.apply(validateRequestParams, provisionRequest),
    getOrganizationDetails,
    getExperienceManifest,
    checkAllowedProvisioningLimit,
    checkIfExperienceAlreadyProvisioned
  ], function (err, provisionRequest) {
    if (err) {
      cb(err);
      return;
    }
    cb(null, provisionRequest);
  });
}

function createRequestInPendingState(provisionRequest, cb) {
  //console.log('in createRequestInPendingState');
  logger.debug('Create experience provisioning request in pending state.');

  var momentDate = moment();
  momentDate.add(config.EXPERIENCE_EXPIRY_DAYS, 'days');
  provisionRequest.expiry = momentDate.toDate();
  dao.addProvisioningRequest(provisionRequest, cb);
}

function updateRequestDetails(provisionRequest, cb) {
	  //console.log('in updateRequestDetails');
	  logger.debug('Add apps & experience attributes to reqeuest');
	  var update = false;
	  var json = {};	  
	  if(provisionRequest.experience.attributes && provisionRequest.experience.attributes.length) {
		  json.expAttributes = provisionRequest.experience.attributes;
		  update = true;
	  }	  
	  if(provisionRequest.experience.applications && provisionRequest.experience.applications.length) {
		  var appsAttributes = [];
		  provisionRequest.experience.applications.forEach(function(app){
				if(app.attributes && app.attributes.length) {					
					appsAttributes.push({
						appId: app.id,
						attributes: app.attributes
					});					
					update = true;
				}
		  });
		  json.appsAttributes = appsAttributes;
		  appsAttributes = null;
	  }
	  if(update) {
		  dao.updateFields(provisionRequest, json, cb);
	  } else {
		  cb(null, provisionRequest);
	  }	  
}

function initiateProvisioning(provisionRequest, cb) {
  //console.log('in initiateProvisioning');
  logger.debug(`Request # ${provisionRequest.id} : Initiate provisioning.`);

  var directDeploy = "true";

  for(var i=0; i< provisionRequest.experience.applications.length; i++) {
    if(provisionRequest.experience.applications[i].deployOptionFlag == "OTHER") {
      directDeploy = "false";
      break;
    }
  }
  if (directDeploy == "true") {

    provisionRequest.organization.abbreviation = '';

    provisionHelper.directProvisioning(provisionRequest, cb);
  } else {

    /*  start provisioning in background in same process. need to assert impact
    and accordingly decide approach to spawn separate process
    */
    provisionHelper.startProvisioning(provisionRequest);
    cb(null, provisionRequest);
  }
}

function initiateDirectProvisioning(provisionRequest, cb) {
  provisionHelper.startDirectProvisioning(provisionRequest);
  cb(null, provisionRequest);
}

function initiateDirectWebProvisioning(provisionRequest, cb) {
  provisionHelper.startDirectWebProvisioning(provisionRequest);
  cb(null, provisionRequest);
}


var provision = function (provisionRequest, cb) {
   logger.info(`provision : received request : body : ${JSON.stringify(provisionRequest)}`);
   provisionDelegate.addProvisionReqToQueue(provisionRequest, cb);
}

function getProvisioningRequestById(id, cb) {
  logger.info(`Request # ${id} : Get provisioning request details from datastore.`);
  dao.getProvisioningRequestById(id,
    function (err, provisionRequest) {
      if (err) {
        cb(err);
        return;
      }

      if (!provisionRequest || !provisionRequest._id) {
        cb(new PlatformError('PROV005', [id], 404));
        return;
      }
      provisionRequest.id = provisionRequest._id;
      cb(null, provisionRequest);
    }
  );
}

function validateDeprovisioningRequest(id, cb) {
  logger.debug(`Request # ${id} : Validate deprovisioning request.`);

  async.waterfall([
    async.apply(getProvisioningRequestById, id),
    checkIfDeprovisioningAlreadyStarted,
    getOrganizationDetails,
    getExperienceManifest
  ], function (err, provisionRequest) {
    if (err) {
      cb(err);
      return;
    }
    cb(null, provisionRequest);
  });
}

function checkIfDeprovisioningAlreadyStarted(provisionRequest, cb) {
  logger.debug(`Request # ${provisionRequest.id} : Check if experience deprovisioning in progress.`);

  if(provisionRequest.deprovisionState && provisionRequest.deprovisionState != "DEPROVISIONED") {
    cb(new PlatformError('PROV010', [provisionRequest.experienceId], 409));
    return;
  }
  cb(null, provisionRequest);
}

function initiateDeprovisioning(provisionRequest, cb) {
  logger.debug(`Request # ${provisionRequest.id} : Initiate experience deprovisioning for organization id : ${provisionRequest.orgId}.`);
  provisionHelper.startDeprovisioning(provisionRequest, cb);
  //cb(null, provisionRequest);
}

function deleteProvisioningRequest(provisionRequest, cb) {
  logger.debug(`Request # ${provisionRequest.id} : Delete provisioning request details from datastore.`);
  dao.deleteProvisioningRequest(provisionRequest.id, cb);
}

function renewProvisioningRequest(provisionRequest, cb) {
  logger.debug(`Request # ${provisionRequest.id} : Renew provisioning request details from datastore.`);
  dao.renewProvisioningRequest(provisionRequest.id, cb);

}

function updateRequestToDeprovisioningState(provisionRequest, cb) {
  logger.debug(`Request # ${provisionRequest.id} : Set deprovision state to START.`);

  provisionRequest.deprovisionState = deProvisionState.START.key;
  provisionRequest.status = 'DE-PROVISIONING';

  dao.updateRequestState(provisionRequest, cb);
}

var deprovision = function (id, cb) {
	logger.info(`de-provision : received request : body :${id}`);
	deProvisionDelegate.addDeProvisionReqToQueue(id, cb);
}

var renew = function (id, cb) {
  renewProvisioningRequest(getProvisioningRequestById, function (err, provisionRequest) {
    if (err) {
      cb(err);
      return;
    }

    logger.info(`Request # ${id} : Experience successfully renewed.`);
    cb();
  });
}

var getAllExp = function getAllExperiences(id,cb){

  dao.getAllExperiences(id, function (err, provisionRequest) {
    if (err) {
      cb(err);
      return;
    }

    logger.info(`Provisioned Experiences successfully retrieved.`);

    cb(null, provisionRequest);
  });
}

var getExperiencesProvisioned = function getExperiencesProvisioned(cb) {

  logger.info('provision : controller : received request : getExperiencesProvisioned : Get the list of all experiences that are provisioned');

  async.waterfall([
    dao.getAllExperiencesProvisioned,
    uniqueExpHelper.getUniqueExperiences,
    expDAO.getExperiencesByExperienceIdsInQuery
  ], function(err, data){
    if(err) {
      return cb(err);
    }
    cb(null, data);
  });
}

var getAllProvisionedExperiences = function getAllProvisionedExperiences(req, cb) {
  logger.info('provision : controller : received request : getAllProvisionedExperiences : Get all the provisioned '+
		  'experiences : (query:'+JSON.stringify(req.query)+')');
  dao.getAllExperiencesProvisionedByStatus(req, cb);
}

module.exports = {
  provision: provision,
  deprovision: deprovision,
  renew: renew,
  getAllExp: getAllExp,
  getById : getProvisioningRequestById,
  getExperiencesProvisioned: getExperiencesProvisioned,
  getAllProvisionedExperiences: getAllProvisionedExperiences,
  validateProvisioningRequest: validateProvisioningRequest,
  createRequestInPendingState: createRequestInPendingState,
  initiateProvisioning: initiateProvisioning,
  validateDeprovisioningRequest: validateDeprovisioningRequest,
  updateRequestToDeprovisioningState: updateRequestToDeprovisioningState,
  initiateDeprovisioning: initiateDeprovisioning,
  deleteProvisioningRequest: deleteProvisioningRequest,
  updateRequestDetails: updateRequestDetails
};
