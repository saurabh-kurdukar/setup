'use strict';

var mongoose = require('../../common/MongoDbConnection').mongoose,
Schema = mongoose.Schema;

var VMSchema = new Schema({
  dateCreated: { type: Date, default: Date.now },
  fqdn: String,
  hostname:String,
  deleted: { type: Boolean, default: false },
  osType: String,
  osVersion: String,
  password : String,
  type: String,
  diskSize: String,
  status: { type: String, default: 'PENDING' },
  dateUpdated: { type: Date, default: Date.now },
  username:String,
  tcpPorts : String ,
  usageData: Object
});

var VMDetails = mongoose.model('vm_details', VMSchema);
module.exports.VMDetails= VMDetails;
