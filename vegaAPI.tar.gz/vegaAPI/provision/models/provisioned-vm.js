'use strict';

var mongoose = require('../../common/MongoDbConnection').mongoose,
Schema = mongoose.Schema;

var provisionedVMSchema = new Schema({
  provisionId : { type: Schema.Types.ObjectId, ref: 'provisioned.experiences'},
  orgId: { type: Number, required: true },
  experienceId: { type: Number, required: true },
  vmId: { type: Schema.Types.ObjectId, ref: 'vm_details'},
  created: { type: Date, default: Date.now },
  updated: { type: Date, default: Date.now },
  deleted: { type: Boolean, default: false }
});

var ProvisionedVM = mongoose.model('provisioned.vms', provisionedVMSchema);
module.exports.ProvisionedVM = ProvisionedVM;
