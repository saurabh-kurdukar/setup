var mongoose = require('../../common/MongoDbConnection').mongoose,
Schema = mongoose.Schema,
connection = mongoose.connection;

var sandboxItemSchema = mongoose.Schema({
	sandboxId : { type: Schema.Types.ObjectId, ref: 'sandboxes'},
	experienceId: Number,
	host: String,
	port: Number,
	username: String,
	created: { type: Date, default: Date.now },
	updated: { type: Date, default: Date.now },
	state: { type: String, default: 'PROVISIONING'},
	deleted: { type: Boolean, default: false }
});

var sandboxSchema = mongoose.Schema({
	userId: String,
	state: { type: String, default: 'PROVISIONING' },
	created: { type: Date, default: Date.now },
	updated: { type: Date, default: Date.now },
	deleted: { type: Boolean, default: false }
});

var SandboxItem = mongoose.model('sandbox.items', sandboxItemSchema);
var Sandbox = mongoose.model('sandboxes', sandboxSchema);

module.exports.Sandbox = Sandbox;
module.exports.SandboxItem = SandboxItem;
