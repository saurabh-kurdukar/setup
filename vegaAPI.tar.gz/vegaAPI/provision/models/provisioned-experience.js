'use strict';

var mongoose = require('../../common/MongoDbConnection').mongoose;

var provisionedExperienceSchema = new mongoose.Schema({
	orgId: { type: Number, required: true },
	experienceId: { type: Number, required: true },
	createdBy : { type: String, required: true },		// username who provisioned experience
	created: { type: Date, default: Date.now },
	updated: { type: Date, default: Date.now },
	deleted: { type: Boolean, default: false },
	expiry : { type: Date },
	ownerId : String, // should be changed to objectid after integration
	state: { type: String, default: 'START' },
	status : { type: String, default: 'IN-PROGRESS' },
	deprovisionState: String,
	errorCode : String,
	hasInternalAppStoreApps: { type: Boolean, default: false },
	appLinks: [],
	expAttributes: [],
	appsAttributes: []
});

var ProvisionedExperience = mongoose.model('provisioned.experiences', provisionedExperienceSchema);
module.exports.ProvisionedExperience = ProvisionedExperience;
