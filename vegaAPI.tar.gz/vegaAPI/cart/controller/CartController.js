var cartDao = require('../dao/CartDAO');
var logger = require('../../common/logger').log;

var AddCartItemByOrgId = function(req, res, callback) {
	logger.info('cart : controller : received request : getCartById : id : '+req.params.id);
	cartDao.AddCartItemByOrgId(req, res, callback);
};


var getCartItemsByOrgId = function(req, res, callback) {
	logger.info('cart : controller : received request : getCartById : id : '+req.params.userName);
	cartDao.getCartItemsByOrgId(req, res, callback);
};


var deleteCartItemsByCartItemId = function(req, res, callback) {
	logger.info('cart : controller : received request : getCartById : id : '+req.params.id);
	cartDao.deleteCartItemsByCartItemId(req, res, callback);
};


module.exports.deleteCartItemsByCartItemId=deleteCartItemsByCartItemId;
module.exports.getCartItemsByOrgId = getCartItemsByOrgId;
module.exports.AddCartItemByOrgId = AddCartItemByOrgId;
