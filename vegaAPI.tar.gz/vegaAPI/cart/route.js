var express = require('express');
var CartController = require('./controller/CartController');
var logger = require('../common/logger').log;
var ErrorResponse = require('../common/ErrorResponse').ErrorResponse;
var router = express.Router();



/*
 * Add new cart Item
 */
router.post('/', function(req, res) {
	logger.info('cart : router : received request : addNewCart : body : '+JSON.stringify(req.body));	
	CartController.AddCartItemByOrgId(req, res, function(err, data) {
        if(err) {
        	logger.error('cart : router : failed addNewCart : error : '+err);     
        	var error = new ErrorResponse();
        	if(err.name == 'ValidationError'){
        		error.setErrorMessage(err.errors[Object.keys(err.errors)[0]].message);
        	} else {
        		error.setErrorMessage(err.message);
        	}
        	error.setErrorCode("A0002");        	
        	error.setHttpResponseCode(500);        	
        	res.status(500).end(JSON.stringify(error));        
        } else {        	
        	logger.info("cart : router : addNewCart successful !");
        	res.status(200).end(JSON.stringify(data));
        }
    });
});

/*
 * Get Cart Item by  Username
 */
router.get('/:orgId', function (req, res) {
	logger.info('cart : router : received request : getCartById : id : '+req.params.orgId);
	CartController.getCartItemsByOrgId(req, res, function(err, data) {
        if(err){
        	logger.error('cart : router : failed getCartItemsByUserName : error : '+err);  
        	var error = new ErrorResponse();
        	error.setErrorCode("A0002");
        	error.setErrorMessage(err.message);
        	error.setHttpResponseCode(500);
            res.status(500).end(JSON.stringify(error));
        }else{        	
        	logger.info("cart : router : getCartItemsByUserName successful !") ;
        	res.status(200).end(JSON.stringify(data));
        }
    });
});





router.delete('/:cartItemId', function(req, res) {
	logger.info('cart : router : received request : addNewCart : body : '+JSON.stringify(req.body));	
	CartController.deleteCartItemsByCartItemId(req, res, function(err, data) {
        if(err) {
        	logger.error('cart : router : failed addNewCart : error : '+err);     
        	var error = new ErrorResponse();
        	if(err.name == 'ValidationError'){
        		error.setErrorMessage(err.errors[Object.keys(err.errors)[0]].message);
        	} else {
        		error.setErrorMessage(err.message);
        	}
        	error.setErrorCode("A0002");        	
        	error.setHttpResponseCode(500);        	
        	res.status(500).end(JSON.stringify(error));        
        } else {        	
        	logger.info("cart : router : addNewCart successful !");
        	res.status(200).end(JSON.stringify(data));
        }
    });
});



router.all('/v1/*', function (req, res) {	

	logger.info('company : router : received request : with URL : ' + req.originalUrl);
	logger.error('company : router : No matching resource for URL : ' + req.originalUrl);
	var error = new ErrorResponse();
	error.setErrorCode("A0002");
	error.setErrorMessage('No matching resource for URL: ' + req.originalUrl);
	error.setHttpResponseCode(404);
	res.status(404).send(JSON.stringify(error));
});


module.exports = router;
