var mongoose = require('../../common/MongoDbConnection').mongoose;
var autoIncrement = require('mongoose-auto-increment');
var logger = require('../../common/logger').log;
var connection = mongoose.connection;
autoIncrement.initialize(connection);

/*
 * Define schema
 */
var cartSchema = mongoose.Schema({
	cartItemId : Number,
	orgId: Number ,
	expId: String
	
});

cartSchema.plugin(autoIncrement.plugin, { model: 'Cart', field: 'cartItemId', startAt: 1 });

cartSchema.methods.setOrgId = function(orgId) {	
	this.orgId = orgId;
};

cartSchema.methods.setExpId = function(expId) {	
	this.expId = expId;
};

cartSchema.methods.getOrgId = function() {
	return this.orgId;
};

cartSchema.methods.getExpId = function() {	
	return this.expId ;
};




/*
 * Create collection/model in mongo db using Schema
 */
var Cart = mongoose.model('Carts', cartSchema);
logger.info('cart : model : created model : carts : ' + Cart);



module.exports = Cart;
