var Cart = require('../models/Cart');
var incExperienceHitsCounter = require('../../experience/dao/ExperienceDAO').incrementHitsCounter;
var logger = require('../../common/logger').log;


var AddCartItemByOrgId= function(req, res, callback) {
	logger.info('cart : DAO : received request : addNewCart : body : '
			+ JSON.stringify(req.body));
	console.log(JSON.stringify(req.body))
//for(var i=0;i<req.body.experiences.length;i++){
	
	
	
	//console.log(req.body.userName);
	var cart = new Cart();	
	cart.setOrgId(req.body.orgId);
	cart.setExpId(req.body.expId);
	

	//console.log(req.body.userName+"::"+reqBody.id);
	Cart.findOne({
		'orgId' : req.body.orgId,
		'expId' : req.body.expId
	}, function(err, data) {
		if (err) {
			logger.error('cart : DAO : failed getCartById : error : ' + err);
			callback(err, null);
		} else {
			
			if (!data) {
				
				cart.save(function(error, dataOnSave) {
					if (error) {
						logger.error('cart : DAO : failed addNewCart: error : ' + err);
						callback(err, null);
					} else if(dataOnSave != null){
						logger.info('cart : DAO : addNewCart successful !');
						console.log(dataOnSave);
						callback(null, dataOnSave);
						incExperienceHitsCounter(req.body.expId);
					} else {
					var errorThrow = new Error('Failed to add new cart details');			
					logger.error('cart : DAO : failed addNewCart : error : '+ errorThrow);
					callback(errorThrow, null);
					}
				});
				//callback(err, null);
			}else {				
				var errorThrow2 = new Error('Experience already Exist in your Cart.');			
				logger.error('cart : DAO : failed addNewCart : error : '+ errorThrow2);
				callback(errorThrow2, null);
			} 
		}
	});
	

};



var getCartItemsByOrgId = function(req, res, callback) {

	logger.info('cart : DAO : received request : getCartById : id : '+req.params.id);
	//console.log(req.params.userName);
	Cart.find({
		'orgId' : req.params.orgId
	}, function(err, data) {
		if (err) {
			logger.error('cart : DAO : failed get : error : ' + err);
			callback(err, null);
		} else {
		
			if (data.length != 0) {				
				logger.info('company : DAO : getCartUsername successful !');
				callback(null, data);
			} else {
				var err = new Error('Invalid UserName');
				err.status = 404;
				logger.error('cart : DAO : failed getCartById : error : '+ err);
				callback(null,[]);
			}
		}
	});
};






var deleteCartItemsByCartItemId = function(req, res, callback) {
	
	Cart.remove({
		
		'cartItemId' : req.params.cartItemId
		
  		
	}, function(err, data) {
		if (err) {
			logger.error('cart : DAO : failed getCartById : error : ' + err);
			callback(err, null);
		} else {
			if (data.length != 0) {				
				logger.info('company : DAO : getCartById successful !');
				callback(null, data);
			} else {
				var err = new Error('Invalid cart id');
				err.status = 404;
				logger.error('company : DAO : failed getCartById : error : '+ err);
				callback(err, null);
			}
		}
	});
};


var AddMultipleCartItemByOrgId = function(itemsArray, callback) {
	logger.info('cart : DAO : received request : AddMultipleCartItemByOrgId : items : '+itemsArray);
	Cart.create(itemsArray, function(err, data) {
		if (err) {
			console.log('add multiple err: '+JSON.stringify(err));
			logger.error('cart : DAO : failed AddMultipleCartItemByOrgId : error : ' + err);
			callback(err);
		} else {
			if (data) {	
				console.log('add multiple res: '+JSON.stringify(data));
				logger.info('cart : DAO : AddMultipleCartItemByOrgId successful !');
				callback(null, data);
			} else {
				var err = new Error('Failed to add to cart');
				err.status = 404;
				logger.error('cart : DAO : failed AddMultipleCartItemByOrgId : error : '+ err);
				callback(err);
			}
		}
	});
}



module.exports.deleteCartItemsByCartItemId = deleteCartItemsByCartItemId
module.exports.AddCartItemByOrgId = AddCartItemByOrgId;
module.exports.getCartItemsByOrgId = getCartItemsByOrgId;
module.exports.AddMultipleCartItemByOrgId = AddMultipleCartItemByOrgId;











