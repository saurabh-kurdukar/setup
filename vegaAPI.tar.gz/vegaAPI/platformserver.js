var http = require('http');
var app = require('express')();
var bodyparser = require('body-parser');
var sequelize = require('sequelize');
var cors = require('cors');
var crypto = require('crypto');
var mongoose = require('mongoose');
//var methodOverride = require('method-override');
var RequestFilter = require('./filters/RequestFilter');
var appConfig = require('./common/Config');
var os = require('os');
var express = require('express');
var provisionListener = require('./provision/delegate/listener');
var deProvisionListener = require('./provision/delegate/deProvisioningListener');
var ResendMailListener= require('./registration/listeners/ResendMailListener')
var otpListener = require('./otpRecords/listeners/OTPListener');

app.use(bodyparser.json());
app.use(bodyparser.urlencoded({
	extended : true
}));


/*---------------Routes-----------------*/
var radiaApp = require('./radia-app/route');
var discover = require('./discover/route');
var manifest = require('./manifest/route');
var media = require('./media/route');
var companies = require('./company/route');
var surveys = require('./survey/route');
var surveyQuestions = require('./survey/surveyQuestionRoute');
var surveyAssociations = require('./survey/surveyAssociationRoute');
var surveyResponses = require('./survey/surveyResponseRoute ');
var apimanagers = require('./apiMgrConfig/route');
var smsgateways = require('./smsGateway/route');
var experiences = require('./experience/route');
var services = require('./service/route');
var experiencesenrolled = require('./experiencesenrolled/route');
var audits = require('./audits/route');
if(!appConfig.audit_post_db_direct){
	console.log("Loading Audit Lister");
	var AuditsMessagingListner = require('./audits/listeners/AuditsMessagingListner');
}
var auditEvent = require('./auditEvent/route');
var smtpservers = require('./smtpServer/route');
var messages= require('./sendMessage/route');
var templates = require('./template/route');
var locations= require('./location/route');
var apps = require('./application/route');
var SMSListener= require('./sendMessage/listeners/SMSListener');
var EmailListener= require('./sendMessage/listeners/SMTPEmailListener');
var users= require('./userManagement/route');
var provision = require('./provision/route');
var cloudProviders=require('./cloudProvider/route');
var domains= require('./domain/route');
var platformusers= require('./platformUser/route');
var cart= require('./cart/route');
var auth= require('./auth/route');
var component = require('./component/route');
var forgotPassword= require('./forgotPassword/route');
var Listener= require('./userManagement/dao/SMTPEmailListener');
var platformUserListener= require('./platformUser/listeners/EmailListener')
var roles= require('./roles/route');
var userRoles= require('./userRoles/route');
var provisionV2= require('./provisionV2/route');
var documents = require('./documents/route');
var vmDetails = require('./vmDetails/route');
var trace= require('./trace/route');
var otpRecords= require('./otpRecords/route');
var otpRegistration = require('./otpRegistration/route');
var resAccGrp = require('./resAccGrp/route');
var registration= require('./registration/route');
var userAttributes= require('./userAttributes/route');
var attributes= require('./attributes/route');
var script= require('./script/route');
var sampleMsg= require('./sampleMsg/route');
var algorithm= require('./algorithm/route');
var dataPipeline = require('./data-pipeline/route');
var visualization= require('./visualization/route');
var myVisualization= require('./myVisualization/route');
var openempi= require('./openempi/route');
var widget= require('./widget/route');

function logErrors(err, req, res, next) {
	console.error(err.stack);
	next(err);
}

function clientErrorHandler(err, req, res, next) {
	if (req.xhr) {
		res.status(500).send({
			error : "Error while processing request."
		});
	} else {
		next(err);
	}

}

function errorHandler(err, req, res, next) {
	if (res.headersSent) {
		return next(err);
	} else {
		res.status(500).send({
			error : "Error while processing request."
		});
	}
}

app.use('/docs', express.static(__dirname + '/swagger-ui-master/dist'));

app.use(cors());

app.use("*", function(req, res, next){
	RequestFilter.filter(req, res, next);
});

app.use('/v1.0/radiaapp', radiaApp);
app.use('/v1.0/discover', discover);
app.use('/v1.0/manifests', manifest);
app.use('/v1.0/media', media);
app.use('/v1.0/companies', companies);

app.use('/v1.0/surveys', surveys);
app.use('/v1.0/surveyquestions', surveyQuestions);
app.use('/v1.0/surveyassociations', surveyAssociations);
app.use('/v1.0/surveyresponses', surveyResponses);


app.use('/v1.0/apimanagers', apimanagers);
app.use('/v1.0/experiences', experiences);
app.use('/v1.0/services', services);
app.use('/v1.0/experiencesenrolled', experiencesenrolled);
app.use('/v1.0/audits', audits);
app.use('/v1.0/auditEvent', auditEvent);
app.use('/v1.0/smsgateways', smsgateways);
app.use('/v1.0/smtpservers', smtpservers);
app.use('/v1.0/messages',messages);
app.use('/v1.0/templates', templates);
app.use('/v1.0/locations',locations);
app.use('/v1.0/apps', apps);
app.use('/v1.0/users', users);
app.use('/v1.0/provision', provision);
app.use('/v1.0/cloudProviders', cloudProviders);
app.use('/v1.0/domains',domains);
app.use('/v1.0/platformusers',platformusers);
app.use('/v1.0/cart',cart);
app.use('/v1.0/captcha',auth);
app.use('/v1.0/component',component);
app.use('/v1.0/forgotPassword',forgotPassword);
app.use('/v1.0/roles',roles);
app.use('/v1.0/userRoles',userRoles);
app.use('/v2.0/provision', provisionV2);
app.use('/v1.0/documents', documents);
app.use('/v1.0/vmDetails',vmDetails);
app.use('/v1.0/trace',trace);
app.use('/v1.0/otp', otpRecords);
app.use('/v1.0/otpRegistration', otpRegistration);
app.use('/v1.0/resAccGrp', resAccGrp);
app.use('/v1.0/activation',registration);
app.use('/v1.0/userAttributes',userAttributes);
app.use('/v1.0/attributes',attributes);
app.use('/v1.0/script',script);
app.use('/v1.0/sampleMsg',sampleMsg);
app.use('/v1.0/algorithm',algorithm);
app.use('/v1.0/pipeline', dataPipeline);
app.use('/v1.0/visualization',visualization);
app.use('/v1.0/myVisualization',myVisualization);
app.use('/v1.0/openempi',openempi);
app.use('/v1.0/widget',widget);

app.use(logErrors);
app.use(clientErrorHandler);
app.use(errorHandler);

var server = app.listen(appConfig.SERVER.PORT, '0.0.0.0');

server.timeout = appConfig.REQUEST_TIMEOUT;
console.log(`Server listening at ${appConfig.SERVER.PROTOCOL}${os.hostname()}:${appConfig.SERVER.PORT}`);
