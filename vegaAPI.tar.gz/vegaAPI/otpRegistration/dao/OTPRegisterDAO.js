var OTPRegister = require('../models/OTPRegister');
var logger = require('../../common/logger').log;
var audit = require('../../common/Audit').audit;
const MODULE_NAME = 'otp';

/*
 * logging format followed: logger.info(<module_name>: <component name> : <description> : [<long_description>] : <data/params/errors>);
 */


/*
 * Add new otp details
 */
var addNewOtpDetail = function(req, callback) {
	logger.info(MODULE_NAME + ' : DAO : addNewOtpDetail : '
			+'(body:'+JSON.stringify(req.body)+', username:'+req.header('username')+')');
	var reqBody = req.body;
	var otp_register = new OTPRegister(reqBody);
	otp_register.status = 'ACTIVE';
	otp_register.createdBy = req.headers.username;
	otp_register.updatedBy = req.headers.username;

	otp_register.save(function(err, data) {
		if (err) {
			err.status = 500;
			logger.error(MODULE_NAME + ' : DAO : failed addNewOtpDetail : error : ' + err);
			callback(err);
		} else if(data){
			logger.info(MODULE_NAME + ' : DAO : addNewOtpDetail successful !');
			callback(err, data);
		} else {
			var err = new Error('Failed to add new otp details');
			err.status = 500;
			logger.error(MODULE_NAME + ' : DAO : failed addNewOtpDetail : error : '+ err);
			callback(err);
		}
	});
};

/*
 * Get otp details by id
*/
var getOtpDetailsById = function(id, callback) {
	logger.info(MODULE_NAME + ' : DAO : received request : getOtpDetailsById : id : ' + id);
	OTPRegister.findOne({
		'id' : id,
		'status': { $ne: 'DELETED' }
	}, function(err, data) {
		if (err) {
			err.status = 500;
			logger.error(MODULE_NAME + ' : DAO : failed getOtpDetailsById : error : ' + JSON.stringify(err));
			callback(err);
		} else {
			if (data) {				
				logger.info(MODULE_NAME + ' : DAO : getOtpDetailsById successful !');
                callback(null, data);
			} else {
				var err = new Error('otp register id not exist');
				err.status = 404;
				logger.error(MODULE_NAME + ' : DAO : failed getOtpDetailsById : error : '+ err);
				callback(err);
			}
		}
	});
};





module.exports.addNewOtpDetail = addNewOtpDetail;
module.exports.getOtpDetailsById = getOtpDetailsById;











