var mongoose = require('../../common/MongoDbConnection').mongoose;
var autoIncrement = require('mongoose-auto-increment');
var logger = require('../../common/logger').log;
const MODULE_NAME = 'otp_register';
var connection = mongoose.connection;
autoIncrement.initialize(connection);

/*
 * logging format followed: logger.info(<module_name>: <component name> :
 * <description> : <long_description> : <data/params/errors>);
 */


/*
 * Define schema
 */
var otpRegisterSchema = mongoose.Schema({
    id: Number,
    name: {type: String, unique: true, required: 'field name is required'},
	appId: { type: Number, required: 'field appId is required' },
	experienceId: { type: Number },
	templateId: {type: Number},
	templateVersion: {type: String},
	featureRef: {type: String},					// optional info
	summary: {type: String},
	description: {type: String},	
	expiresIn: {type: Number, default: 15},		// in minutes
	onSuccessURL: {type: String},
	onFailureURL: {type: String},
	status: {type: String, default: 'ACTIVE'},
	createdOn: { type: Date, default: Date.now },
	createdBy: {type: String},
	updatedOn: { type: Date, default: Date.now },
	updatedBy: {type: String}
});


logger.info(MODULE_NAME + ' : model : created schema : otp_register :'+JSON.stringify(otpRegisterSchema.paths));


otpRegisterSchema.pre('findOneAndUpdate', function(next) {
	  this.options.runValidators = true;
	  next();
});

otpRegisterSchema.pre('update', function(next) {
	  this.options.runValidators = true;
	  next();
});



/*
 * Add Auto increment for field id
 */
otpRegisterSchema.plugin(autoIncrement.plugin, { model: 'otp_register', field: 'id', startAt: 1 });
	

/*
 * Create collection/model in mongo db using Schema
 */
var OtpRegister = mongoose.model('otp_register', otpRegisterSchema);
logger.info(MODULE_NAME + ' : model : created model : otp_register : ' + OtpRegister);



module.exports = OtpRegister;