var express = require('express');
var otpRegisterController = require('./controller/OTPRegisterController');
var logger = require('../common/logger').log;
var ErrorResponse = require('../common/ErrorResponse').ErrorResponse;
var router = express.Router();
const MODULE_NAME = 'otp';

/*
* logging format followed: logger.info(<module_name>: <component name> : <description> : [<long_description>] : <data/params/errors>);
*/

/*
* Add new otp details
*/
router.post('/', function(req, res) {
	logger.info(MODULE_NAME + ' : router : received request : addNewOtpDetail : '
			+'(body:'+JSON.stringify(req.body)+', username:'+req.header('username')+')');
	if(req.body.name && req.body.appId && req.body.templateBody && req.body.sampleJson && req.headers.username) {
		otpRegisterController.addNewOtpDetail(req, function(err, data) {
			if(err) {			
				logger.error(MODULE_NAME + ' : router : failed addNewOtpDetail : error : '+err);
				var error = new ErrorResponse();
				if(err.name == 'ValidationError'){
					error.setErrorMessage(err.errors[Object.keys(err.errors)[0]].message);
				} else {
					error.setErrorMessage(err.message);
				}
				error.setErrorCode("OTPR0001");
				error.setHttpResponseCode(err.status);
				res.status(err.status).end(JSON.stringify(error));			
			} else {
				logger.info(MODULE_NAME + " : router : addNewOtpDetail successful !");
				res.status(200).end(JSON.stringify(data));
			}
		});
	} else {
		var error = new ErrorResponse('OTPR0001', 'fields name, appId, templateBody, sampleJson and header username is required', 200);	
		logger.error(MODULE_NAME + ' : router : failed addNewOtpDetail : error : '+JSON.stringify(error));
		res.status(200).end(JSON.stringify(error));
	}
});







module.exports = router;
