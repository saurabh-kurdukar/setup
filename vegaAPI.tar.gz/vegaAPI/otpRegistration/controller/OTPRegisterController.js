var otpRegisterDao = require('../dao/OTPRegisterDAO');
var appDao = require('../../application/dao/AppDAO');
var templateDao = require('../../template/dao/TemplateDAO');
var logger = require('../../common/logger').log;
var config = require('../../common/Config');
const MODULE_NAME = 'otp';


/*
* logging format followed: logger.info(<module_name>: <component name> : <description> : [<long_description>] : <data/params/errors>);
*/


/*
* Add new otp details
*/
var addNewOtpDetail = function(req, callback) {
	logger.info(MODULE_NAME + ' : controller : received request : addNewOtpDetail : '
			+'(body:'+JSON.stringify(req.body)+', username:'+req.header('username')+')');
	req.params.id = req.body.appId;
	appDao.getAppById(req, null, function(err, app){
		if(err) {
			err.status=500;
			return callback(err);
		}		
		req.headers.companyid = config.PLATFORMUSER_COMPANYID;
		req.body.templateName = req.body.name;
		req.body.templateDescription = req.body.description;
		req.body.version = config.PLATFORMUSER_TEMPLATE_VERSION;
		req.body.adminFullName = req.header('username');	
		templateDao.addNewTemplate(req, null, function(err, template) {
			if(err) {
				err.status=500;
				return callback(err);
			}
			req.body.experienceId = app.experienceId;
			req.body.templateId = template.templateId;
			req.body.templateVersion = config.PLATFORMUSER_TEMPLATE_VERSION;
			otpRegisterDao.addNewOtpDetail(req, callback);
		});		
	});
};



module.exports.addNewOtpDetail = addNewOtpDetail;









