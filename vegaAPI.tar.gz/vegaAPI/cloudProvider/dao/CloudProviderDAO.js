var CloudProvider = require('../models/CloudProvider');
var logger = require('../../common/logger').log;
var audit = require('../../common/Audit').audit;

/*
 * logging format followed: logger.info(<module_name>: <component name> : <description> : [<long_description>] : <data/params/errors>);
 */


/*
 * Add new Cloud Provider
 */

var addNewCloudProvider = function(req, res, callback) {
	logger.info('cloudProvider : DAO : received request : addNewCloudProvider : body : '
			+ JSON.stringify(req.body));
	var reqBody = req.body;
	var cloudProvider = new CloudProvider();	
	cloudProvider.setname(reqBody.name);
	cloudProvider.setdescription(reqBody.description);

	cloudProvider.save(function(err, data) {
		if (err) {
			logger.error('cloudProvider : DAO : failed addNewCloudProvider : error : ' + err);
			callback(err, null);
		} else if(data != null){
			logger.info('cloudProvider : DAO : addNewCloudProvider successful !');
			callback(null, data);
		} else {
			var err = new Error('Failed to addNewCloudProvider details');			
			logger.error('cloudProvider : DAO : failed addNewCloudProvider : error : '+ err);
			callback(err, null);
		}
	});
};

/*
 * Get all companies
 */
var getAllCloudProviders = function(req, res, callback) {
	logger.info('cloudProvider : DAO : received request : getAllCloudProviders :');		
	//var cloudProvider = new CloudProvider();	
	CloudProvider.find(function(err, data) {
		if (err) {
			logger.error('cloudProvider : DAO : failed getAllCloudProviders : error : ' + err);
			callback(err, null);
		} else {
			if (data.length != 0) {
				logger.info('cloudProvider : DAO : getAllCloudProviders successful !');
				callback(null, data);
			} else {
				var err = new Error('No records found');
				err.status = 404;
				logger.error('cloudProvider : DAO : failed getAllCloudProviders : error : ' + err);
				callback(err, null);
			}
		}
	});
};


/*
 *  Get CloudProvider specified by the id parameter
 */
var getCloudProviderById = function(req, res, callback) {
	/*var companyId = req.swagger.params.id.value;
	console.log(companyId);*/
	logger.info('cloudProvider : DAO : received request : getCloudProviderById : id : '+req.params.id);
	CloudProvider.find({
		'id' : req.params.id
	}, function(err, data) {
		if (err) {
			logger.error('cloudProvider : DAO : failed getCloudProviderById : error : ' + err);
			callback(err, null);
		} else {
			if (data.length != 0) {				
				logger.info('cloudProvider : DAO : getCloudProviderById successful !');
				callback(null, data[0]);
			} else {
				var err = new Error('Invalid id');
				err.status = 404;
				logger.error('cloudProvider : DAO : failed getCloudProviderById : error : '+ err);
				callback(err, null);
			}
		}
	});
};


/*
 * Updates an Cloud Provider specified by the id parameter
 */
var updateCloudProviderById = function(req, res, callback) {
	logger.info('cloudProvider : DAO : received request : updateCloudProviderById : (id: '+req.params.id+', body: '+JSON.stringify(req.body)+')');
	
	/*
	 * Callback function after getting original record to update with new values.
	 */ 
	var callbackUpdate = function(err, data) {	
		if(err) {
			logger.error('cloudProvider : DAO : failed updateCloudProviderById : error :' + err);
			callback(err, null);
		} else if(data != null) {
			/*
			 *	Compare updatable fields values in db with request data
			 *	Add those fields in temproary object which are having new values
			 */			
			var cloudprovider = data;
			var json = {};
			var updatedData = [];
			if (req.body.name && cloudprovider['name'] != req.body.name) {
				json.name = req.body.name;
				var obj = {};				
				obj.column = 'name';
				obj.oldValue = cloudprovider['name'];
				obj.newValue = req.body.name;
				obj.identifier = 'Platform_cloudprovider_'+req.params.id;
				obj.modifiedBy = 'admin';
				obj.modifiedOn = new Date();
				updatedData.push(obj);
			}
			if (req.body.description && cloudprovider['description'] != req.body.description) {
				json.description = req.body.description;
				var obj = {};
				obj.column = 'description';
				obj.oldValue = cloudprovider['description'];
				obj.newValue = req.body.description;
				obj.identifier = 'Platform_cloudprovider_'+req.params.id;
				obj.modifiedBy = 'admin';
				obj.modifiedOn = new Date();
				updatedData.push(obj);
			}		
			
			
			/*
			 *	Update the data to database 
			 */
			if (Object.keys(json).length != 0) {
				
				
				logger.info('cloudProvider : DAO : updateCloudProviderById : updating data : ' + JSON.stringify(json));
				CloudProvider.findOneAndUpdate({
					'id' : req.params.id
				}, json, {
					'new' : true
				// returns updated entity if update successful, if false then old entry
				}, function(err, data) {
					if (err) {
						logger.error('cloudProvider : DAO : failed updateCloudProviderById : error :' + err);
						callback(err, null);
					} else {
						if(data != null) {
							logger.info('cloudProvider : DAO : updateCloudProviderById successful !');		
							/*
							 *	Call audit function for changed data 
							 */
							audit(req, res, updatedData);
							/*
							 *	Call function to send response to client 
							 */
							callback(null, data);
						} else {
							var err = new Error('Bad request data');
							logger.error('cloudProvider : DAO : failed updateCloudProviderById : error :' + err);
							callback(err, null);
						}
					}
				});
			} else {
				var err = new Error('Cannot update data');
				logger.error('cloudProvider : DAO : failed updateCloudProviderById : error :' + err);
				callback(err, null);
			}
		} else {
			var err = new Error('Failed to get cloudProvider details');
			logger.error('cloudProvider : DAO : failed updateCloudProviderById : error :' + err);
			callback(err, null);
		}
	}
	
	/*
	 * Get the original record from db before update.
	 */ 
	getCloudProviderById(req, res, callbackUpdate);
	

};

/*
 *  Deletes a Cloud Provider specified by the id parameter
 */
var deleteCloudProviderById = function(req, res, callback) {
	logger.info('cloudProvider : DAO : received request : deleteCloudProviderById : (id: '+req.params.id);
	var callbackDelete = function(err, data) {
		if (err) {
			logger.error('cloudProvider : DAO : failed deleteCloudProviderById : error :' + err);
			callback(err, data);
		} else {
			
			CloudProvider.remove({ 'id': req.params.id }, 
			function(err, data) {
				if (err) {
					callback(err, data);
				} else {
					callback(err, data);
				}
			});
		}
	};

	getCloudProviderById(req, res, callbackDelete);
};




module.exports.addNewCloudProvider = addNewCloudProvider;
module.exports.getAllCloudProviders = getAllCloudProviders;
module.exports.getCloudProviderById = getCloudProviderById;
module.exports.updateCloudProviderById = updateCloudProviderById;
module.exports.deleteCloudProviderById = deleteCloudProviderById;
