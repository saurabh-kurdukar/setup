var mongoose = require('../../common/MongoDbConnection').mongoose;
var autoIncrement = require('mongoose-auto-increment');
var logger = require('../../common/logger').log;
var connection = mongoose.connection;
autoIncrement.initialize(connection);
/*
 * logging format followed: logger.info(<module_name>: <component name> :
 * <description> : <long_description> : <data/params/errors>);
 */


/*
 * Define schema
 */

var cloudProviderSchema = mongoose.Schema({
	
    id: Number,
    name: {type: String},
    description: {type: String}
	
});


logger.info('cloudProvider : model : created schema : CloudProviders :'+JSON.stringify(cloudProviderSchema.paths));

cloudProviderSchema.path('name').validate(function (v) {
	  return v.length <= 50;
}, 'data too long for field name'); 

cloudProviderSchema.path('description').validate(function (v) {
	  return v.length <= 50;
}, 'data too long for field description');

/*
 * Add Auto increment plugin for field companyId
 */
cloudProviderSchema.plugin(autoIncrement.plugin, { model: 'CloudProviders', field: 'id', startAt: 1 });

/*
 * Setters
 */
cloudProviderSchema.methods.setid = function(id) {	
	this.id = id;
};

cloudProviderSchema.methods.setname = function(name) {
	this.name = name;
};

cloudProviderSchema.methods.setdescription = function(description) {
	this.description = description;
};

/*
 * Getters
 */
cloudProviderSchema.methods.getid = function() {
	return this.id;
};

cloudProviderSchema.methods.getname = function() {
	return this.name;
};

cloudProviderSchema.methods.getdescription = function() {
	return this.description;
};



/*
 * Create collection/model in mongo db using Schema
 */
var CloudProvider = mongoose.model('CloudProviders', cloudProviderSchema);
logger.info('cloudProvider : model : created model : CloudProviders : ' + CloudProvider);



module.exports = CloudProvider;

