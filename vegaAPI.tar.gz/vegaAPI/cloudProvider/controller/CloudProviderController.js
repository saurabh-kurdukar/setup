var cloudProviderDao = require('../dao/CloudProviderDAO');
var logger = require('../../common/logger').log;


/*
 * logging format followed: logger.info(<module_name>: <component name> : <description> : [<long_description>] : <data/params/errors>);
 */


/*
 
 * Add new Cloud Provider
 */

var addNewCloudProvider = function(req, res, callback) {
	logger.info('cloudProvider : controller : received request : addNewCloudProvider : body : '+JSON.stringify(req.body));
	cloudProviderDao.addNewCloudProvider(req, res, callback);
};

/*
 *  Get list of all cloud providers in the system
 */
var getAllCloudProviders = function(req, res, callback) {
	logger.info('cloudProvider : controller : received request : getAllCloudProviders ');
	cloudProviderDao.getAllCloudProviders(req, res, callback);
};



/*
 * Get CloudProvider specified by the id parameter
 */
var getCloudProviderById = function(req, res, callback) {
	logger.info('cloudProvider : controller : received request : getAllCloudProviders : id : '+req.params.id);
	cloudProviderDao.getCloudProviderById(req, res, callback);
};

/*
 * Updates an Cloud Provider specified by the id parameter
 */
var updateCloudProviderById = function(req, res, callback) {
	logger.info('cloudProvider : controller : received request : updateCloudProviderById : (id: '+req.params.id+', body: '+JSON.stringify(req.body)+')');
	cloudProviderDao.updateCloudProviderById(req, res, callback);
};


/*
 *  Deletes a Cloud Provider specified by the id parameter
 */
var deleteCloudProviderById = function(req, res, callback) {
	logger.info('cloudProvider : controller : received request : deleteCloudProviderById : id : '+req.params.id);
	cloudProviderDao.deleteCloudProviderById(req, res, callback);
};


module.exports.addNewCloudProvider = addNewCloudProvider;
module.exports.getAllCloudProviders = getAllCloudProviders;
module.exports.getCloudProviderById = getCloudProviderById;
module.exports.updateCloudProviderById = updateCloudProviderById;
module.exports.deleteCloudProviderById = deleteCloudProviderById;