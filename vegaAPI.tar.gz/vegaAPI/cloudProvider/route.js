var express = require('express');
var cloudProviderController = require('./controller/CloudProviderController');
var logger = require('../common/logger').log;
var ErrorResponse = require('../common/ErrorResponse').ErrorResponse;
var router = express.Router();

/*
 * logging format followed: logger.info(<module_name>: <component name> : <description> : [<long_description>] : <data/params/errors>);
 */

/*
 * Add new Cloud Provider
 */
router.post('/', function(req, res) {
	logger.info('cloudProvider : router : received request : addNewCloudProvider : body : '+JSON.stringify(req.body));	
	cloudProviderController.addNewCloudProvider(req, res, function(err, data) {
        if(err) {
        	logger.error('cloudProvider : router : failed addNewCloudProvider : error : '+err);     
        	var error = new ErrorResponse();
        	if(err.name == 'ValidationError'){
        		error.setErrorMessage(err.errors[Object.keys(err.errors)[0]].message);
        	} else {
        		error.setErrorMessage(err.message);
        	}
        	error.setErrorCode("CP001");        	
        	error.setHttpResponseCode(500);        	
        	res.status(500).end(JSON.stringify(error));        
        } else {        	
        	logger.info("cloudProvider : router : addNewCloudProvider successful !");
        	res.status(200).end(JSON.stringify(data));
        }
    });
});

/*
 * Get list of all cloud providers in the system
 */
router.get('/', function (req, res) {	
	logger.info('cloudProvider : router : received request : getAllCloudProviders : ');
	
	cloudProviderController.getAllCloudProviders(req, res, function(err, data) {
        if(err){
        	logger.error('cloudProvider : router : failed getAllCloudProviders : error : '+err);   
        	var error = new ErrorResponse();
        	error.setErrorCode("CP002");
        	error.setErrorMessage(err.message);
        	error.setHttpResponseCode(500);
            res.status(500).end(JSON.stringify(error));
        }else{        	
        	logger.info("cloudProvider : router : getAllCloudProviders successful !");
        	res.status(200).end(JSON.stringify(data));
        }
    });
});


/*
 * Get CloudProvider specified by the id parameter
 */
router.get('/:id', function (req, res) {
	logger.info('cloudProvider : router : received request : getCloudProviderById : id : '+req.params.id);
	cloudProviderController.getCloudProviderById(req, res, function(err, data) {
        if(err){
        	logger.error('cloudProvider : router : failed getCloudProviderById : error : '+err);  
        	var error = new ErrorResponse();
        	error.setErrorCode("CP003");
        	error.setErrorMessage(err.message);
        	error.setHttpResponseCode(500);
            res.status(500).end(JSON.stringify(error));
        }else{        	
        	logger.info("cloudProvider : router : getCloudProviderById successful !") ;
        	res.status(200).end(JSON.stringify(data));
        }
    });
});


/*
 * Updates an Cloud Provider specified by the id parameter
 */
router.put('/:id', function(req, res){	 
	logger.info('cloudProvider : router : received request : updateCloudProviderById : (id: '+req.params.id+', body: '+JSON.stringify(req.body)+')');
	cloudProviderController.updateCloudProviderById(req, res, function(err, data) {
        if(err){
        	logger.error('cloudProvider : router : failed updateCloudProviderById : error : '+err);   
        	var error = new ErrorResponse();
        	if(err.name == 'ValidationError'){
        		error.setErrorMessage(err.errors[Object.keys(err.errors)[0]].message);
        	} else {
        		error.setErrorMessage(err.message);
        	}
        	error.setErrorCode("CP004");        	
        	error.setHttpResponseCode(500);
            res.status(500).end(JSON.stringify(error));
        }else{        	
        	logger.info("cloudProvider : router : updateCloudProviderById successful !");
        	res.status(200).end(JSON.stringify(data));
        }
    });
});

/*
 * Deletes a Cloud Provider specified by the id parameter
 */
router.delete('/:id', function(req, res){
	logger.info('cloudProvider : router : received request : deleteCloudProviderById : id : '+req.params.id);
	cloudProviderController.deleteCloudProviderById(req, res, function(err, data) {
        if(err){
        	logger.error('cloudProvider : router : failed deleteCloudProviderById : error : '+err); 
        	var error = new ErrorResponse();
        	error.setErrorCode("CP005");
        	error.setErrorMessage(err.message);
        	error.setHttpResponseCode(500);
            res.status(500).end(JSON.stringify(error));
        }else{        	
        	logger.info("cloudProvider : router : deleteCloudProviderById successful !");
        	res.status(200).end(JSON.stringify(data));
        }
    });
});



router.all('/*', function(req, res) {
	logger.info('cloudProvider : router : received request : with URL : ' + req.originalUrl);
	logger.error('cloudProvider : router : No matching resource for URL : ' + req.originalUrl);
	var error = new ErrorResponse();
	error.setErrorCode("CP002");
	error.setErrorMessage('No matching resource for URL: ' + req.originalUrl);
	error.setHttpResponseCode(404);
	res.status(404).send(JSON.stringify(error));
});


module.exports = router;