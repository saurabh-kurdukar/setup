var db = require('../../common/MongoDbConnection');
var APIManager = require('../models/APIManager');
var Company=require('../../company/models/Company');
var logger = require('../../common/logger').log;
var encryptdecrypt= require('../../common/EncryptDecrypt');
var audit = require('../../common/Audit').audit;
/*
 * logging format followed: logger.info(<module_name>: <component name> : <description> : [<long_description>] : <data/params/errors>);
 */

var mongoose = db.mongoose;


/*
 * Add new Api manager details
 */
var addNewApiManagerInfo = function(req, res, callback) {
	
	logger.info('apiMgrConfig : DAO : received request : addNewApiManagerInfo : body : '
			+ JSON.stringify(req.body));
	var reqBody = req.body;
	var apimanager = new APIManager();
	
	var usernm=req.headers['username']; 
	var companyid = req.headers['companyid']; 
	
	apimanager.setAppmgrid(reqBody.Appmgrid);
	apimanager.setAppMgrName(reqBody.AppMgrName);
	apimanager.setCompanyId(companyid);
	apimanager.setIPAddress(reqBody.IPAddress);
	apimanager.setPort(reqBody.Port);
	apimanager.setURL(reqBody.URL);
	apimanager.setUsername(usernm);
	apimanager.setPassword(crypted);
	apimanager.setAttribute1(reqBody.Attribute1);
	apimanager.setAttribute1Value(reqBody.Attribute1Value);
	apimanager.setAttribute2(reqBody.Attribute2);
	apimanager.setAttribute2Value(reqBody.Attribute2Value);
	apimanager.setAttribute3(reqBody.Attribute3);
	apimanager.setAttribute3Value(reqBody.Attribute3Value);
	apimanager.setAttribute4(reqBody.Attribute4);
	apimanager.setAttribute4Value(reqBody.Attribute4Value);	
	apimanager.setAttribute5(reqBody.Attribute5);
	apimanager.setAttribute5Value(reqBody.Attribute5Value);
	
	apimanager.setCreatedBy(usernm);
	apimanager.setCreatedOn(new Date());
	apimanager.setUpdatedBy(usernm);
	apimanager.setUpdatedOn(new Date());
	
	

	
	Company.find({
			'companyId' : companyid
		}, function(err, data) {
			if (err) {
				callback(err, data);
			} else {
				if (data.length != 0) {
					//callback(err, data);
					apimanager.save(function(err, data) {
						if (err) {
							logger.error('apiMgrConfig : DAO : failed addNewApiManagerInfo : error : ' + err);
							callback(err, null);
						} else {
							logger.info('apiMgrConfig : DAO : addNewApiManagerInfo successful !');
							callback(null, data);
						}
					});
				} else {
					var err = new Error('Invalid company id');
					err.status = 404;
					callback(err, data);
				}
			}
		});
	};
	
	
	
	/*
	 * 	Get API Manager Config  by company id
	 */
	var getAPIManagerConfig = function(req, res, callback) {
		logger.info('apiMgrConfig : DAO : received request : getAPIManagerConfig : id : '+req.params.id);
		APIManager.find({
			'CompanyId' : req.params.id
		}, function(err, data) {
			if (err) {
				logger.error('apiMgrConfig : DAO : failed getAPIManagerConfig : error : ' + err);
				callback(err, null);
			} else {
				if (data.length != 0) {
					logger.info('apiMgrConfig : DAO : getAPIManagerConfig successful !');
					callback(null, data);
				} else {
					var err = new Error('Invalid company id');
					err.status = 404;
					logger.error('apiMgrConfig : DAO : failed getAPIManagerConfig : error : '+ err);
					callback(err, null);
				}
			}
		});
	};


	
	/*
	 * 	Get API Manager Info  by company id and apiMgrId
	 */
	var getAPIManagerInfo = function(req, res, callback) {
		logger.info('apiMgrConfig : DAO : received request : getAPIManagerInfo : id : '+req.params.id);
		var companyid = req.headers['companyid']; 
				
		APIManager.find({
			'CompanyId' : companyid,
			'Appmgrid':req.params.id
		}, function(err, data) {
			if (err) {
				logger.error('apiMgrConfig : DAO : failed getAPIManagerInfo : error : ' + err);
				callback(err, null);
			} else {
				if (data.length != 0) {
					logger.info('apiMgrConfig : DAO : getAPIManagerInfo successful !');
					callback(null, data);
				} else {
					var err = new Error('Invalid company id');
					err.status = 404;
					logger.error('apiMgrConfig : DAO : failed getAPIManagerInfo : error : '+ err);
					callback(err, null);
				}
			}
		});
	};
	
	
	
	/*
	 * Get all API Manager Info 
	 */
	var getAllAPIManagerInfo = function(req, res, callback) {
		logger.info('apiMgrConfig : DAO : received request : getAllAPIManagerInfo ');
		
				
		APIManager.find(function(err, data) {
		if (err) {
			logger.error('apiMgrConfig : DAO : failed getAllAPIManagerInfo : error : ' + err);
			callback(err, null);
		} else {
			if (data.length != 0) {
				logger.info('apiMgrConfig : DAO : getAllAPIManagerInfo successful !');
				callback(null, data);
			} else {
				var err = new Error('No records found');
				err.status = 404;
				logger.error('apiMgrConfig : DAO : failed getAllAPIManagerInfo : error : ' + err);
				callback(err, null);
			}
		}
	});
	};
	
	
	
	
//	update API Manager Info by apiMgrid and company id
	
	
	
	
var updateAPIManagerInfo = function(req, res, callback) {
		
		logger.info('apiMgrConfig : DAO : received request : updateAPIManagerInfo : id : '
				+ req.params.id + ' & body: ' + JSON.stringify(req.body));
		
		
		/*
		 * Callback function after getting original record to update with new values.
		 */ 
		var callbackUpdate = function(err, data) {	
			if(err) {
				logger.error('apiMgrConfig : DAO : failed updateAPIManagerInfo : error :' + err);
				callback(err, null);
			} else if(data != null) {
				/*
				 *	Compare updatable fields values in db with request data
				 *	Add those fields in temproary object which are having new values
				 */			
				var apimanager = data;
				var json = {};
				var updatedData = [];
				var companyid = req.headers['companyid'];
				var usernm=req.headers['username'];
				
				//console.log(usernm);
				
				
				if (req.body.CompanyId && apimanager['CompanyId'] != req.body.CompanyId) {
					json.CompanyId = req.body.CompanyId;
					var obj = {};				
					obj.column = 'CompanyId';
					obj.oldValue = apimanager['CompanyId'];
					obj.newValue = req.body.CompanyId;
					obj.identifier = 'Platform_apimanager_'+req.params.id;
					obj.modifiedBy = 'admin';
					obj.modifiedOn = new Date();
					updatedData.push(obj);
				}
				if (req.body.IPAddress && apimanager['IPAddress'] != req.body.IPAddress) {
					json.IPAddress = req.body.IPAddress;
					var obj = {};
					obj.column = 'IPAddress';
					obj.oldValue = apimanager['IPAddress'];
					obj.newValue = req.body.IPAddress;
					obj.identifier = 'Platform_apimanager_'+req.params.id;
					obj.modifiedBy = 'admin';
					obj.modifiedOn = new Date();
					updatedData.push(obj);
				}
				if (req.body.Port && apimanager['Port'] != req.body.Port) {
					json.Port = req.body.Port;
					var obj = {};
					obj.column = 'Port';
					obj.oldValue = apimanager['Port'];
					obj.newValue = req.body.Port;
					obj.identifier = 'Platform_apimanager_'+req.params.id;
					obj.modifiedBy = 'admin';
					obj.modifiedOn = new Date();
					updatedData.push(obj);
				}
				if (req.body.URL && apimanager['URL'] != req.body.URL) {
					json.URL = req.body.URL;
					var obj = {};
					obj.column = 'URL';
					obj.oldValue = apimanager['URL'];
					obj.newValue = req.body.URL;
					obj.identifier = 'Platform_apimanager_'+req.params.id;
					obj.modifiedBy = 'admin';
					obj.modifiedOn = new Date();
					updatedData.push(obj);
				}
				if (req.body.Username && apimanager['Username'] != req.body.Username) {
					json.Username = req.body.Username;
					var obj = {};
					obj.column = 'Username';
					obj.oldValue = apimanager['Username'];
					obj.newValue = req.body.Username;
					obj.identifier = 'Platform_apimanager_'+req.params.id;
					obj.modifiedBy = 'admin';
					obj.modifiedOn = new Date();
					updatedData.push(obj);
				}
				if (req.body.Password && apimanager['Password'] != req.body.Password) {
					//encrypt password
					var encpassword=encryptdecrypt.encryption(req.body.Password);
					json.Password = encpassword;
					var obj = {};
					obj.column = 'Password';
					obj.oldValue = apimanager['Password'];
					obj.newValue = req.body.Password;
					obj.identifier = 'Platform_apimanager_'+req.params.id;
					obj.modifiedBy = 'admin';
					obj.modifiedOn = new Date();
					updatedData.push(obj);
				}
				if (req.body.Attribute1 && apimanager['Attribute1'] != req.body.Attribute1) {
					json.Attribute1 = req.body.Attribute1;
					var obj = {};
					obj.column = 'Attribute1';
					obj.oldValue = apimanager['Attribute1'];
					obj.newValue = req.body.Attribute1;
					obj.identifier = 'Platform_apimanager_'+req.params.id;
					obj.modifiedBy = 'admin';
					obj.modifiedOn = new Date();
					updatedData.push(obj);
				}
				if (req.body.Attribute1Value && apimanager['Attribute1Value'] != req.body.Attribute1Value) {
					json.Attribute1Value = req.body.Attribute1Value;
					var obj = {};
					obj.column = 'Attribute1Value';
					obj.oldValue = apimanager['Attribute1Value'];
					obj.newValue = req.body.Attribute1Value;
					obj.identifier = 'Platform_apimanager_'+req.params.id;
					obj.modifiedBy = 'admin';
					obj.modifiedOn = new Date();
					updatedData.push(obj);
				}
				if (req.body.Attribute2 && apimanager['Attribute2'] != req.body.Attribute2) {
					json.Attribute2 = req.body.Attribute2;
					var obj = {};
					obj.column = 'Attribute2';
					obj.oldValue = apimanager['Attribute2'];
					obj.newValue = req.body.Attribute2;
					obj.identifier = 'Platform_apimanager_'+req.params.id;
					obj.modifiedBy = 'admin';
					obj.modifiedOn = new Date();
					updatedData.push(obj);
				}
				if (req.body.Attribute2Value && apimanager['Attribute2Value'] != req.body.Attribute2Value) {
					json.Attribute2Value = req.body.Attribute2Value;
					var obj = {};
					obj.column = 'Attribute2Value';
					obj.oldValue = apimanager['Attribute2Value'];
					obj.newValue = req.body.Attribute2Value;
					obj.identifier = 'Platform_apimanager_'+req.params.id;
					obj.modifiedBy = 'admin';
					obj.modifiedOn = new Date();
					updatedData.push(obj);
				}
				if (req.body.Attribute3 && apimanager['Attribute3'] != req.body.Attribute3) {
					json.Attribute3 = req.body.Attribute3;
					var obj = {};
					obj.column = 'Attribute3';
					obj.oldValue = apimanager['Attribute3'];
					obj.newValue = req.body.Attribute3;
					obj.identifier = 'Platform_apimanager_'+req.params.id;
					obj.modifiedBy = 'admin';
					obj.modifiedOn = new Date();
					updatedData.push(obj);
				}
				if (req.body.Attribute3Value && apimanager['Attribute3Value'] != req.body.Attribute3Value) {
					json.Attribute3Value = req.body.Attribute3Value;
					var obj = {};
					obj.column = 'Attribute3Value';
					obj.oldValue = apimanager['Attribute3Value'];
					obj.newValue = req.body.Attribute3Value;
					obj.identifier = 'Platform_apimanager_'+req.params.id;
					obj.modifiedBy = 'admin';
					obj.modifiedOn = new Date();
					updatedData.push(obj);
				}
				if (req.body.Attribute4 && apimanager['Attribute4'] != req.body.Attribute4) {
					json.Attribute4 = req.body.Attribute4;
					var obj = {};
					obj.column = 'Attribute4';
					obj.oldValue = apimanager['Attribute4'];
					obj.newValue = req.body.Attribute4;
					obj.identifier = 'Platform_apimanager_'+req.params.id;
					obj.modifiedBy = 'admin';
					obj.modifiedOn = new Date();
					updatedData.push(obj);
				}
				if (req.body.Attribute4Value && apimanager['Attribute4Value'] != req.body.Attribute4Value) {
					json.Attribute4Value = req.body.Attribute4Value;
					var obj = {};
					obj.column = 'Attribute4Value';
					obj.oldValue = apimanager['Attribute4Value'];
					obj.newValue = req.body.Attribute4Value;
					obj.identifier = 'Platform_apimanager_'+req.params.id;
					obj.modifiedBy = 'admin';
					obj.modifiedOn = new Date();
					updatedData.push(obj);
				}
				if (req.body.Attribute5 && apimanager['Attribute5'] != req.body.Attribute5) {
					json.Attribute5 = req.body.Attribute5;
					var obj = {};
					obj.column = 'Attribute5';
					obj.oldValue = apimanager['Attribute5'];
					obj.newValue = req.body.Attribute5;
					obj.identifier = 'Platform_apimanager_'+req.params.id;
					obj.modifiedBy = 'admin';
					obj.modifiedOn = new Date();
					updatedData.push(obj);
				}
				if (req.body.Attribute5Value && apimanager['Attribute5Value'] != req.body.Attribute5Value) {
					json.Attribute5Value = req.body.Attribute5Value;
					var obj = {};
					obj.column = 'Attribute5Value';
					obj.oldValue = apimanager['Attribute5Value'];
					obj.newValue = req.body.Attribute5Value;
					obj.identifier = 'Platform_apimanager_'+req.params.id;
					obj.modifiedBy = 'admin';
					obj.modifiedOn = new Date();
					updatedData.push(obj);
				}
				
				
				/*
				 *	Update the data to database 
				 */
				if (Object.keys(json).length != 0) {
					json.UpdatedBy = usernm;
					json.UpdatedOn = new Date();
					logger.info('apiMgrConfig : DAO : updateAPIManagerInfo : updating data : ' + JSON.stringify(json));
					APIManager.findOneAndUpdate({
						'CompanyId' : companyid,
						'Appmgrid' : req.params.id
					}, json, {
						'new' : true
					// returns updated entity if update successful, if false then old entry
					}, function(err, data) {
						if (err) {
							logger.error('apiMgrConfig : DAO : failed updateAPIManagerInfo : error :' + err);
							callback(err, null);
						} else {
							if(data != null) {
								logger.info('apiMgrConfig : DAO : updateAPIManagerInfo successful !');		
								/*
								 *	Call audit function for changed data 
								 */
								audit(req, res, updatedData);
								/*
								 *	Call function to send response to client 
								 */
								callback(null, data);
							} else {
								var err = new Error('Bad request data');
								logger.error('apiMgrConfig : DAO : failed updateAPIManagerInfo : error :' + err);
								callback(err, null);
							}
						}
					});
				} else {
					var err = new Error('Cannot update data');
					logger.error('apiMgrConfig : DAO : failed updateAPIManagerInfo : error :' + err);
					callback(err, null);
				}
			} else {
				var err = new Error('Failed to get apimanager details');
				logger.error('apiMgrConfig : DAO : failed updateAPIManagerInfo : error :' + err);
				callback(err, null);
			}
		};

		getAPIManagerInfo(req, res, callbackUpdate);
	
	};
	

module.exports.addNewApiManagerInfo = addNewApiManagerInfo;
module.exports.getAPIManagerConfig = getAPIManagerConfig;
module.exports.getAPIManagerInfo = getAPIManagerInfo;
module.exports.updateAPIManagerInfo = updateAPIManagerInfo;
module.exports.getAllAPIManagerInfo = getAllAPIManagerInfo;

