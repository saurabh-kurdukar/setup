var express = require('express');
var apimanagerController = require('./controller/APIManagerController');
var logger = require('../common/logger').log;
var ErrorResponse = require('../common/ErrorResponse').ErrorResponse;
var router = express.Router();



/*
 * logging format followed: logger.info(<module_name>: <component name> : <description> : [<long_description>] : <data/params/errors>);
 */

/*
 * Add new Api manager details
 */
router.post('/', function(req, res){
	logger.info('apiMgrConfig : router : received request : addNewApiManagerInfo : body : '+JSON.stringify(req.body));
	apimanagerController.addNewApiManagerInfo(req, res, function(err, data) {
        if(err){
        	logger.error('apiMgrConfig : router : failed addNewApiManagerInfo : error : '+err);
        	var error = new ErrorResponse();
        	if(err.name == 'ValidationError'){
        		error.setErrorMessage(err.errors[Object.keys(err.errors)[0]].message);
        	} else {
        		error.setErrorMessage(err.message);
        	}
        	error.setErrorCode("AM001");        	
        	error.setHttpResponseCode(500);  
            res.status(500).end(JSON.stringify(error));
        }else{
        	logger.info("apiMgrConfig : router : addNewApiManagerInfo successful !");
        	res.status(200).end(JSON.stringify(data));
        }
    });
});


/*
 * 	Get API Manager Info  by company id and apiMgrId
 */
router.get('/:id(\\d+)', function (req, res) {	
	logger.info('apiMgrConfig : router : received request : getAPIManagerInfo : id : '+req.params.id);
	apimanagerController.getAPIManagerInfo(req, res, function(err, data) {
        if(err){
        	logger.error('apiMgrConfig : router : failed getAPIManagerInfo : error : '+err);
        	var error = new ErrorResponse();
        	error.setErrorCode("AM002");
        	error.setErrorMessage(err.message);
        	error.setHttpResponseCode(500);   
            res.status(500).end(JSON.stringify(error));
        }else{
        	logger.info("apiMgrConfig : router : getAPIManagerInfo successful !");
        	res.status(200).end(JSON.stringify(data));
        }
    });
});



/*
 * 	Get all API Manager Info 
 */
router.get('/', function (req, res) {	
	logger.info('apiMgrConfig : router : received request : getAllAPIManagerInfo ');
	apimanagerController.getAllAPIManagerInfo(req, res, function(err, data) {
        if(err){
        	logger.error('apiMgrConfig : router : failed getAllAPIManagerInfo : error : '+err);
        	var error = new ErrorResponse();
        	error.setErrorCode("AM004");
        	error.setErrorMessage(err.message);
        	error.setHttpResponseCode(500);   
            res.status(500).end(JSON.stringify(error));
        }else{
        	logger.info("apiMgrConfig : router : getAllAPIManagerInfo successful !");
        	res.status(200).end(JSON.stringify(data));
        }
    });
});



/*
 * Update APi manager configuration details
 */
router.put('/:id(\\d+)', function(req, res){	
	logger.info('apiMgrConfig : router : received request : updateAPIManagerInfo : id : '+req.params.id);
	apimanagerController.updateAPIManagerInfo(req, res, function(err, data) {
        if(err){
        	logger.error('apiMgrConfig : router : failed updateAPIManagerInfo : error : '+err);
        	var error = new ErrorResponse();
        	if(err.name == 'ValidationError'){
        		error.setErrorMessage(err.errors[Object.keys(err.errors)[0]].message);
        	} else {
        		error.setErrorMessage(err.message);
        	}
        	error.setErrorCode("AM003");
        	error.setErrorMessage(err.message);
        	error.setHttpResponseCode(500);  
            res.status(500).end(JSON.stringify(error));
        }else{
        	
        	logger.info("apiMgrConfig : router :  updateAPIManagerInfo  successful !");
        	res.status(200).end(JSON.stringify(data));
        }
    });
});


router.options('/', function(req, res) {
	logger.info('apiMgrConfig : router : received request : Options call APiManagers APIs');
	res.header('Allow-Access-Allow-Origin', '*');
	res.header('Access-Control-Allow-Headers', '*');
	res.header('Access-Control-Allow-Methods', 'GET,POST,DELETE,PUT,OPTIONS');
	res.header('Connection', 'keep-alive');
	res.header('Content-Type', 'application/json;charset=UTF-8');
	res.end();
	logger.info('apiMgrConfig : router : received request : headers sent !');
});



router.all('/*', function (req, res) {	
	logger.info('apiMgrConfig : router : received request : with URL : ' + req.originalUrl);
	logger.error('apiMgrConfig : router : No matching resource for URL : ' + req.originalUrl);
	var error = new ErrorResponse();
	error.setErrorCode("AM004");
	error.setErrorMessage('No matching resource for URL: ' + req.originalUrl);
	error.setHttpResponseCode(404);
	res.status(404).send(JSON.stringify(error));
});


module.exports = router;