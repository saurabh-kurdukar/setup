var mongoose = require('../../common/MongoDbConnection').mongoose;
var autoIncrement = require('mongoose-auto-increment');
var logger = require('../../common/logger').log;
var connection = mongoose.connection;
autoIncrement.initialize(connection);

/*
 * logging format followed: logger.info(<module_name>: <component name> :
 * <description> : <long_description> : <data/params/errors>);
 */


/*
 * Define schema
 */



var ApimanagerSchema = mongoose.Schema({
	 Appmgrid: Number,
	 AppMgrName: {type:String,unique: true},
	 CompanyId: {type:Number, required: true},
	 IPAddress:{type :String, allowNull: false,required: true,minLength: 0, maxLength: 30},
	 Port:{type:Number,allowNull: false,required: true,minLength: 0, maxLength: 10},
	 URL:{type:String,allowNull: false,required: true,minLength: 0, maxLength: 255},
	 Username:{type:String,minLength: 0, maxLength: 100},
	 Password:{type:String,minLength: 0, maxLength: 100},
	 Attribute1:{type:String,minLength: 0, maxLength: 100},
	 Attribute1Value:{type:String,minLength: 0, maxLength: 100},
	 Attribute2:{type:String,minLength: 0, maxLength: 100},
	 Attribute2Value:{type:String,minLength: 0, maxLength: 100},
	 Attribute3:{type:String,minLength: 0, maxLength: 100},
	 Attribute3Value:{type:String,minLength: 0, maxLength: 100},
	 Attribute4:{type:String,minLength: 0, maxLength: 100},
	 Attribute4Value:{type:String,minLength: 0, maxLength: 100},
	 Attribute5:{type:String,minLength: 0, maxLength: 100},
	 Attribute5Value:{type:String,minLength: 0, maxLength: 100},
	 CreatedBy:{type:String,minLength: 0, maxLength: 50},
	 CreatedOn: { type: Date, default: Date.now },
	 UpdatedBy:{type:String,minLength: 0, maxLength: 50},
	 UpdatedOn: { type: Date, default: Date.now }
	
}); 

logger.info('apiMgrConfig : model : created schema : ApiManager :'+JSON.stringify(ApimanagerSchema.paths));

ApimanagerSchema.path('AppMgrName').validate(function(value, fn) {	  
	  var ApiManager = mongoose.model('ApiManager');
	  ApiManager.find({'AppMgrName': value}, function (err, data) {
	    fn(err || data.length === 0);
	  });
}, 'AppMgrName name is already taken');

ApimanagerSchema.path('AppMgrName').validate(function (v) {
	  return v.length <= 100;
}, 'data too long for field AppMgrName'); 

ApimanagerSchema.path('IPAddress').validate(function (v) {
	  return v.length <= 30;
}, 'data too long for field IPAddress'); 

/*ApimanagerSchema.path('Port').validate(function (v) {
	  return v.length <= 10;
}, 'data too long for field Port'); */

ApimanagerSchema.path('URL').validate(function (v) {
	  return v.length <= 255;
}, 'data too long for field URL'); 

ApimanagerSchema.path('Username').validate(function (v) {
	  return v.length <= 100;
}, 'data too long for field Username'); 

ApimanagerSchema.path('Password').validate(function (v) {
	  return v.length <= 100;
}, 'data too long for field Password'); 

ApimanagerSchema.path('Attribute1').validate(function (v) {
	  return v.length <= 100;
}, 'data too long for field Attribute1'); 

ApimanagerSchema.path('Attribute1Value').validate(function (v) {
	  return v.length <= 100;
}, 'data too long for field Attribute1Value'); 

ApimanagerSchema.path('Attribute2').validate(function (v) {
	  return v.length <= 100;
}, 'data too long for field Attribute2'); 

ApimanagerSchema.path('Attribute2Value').validate(function (v) {
	  return v.length <= 100;
}, 'data too long for field Attribute2Value'); 

ApimanagerSchema.path('Attribute3').validate(function (v) {
	  return v.length <= 100;
}, 'data too long for field Attribute3'); 

ApimanagerSchema.path('Attribute3Value').validate(function (v) {
	  return v.length <= 100;
}, 'data too long for field Attribute3Value'); 

ApimanagerSchema.path('Attribute4').validate(function (v) {
	  return v.length <= 100;
}, 'data too long for field Attribute4'); 

ApimanagerSchema.path('Attribute4Value').validate(function (v) {
	  return v.length <= 100;
}, 'data too long for field Attribute4Value'); 

ApimanagerSchema.path('Attribute5').validate(function (v) {
	  return v.length <= 100;
}, 'data too long for field Attribute5'); 

ApimanagerSchema.path('Attribute5Value').validate(function (v) {
	  return v.length <= 100;
}, 'data too long for field Attribute5Value'); 

ApimanagerSchema.path('CreatedBy').validate(function (v) {
	  return v.length <= 50;
}, 'data too long for field CreatedBy'); 

ApimanagerSchema.path('UpdatedBy').validate(function (v) {
	  return v.length <= 50;
}, 'data too long for field UpdatedBy'); 

ApimanagerSchema.plugin(autoIncrement.plugin, { model: 'ApiManager', field: 'Appmgrid', startAt: 1 });

/*
 * Setters
 */
ApimanagerSchema.methods.setAppmgrid = function(Appmgrid) {	
	this.Appmgrid = Appmgrid;
};

ApimanagerSchema.methods.setAppMgrName = function(AppMgrName) {
	this.AppMgrName = AppMgrName;
};

ApimanagerSchema.methods.setCompanyId = function(CompanyId) {
	this.CompanyId = CompanyId;
};

ApimanagerSchema.methods.setIPAddress = function(IPAddress) {	
	this.IPAddress = IPAddress;
};

ApimanagerSchema.methods.setPort = function(Port) {
	this.Port = Port;
};

ApimanagerSchema.methods.setURL = function(URL) {
	this.URL = URL;
};


ApimanagerSchema.methods.setUsername = function(Username) {	
	this.Username = Username;
};

ApimanagerSchema.methods.setPassword = function(Password) {
	this.Password = Password;
};

ApimanagerSchema.methods.setAttribute1 = function(Attribute1) {
	this.Attribute1 = Attribute1;
};


ApimanagerSchema.methods.setAttribute1Value = function(Attribute1Value) {
	this.Attribute1Value = Attribute1Value;
};

ApimanagerSchema.methods.setAttribute2 = function(Attribute2) {
	this.Attribute2 = Attribute2;
};


ApimanagerSchema.methods.setAttribute2Value = function(Attribute2Value) {	
	this.Attribute2Value = Attribute2Value;
};

ApimanagerSchema.methods.setAttribute3 = function(Attribute3) {
	this.Attribute3 = Attribute3;
};

ApimanagerSchema.methods.setAttribute3Value = function(Attribute3Value) {
	this.Attribute3Value = Attribute3Value;
};



ApimanagerSchema.methods.setAttribute4 = function(Attribute4) {
	this.Attribute4 = Attribute4;
};


ApimanagerSchema.methods.setAttribute4Value = function(Attribute4Value) {	
	this.Attribute4Value = Attribute4Value;
};

ApimanagerSchema.methods.setAttribute5 = function(Attribute5) {
	this.Attribute5 = Attribute5;
};

ApimanagerSchema.methods.setAttribute5Value = function(Attribute5Value) {
	this.Attribute5Value = Attribute5Value;
};



ApimanagerSchema.methods.setCreatedBy = function(CreatedBy) {	
	this.CreatedBy = CreatedBy;
};

ApimanagerSchema.methods.setCreatedOn = function(CreatedOn) {
	this.CreatedOn = CreatedOn;
};

ApimanagerSchema.methods.setUpdatedBy = function(UpdatedBy) {
	this.UpdatedBy = UpdatedBy;
};


ApimanagerSchema.methods.setUpdatedOn = function(UpdatedOn) {
	this.UpdatedOn = UpdatedOn;
};


/*
 * Getters
 */
ApimanagerSchema.methods.getAppmgrid = function() {
	return this.Appmgrid;
};


ApimanagerSchema.methods.getAppMgrName = function() {
	return this.AppMgrName ;
};

ApimanagerSchema.methods.getCompanyId = function() {
	return this.CompanyId;
};

ApimanagerSchema.methods.getIPAddress = function() {	
	return this.IPAddress;
};

ApimanagerSchema.methods.getPort = function() {
	return this.Port ;
};

ApimanagerSchema.methods.getURL = function() {
	return this.URL;
};


ApimanagerSchema.methods.getUsername = function() {	
	return this.Username ;
};

ApimanagerSchema.methods.getPassword = function() {
	return this.Password ;
};

ApimanagerSchema.methods.getAttribute1 = function() {
	return this.Attribute1 ;
};


ApimanagerSchema.methods.getAttribute1Value = function() {
	return this.Attribute1Value ;
};

ApimanagerSchema.methods.getAttribute2 = function() {
	return this.Attribute2 ;
};


ApimanagerSchema.methods.getAttribute2Value = function() {	
	return this.Attribute2Value ;
};

ApimanagerSchema.methods.getAttribute3 = function() {
	return this.Attribute3 ;
};

ApimanagerSchema.methods.getAttribute3Value = function() {
	return this.Attribute3Value ;
};



ApimanagerSchema.methods.getAttribute4 = function() {
	return this.Attribute4 ;
};


ApimanagerSchema.methods.getAttribute4Value = function() {	
	return this.Attribute4Value ;
};

ApimanagerSchema.methods.getAttribute5 = function() {
	return this.Attribute5 ;
};

ApimanagerSchema.methods.getAttribute5Value = function() {
	return this.Attribute5Value;
};



ApimanagerSchema.methods.getCreatedBy = function() {	
	return this.CreatedBy;
};

ApimanagerSchema.methods.getCreatedOn = function() {
	return this.CreatedOn ;
};

ApimanagerSchema.methods.getUpdatedBy = function() {
	return this.UpdatedBy ;
};


ApimanagerSchema.methods.getUpdatedOn = function() {
	return this.UpdatedOn;
};


/*
 * Create collection/model in mongo db using Schema
 */
var Apimanager = mongoose.model('ApiManager', ApimanagerSchema);
logger.info('apiMgrConfig : model : created model : Apimanager');

/*
 * Insert records in collection
 */
/*var apimanager = new Apimanager({ Appmgrid: 1, AppMgrName: 'App', IPAddress: 'IPv4',Port: '8080',URL: '/apimanager.com' });
apimanager.save(function (err, data) {
  if (err) 
	  return console.error(err);
  else
	  console.log('data inserted: '+data.AppMgrName);
});
*/

module.exports = Apimanager;
