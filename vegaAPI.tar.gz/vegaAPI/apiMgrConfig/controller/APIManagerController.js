var apimanagerDao = require('../dao/ApiManagerDAO');
var encdec = require('../../common/EncryptDecrypt');
var logger = require('../../common/logger').log;
/*
 * logging format followed: logger.info(<module_name>: <component name> : <description> : [<long_description>] : <data/params/errors>);
 */



/*
 * Add new API Manager Info
 */

var addNewApiManagerInfo = function(req, res, callback) {
	
	logger.info('apiMgrConfig : controller : received request : addNewApiManagerInfo : body : '+JSON.stringify(req.body));
	encdec.encryption(req.body.Password);
	
	apimanagerDao.addNewApiManagerInfo(req, res, callback);
};



/*
 * 	Get API Manager Info  by company id and apiMgrId
 */
var getAPIManagerInfo = function(req, res, callback) {
	
	logger.info('apiMgrConfig : controller : received request : getAPIManagerInfo : id : '+req.params.id);
	apimanagerDao.getAPIManagerInfo(req, res, callback);
};



/*
 * 	Get all API Manager Info 
 */
var getAllAPIManagerInfo = function(req, res, callback) {
	
	logger.info('apiMgrConfig : controller : received request : getAllAPIManagerInfo ');
	apimanagerDao.getAllAPIManagerInfo(req, res, callback);
};

//	update API Manager Info by apiMgrid and company id

var updateAPIManagerInfo = function(req, res, callback) {
	
	logger.info('apiMgrConfig : controller : received request : updateAPIManagerInfo : id : '+req.params.id);
	apimanagerDao.updateAPIManagerInfo(req, res, callback);
};


module.exports.addNewApiManagerInfo = addNewApiManagerInfo;
module.exports.getAPIManagerInfo = getAPIManagerInfo;
module.exports.updateAPIManagerInfo = updateAPIManagerInfo;
module.exports.getAllAPIManagerInfo = getAllAPIManagerInfo;