var mongoose = require('../../common/MongoDbConnection').mongoose;
var autoIncrement = require('mongoose-auto-increment');
var logger = require('../../common/logger').log;
var connection = mongoose.connection;
autoIncrement.initialize(connection);

/*
 * Define schema
 */
var domainSchema = mongoose.Schema({
	
	id: Number ,
	name: String ,
	description:  String ,
	longDescription: String,
	logo: String	            
});

logger.info('Domain : model : created schema : Domain :'+JSON.stringify(domainSchema.paths));

domainSchema.path('name').validate(function (v) {
	  return v.length <= 50;
}, 'data too long for field name'); 

domainSchema.path('description').validate(function (v) {
	  return v.length <= 50;
}, 'data too long for field description');

domainSchema.path('longDescription').validate(function (v) {
	  return v.length <= 100;
}, 'data too long for field longDescription');

domainSchema.path('logo').validate(function (v) {
	  return v.length <= 50;
}, 'data too long for field logo');


/*
* Add Auto increment plugin for field id
*/
domainSchema.plugin(autoIncrement.plugin, { model: 'Domains', field: 'id', startAt: 1 });



/*
 * Setters
 */
domainSchema.methods.setId=function(id){
	this.id=id;
}

domainSchema.methods.setName=function(name){
	this.name=name;
}

domainSchema.methods.setDescription=function(description){
	this.description=description;
}

domainSchema.methods.setLongDescription=function(longDescription){
	this.longDescription=longDescription;
}

domainSchema.methods.setLogo=function(logo){
	this.logo=logo;
}

/*
 * Getters
 */
domainSchema.methods.getId=function(){
	return this.id;
}

domainSchema.methods.getName=function(){
	return this.name;
}

domainSchema.methods.getDescription=function(){
	return this.description;
}

domainSchema.methods.getLongDescription=function(){
	return this.longDescription;
}

domainSchema.methods.getLogo=function(){
	return this.logo;
}


/*
 * Create collection/model in mongo db using Schema
 */
var Domain = mongoose.model('Domains', domainSchema);

module.exports = Domain;