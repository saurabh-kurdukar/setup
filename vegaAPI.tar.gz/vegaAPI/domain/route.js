var express = require('express');
var logger = require('../common/logger').log;
var domainController=require('./controller/DomainController');
var ErrorResponse = require('../common/ErrorResponse').ErrorResponse;
var router = express.Router();


/*
 * Add new domain details
 */
router.post('/', function(req, res){
	logger.info('Domain : router : received request : addNewDomain : body : '+JSON.stringify(req.body));
	domainController.addNewDomain(req, res, function(err, data) {
        if(err){
        	logger.error('Domain : router : failed addNewDomain : error : '+err);             	     
        	var error = new ErrorResponse();
        	if(err.name == 'ValidationError'){
        		error.setErrorMessage(err.errors[Object.keys(err.errors)[0]].message);
        	} else {
        		error.setErrorMessage(err.message);
        	}
        	error.setErrorCode("D0001");        	
        	error.setHttpResponseCode(500);        	
        	res.status(500).end(JSON.stringify(error));        
        
        } else {        	
        	logger.info("Domain : router : addNewDomain successful !");
        	res.status(200).end(JSON.stringify(data));
        }
    });
});

/*
 * Get all domains
 */
router.get('/', function (req, res) {	
	logger.info('domain : router : received request : getAllDomains : status : '
			+ req.query.status);
	domainController.getAllDomains(req, res, function(err, data) {
        if(err){
        	logger.error('domain : router : failed getAllDomains : error : '+err);   
        	var error = new ErrorResponse();
        	error.setErrorCode("D0002");
        	error.setErrorMessage(err.message);
        	error.setHttpResponseCode(500);
            res.status(500).end(JSON.stringify(error));
        }else{        	
        	logger.info("domain : router : getAllDomains successful !");
        	res.status(200).end(JSON.stringify(data));
        }
    });
});


/*
 * Get domain by id
 */
router.get('/:id', function (req, res) {
	logger.info('domain : router : received request : getDomainById : id : '+req.params.id);
	domainController.getDomainById(req, res, function(err, data) {
        if(err){
        	logger.error('domain : router : failed getDomainById : error : '+err);  
        	var error = new ErrorResponse();
        	error.setErrorCode("D0003");
        	error.setErrorMessage(err.message);
        	error.setHttpResponseCode(500);
            res.status(500).end(JSON.stringify(error));
        }else{        	
        	logger.info("domain : router : getDomainById successful !") ;
        	res.status(200).end(JSON.stringify(data));
        }
    });
});


/*
 * Update domain details
 */
router.put('/:id', function(req, res){	 
	logger.info('domain : router : received request : updateDomainById : (id: '+req.params.id+', body: '+JSON.stringify(req.body)+')');
	domainController.updateDomainById(req, res, function(err, data) {
        if(err){
        	logger.error('domain : router : failed updateDomainById : error : '+err);   
        	var error = new ErrorResponse();
        	if(err.name == 'ValidationError'){
        		error.setErrorMessage(err.errors[Object.keys(err.errors)[0]].message);
        	} else {
        		error.setErrorMessage(err.message);
        	}
        	error.setErrorCode("D0004");        	
        	error.setHttpResponseCode(500);
            res.status(500).end(JSON.stringify(error));
        }else{        	
        	logger.info("domain : router : updateDomainById successful !");
        	res.status(200).end(JSON.stringify(data));
        }
    });
});

/*
 * Delete domain details
 */
/*router.delete('/:id', function(req, res){
	logger.info('domain : router : received request : deleteDomainById : id : '+req.params.id);
	domainController.deleteDomainById(req, res, function(err, data) {
        if(err){
        	logger.error('domain : router : failed deleteDomainById : error : '+err); 
        	var error = new ErrorResponse();
        	error.setErrorCode("D0005");
        	error.setErrorMessage(err.message);
        	error.setHttpResponseCode(500);
            res.status(500).end(JSON.stringify(error));
        }else{        	
        	logger.info("domain : router : deleteDomainById successful !");
        	res.status(200).end(JSON.stringify(data));
        }
    });
});*/




module.exports = router;