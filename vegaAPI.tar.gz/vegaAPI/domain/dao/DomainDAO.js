var db = require('../../common/MongoDbConnection');
var Domain = require('../models/Domain');
var logger = require('../../common/logger').log;
var audit = require('../../common/Audit').audit;

/*
 * Add new Domain details
 */
var addNewDomain = function(req, res, callback) {	
	logger.info('Domain : DAO : received request : addNewDomain : body : '
			+ JSON.stringify(req.body));
	
	var reqBody = req.body;
	var domain = new Domain();
	
	domain.setName(reqBody.name);
	domain.setDescription(reqBody.description);
	domain.setLongDescription(reqBody.longDescription);
	domain.setLogo(reqBody.logo);
	
	domain.save(function(err, data) {
		if (err) {
			logger.error('domain : DAO : failed addNewDomain : error : ' + err);
			callback(err, null);
		} else if(data != null){
			logger.info('domain : DAO : addNewDomain successful !');
			callback(null, data);
		} else {
			var err = new Error('Failed to add new domain details');			
			logger.error('domain : DAO : failed addNewDomain : error : '+ err);
			callback(err, null);
		}
	});		
};

/*
 * Get all domains
 */

var getAllDomains = function(req, res, callback) {
	logger.info('Domain : DAO : received request : getAllDomains :');
	
	var obj = {};
	if (Object.keys(req.query).length != 0) {
		var keys = Object.keys(req.query);
		for(var i=0; i < keys.length; i++) {
			if((keys[i] == 'status' || keys[i] == 'name') && req.query[keys[i]]) {				
				var key = keys[i];
				if(keys[i] == 'id') {
					key = 'domainId';
				}
				obj[key] = new RegExp('^' + req.query[keys[i]].toLowerCase(), 'i');				
			}
		}		
	}	
	
	Domain.find(obj, function(err, data) {
		if (err) {
			logger.error('domain : DAO : failed getAllDomains : error : ' + err);
			callback(err, null);
		} else {
			if (data.length != 0) {
				logger.info('domain : DAO : getAllDomains successful !');
				callback(null, data);
			} else {
				var err = new Error('No records found');
				err.status = 404;
				logger.error('domain : DAO : failed getAllDomains : error : ' + err);
				callback(err, null);
			}
		}
	});
};

/*
 * Get domain by id
 */
var getDomainById = function(req, res, callback) {
	logger.info('Domain : DAO : received request : getDomainById : id : '+req.params.id);
	Domain.find({
		'id' : req.params.id
	}, function(err, data) {
		if (err) {
			callback(err, data);
		} else {
			if (data.length != 0) {
				callback(err, data);
			} else {
				var err = new Error('Invalid domain id');
				err.status = 404;
				callback(err, data);
			}
		}
	});
};

/*
 * Update domain details
 */
var updateDomainById = function(req, res, callback) {
	logger.info('domain : DAO : received request : updateDomainById : (id: '+req.params.id+', body: '+JSON.stringify(req.body)+')');
	
	/*
	 * Callback function after getting original record to update with new values.
	 */ 
	var callbackUpdate = function(err, data) {	
		if(err) {
			logger.error('domain : DAO : failed updateDomainById : error :' + err);
			callback(err, null);
		} else if(data != null) {
			/*
			 *	Compare updatable fields values in db with request data
			 *	Add those fields in temproary object which are having new values
			 */			
			var domain = data;
			var json = {};
			var updatedData = [];
			if (req.body.name && domain['name'] != req.body.name) {
				json.name = req.body.name;
				var obj = {};				
				obj.column = 'name';
				obj.oldValue = domain['name'];
				obj.newValue = req.body.name;
				obj.identifier = 'Platform_domain_'+req.params.id;
				obj.modifiedBy = 'admin';
				obj.modifiedOn = new Date();
				updatedData.push(obj);
			}
			if (req.body.description && domain['description'] != req.body.description) {
				json.description = req.body.description;
				var obj = {};
				obj.column = 'description';
				obj.oldValue = domain['description'];
				obj.newValue = req.body.description;
				obj.identifier = 'Platform_domain_'+req.params.id;
				obj.modifiedBy = 'admin';
				obj.modifiedOn = new Date();
				updatedData.push(obj);
			}
			if (req.body.longDescription && domain['longDescription'] != req.body.longDescription) {
				json.longDescription = req.body.longDescription;
				var obj = {};
				obj.column = 'longDescription';
				obj.oldValue = domain['longDescription'];
				obj.newValue = req.body.longDescription;
				obj.identifier = 'Platform_domain_'+req.params.id;
				obj.modifiedBy = 'admin';
				obj.modifiedOn = new Date();
				updatedData.push(obj);
			}
			if (req.body.logo && domain['logo'] != req.body.logo) {
				json.logo = req.body.logo;
				var obj = {};
				obj.column = 'logo';
				obj.oldValue = domain['logo'];
				obj.newValue = req.body.logo;
				obj.identifier = 'Platform_domain_'+req.params.id;
				obj.modifiedBy = 'admin';
				obj.modifiedOn = new Date();
				updatedData.push(obj);
			}
			
			
			/*
			 *	Update the data to database 
			 */
			if (Object.keys(json).length != 0) {
				json.updatedOn = new Date();
				json.updatedBy = 'admin';
				logger.info('domain : DAO : updateDomainById : updating data : ' + JSON.stringify(json));
				Domain.findOneAndUpdate({
					'id' : req.params.id
				}, json, {
					'new' : true
				// returns updated entity if update successful, if false then old entry
				}, function(err, data) {
					if (err) {
						logger.error('domain : DAO : failed updateDomainById : error :' + err);
						callback(err, null);
					} else {
						if(data != null) {
							logger.info('domain : DAO : updateDomainById successful !');		
							/*
							 *	Call audit function for changed data 
							 */
							audit(req, res, updatedData);
							/*
							 *	Call function to send response to client 
							 */
							callback(null, data);
						} else {
							var err = new Error('Bad request data');
							logger.error('domain : DAO : failed updateDomainById : error :' + err);
							callback(err, null);
						}
					}
				});
			} else {
				var err = new Error('Cannot update data');
				logger.error('domain : DAO : failed updateDomainById : error :' + err);
				callback(err, null);
			}
		} else {
			var err = new Error('Failed to get domain details');
			logger.error('company : DAO : failed updateDomainById : error :' + err);
			callback(err, null);
		}
	}
	
	/*
	 * Get the original record from db before update.
	 */ 
	getDomainById(req, res, callbackUpdate);
	
};


/*
 * Delete domain by id
 */
/*var deleteDomainById =function (req,res,callback){
		
	var callbackDelete = function(err, data) {
		if (err) {
			callback(err, data);
		} else {
			
			Domain.remove({'id': req.params.id }, 
			function(err, data) {
				if (err) {
					callback(err, data);
				} else {
					callback(err, data);
				}
			});
		}
	};
	getDomainById(req, res, callbackDelete);
};*/	

module.exports.addNewDomain = addNewDomain;
module.exports.getAllDomains=getAllDomains;
module.exports.getDomainById= getDomainById;
//module.exports.deleteDomainById= deleteDomainById;
module.exports.updateDomainById= updateDomainById;
