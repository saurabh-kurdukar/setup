var domainDao = require('../dao/DomainDAO');
var logger = require('../../common/logger').log;
/*
 * Add new Domain details
 */
var addNewDomain = function(req, res, callback) {
	logger.info('Domain : controller : received request : addNewDomain : body : '+JSON.stringify(req.body));			
	domainDao.addNewDomain(req, res, callback);
}; 	

/*
 * Get all domains
 */
var getAllDomains = function(req, res, callback) {	
	logger.info('Domain : controller : received request : getAllDomains : ');
	domainDao.getAllDomains(req, res ,callback);
};

/*
 * Get domain by id
*/
var getDomainById = function(req, res, callback) {	
	logger.info('Domain : controller : received request : getDomainById : id : '+req.params.id);
	domainDao.getDomainById(req, res ,callback);
};

/*
 * Update domain details
 */
var updateDomainById = function(req, res, callback) {
	logger.info('domain : controller : received request : updateDomainById : (id: '+req.params.id+', body: '+JSON.stringify(req.body)+')');
	domainDao.updateDomainById(req, res, callback);
};

/*
 * Delete domain details
 */
/*var deleteDomainById = function(req, res, callback) {
	logger.info('domain : controller : received request : deleteDomainById : id : '+req.params.id);
	domainDao.deleteDomainById(req, res, callback);
};*/



module.exports.addNewDomain = addNewDomain;
module.exports.getAllDomains= getAllDomains;
module.exports.getDomainById= getDomainById;
//module.exports.deleteDomainById= deleteDomainById;
module.exports.updateDomainById= updateDomainById;

