var mongoose = require('../../common/MongoDbConnection').mongoose;
var logger = require('../../common/logger').log;
var connection = mongoose.connection;
var autoIncrement = require('mongoose-auto-increment');
autoIncrement.initialize(connection);
var encryptDecrypt = require('../../common/EncryptDecrypt');

/*
 * Define schema
 */
var messageSchema = mongoose.Schema({

  messageId: {
    type: Number,
    unique: true
  },
  messageType: String,
  message: {
    type: String,
    set: encryptDecrypt.encryption
  },
  createdBy: String,
  createdOn: {
    type: Date,
    default: Date.now
  },
  updatedBy: String,
  updatedOn: {
    type: Date,
    default: Date.now
  },
  status: {
    type: String,
    default: 'Pending'
  },
  companyId: Number,
  experienceid: Number,
  appId: Number
});

logger.info('message : model : created schema : Messages :' + JSON.stringify(messageSchema.paths));

messageSchema.methods.toJSON = function() {
  var obj = this.toObject();
  obj.message = encryptDecrypt.decryption(obj.message);
  return obj;
}

messageSchema.path('messageType').validate(function(v) {
  return v.length <= 20;
}, 'data too long for field messageType');

messageSchema.plugin(autoIncrement.plugin, {
  model: 'Messages',
  field: 'messageId',
  startAt: 1
});

/*
 * Setters
 */
messageSchema.methods.setMessageId = function(messageId) {
  this.messageId = messageId;
};

messageSchema.methods.setMessage = function(message) {
  this.message = message;
};

messageSchema.methods.setMessageType = function(messageType) {
  this.messageType = messageType;
};

messageSchema.methods.setCreatedBy = function(createdBy) {
  this.createdBy = createdBy;
};

messageSchema.methods.setCreatedOn = function(createdOn) {
  this.createdOn = createdOn;
};

messageSchema.methods.setUpdatedBy = function(updatedBy) {
  this.updatedBy = updatedBy;
};

messageSchema.methods.setUpdatedOn = function(updatedOn) {
  this.updatedOn = updatedOn;
};

messageSchema.methods.setStatus = function(status) {
  this.status = status;
};

messageSchema.methods.setCompanyId = function(companyId) {
  this.companyId = companyId;
};

messageSchema.methods.setExperienceid = function(experienceid) {
  this.experienceid = experienceid;
};

messageSchema.methods.setAppId = function(appId) {
  this.appId = appId;
};

/*
 * Getters
 */
messageSchema.methods.getMessageId = function() {
  return this.messageId;
};

messageSchema.methods.getMessage = function() {
  return this.message;
};

messageSchema.methods.getMessageType = function() {
  return this.messageType;
};

messageSchema.methods.getCreatedBy = function() {
  return this.createdBy;
};

messageSchema.methods.getCreatedOn = function() {
  return this.createdOn;
};

messageSchema.methods.getUpdatedBy = function() {
  return this.updatedBy;
};

messageSchema.methods.getUpdatedOn = function() {
  return this.updatedOn;
};

messageSchema.methods.getStatus = function() {
  return this.status;
};

messageSchema.methods.getCompanyId = function() {
  return this.companyId;
};

messageSchema.methods.getExperienceid = function() {
  return this.experienceid;
};

messageSchema.methods.getAppId = function() {
  return this.appId;
};

/*
 * Create collection/model in mongo db using Schema
 */
var Message = mongoose.model('Messages', messageSchema);

module.exports = Message;
