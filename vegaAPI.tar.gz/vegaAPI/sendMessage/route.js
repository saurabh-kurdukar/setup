var express = require('express');
var sendMessageController= require('./controller/SendMessageController');
var router = express.Router();
var ErrorResponse = require('../common/ErrorResponse').ErrorResponse;
var logger = require('../common/logger').log;

/*
 * send Message
 */
router.post('/', function(req, res){
	logger.info('message : router : received request : sendMessage : body : '+JSON.stringify(req.body));
	sendMessageController.sendMessage(req, res, function(err, data) {
        if(err){
        	logger.error('message : router : failed sendMessage : error : '+err);     
        	var error = new ErrorResponse();
        	if(err.name == 'ValidationError'){
        		error.setErrorMessage(err.errors[Object.keys(err.errors)[0]].message);
        	} else {
        		error.setErrorMessage(err.message);
        	}
        	error.setErrorCode("SM001");        	
        	error.setHttpResponseCode(500);        	
        	res.status(500).end(JSON.stringify(error));      
			
        }else{
        	logger.info("message : router : sendMessage successful !");
        	console.log("sending 200 response back from route.");
        	res.status(200).end(JSON.stringify(data));
        }
    });
});


/*
 * Get message status 
 */
router.get('/', function (req, res) {
	logger.info('message : router : received request : getNessageStatus');
	sendMessageController.getMessageStatus(req, res, function(err, data) {
        if(err){     
        	logger.error('message : router : failed getMessageStatus : error : '+err);  
        	var error = new ErrorResponse();
        	error.setErrorCode("SM002");
        	error.setErrorMessage(err.message);
        	error.setHttpResponseCode(500);
            res.status(500).end(JSON.stringify(error));
        }else{    
        	logger.info("message : router : getMessageStatus successful !") ;
        	res.status(200).end(JSON.stringify(data));
        }
    });
}); 


/*
 * Options method
 */
router.options('/', function(req, res) {
	logger.info('message : router : received request : Options call messages APIs');
	res.header('Allow-Access-Allow-Origin', '*');
	res.header('Access-Control-Allow-Headers', '*');
	res.header('Access-Control-Allow-Methods', 'GET,POST,DELETE,PUT,OPTIONS');
	res.header('Connection', 'keep-alive');
	res.header('Content-Type', 'application/json;charset=UTF-8');
	res.end();
	logger.info('message : router : Options call messages APIs processed !');
});

router.all('/*', function (req, res) {		
	res.status(404).send(JSON.stringify({'error':'No matching resource for url: '+req.originalUrl}));	  	
});


module.exports = router;