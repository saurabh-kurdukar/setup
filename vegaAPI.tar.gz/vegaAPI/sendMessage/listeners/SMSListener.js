var request=require('request');
var amqp = require('amqplib/callback_api');
var RabbitMQ= require('../../common/RabbitMQ');
var sendSMSDelegate = require('../delegate/SendSMSMessageDelegate');
var config= require('../../common/Config');
var messageDao= require('../dao/MessageDAO');
var logger = require('../../common/logger').log;
 /*
  * Receive Message
  */

RabbitMQ.getConnection(function(connection){	
  connection.createChannel(function(err, ch) {	  	  	  
    var q = 'smsqueue';	
    ch.assertQueue(q, {durable: false});	
	console.log(" [*] Waiting for messages in smsqueue");	
ch.consume(q, function(msg) {	
  console.log(" [x] Received %s", msg.content.toString());  
 	
  
  
 //Send SMS 
  sendSMS();  
  
}, {noAck: true});
});	
});


sendSMS=function()
{
	var url= sendSMSDelegate.getSMSConfig();		
	var proxyurl=config.NETWORK_PROXY+":"+config.NETWORK_PROXY_PORT;
	var httpMethod= sendSMSDelegate.getHttpMethod();
	var headerslist= sendSMSDelegate.getHeaderslist();	
	
	request({
		headers: headerslist ,
		 method: httpMethod,
		'url':url
		//Proxy block to be removed
		//,'proxy':proxyurl
		}, function (error, response, body) {		
			if (!error) 	{			
				console.log(body);
				logger.info('message : LISTENER : send message response'+body);		
				var status= 'Sent' ;
				
				messageDao.updateMessageStatus(status,sendSMSDelegate.getSmsId(),function(err,data){
					if(err){
						console.log('unable to update status');
						logger.error('message : LISTENER : failed updateMessageStatus : error : '+err);   
					}
					else{
					console.log('status updated as sent');
					logger.info('message : LISTENER : updateMessageStatus successful !');		
					}
					
				
			})
			}
			else{								
				console.log(error);					
				var status='Failed';		
				messageDao.updateMessageStatus(status,sendSMSDelegate.getSmsId(),function(err,data){
					if(err){
						console.log('unable to update status');
						logger.error('message : LISTENER : failed updateMessageStatus : error : '+err);   
					}
					else{
						console.log('status updated as failed');
						logger.info('message : LISTENER : updateMessageStatus successful !');
					}
				})
			}
		});	 //Proxy block ends here
	};