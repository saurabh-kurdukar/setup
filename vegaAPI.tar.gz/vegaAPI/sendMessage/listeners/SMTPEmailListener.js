var amqp = require('amqplib/callback_api');
var RabbitMQ= require('../../common/RabbitMQ');
var email   = require('emailjs/email');
var config= require('../../common/Config');
var messageDao= require('../dao/MessageDAO');
var fs= require('fs');
var async= require('async');
var emailDelegate= require('../delegate/SendEmailMessageDelegate');
var logger = require('../../common/logger').log;

var individualFileSizeFlag= true;
var totalFileSizeFlag= true;
var fileTypesAllowedFlag= true;
var totalFileSize= 0;


 /*
  * Receive Email
  */
RabbitMQ.getConnection(function(connection){	
	connection.createChannel(function(err, ch) {	  	  	  
    var q = 'smtpqueue';	
    ch.assertQueue(q, {durable: false});	
	console.log(" [*] Waiting for messages in smtpqueue");	
ch.consume(q, function(msg) {
  console.log(" [x] Received %s", msg.content.toString()); 
    
  async.series([getFlags, 
                sendEmail], function(err, results){
      console.log('Result of the whole run is ' + results);
  })    
 
}, {noAck: true});

  });
});


sendEmail=function(callback)
{				
	 if(individualFileSizeFlag && totalFileSizeFlag && fileTypesAllowedFlag)
		 {			 
			var server  = email.server.connect({		  	  
				   host:    config.SMTP_HOST,		 
				   port: config.SMTP_PORT ,		 		
				   user:  emailDelegate.getFrom() , 
				   password: emailDelegate.getPassword() , 		  		 
				   protocol: "SMTP" ,
				   Tls: true 		  			   		   
			});
			
			// send the message and get a callback with an error or details of the message that was sent
			server.send({
			   text:    emailDelegate.getMessage(), 
			   from:   emailDelegate.getFrom(), 
			   to:      emailDelegate.getTo(),	  	  
			   subject: emailDelegate.getSubject ,
			   cc : emailDelegate.getCc() ,
			   bcc: emailDelegate.getBcc() ,
			   attachment: emailDelegate.getAttachments()		  
			   
			}, function(err, message) {
				if(err){
				console.log(err);				
				
						var status='Failed';		
				messageDao.updateMessageStatus(status,emailDelegate.getMessageId(),function(err,data){
					if(err){
						console.log('unable to update status');
						logger.error('message : LISTENER : failed updateMessageStatus : error : '+err);   
					}
					else{
						console.log('status updated as failed');
						logger.info('message : LISTENER : updateMessageStatus successful !');		
					}
				})
				}
				else{
					console.log(message);			
							var status= 'Sent' ;
					
					messageDao.updateMessageStatus(status,emailDelegate.getMessageId(),function(err,data){
						if(err){
							console.log('unable to update status');
							logger.error('message : LISTENER : failed updateMessageStatus : error : '+err);   
						}
						else{
						console.log('status updated as sent');
						logger.info('message : LISTENER : updateMessageStatus successful !');
						}
				})
				}
				});
		 
		 }	 
};


getFlags= function(callbackGetFlags)
{			
	var attachments=emailDelegate.getAttachments();
	individualFileSizeFlag= true;
	 totalFileSizeFlag= true;
	 fileTypesAllowedFlag= true;
	 totalFileSize= 0;
	 	 
	//check for empty attachments
	if(typeof attachments !=='undefined')
		{	
	//check for no of attachments 
	if(attachments.length < config.EMAIL_NUMBER_OF_ATTACHMENTS)
		{	
			
		async.each(attachments, function(attachment, callback){
		//check for individual file size
			 if(individualFileSizeFlag) {
			 var file= attachment.path;
		     	fs.stat(file, function (err, stats) {
		   		console.log('size*****'+stats.size);
		   		totalFileSize+= stats.size;
		   		console.log('totalFileSize'+totalFileSize);
		   		if(stats.size > config.EMAIL_INDIVIDUAL_FILE_SIZE)
	     		{
		   			individualFileSizeFlag= false;
		   		 console.log('individualFileSizeflag'+individualFileSizeFlag);
		   		 callback();
	     		}
		   		else{
		   			console.log('individualFileSizeflag'+individualFileSizeFlag);
		   			//check for total file size
		   			if(totalFileSize > config.EMAIL_TOTAL_ATTACHMENT_SIZE)
		   			 {
		   			 totalFileSizeFlag= false;
		   			 console.log('totalFileSizeFlag'+totalFileSizeFlag);
		   			 callback();
		   			 }
		   			else
		   			{
		   			 console.log('totalFileSizeFlag'+totalFileSizeFlag);
		   			 callback();
		   			 }
		   			}
		     	});
			 }else{
				callback(); 
			 }	
		  }, function (error) {
			  console.log("loop completed");
			  callbackGetFlags();
			});			 	
		  }
		}else{
			callbackGetFlags();
		}
	
	//check for file types allowed	
	if(typeof attachments !=='undefined')
	{	
	 for(var i=0; i<attachments.length; i++)
	  {
		 var fileTypesAllowed= config.EMAIL_FILE_TYPES_ALLOWED;	
		 if(fileTypesAllowedFlag)
			 {
		 fileTypesAllowedFlag= false;
		 for(var j=0; j<fileTypesAllowed.length; j++){		   				 
			 if(!fileTypesAllowedFlag)
				 {										
			 if(attachments[i].type !==fileTypesAllowed[j]){
				 fileTypesAllowedFlag= false;
				 console.log('fileTypesAllowed'+fileTypesAllowedFlag);
			 }
			 else
				 {
				 fileTypesAllowedFlag= true;
				 console.log('fileTypesAllowed'+fileTypesAllowedFlag);
				 }
				 }
		 }
			 }
	  }		
	}
	}