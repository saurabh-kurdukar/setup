var Message = require('../models/Message');
var url = require('url');
var logger = require('../../common/logger').log;
var audit = require('../../common/Audit').audit;
var encryptDecrypt = require('../../common/EncryptDecrypt');

/*
 * Add message details
 */
var addNewMessage = function(req, res, callback) {
  logger.info('message : DAO : received request : sendMessage : body : ' + JSON.stringify(req.body));
  var CompanyID = req.headers['companyid'];
  var reqBody = req.body;
  var message = new Message();
  
  message.setMessage(reqBody.Message);
  message.setMessageType(reqBody.MessageType);
  message.setCreatedBy(req.body.To);
  message.setCreatedOn(new Date());
  message.setUpdatedBy(req.body.To);
  message.setUpdatedOn(new Date());
  message.setCompanyId(CompanyID);
  message.setExperienceid(reqBody.experienceid);
  message.setAppId(reqBody.AppId);

  message.save(function(err, data) {
    if (err) {
      logger.error('message : DAO : failed addNewMessage : error : ' + err);
      callback(err, null);
    } else if (data != null) {
      logger.info('message : DAO : addNewMessage successful !');
      callback(null, data);
    } else {
      var err = new Error('Failed to addNewMessage  details');
      logger.error('message : DAO : failed addNewMessage : error : ' + err);
      callback(err, null);
    }
  });
};

/*
 * Update Mesage Status 
 */
var updateMessageStatus = function(status, messageId, callback) {
  logger.info('message : DAO : received request : updateMessageStatus : (status: ' + status + ', messageId: ' + messageId + ')');
  var json = {};
  json.status = status;

  if (Object.keys(json).length != 0) {
    json.updatedOn = new Date();    		

    Message.findOneAndUpdate({
      'messageId': messageId,
    }, json, {
      'new': true
        // returns updated entity if update successful
    }, function(err, data) {
      if (err) {
        logger.error('message : DAO : failed updateMessageStatus : error :' + err);
        callback(err, null);
      } else {
        if (data != null) {
          logger.info('message : DAO : updateMessageStatus successful !');
          callback(null, data);
        } else {
          var err = new Error('Bad request data');
          logger.error('message : DAO : failed updateMessageStatus : error :' + err);
          callback(err, null);
        }
      }
    });
  } else {
    var err = new Error('Cannot update data');
    logger.error('message : DAO : failed updateMessageStatus : error :' + err);
    callback(err, null);
  }
};

/*
 * get message status
 */
var getMessageStatus = function(req, res, callback) {
  logger.info('message : DAO : received request : getMessageStatus ');
  var CompanyID = req.headers['companyid'];
  var query = url.parse(req.url, true).query;
  var status = query.status;
  var experienceid = query.experienceid;
  var appId = query.appId;
    
  Message.find({
    'companyId': CompanyID,
    'status': status,
    'experienceid': experienceid,
    'appId': appId,
  }, function(err, data) {
    if (err) {
      logger.error('message : DAO : failed getMessageStatus : error : ' + err);
      callback(err, data);
    } else {
      if (data.length != 0) {
        logger.info('message : DAO : getMessagestatus successful !');
        callback(err, data);
      } else {
        var err = new Error('Invalid id or status');
        err.status = 404;
        logger.error('message : DAO : failed getMessageStatus : error : ' + err);
        callback(err, data);
      }
    }
  });
};

/*
 * get message details by createdBy
 */
var getMessageByCreatedBy = function(req, res, callback) {
  logger.info('message : DAO : received request : getMessageByCreatedBy ');

  Message.findOne({
    'createdBy': req.params.username
  }, function(err, data) {
    if (err) {
      logger.error('message : DAO : failed getMessageByCreatedBy : error : ' + err);
      callback(err, null);
    } else {
      if (data && data.length != 0) {
        logger.info('message : DAO : getMessageByCreatedBy successful !');		
        callback(null, data);
      } else {
        var err = new Error('No message found for username');
        err.status = 404;
        logger.error('message : DAO : failed getMessageByCreatedBy : error : ' + err);
        callback(err, null);
      }
    }
  });
};

/*
 * Update message details
 */
var updateMessage = function(req, res, callback) {
  logger.info('message : DAO : received request : updateMessage : body : ' + JSON.stringify(req.body));

  var callbackUpdate = function(err, data) {
      if (err) {
        logger.error('message : DAO : failed updateMessage : error :' + err);
        callback(err, null);
      } else if (data != null) {
        /*
         *	Compare updatable fields values in db with request data
         *	Add those fields in temproary object which are having new values
         */
        var token = data;
        var json = {};
        var updatedData = [];
		var msg= encryptDecrypt.encryption(req.body.message);
		
        if (req.body.message && token['message'] != req.body.message) {
          json.message = msg;
          var obj = {};
          obj.column = 'message';
          obj.oldValue = token['message'];
          obj.newValue = req.body.message;
          obj.identifier = 'Platform_token_' + req.params.id;
          obj.modifiedBy = 'admin';
          obj.modifiedOn = new Date();
          updatedData.push(obj);
        }
        /*
         *	Update data to database 
         */
        if (Object.keys(json).length != 0) {
          json.updatedOn = new Date();		
          logger.info('message : DAO : updateMessage : updating data : ' + JSON.stringify(json));
          Message.findOneAndUpdate({
            'createdBy': req.params.username
          }, json, {
            'new': true
              // returns updated entity if update successful, if false then old entry
          }, function(err, data) {
            if (err) {
              logger.error('message : DAO : failed updateMessage : error :' + err);
              callback(err, null);
            } else {
              if (data != null) {
                logger.info('message : DAO : updateMessage successful !');
                /*
                 *	Call audit function for changed data 
                 */
                audit(req, res, updatedData);
                /*
                 *	Call function to send response to client 
                 */
                callback(null, data);
              } else {
                var err = new Error('Bad request data');
                logger.error('message  : DAO : failed updateMessage : error :' + err);
                callback(err, null);
              }
            }
          });
        } else {
          var err = new Error('Cannot update data');
          logger.error('message  : DAO : failed updateMessage : error :' + err);
          callback(err, null);
        }
      } else {
        var err = new Error('Failed to get message details');
        logger.error('message  : DAO : failed updateMessage : error :' + err);
        callback(err, null);
      }
    }
    /*
     * Get the original record from db before update.
     */
  getMessageByCreatedBy(req, res, callbackUpdate);
};

module.exports.addNewMessage = addNewMessage;
module.exports.updateMessageStatus = updateMessageStatus;
module.exports.getMessageStatus = getMessageStatus;
module.exports.getMessageByCreatedBy = getMessageByCreatedBy;
module.exports.updateMessage = updateMessage;
