var RabbitMQ= require('../../common/RabbitMQ');
var amqp = require('amqplib/callback_api');
var SMSGateway = require('../../smsGateway/models/SMSGateway');
var SMSGatewayDAO= require('../../smsGateway/dao/SMSGatewayDAO');
var Decrypt= require('../../common/EncryptDecrypt');
var messageDao= require('../dao/MessageDAO');
var logger = require('../../common/logger').log;

var httpMethod= 'POST';
var headerslist = {};
var smsGwatewayURL='';
var to='';
var message='';
var attributes=[];
var smsId=0;
/*
 * Send Message
 */
var sendMessage = function(req, res, callback) {		
	logger.info('message : DELEGATE : received request : sendMessage : body : '+ JSON.stringify(req.body));
	SMSGatewayDAO.getSMSServerDetails(req, res, function(err,data){				
		if (err) {
			callback(err, data);
		} 
		else {
			if (data.length != 0) {		
				
					messageDao.addNewMessage(req, res, function(error,val) {
					
					if(error)
						{
						logger.error('message : router : failed addNewMessage : error : '+error);     
						callback(error,val);
						}
					else
						{	
				
				var queueName='smsqueue';		
				 var messageId=req.body.MessageId;	
				 smsGwatewayURL= data.SMSGwatewayURL;
				 httpMethod= data.HTTPMethod;
				 contentType=data.contentType;
				 to= req.body.To;	
				 message= req.body.Message;					 
				 attributes= data.attributes;				 				 
				 					
				 smsId=messageId;
					RabbitMQ.getConnection(function(connection){						
								connection.createChannel(function(err, ch) {									
									    ch.assertQueue(queueName, {durable: false});
									    ch.sendToQueue(queueName, new Buffer(req.body.Message));
									    console.log(" [x] Message Sent");									
										callback(err, 'Message submitted successfully');
										setTimeout(function() { connection.close();  }, 500);  																														
									  });									
					});		
						}
					})
				
			} else {
				var err = new Error('Invalid company id');
				err.status = 404;
				logger.error('message : DELEGATE : failed : error : '+ err);
				callback(err, data);
			}
		}
	});	
};


/*
 * get SMS config
 */
var getSMSConfig= function()
{			
	var url=getSmsGwatewayURL();			    
	headerName='';
	 var j=0;
	 var decpwd='';
	 var attributes= getAttributes();
	//iterate over attributes
	 for(var i = 0; i < attributes.length; i++) {					 
		    var obj = attributes[i];
		   
		    if(obj.attributeParamType=="queryParam")
		    	{
		    if(j==0)	
		    	{
		    	if(obj.attributeKey=="password")
		    		{		    		
		    		//decrypt password
		    		decpwd=Decrypt.decryption(obj.attributeValue);		    		
		    		 url +="?"+obj.attributeKey+"="+decpwd;
		    		 j++;
		    		}
		    	else{
		    	url +="?"+obj.attributeKey+"="+obj.attributeValue;
		    	j++;}
		    	}
		    else	
		    	{
		    	if(obj.attributeKey=="password")
	    		{
	    		//decrypt password
	    		 decpwd= Decrypt.decryption(obj.attributeValue);	    		
	    		 url +="&"+obj.attributeKey+"="+decpwd;	    		 
	    		}
		    	else		    		
		    url +="&"+obj.attributeKey+"="+obj.attributeValue;		    	
		    	}
	 }
		    else
		    	{
		    	if(obj.attributeKey=="password")
		    		{
		    		//decrypt password
		    		decpwd= Decrypt.decryption(obj.attributeValue);
		    		 headerName= obj.attributeKey;		   
		    		 headerslist[headerName] = decpwd;      
		    		}
		    	else
		    		{
		    	headerName= obj.attributeKey;		    		
		    	headerslist[headerName] = obj.attributeValue;
		    		}
		    	}
	 }		
	 if(j==0)
		 url +="?"+"mobileno=" + getTo() + "&message=" +getMessage();
	 else		 
	 url +="&mobileno=" + getTo() + "&message=" +getMessage();			
	console.log(url);		
	console.log(headerslist);	
		
	return url;
	};	
	
	
 var getHttpMethod=function() {		 
		return httpMethod;
	};
	
	var getHeaderslist=function(){
		return headerslist;
	}
	
	var getSmsGwatewayURL=function(){
		return smsGwatewayURL;
	}
	
	var getTo=function(){
		return to;
	}
	
	var getMessage=function(){
		return message;
	}
	
	var getAttributes=function(){
		return attributes;
	}
	
	var getSmsId=function(){
		return smsId;
	}
	
module.exports.sendMessage = sendMessage;
module.exports.getSMSConfig= getSMSConfig;
module.exports.getHttpMethod= getHttpMethod;
module.exports.getHeaderslist= getHeaderslist;
module.exports.getSmsId= getSmsId;