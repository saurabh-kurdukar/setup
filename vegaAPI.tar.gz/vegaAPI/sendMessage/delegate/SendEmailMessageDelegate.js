var amqp = require('amqplib/callback_api');
var SMTPServerDao= require('../../smtpServer/dao/SMTPServerDAO');
var RabbitMQ= require('../../common/RabbitMQ');
var Decrypt= require('../../common/EncryptDecrypt');
var messageDao= require('../dao/MessageDAO');
var logger = require('../../common/logger').log;

var to= '';
var from ='';
var message='';
var subject= '';
var cc= '';
var bcc='';
var password='';
var attachments=[];
var messageId=0;

/*
 * Send Email
 */

var sendMessage = function(req, res, callback) {	
	logger.info('message : DELEGATE : received request : sendMessage : body : '+ JSON.stringify(req.body));	
	SMTPServerDao.getSMTPServerDetails(req, res, function(err,data){		
		if (err) {
			callback(err, data);
		} 
		else {
			if (data.length != 0) {		
				
				messageDao.addNewMessage(req, res, function(error,val) {
					
					if(error)
						{
						logger.error('message : router : failed addNewMessage : error : '+error);     
						callback(error,val);
						}
					else
						{							
						var queueName='smtpqueue';									
						 to= req.body.To;	
						 messageId=req.body.MessageId;						 
						 message= req.body.Message;
						 from= data.Username;		
						 subject= req.body.Subject;
						 cc=req.body.CC;
						 bcc= req.body.BCC;
						 attachments= req.body.Attachments;				 
						  password=Decrypt.decryption(data.Password);				
						  			
						 // msgId=messageId;
						 RabbitMQ.getConnection(function(connection){	
							 connection.createChannel(function(err, ch) {							  

									    ch.assertQueue(queueName, {durable: false});
									    ch.sendToQueue(queueName, new Buffer(req.body.Message));
									    console.log(" [x] Message Sent");								
										callback(err, "Message Submitted successfully");
										setTimeout(function() { connection.close();  }, 500);  																									
									  });
									});
						}
				})								 
				 
			} else {
				var err = new Error('Invalid company id');
				err.status = 404;
				logger.error('message : DELEGATE : failed : error : '+ err);
				callback(err, data);
			}
		}
	});	
};	

var getTo=function(){
	return to;
}

var getFrom=function(){
	return  from;
}

var getMessage= function(){
	return message;
}

var getSubject= function(){
	return subject;
}

var getCc=function(){
	return cc;
}

var getBcc=function(){
	return bcc;
}

var getPassword=function(){
	return password;
} 

var getAttachments=function(){
	return attachments;
}

var getMessageId=function(){
	return messageId;
}

module.exports.sendMessage = sendMessage;
module.exports.getTo= getTo;
module.exports.getFrom= getFrom;
module.exports.getMessage= getMessage;
module.exports.getSubject= getSubject;
module.exports.getCc=getCc;
module.exports.getBcc=getBcc;
module.exports.getPassword=getPassword;
module.exports.getAttachments= getAttachments;
module.exports.getMessageId= getMessageId;
