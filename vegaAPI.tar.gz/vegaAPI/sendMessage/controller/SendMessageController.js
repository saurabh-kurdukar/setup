var Dot = require('dot');
var smsgatewayDao = require('../../smsGateway/dao/SMSGatewayDAO');
var sendEmailMessageDelegate= require('../delegate/SendEmailMessageDelegate');
var sendSmsMessageDelegate= require('../delegate/SendSMSMessageDelegate');
var messageDao= require('../dao/MessageDAO');
var config = require('../../common/Config');
var logger = require('../../common/logger').log;
var Decrypt= require('../../common/EncryptDecrypt');
const MODULE_NAME = 'sendMessage';

Dot.templateSettings = {
	  evaluate:    /\{\{([\s\S]+?)\}\}/g,
	  interpolate: /\{\{=([\s\S]+?)\}\}/g,
	  encode:      /\{\{!([\s\S]+?)\}\}/g,
	  use:         /\{\{#([\s\S]+?)\}\}/g,
	  define:      /\{\{##\s*([\w\.$]+)\s*(\:|=)([\s\S]+?)#\}\}/g,
	  conditional: /\{\{\?(\?)?\s*([\s\S]*?)\s*\}\}/g,
	  iterate:     /\{\{~\s*(?:\}\}|([\s\S]+?)\s*\:\s*([\w$]+)\s*(?:\:\s*([\w$]+))?\s*\}\})/g,
	  varname: 'object',
	  strip: true,
	  append: true,
	  selfcontained: false
};

/*
 * Send Message
 */
var sendMessage = function(req, res, callback) {
	
	logger.info('message : controller : received request : sendMessage : body : '+JSON.stringify(req.body));
	var reqBody = req.body;
	var messageType= reqBody.MessageType;		
	
	if(messageType.toUpperCase()=="SMS")
		{		
		sendSmsMessageDelegate.sendMessage(req, res, callback);				
		}
	else if(messageType.toUpperCase()=="EMAIL")
		{		
		sendEmailMessageDelegate.sendMessage(req, res, callback);
		}
	else
		{				
		var error= new Error("Invalid Message Type");
		if (error) {
			callback(error, messageType);
		}	
		}
	
};

/*
 * getMessage status
 */

var getMessageStatus = function(req, res, callback) {	
	logger.info('message : controller : received request : getMessageStatus');
	messageDao.getMessageStatus(req, res ,callback);
}; 

var createSMSRequest = function(smsGatewayId, mobileNo, message, req, callback) {	
	smsgatewayDao.getSMSServerDetailsBySMSGatewayId(smsGatewayId, function(err, data){				
		 if (err) {					
			 return callback(err);
		 }			
		 var url= data.SMSGwatewayURL;
		 var httpMethod= data.HTTPMethod;
		 var contentType=data.contentType;
		 var attributes= data.attributes;
		 var requestObj = {};
		 if(data.MessageRetries) {
			 requestObj.SMSMessageRetries = data.MessageRetries;
		 } else {
			 requestObj.SMSMessageRetries = config.SMS_DEFAULT_MAX_RETRY_COUNT;
		 }
		 
		 //form Url							    
		 var headerName='', j=0, decpwd='', headerslist = {}, tempFn, formData = {},
		 jsonData = {}, jsonBodyFlag = false, formDataFlag = false, mobileNumberPrefix = '';		 
		 for(var i = 0; i < attributes.length; i++) {
			    var obj = attributes[i];
			    if(obj.usePlusPrefix) {
			    	if(mobileNo.indexOf('+') == -1) {
			    		mobileNumberPrefix = '+';
			    	}
			    } else {
			    	if(mobileNo.indexOf('+') > -1) {
			    		mobileNo = mobileNo.replace('+', '');
			    	}
			    }
			    if(obj.attributeParamType == "queryParam") {
			    	if(j==0) {
			    		if(obj.attributeKey=="password") {
				    		 //decrypt password
				    		 decpwd = Decrypt.decryption(obj.attributeValue);		    		
				    		 url += "?"+obj.attributeKey+"="+decpwd;
				    		 j++;
			    		} else if(obj.attributeKey === "toNumber") {			    			
			    			url += "?" + obj.mappedTo + "=" + mobileNumberPrefix + "" + mobileNo;
				    		j++;
			    		} else if(obj.attributeKey === "messageBody") {
			    			url += "?" + obj.mappedTo + "=" + message;
				    		j++;
			    		} else {
					    	url += "?"+obj.attributeKey+"="+obj.attributeValue;
					    	j++;
					    }
				    } else {
				    	if(obj.attributeKey == "password") {
				    		 //decrypt password
				    		 decpwd= Decrypt.decryption(obj.attributeValue);	    		
				    		 url += "&"+obj.attributeKey+"="+decpwd;	    		 
			    		} else if(obj.attributeKey == "toNumber") {			    			
			    			url += "&" + obj.mappedTo + "=" + mobileNumberPrefix + "" + mobileNo;
				    		j++;				    		
			    		} else if(obj.attributeKey == "messageBody") {			    			
			    			url += "&" + obj.mappedTo + "=" + message;
				    		j++;
			    		} else	{	    		
			    			 url += "&"+obj.attributeKey+"="+obj.attributeValue;	
			    		}
			    	}
			    } else if (obj.attributeParamType == "pathParam") {
			    	tempFn = Dot.template(url);	
					url = tempFn(JSON.parse(obj.attributeValue));					
			    } else if (obj.attributeParamType == "formParam") {
			    	formDataFlag = true;
			    	if(obj.attributeKey === "toNumber") {
			    		formData[obj.mappedTo] = mobileNumberPrefix + "" + mobileNo;
			    	} else if(obj.attributeKey === "messageBody") {
			    		formData[obj.mappedTo] = message;
			    	} else {
			    		formData[obj.attributeKey] = obj.attributeValue;
			    	}
			    } else if (obj.attributeParamType == "bodyParam") {
			    	jsonBodyFlag=true;
			    	if(obj.attributeKey === "toNumber") {
			    		jsonData[obj.mappedTo] = mobileNumberPrefix + "" + mobileNo;
			    	} else if(obj.attributeKey === "messageBody") {
			    		jsonData[obj.mappedTo] = message;
			    	} else {
			    		jsonData[obj.attributeKey] = obj.attributeValue;
			    	}
			    } else {
			    	if(obj.attributeKey == "password") {
			    		 //decrypt password
			    		 decpwd= Decrypt.decryption(obj.attributeValue);
			    		 headerName= obj.attributeKey;		   
			    		 headerslist[headerName] = decpwd;      
			    	} else if(obj.attributeKey == "toNumber") {
			    		 headerName= obj.mappedTo;		    		
				    	 headerslist[headerName] = mobileNumberPrefix + "" + mobileNo;
		    		} else if(obj.attributeKey == "messageBody") {
		    			 headerName= obj.mappedTo;		    		
				    	 headerslist[headerName] = message;
		    		} else {
				    	 headerName= obj.attributeKey;		    		
				    	 headerslist[headerName] = obj.attributeValue;
			    	}
			    }
		 }
		 if(contentType) {
			 headerslist['Content-Type'] = contentType;
		 }
		 
		 logger.info(MODULE_NAME + ' : controller : createSMSRequest : sms server url: ' + url);		 
		 //console.log('form data='+JSON.stringify(formData));		 
		 var requestOptions = {
			method : httpMethod,
			url : url,
			headers: headerslist,			
		 };
		 if(jsonBodyFlag) {
			 requestOptions.json = jsonData;
		 } else if (formDataFlag) {
			 requestOptions.form = formData;
		 }		 
		 if(config.NETWORK_PROXY_ENABLE) {
			requestOptions.proxy = config.NETWORK_PROXY+":"+config.NETWORK_PROXY_PORT;
		 }
		 requestObj.requestOptions = requestOptions;
		 req.requestObj = requestObj;
		 logger.info(MODULE_NAME + ' : controller : createSMSRequest : requestObj: ' + JSON.stringify(requestObj));
		 callback(null, req);
	});
}

module.exports.sendMessage = sendMessage;
module.exports.getMessageStatus= getMessageStatus;
module.exports.createSMSRequest = createSMSRequest;




