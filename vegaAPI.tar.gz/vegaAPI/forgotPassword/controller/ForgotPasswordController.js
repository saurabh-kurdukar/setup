var forgotPasswordDelegate = require('../delegate/ForgotPasswordDelegate');
var logger = require('../../common/logger').log;
var MODULE_NAME='forgotPassword';
var registrationDao= require('../../registration/dao/RegistrationDAO');

/*
 * 	Send Email to Reset Password
 */
var forgotPassword = function(req, res, callback) {
	logger.info(MODULE_NAME+': controller : received request : forgotPassword : body : '+JSON.stringify(req.body));
	req.params.username= req.body.username;	
	registrationDao.getAllUserByUsername(req, res, function(err, data) {
		 if (err) {
      logger.error('Registration : DAO : failed getUserByUsername : error : ' + err);
      callback(err, null);
    } else {
		logger.info('Registration : DAO : getUserByUsername successful !');	
      if (data[0].verified) {
		  forgotPasswordDelegate.forgotPassword(req, res, callback);
	  }
	  else {
        var err = new Error('User Not Verified');
        err.status = 500;
        callback(err, null);
      }
	}
	})
	
};

module.exports.forgotPassword = forgotPassword;