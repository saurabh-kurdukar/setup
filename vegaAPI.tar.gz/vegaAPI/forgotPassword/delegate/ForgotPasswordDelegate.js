var logger = require('../../common/logger').log;
var request = require('request');
var config = require('../../common/Config');
var MODULE_NAME='forgotPassword';

/*
 * Send Email
 */
var forgotPassword = function(req, res, callback) {
  logger.info(MODULE_NAME+ ' : Delegate : received request : forgotPassword : body : ' + JSON.stringify(req.body));

  req.body.message= config.FORGOT_PASSWORD_MESSAGE;
  var proxyurl = config.NETWORK_PROXY + ":" + config.NETWORK_PROXY_PORT;
  request({
        //'proxy':proxyurl ,
        url: config.FORGRROCK_URL+'/api/v1/selfservice/forgot-password',
        method: 'POST',
        headers: {
          'Content-Type': 'application/json'          
        },
        json: req.body
      }, function(error, response, body) {		  
        if (error) {
		  logger.error(MODULE_NAME +': Delegate : failed forgotPassword : error : ' + error);
          callback(error, null);
        } else {		  
          if (response.statusCode == 200){
			logger.info(MODULE_NAME+': DAO : forgotPassword successful !');
            callback(null, 'An Email Is Sent To Reset Password');
		  }
          else {
			logger.error(MODULE_NAME +': Delegate : failed forgotPassword : error : ' + body);
			if(response.statusCode == 404)
			{	
			var err = new Error('User not found');
            err.status = body.code;		  
            callback(err, null);           	
			}
			else if(response.statusCode == 409)
			{
			var err = new Error('Multiple users found');
            err.status = body.code;		  
            callback(err, null); 
			}
			else if(response.statusCode == 400)
			{
			var err = new Error('Bad Request');
            err.status = body.code;		  
            callback(err, null); 
			}
			else if(response.statusCode == 410)
			{
			var err = new Error('Token is expired or already used');
            err.status = body.code;		  
            callback(err, null); 
			}
			else
			{
			var err = new Error('Error occured while resetting a password');
            err.status = body.code;		  
            callback(err, null);
			}
		  }
        }
      });
};

/*
 * Reset Password
 */
var forgotPasswordReset = function(req, res, callback) {
  logger.info(MODULE_NAME+ ' : Delegate : received request : forgotPasswordReset : body : ' + JSON.stringify(req.body));  
  req.body.username= req.params.username;  
  req.body.tokenId = unescape(req.body.tokenId);
  req.body.confirmationId= unescape(req.body.confirmationId);
  
  var proxyurl = config.NETWORK_PROXY + ":" + config.NETWORK_PROXY_PORT;
  request({
        //'proxy':proxyurl ,
        url: config.FORGRROCK_URL+'/api/v1/selfservice/forgot-password-reset',
        method: 'POST',
        headers: {
          'Content-Type': 'application/json'          
        },
        json: req.body
      }, function(error, response, body) {	  
        if (error) {			
		  logger.error(MODULE_NAME +': Delegate : failed forgotPasswordReset : error : ' + error);		  	  
          callback(error, null);
        } else {		  
          if (response.statusCode == 200){
			logger.info(MODULE_NAME+': DAO : forgotPasswordReset successful !');
            callback(null, 'Reset Password Successful');
		  }
          else {
			logger.error(MODULE_NAME +': Delegate : failed forgotPasswordReset : error : ' + body);  
			if(response.statusCode == 404)
			{	
			//var err = new Error('User not found');
			var err = new Error(body.message);
            err.status = body.code;		  
            callback(err, null);           	
			}
			else if(response.statusCode == 409)
			{
			var err = new Error('Multiple users found');
            err.status = body.code;		  
            callback(err, null); 
			}
			else if(response.statusCode == 400)
			{
			var err = new Error('Bad Request');
            err.status = body.code;		  
            callback(err, null); 
			}
			else if(response.statusCode == 410)
			{
			var err = new Error('Token is invalid or expired');
            err.status = body.code;		  
            callback(err, null); 
			}
			else
			{
			var err = new Error('Error occured while resetting a password');
            err.status = body.code;		  
            callback(err, null);
			}	       	
		  }
        }
      });
};

module.exports.forgotPassword = forgotPassword;
module.exports.forgotPasswordReset= forgotPasswordReset;