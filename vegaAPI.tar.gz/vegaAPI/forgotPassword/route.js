var express = require('express');
var ForgotPasswordController = require('./controller/ForgotPasswordController');
var logger = require('../common/logger').log;
var ErrorResponse = require('../common/ErrorResponse').ErrorResponse;
var router = express.Router();
var MODULE_NAME='forgotPassword';

/*
 * 	Send Email to Reset Password
 */
router.post('/', function(req, res) {
	logger.info(MODULE_NAME+': router : received request : forgotPassword : body : '+JSON.stringify(req.body));	
	ForgotPasswordController.forgotPassword(req, res, function(err, data) {
        if(err) {
        	logger.error(MODULE_NAME+': router : failed forgotPassword : error : '+err);     
        	var error = new ErrorResponse();
        	if(err.name == 'ValidationError'){
        		error.setErrorMessage(err.errors[Object.keys(err.errors)[0]].message);
        	} else {
        		error.setErrorMessage(err.message);
        	}
        	error.setErrorCode("FP001");        	
        	error.setHttpResponseCode(500);        	
        	res.status(500).end(JSON.stringify(error));        
        } else {        	
        	logger.info(MODULE_NAME+' : router : forgotPassword successful !');
        	res.status(200).end(JSON.stringify(data));
        }
    });
});

module.exports = router;