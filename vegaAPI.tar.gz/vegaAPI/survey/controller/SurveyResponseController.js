var surveyResponseDAO = require('../dao/SurveyResponseDAO');
//var appgroupDao = require('../../appgroup/dao/AppGroupDAO');
//var apimanagerDao = require('../../apiMgrConfig/dao/ApiManagerDAO');
//var smsgatewayDao=require('../../smsGateway/dao/SMSGatewayDAO');
//var SMTPServerDao= require('../../smtpServer/dao/SMTPServerDAO');
var logger = require('../../common/logger').log;


/*
 * logging format followed: logger.info(<module_name>: <component name> : <description> : [<long_description>] : <data/params/errors>);
 */


/*
 * Add new surveyResponse details
 */
var addNewSurveyResponse = function(req, res, callback) {
    logger.info('surveyResponse : controller : received request : addNewSurveyResponse : body : ' + JSON.stringify(req.body));
    surveyResponseDAO.addNewSurveyResponse(req, res, callback);
};

/*
 * Get surveyResponse by surveyResponse id
 */
var getSurveyResponseById = function(req, res, callback) {
    logger.info('surveyResponse : controller : received request : getSurveyResponseById : id : ' + req.params.id);
    surveyResponseDAO.getSurveyResponseById(req, res, callback);
};

/*
 * Get all surveyResponses
 */
var getAllSurveyResponses = function(req, res, callback) {
    logger.info('surveyResponse : controller : received request : getAllSurveyResponses : ');
    surveyResponseDAO.getAllSurveyResponses(req, res, callback);
};

/*
 * Update surveyResponse details
 */
var updateSurveyResponseById = function(req, res, callback) {
    logger.info('surveyResponse : controller : received request : updateSurveyResponseById : (surveyResponseById: ' + req.params.id + ', body: ' + JSON.stringify(req.body) + ')');
    surveyResponseDAO.updateSurveyResponseById(req, res, callback);
};

/*
 * Delete surveyResponse details
 */
var deleteSurveyResponseById = function(req, res, callback) {
    logger.info('surveyResponse : controller : received request : deleteSurveyResponseById : id : ' + req.params.id);
    surveyResponseDAO.deleteSurveyResponseById(req, res, callback);
};




module.exports.addNewSurveyResponse = addNewSurveyResponse;
module.exports.getSurveyResponseById = getSurveyResponseById;
module.exports.getAllSurveyResponses = getAllSurveyResponses;
//module.exports.updateSurveyResponseById = updateSurveyResponseById;
//module.exports.deleteSurveyResponseById = deleteSurveyResponseById;
//module.exports.getAppGroupsByQuestionId = getAppGroupsByQuestionId;
//module.exports.getAPIManagerConfig = getAPIManagerConfig;
//module.exports.getSMSGateway = getSMSGateway;
//module.exports.getSmtpServers= getSmtpServers;