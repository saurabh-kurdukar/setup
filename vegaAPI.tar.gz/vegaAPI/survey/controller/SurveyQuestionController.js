var surveyQuestionDao = require('../dao/SurveyQuestionDAO');
var logger = require('../../common/logger').log;


/*
 * logging format followed: logger.info(<module_name>: <component name> : <description> : [<long_description>] : <data/params/errors>);
 */


/*
 * Add new surveyQuestion details
 */
var addNewSurveyQuestion = function(req, res, callback) {
    logger.info('surveyQuestion : controller : received request : addNewSurveyQuestion : body : ' + JSON.stringify(req.body));
    surveyQuestionDao.addNewSurveyQuestion(req, res, callback);
};

/*
 * Get surveyQuestion by surveyQuestion id
 */
var getSurveyQuestionById = function(req, res, callback) {
    logger.info('surveyQuestion : controller : received request : getSurveyQuestionById : id : ' + req.params.id);
    surveyQuestionDao.getSurveyQuestionById(req, res, callback);
};

/*
 * Get all surveyQuestions
 */
var getAllSurveySurveyQuestions = function(req, res, callback) {
    logger.info('surveyQuestion : controller : received request : getAllSurveySurveyQuestions : status : ' + req.query.status);
    surveyQuestionDao.getAllSurveyQuestions(req, res, callback);
};

/*
 * Update surveyQuestion details
 */
var updateSurveyQuestionById = function(req, res, callback) {
    logger.info('surveyQuestion : controller : received request : updateSurveyQuestionById : (surveyQuestionId: ' + req.params.id + ', body: ' + JSON.stringify(req.body) + ')');
    surveyQuestionDao.updateSurveyQuestionById(req, res, callback);
};

/*
 * Delete surveyQuestion details
 */
var deleteSurveyQuestionById = function(req, res, callback) {
    logger.info('surveyQuestion : controller : received request : deleteSurveyQuestionById : id : ' + req.params.id);
    surveyQuestionDao.deleteSurveyQuestionById(req, res, callback);
};



module.exports.addNewSurveyQuestion = addNewSurveyQuestion;
module.exports.getSurveyQuestionById = getSurveyQuestionById;
module.exports.getAllSurveyQuestions = getAllSurveySurveyQuestions;
//module.exports.updateSurveyQuestionById = updateSurveyQuestionById;
//module.exports.deleteSurveyQuestionById = deleteSurveyQuestionById;