var surveyDao = require('../dao/SurveyDAO');
//var appgroupDao = require('../../appgroup/dao/AppGroupDAO');
//var apimanagerDao = require('../../apiMgrConfig/dao/ApiManagerDAO');
//var smsgatewayDao=require('../../smsGateway/dao/SMSGatewayDAO');
//var SMTPServerDao= require('../../smtpServer/dao/SMTPServerDAO');
var logger = require('../../common/logger').log;


/*
 * logging format followed: logger.info(<module_name>: <component name> : <description> : [<long_description>] : <data/params/errors>);
 */


/*
 * Add new survey details
 */
var addNewSurvey = function(req, res, callback) {
    logger.info('survey : controller : received request : addNewSurvey : body : ' + JSON.stringify(req.body));
    surveyDao.addNewSurvey(req, res, callback);
};

/*
 * Get survey by survey id
 */
var getSurveyById = function(req, res, callback) {
    logger.info('survey : controller : received request : getSurveyById : id : ' + req.params.id);
    surveyDao.getSurveyById(req, res, callback);
};

/*
 * Get all surveys
 */
var getAllSurveys = function(req, res, callback) {
    logger.info('survey : controller : received request : getAllSurveys : status : ' + req.query.status);
    surveyDao.getAllSurveys(req, res, callback);
};

/*
 * Update survey details
 */
var updateSurveyById = function(req, res, callback) {
    logger.info('survey : controller : received request : updateSurveyById : (surveyId: ' + req.params.id + ', body: ' + JSON.stringify(req.body) + ')');
    surveyDao.updateSurveyById(req, res, callback);
};

/*
 * Delete survey details
 */
var deleteSurveyById = function(req, res, callback) {
    logger.info('survey : controller : received request : deleteSurveyById : id : ' + req.params.id);
    surveyDao.deleteSurveyById(req, res, callback);
};




module.exports.addNewSurvey = addNewSurvey;
module.exports.getSurveyById = getSurveyById;
module.exports.getAllSurveys = getAllSurveys;
//module.exports.updateSurveyById = updateSurveyById;
//module.exports.deleteSurveyById = deleteSurveyById;