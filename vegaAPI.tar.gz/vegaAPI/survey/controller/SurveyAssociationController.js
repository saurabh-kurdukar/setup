var surveyAssociationDao = require('../dao/SurveyAssociationDAO');


var logger = require('../../common/logger').log;


/*
 * logging format followed: logger.info(<module_name>: <component name> : <description> : [<long_description>] : <data/params/errors>);
 */


/*
 * Add new surveyAssociation details
 */
var addNewSurveyAssociation = function(req, res, callback) {
    logger.info('surveyAssociation : controller : received request : addNewSurveyAssociation : body : ' + JSON.stringify(req.body));
    surveyAssociationDao.addNewSurveyAssociation(req, res, callback);
};

/*
 * Get surveyAssociation by surveyAssociation id
 */
var getSurveyAssociationById = function(req, res, callback) {
    logger.info('surveyAssociation : controller : received request : getSurveyAssociationById : id : ' + req.params.id);
    surveyAssociationDao.getSurveyAssociationById(req, res, callback);
};

/*
 * Get surveyAssociations
 */
var getAllSurveyAssociations = function(req, res, callback) {
    logger.info('surveyAssociation : controller : received request : getAllSurveyAssociations : query params : ' + JSON.stringify(req.query));
    surveyAssociationDao.getAllSurveyAssociations(req, res, callback);
};

/*
 * Update surveyAssociation details
 */
var updateSurveyAssociationById = function(req, res, callback) {
    logger.info('surveyAssociation : controller : received request : updateSurveyAssociationById : (surveyAssociationId: ' + req.params.id + ', body: ' + JSON.stringify(req.body) + ')');
    surveyAssociationDao.updateSurveyAssociationById(req, res, callback);
};

/*
 * Delete surveyAssociation details
 */
var deleteSurveyAssociationById = function(req, res, callback) {
    logger.info('surveyAssociation : controller : received request : deleteSurveyAssociationById : id : ' + req.params.id);
    surveyAssociationDao.deleteSurveyAssociationById(req, res, callback);
};

module.exports.addNewSurveyAssociation = addNewSurveyAssociation;
module.exports.getSurveyAssociationById = getSurveyAssociationById;
module.exports.getAllSurveyAssociations = getAllSurveyAssociations;
module.exports.updateSurveyAssociationById = updateSurveyAssociationById;
//module.exports.deleteSurveyAssociationById = deleteSurveyAssociationById;