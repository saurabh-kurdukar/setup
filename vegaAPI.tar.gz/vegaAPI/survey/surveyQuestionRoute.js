var express = require('express');
var surveyQuestionController = require('./controller/SurveyQuestionController');
var logger = require('../common/logger').log;
var ErrorResponse = require('../common/ErrorResponse').ErrorResponse;
var router = express.Router();

/*
 * logging format followed: logger.info(<module_name>: <component name> : <description> : [<long_description>] : <data/params/errors>);
 */

/*
 * Add new surveyQuestion details
 */
router.post('/', function(req, res) {
	logger.info('surveyQuestion : router : received request : addNewSurveyQuestion : body : '+JSON.stringify(req.body));	
	if(req.headers['username']) {
		surveyQuestionController.addNewSurveyQuestion(req, res, function(err, data) {
	        if(err) {
	        	logger.error('surveyQuestion : router : failed addNewSurveyQuestion : error : '+err);     
	        	var error = new ErrorResponse();
	        	if(err.name == 'ValidationError'){
	        		error.setErrorMessage(err.errors[Object.keys(err.errors)[0]].message);
	        	} else {
	        		error.setErrorMessage(err.message);
	        	}
	        	error.setErrorCode("SQ0001");        	
	        	error.setHttpResponseCode(500);        	
	        	res.status(500).end(JSON.stringify(error));        
	        } else {        	
	        	logger.info("surveyQuestion : router : addNewSurveyQuestion successful !");
	        	res.status(200).end(JSON.stringify(data));
	        }
	    });
	} else {
		var error = new ErrorResponse();
		error.setErrorCode("SQ0001");
		error.setErrorMessage('missing username in header.');
		error.setHttpResponseCode(400);
		res.status(400).send(JSON.stringify(error));
	}
});

/*
 * Get surveyQuestion by surveyQuestion id
 */
router.get('/:id', function (req, res) {
	logger.info('surveyQuestion : router : received request : getSurveyQuestionById : id : '+req.params.id);
	surveyQuestionController.getSurveyQuestionById(req, res, function(err, data) {
        if(err){
        	logger.error('surveyQuestion : router : failed getSurveyQuestionById : error : '+err);  
        	var error = new ErrorResponse();
        	error.setErrorCode("SQ0002");
        	error.setErrorMessage(err.message);
        	error.setHttpResponseCode(500);
            res.status(500).end(JSON.stringify(error));
        }else{        	
        	logger.info("surveyQuestion : router : getSurveyQuestionById successful !") ;
        	res.status(200).end(JSON.stringify(data));
        }
    });
});

/*
 * Get all surveyQuestions
 */
router.get('/', function (req, res) {	
	logger.info('surveyQuestion : router : received request : getAllSurveyQuestions : status : '
			+ req.query.status);
	surveyQuestionController.getAllSurveyQuestions(req, res, function(err, data) {
        if(err){
        	logger.error('surveyQuestion : router : failed getAllSurveyQuestions : error : '+err);   
        	var error = new ErrorResponse();
        	error.setErrorCode("SQ0003");
        	error.setErrorMessage(err.message);
        	error.setHttpResponseCode(500);
            res.status(500).end(JSON.stringify(error));
        }else{        	
        	logger.info("surveyQuestion : router : getAllSurveyQuestions successful !");
        	res.status(200).end(JSON.stringify(data));
        }
    });
});

/*
 * Update surveyQuestion details

router.put('/:id', function(req, res){	 
	logger.info('surveyQuestion : router : received request : updateSurveyQuestionById : (surveyQuestionId: '+req.params.id+', body: '+JSON.stringify(req.body)+')');
	surveyQuestionController.updateSurveyQuestionById(req, res, function(err, data) {
        if(err){
        	logger.error('surveyQuestion : router : failed updateSurveyQuestionById : error : '+err);   
        	var error = new ErrorResponse();
        	if(err.name == 'ValidationError'){
        		error.setErrorMessage(err.errors[Object.keys(err.errors)[0]].message);
        	} else {
        		error.setErrorMessage(err.message);
        	}
        	error.setErrorCode("A0002");        	
        	error.setHttpResponseCode(500);
            res.status(500).end(JSON.stringify(error));
        }else{        	
        	logger.info("surveyQuestion : router : updateSurveyQuestionById successful !");
        	res.status(200).end(JSON.stringify(data));
        }
    });
}); */

/*
 * Delete surveyQuestion details

router.delete('/:id', function(req, res){
	logger.info('surveyQuestion : router : received request : deleteSurveyQuestionById : id : '+req.params.id);
	surveyQuestionController.deleteSurveyQuestionById(req, res, function(err, data) {
        if(err){
        	logger.error('surveyQuestion : router : failed deleteSurveyQuestionById : error : '+err); 
        	var error = new ErrorResponse();
        	error.setErrorCode("A0002");
        	error.setErrorMessage(err.message);
        	error.setHttpResponseCode(500);
            res.status(500).end(JSON.stringify(error));
        }else{        	
        	logger.info("surveyQuestion : router : deleteSurveyQuestionById successful !");
        	res.status(200).end(JSON.stringify(data));
        }
    });
}); */



module.exports = router;






