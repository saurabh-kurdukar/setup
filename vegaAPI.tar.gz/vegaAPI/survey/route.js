var express = require('express');
var surveyController = require('./controller/SurveyController');
var logger = require('../common/logger').log;
var ErrorResponse = require('../common/ErrorResponse').ErrorResponse;
var router = express.Router();

/*
 * logging format followed: logger.info(<module_name>: <component name> : <description> : [<long_description>] : <data/params/errors>);
 */

/*
 * Add new survey details
 */
router.post('/', function(req, res) {
	logger.info('survey : router : received request : addNewSurvey : body : '+JSON.stringify(req.body));	
	if(req.headers['username']) {
		surveyController.addNewSurvey(req, res, function(err, data) {
	        if(err) {
	        	logger.error('survey : router : failed addNewSurvey : error : '+err);     
	        	var error = new ErrorResponse();
	        	if(err.name == 'ValidationError'){
	        		error.setErrorMessage(err.errors[Object.keys(err.errors)[0]].message);
	        	} else {
	        		error.setErrorMessage(err.message);
	        	}
	        	error.setErrorCode("SUR0001");        	
	        	error.setHttpResponseCode(500);        	
	        	res.status(500).end(JSON.stringify(error));        
	        } else {        	
	        	logger.info("survey : router : addNewSurvey successful !");
	        	res.status(200).end(JSON.stringify(data));
	        }
	    });
	} else {
		var error = new ErrorResponse();
		error.setErrorCode("SUR0001");
		error.setErrorMessage('missing username in header.');
		error.setHttpResponseCode(400);
		res.status(400).send(JSON.stringify(error));
	}
});

/*
 * Get survey by survey id
 */
router.get('/:id', function (req, res) {
	logger.info('survey : router : received request : getSurveyById : id : '+req.params.id);
	surveyController.getSurveyById(req, res, function(err, data) {
        if(err){
        	logger.error('survey : router : failed getSurveyById : error : '+err);  
        	var error = new ErrorResponse();
        	error.setErrorCode("SUR0002");
        	error.setErrorMessage(err.message);
        	error.setHttpResponseCode(500);
            res.status(500).end(JSON.stringify(error));
        }else{        	
        	logger.info("survey : router : getSurveyById successful !") ;
        	res.status(200).end(JSON.stringify(data));
        }
    });
});

/*
 * Get all surveys
 */
router.get('/', function (req, res) {	
	logger.info('survey : router : received request : getAllSurveys : status : '
			+ req.query.status);
	surveyController.getAllSurveys(req, res, function(err, data) {
        if(err){
        	logger.error('survey : router : failed getAllSurveys : error : '+err);   
        	var error = new ErrorResponse();
        	error.setErrorCode("SUR0003");
        	error.setErrorMessage(err.message);
        	error.setHttpResponseCode(500);
            res.status(500).end(JSON.stringify(error));
        }else{        	
        	logger.info("survey : router : getAllSurveys successful !");
        	res.status(200).end(JSON.stringify(data));
        }
    });
});

/*
 * Update survey details

router.put('/:id', function(req, res){	 
	logger.info('survey : router : received request : updateSurveyById : (surveyId: '+req.params.id+', body: '+JSON.stringify(req.body)+')');
	surveyController.updateSurveyById(req, res, function(err, data) {
        if(err){
        	logger.error('survey : router : failed updateSurveyById : error : '+err);   
        	var error = new ErrorResponse();
        	if(err.name == 'ValidationError'){
        		error.setErrorMessage(err.errors[Object.keys(err.errors)[0]].message);
        	} else {
        		error.setErrorMessage(err.message);
        	}
        	error.setErrorCode("A0002");        	
        	error.setHttpResponseCode(500);
            res.status(500).end(JSON.stringify(error));
        }else{        	
        	logger.info("survey : router : updateSurveyById successful !");
        	res.status(200).end(JSON.stringify(data));
        }
    });
}); */

/*
 * Delete survey details
router.delete('/:id', function(req, res){
	logger.info('survey : router : received request : deleteSurveyById : id : '+req.params.id);
	surveyController.deleteSurveyById(req, res, function(err, data) {
        if(err){
        	logger.error('survey : router : failed deleteSurveyById : error : '+err); 
        	var error = new ErrorResponse();
        	error.setErrorCode("A0002");
        	error.setErrorMessage(err.message);
        	error.setHttpResponseCode(500);
            res.status(500).end(JSON.stringify(error));
        }else{        	
        	logger.info("survey : router : deleteSurveyById successful !");
        	res.status(200).end(JSON.stringify(data));
        }
    });
}); */


module.exports = router;

