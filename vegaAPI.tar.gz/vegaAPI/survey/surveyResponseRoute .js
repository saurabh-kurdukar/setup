var express = require('express');
var surveyResponseController = require('./controller/SurveyResponseController');
var logger = require('../common/logger').log;
var ErrorResponse = require('../common/ErrorResponse').ErrorResponse;
var router = express.Router();

/*
 * logging format followed: logger.info(<module_name>: <component name> : <description> : [<long_description>] : <data/params/errors>);
 */

/*
 * Add new surveyResponse details
 */
router.post('/', function(req, res) {
	logger.info('surveyResponse : router : received request : addNewSurveyResponse : body : '+JSON.stringify(req.body));	
	if(req.headers['username']) {
		surveyResponseController.addNewSurveyResponse(req, res, function(err, data) {
	        if(err) {
	        	logger.error('surveyResponse : router : failed addNewSurveyResponse : error : '+err);     
	        	var error = new ErrorResponse();
	        	if(err.name == 'ValidationError'){
	        		error.setErrorMessage(err.errors[Object.keys(err.errors)[0]].message);
	        	} else {
	        		error.setErrorMessage(err.message);
	        	}
	        	error.setErrorCode("SR0001");        	
	        	error.setHttpResponseCode(500);        	
	        	res.status(500).end(JSON.stringify(error));        
	        } else {        	
	        	logger.info("surveyResponse : router : addNewSurveyResponse successful !");
	        	res.status(200).end(JSON.stringify(data));
	        }
	    });
	} else {
		var error = new ErrorResponse();
		error.setErrorCode("SR0001");
		error.setErrorMessage('missing username in header.');
		error.setHttpResponseCode(400);
		res.status(400).send(JSON.stringify(error));
	}
});

/*
 * Get surveyResponse by surveyResponse id
 */
router.get('/:id', function (req, res) {
	logger.info('surveyResponse : router : received request : getSurveyResponseById : id : '+req.params.id);
	surveyResponseController.getSurveyResponseById(req, res, function(err, data) {
        if(err){
        	logger.error('surveyResponse : router : failed getSurveyResponseById : error : '+err);  
        	var error = new ErrorResponse();
        	error.setErrorCode("SR0002");
        	error.setErrorMessage(err.message);
        	error.setHttpResponseCode(500);
            res.status(500).end(JSON.stringify(error));
        }else{        	
        	logger.info("surveyResponse : router : getSurveyResponseById successful !") ;
        	res.status(200).end(JSON.stringify(data));
        }
    });
});

/*
 * Get all surveyResponses
 */
router.get('/', function (req, res) {	
	logger.info('surveyResponse : router : received request : getAllSurveyResponses : status : '
			+ req.query.status);
	surveyResponseController.getAllSurveyResponses(req, res, function(err, data) {
        if(err){
        	logger.error('surveyResponse : router : failed getAllSurveyResponses : error : '+err);   
        	var error = new ErrorResponse();
        	error.setErrorCode("SR0003");
        	error.setErrorMessage(err.message);
        	error.setHttpResponseCode(500);
            res.status(500).end(JSON.stringify(error));
        }else{        	
        	logger.info("surveyResponse : router : getAllSurveyResponses successful !");
        	res.status(200).end(JSON.stringify(data));
        }
    });
});

/*
 * Update surveyResponse details

router.put('/:id', function(req, res){	 
	logger.info('surveyResponse : router : received request : updateSurveyResponseById : (surveyResponseId: '+req.params.id+', body: '+JSON.stringify(req.body)+')');
	surveyResponseController.updateSurveyResponseById(req, res, function(err, data) {
        if(err){
        	logger.error('surveyResponse : router : failed updateSurveyResponseById : error : '+err);   
        	var error = new ErrorResponse();
        	if(err.name == 'ValidationError'){
        		error.setErrorMessage(err.errors[Object.keys(err.errors)[0]].message);
        	} else {
        		error.setErrorMessage(err.message);
        	}
        	error.setErrorCode("A0002");        	
        	error.setHttpResponseCode(500);
            res.status(500).end(JSON.stringify(error));
        }else{        	
        	logger.info("surveyResponse : router : updateSurveyResponseById successful !");
        	res.status(200).end(JSON.stringify(data));
        }
    });
}); */

/*
 * Delete surveyResponse details

router.delete('/:id', function(req, res){
	logger.info('surveyResponse : router : received request : deleteSurveyResponseById : id : '+req.params.id);
	surveyResponseController.deleteSurveyResponseById(req, res, function(err, data) {
        if(err){
        	logger.error('surveyResponse : router : failed deleteSurveyResponseById : error : '+err); 
        	var error = new ErrorResponse();
        	error.setErrorCode("A0002");
        	error.setErrorMessage(err.message);
        	error.setHttpResponseCode(500);
            res.status(500).end(JSON.stringify(error));
        }else{        	
        	logger.info("surveyResponse : router : deleteSurveyResponseById successful !");
        	res.status(200).end(JSON.stringify(data));
        }
    });
});
 */


module.exports = router;

