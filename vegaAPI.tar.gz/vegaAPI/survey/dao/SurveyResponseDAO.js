var SurveyResponse = require('../models/SurveyResponse');
var logger = require('../../common/logger').log;
var audit = require('../../common/Audit').audit;
var SurveyAssociation = require('../models/SurveyAssociation');
var surveyAssociationDao = require('../dao/SurveyAssociationDAO');


/*
 * logging format followed: logger.info(<module_name>: <component name> : <description> : [<long_description>] : <data/params/errors>);
 */


/*
 * Add new surveyResponse details
 */
var addNewSurveyResponse = function(req, res, callback) {
        logger.info('surveyResponse : DAO : received request : addNewSurveyResponse : body : ' + JSON.stringify(req.body));
        var reqBody = req.body;
        var surveyResponse = new SurveyResponse();
        var callbackSave = function(err, data) {
            if (err) {
                return callback(err, null);
            }
            surveyResponse.setSurveyAssociationId(reqBody.surveyAssociationId);
            surveyResponse.setUserId(reqBody.userId);
            surveyResponse.setAnswers(reqBody.answers);
            surveyResponse.setSurveyId(reqBody.surveyId);
            surveyResponse.setSurveyEntityType(reqBody.surveyEntityType);
            surveyResponse.setSurveyEntityTypeReF(reqBody.surveyEntityTypeReF);            
            surveyResponse.setCreatedOn(new Date());
            surveyResponse.setCreatedBy(req.headers.username);
            surveyResponse.setUpdatedOn(new Date());
            surveyResponse.setUpdatedBy(req.headers.username);            
            surveyResponse.save(function(err, data) {
                if (err) {
                    logger.error('surveyResponse : DAO : failed addNewSurveyResponse : error : ' + err);
                    callback(err, null);
                } else if (data != null) {
                    logger.info('surveyResponse : DAO : addNewSurveyResponse successful !');
                    callback(null, data);
                } else {
                    var err = new Error('Failed to add new surveyResponse details');
                    logger.error('surveyResponse : DAO : failed addNewSurveyResponse : error : ' + err);
                    callback(err, null);
                }
            });
        };
        req.query.surveyId = reqBody.surveyId;
        req.query.surveyEntityType = reqBody.surveyEntityType;
        req.query.surveyEntityTypeReF = reqBody.surveyEntityTypeReF;
        surveyAssociationDao.getAllSurveyAssociations(req, res, function(err, data) {
        	if(err) {
        		err.message = 'No survey association record exist for surveyId, surveyEntityType, surveyEntityTypeReF';
        		return callback(err);
        	}
        	surveyAssociationDao.updateSurveyAssociationById(req, res, callbackSave);
        });
}

/*
 * Get surveyResponse by surveyResponse id
 */
var getSurveyResponseById = function(req, res, callback) {
    /*var surveyResponseId = req.swagger.params.id.value;
	console.log(surveyResponseId);*/
    logger.info('surveyResponse : DAO : received request : getSurveyResponseById : id : ' + req.params.id);
    SurveyResponse.find({
        'surveyResponseId': req.params.id
    }, function(err, data) {
        if (err) {
            logger.error('surveyResponse : DAO : failed getSurveyResponseById : error : ' + err);
            callback(err, null);
        } else {
            if (data.length != 0) {
                logger.info('surveyResponse : DAO : getSurveyResponseById successful !');
                callback(null, data[0]);
            } else {
                var err = new Error('Invalid surveyResponse id');
                err.status = 404;
                logger.error('surveyResponse : DAO : failed getSurveyResponseById : error : ' + err);
                callback(err, null);
            }
        }
    });
};

/*
 * Get all surveyResponses
 */
var getAllSurveyResponses = function(req, res, callback) {
    logger.info('surveyResponse : DAO : received request : getAllSurveyResponses : status : ' + req.query.status);
    var obj = {};    
    SurveyResponse.find(obj, function(err, data) {
        if (err) {
            logger.error('surveyResponse : DAO : failed getAllSurveyResponses : error : ' + err);
            callback(err, null);
        } else {
            if (data.length != 0) {
                logger.info('surveyResponse : DAO : getAllSurveyResponses successful !');
                callback(null, data);
            } else {
                var err = new Error('No records found');
                err.status = 404;
                logger.error('surveyResponse : DAO : failed getAllSurveyResponses : error : ' + err);
                callback(err, null);
            }
        }
    });
};

/*
 * Update surveyResponse details
 */
var updateSurveyResponseById = function(req, res, callback) {
    logger.info('surveyResponse : DAO : received request : updateSurveyResponseById : (surveyResponseId: ' + req.params.id + ', body: ' + JSON.stringify(req.body) + ')');

    /*
     * Callback function after getting original record to update with new values.
     */
    var callbackUpdate = function(err, data) {
        if (err) {
            logger.error('surveyResponse : DAO : failed updateSurveyResponseById : error :' + err);
            callback(err, null);
        } else if (data != null) {
            /*
             *	Compare updatable fields values in db with request data
             *	Add those fields in temproary object which are having new values
             */
            var surveyResponse = data;
            var json = {};
            var updatedData = [];
            if (req.body.surveyResponseURL && surveyResponse['surveyResponseURL'] != req.body.surveyResponseURL) {
                json.surveyResponseURL = req.body.surveyResponseURL;
                var obj = {};
                obj.column = 'surveyResponseURL';
                obj.oldValue = surveyResponse['surveyResponseURL'];
                obj.newValue = req.body.surveyResponseURL;
                obj.identifier = 'Platform_surveyResponse_' + req.params.id;
                obj.modifiedBy = 'admin';
                obj.modifiedOn = new Date();
                updatedData.push(obj);
            }
            if (req.body.surveyResponseImageURL && surveyResponse['surveyResponseImageURL'] != req.body.surveyResponseImageURL) {
                json.surveyResponseImageURL = req.body.surveyResponseImageURL;
                var obj = {};
                obj.column = 'surveyResponseImageURL';
                obj.oldValue = surveyResponse['surveyResponseImageURL'];
                obj.newValue = req.body.surveyResponseImageURL;
                obj.identifier = 'Platform_surveyResponse_' + req.params.id;
                obj.modifiedBy = 'admin';
                obj.modifiedOn = new Date();
                updatedData.push(obj);
            }
            if (req.body.phone && surveyResponse['phone'] != req.body.phone) {
                json.phone = req.body.phone;
                var obj = {};
                obj.column = 'phone';
                obj.oldValue = surveyResponse['phone'];
                obj.newValue = req.body.phone;
                obj.identifier = 'Platform_surveyResponse_' + req.params.id;
                obj.modifiedBy = 'admin';
                obj.modifiedOn = new Date();
                updatedData.push(obj);
            }
            if (req.body.fax && surveyResponse['fax'] != req.body.fax) {
                json.fax = req.body.fax;
                var obj = {};
                obj.column = 'fax';
                obj.oldValue = surveyResponse['fax'];
                obj.newValue = req.body.fax;
                obj.identifier = 'Platform_surveyResponse_' + req.params.id;
                obj.modifiedBy = 'admin';
                obj.modifiedOn = new Date();
                updatedData.push(obj);
            }
            if (req.body.email && surveyResponse['email'] != req.body.email) {
                json.email = req.body.email;
                var obj = {};
                obj.column = 'email';
                obj.oldValue = surveyResponse['email'];
                obj.newValue = req.body.email;
                obj.identifier = 'Platform_surveyResponse_' + req.params.id;
                obj.modifiedBy = 'admin';
                obj.modifiedOn = new Date();
                updatedData.push(obj);
            }
            if (req.body.adminFullName && surveyResponse['adminFullName'] != req.body.adminFullName) {
                json.adminFullName = req.body.adminFullName;
                var obj = {};
                obj.column = 'adminFullName';
                obj.oldValue = surveyResponse['adminFullName'];
                obj.newValue = req.body.adminFullName;
                obj.identifier = 'Platform_surveyResponse_' + req.params.id;
                obj.modifiedBy = 'admin';
                obj.modifiedOn = new Date();
                updatedData.push(obj);
            }
            if (req.body.adminMobile && surveyResponse['adminMobile'] != req.body.adminMobile) {
                json.adminMobile = req.body.adminMobile;
                var obj = {};
                obj.column = 'adminMobile';
                obj.oldValue = surveyResponse['adminMobile'];
                obj.newValue = req.body.adminMobile;
                obj.identifier = 'Platform_surveyResponse_' + req.params.id;
                obj.modifiedBy = 'admin';
                obj.modifiedOn = new Date();
                updatedData.push(obj);
            }
            if (req.body.adminEmail && surveyResponse['adminEmail'] != req.body.adminEmail) {
                json.adminEmail = req.body.adminEmail;
                var obj = {};
                obj.column = 'adminEmail';
                obj.oldValue = surveyResponse['adminEmail'];
                obj.newValue = req.body.adminEmail;
                obj.identifier = 'Platform_surveyResponse_' + req.params.id;
                obj.modifiedBy = 'admin';
                obj.modifiedOn = new Date();
                updatedData.push(obj);
            }
            if (req.body.status && surveyResponse['status'] != req.body.status) {
                json.status = req.body.status;
                var obj = {};
                obj.column = 'status';
                obj.oldValue = surveyResponse['status'];
                obj.newValue = req.body.status;
                obj.identifier = 'Platform_surveyResponse_' + req.params.id;
                obj.modifiedBy = 'admin';
                obj.modifiedOn = new Date();
                updatedData.push(obj);
            }
            if (req.body.adminMobileVerified && surveyResponse['adminMobileVerified'] != req.body.adminMobileVerified) {
                json.adminMobileVerified = req.body.adminMobileVerified;
                var obj = {};
                obj.column = 'adminMobileVerified';
                obj.oldValue = surveyResponse['adminMobileVerified'];
                obj.newValue = req.body.adminMobileVerified;
                obj.identifier = 'Platform_surveyResponse_' + req.params.id;
                obj.modifiedBy = 'admin';
                obj.modifiedOn = new Date();
                updatedData.push(obj);
            }
            if (req.body.adminEmailVerified && surveyResponse['adminEmailVerified'] != req.body.adminEmailVerified) {
                json.adminEmailVerified = req.body.adminEmailVerified;
                var obj = {};
                obj.column = 'adminEmailVerified';
                obj.oldValue = surveyResponse['adminEmailVerified'];
                obj.newValue = req.body.adminEmailVerified;
                obj.identifier = 'Platform_surveyResponse_' + req.params.id;
                obj.modifiedBy = 'admin';
                obj.modifiedOn = new Date();
                updatedData.push(obj);
            }

            /*
             *	Update the data to database
             */
            if (Object.keys(json).length != 0) {
                json.updatedOn = new Date();
                json.updatedBy = req.headers.username;
                logger.info('surveyResponse : DAO : updateSurveyResponseById : updating data : ' + JSON.stringify(json));
                SurveyResponse.findOneAndUpdate({
                    'surveyResponseId': req.params.id
                }, json, {
                    'new': true
                        // returns updated entity if update successful, if false then old entry
                }, function(err, data) {
                    if (err) {
                        logger.error('surveyResponse : DAO : failed updateSurveyResponseById : error :' + err);
                        callback(err, null);
                    } else {
                        if (data != null) {
                            logger.info('surveyResponse : DAO : updateSurveyResponseById successful !');
                            /*
                             *	Call audit function for changed data
                             */
                            audit(req, res, updatedData);
                            /*
                             *	Call function to send response to client
                             */
                            callback(null, data);
                        } else {
                            var err = new Error('Bad request data');
                            logger.error('surveyResponse : DAO : failed updateSurveyResponseById : error :' + err);
                            callback(err, null);
                        }
                    }
                });
            } else {
                var err = new Error('Cannot update data');
                logger.error('surveyResponse : DAO : failed updateSurveyResponseById : error :' + err);
                callback(err, null);
            }
        } else {
            var err = new Error('Failed to get surveyResponse details');
            logger.error('surveyResponse : DAO : failed updateSurveyResponseById : error :' + err);
            callback(err, null);
        }
    }

    /*
     * Get the original record from db before update.
     */
    getSurveyResponseById(req, res, callbackUpdate);


    // Update using schema, creates new record
    /*
     * var surveyResponse = new SurveyResponse(); surveyResponse.setSurveyResponseId(req.params.id); if
     * (req.body.surveyResponseURL) { surveyResponse.setSurveyResponseURL(req.body.surveyResponseURL); } if
     * (req.body.surveyResponseImageURL) {
     * surveyResponse.setSurveyResponseImageURL(req.body.surveyResponseImageURL); } if
     * (req.body.phone) { surveyResponse.setPhone(req.body.phone); } if (req.body.fax) {
     * surveyResponse.setFax(req.body.fax); } if (req.body.email) {
     * surveyResponse.setEmail(req.body.email); } if (req.body.adminFullName) {
     * surveyResponse.setAdminFullName(req.body.adminFullName); } if
     * (req.body.adminMobile) { surveyResponse.setAdminMobile(req.body.adminMobile); }
     * if (req.body.adminEmail) { surveyResponse.setAdminEmail(req.body.adminEmail); }
     * if (req.body.status) { surveyResponse.setStatus(req.body.status); } if
     * (req.body.adminMobileVerified) {
     * surveyResponse.setAdminMobileVerified(req.body.adminMobileVerified); } if
     * (req.body.adminEmailVerified) {
     * surveyResponse.setAdminEmailVerified(req.body.adminEmailVerified); }
     * surveyResponse.setUpdatedOn(new Date()); surveyResponse.setUpdatedBy('admin');
     * surveyResponse.update(function(err, data) { if (err) { callback(err, data); }
     * else { callback(err, data); } });
     */

};

/*
 * Delete surveyResponse details
 */
var deleteSurveyResponseById = function(req, res, callback) {
    logger.info('surveyResponse : DAO : received request : deleteSurveyResponseById : id : ' + req.params.id);
    var callbackDelete = function(err, data) {
        if (err) {
            logger.error('surveyResponse : DAO : failed deleteSurveyResponseById : error :' + err);
            callback(err, null);
        } else if (data != null) {
            var surveyResponse = data;
            var updatedData = [];
            if (surveyResponse.status != 'DELETED') {
                var json = {
                    'status': 'DELETED'
                };
                SurveyResponse.findOneAndUpdate({
                    'surveyResponseId': req.params.id
                }, json, {
                    'new': true
                }, function(err, data) {
                    if (err) {
                        logger.error('surveyResponse : DAO : failed deleteSurveyResponseById : error :' + err);
                        callback(err, null);
                    } else if (data != null) {
                        logger.info('surveyResponse : DAO : deleteSurveyResponseById successful !');
                        var obj = {};
                        obj.column = 'status';
                        obj.oldValue = surveyResponse['status'];
                        obj.newValue = data.status;
                        obj.identifier = 'Platform_surveyResponse_' + req.params.id;
                        obj.modifiedBy = 'admin';
                        obj.modifiedOn = new Date();
                        updatedData.push(obj);
                        /*
                         *	Call audit function for changed data
                         */
                        audit(req, res, updatedData);
                        /*
                         *	Call function to send response to client
                         */
                        callback(null, data);
                    } else {
                        var err = new Error('Invalid compnay id');
                        logger.error('surveyResponse : DAO : failed deleteSurveyResponseById : error :' + err);
                        callback(err, null);
                    }
                });
            } else {
                var err = new Error('Already deleted');
                logger.error('surveyResponse : DAO : failed deleteSurveyResponseById : error :' + err);
                callback(err, null);
            }
        } else {
            var err = new Error('Failed to get surveyResponse details');
            logger.error('surveyResponse : DAO : failed deleteSurveyResponseById : error :' + err);
            callback(err, null)
        }
    }

    /*
     * Get the original record from db before update.
     */
    getSurveyResponseById(req, res, callbackDelete);

};


module.exports.addNewSurveyResponse = addNewSurveyResponse;
module.exports.getSurveyResponseById = getSurveyResponseById;
module.exports.getAllSurveyResponses = getAllSurveyResponses;
//module.exports.updateSurveyResponseById = updateSurveyResponseById;
//module.exports.deleteSurveyResponseById = deleteSurveyResponseById;