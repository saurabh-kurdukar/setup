var Survey = require('../models/Survey');
//var AppGroup = require('../../appgroup/models/AppGroup');
var logger = require('../../common/logger').log;
var audit = require('../../common/Audit').audit;

/*
 * logging format followed: logger.info(<module_name>: <component name> : <description> : [<long_description>] : <data/params/errors>);
 */


/*
 * Add new survey details
 */
var addNewSurvey = function(req, res, callback) {
    logger.info('survey : DAO : received request : addNewSurvey : body : ' + JSON.stringify(req.body));
    var reqBody = req.body;

    // if(reqBody.hasOwnProperty("surveyName") && reqBody.hasOwnProperty("surveyType")  && //reqBody.hasOwnProperty("surveyFeedback") && reqBody.hasOwnProperty("surveyDescription") && //reqBody.hasOwnProperty("noOfQuestions"))

    var survey = new Survey();
    survey.setSurveyName(reqBody.surveyName);
    survey.setSurveyType(reqBody.surveyType);
    //survey.setSurveyFeedback(reqBody.surveyFeedback);        
    survey.setSurveyDescription(reqBody.surveyDescription);
    survey.setNoOfQuestions(reqBody.noOfQuestions);
    survey.setSurveyEndDate(reqBody.surveyEndDate);    
    survey.setSurveyStartDate(reqBody.surveyStartDate);
    survey.setSurveyStatus(reqBody.surveyStatus);
    
    survey.setCreatedOn(new Date());
    survey.setCreatedBy(req.headers.username);
    survey.setUpdatedOn(new Date());
    survey.setUpdatedBy(req.headers.username);
    
    survey.save(function(err, data) {
        if (err) {
            logger.error('survey : DAO : failed addNewSurvey : error : ' + err);
            callback(err, null);
        } else if (data != null) {
            logger.info('survey : DAO : addNewSurvey successful !');
            callback(null, data);
        } else {
            var err = new Error('Failed to add new survey details');
            logger.error('survey : DAO : failed addNewSurvey : error : ' + err);
            callback(err, null);
        }
    });
};

/*
 * Get survey by survey id
 */
var getSurveyById = function(req, res, callback) {
    /*var surveyId = req.swagger.params.id.value;
	console.log(surveyId);*/
    logger.info('survey : DAO : received request : getSurveyById : id : ' + req.params.id);
    Survey.find({
        'surveyId': req.params.id
    }, function(err, data) {
        if (err) {
            logger.error('survey : DAO : failed getSurveyById : error : ' + err);
            callback(err, null);
        } else {
            if (data.length != 0) {
                logger.info('survey : DAO : getSurveyById successful !');
                callback(null, data[0]);
            } else {
                var err = new Error('Invalid survey id');
                err.status = 404;
                logger.error('survey : DAO : failed getSurveyById : error : ' + err);
                callback(err, null);
            }
        }
    });
};

/*
 * Get all surveys
 */
var getAllSurveys = function(req, res, callback) {
    logger.info('survey : DAO : received request : getAllSurveys : status : ' + req.query.status);
    var obj = {};
    Survey.find(obj, function(err, data) {
        if (err) {
            logger.error('survey : DAO : failed getAllSurveys : error : ' + err);
            callback(err, null);
        } else {
            if (data.length != 0) {
                logger.info('survey : DAO : getAllSurveys successful !');
                callback(null, data);
            } else {
                var err = new Error('No records found');
                err.status = 404;
                logger.error('survey : DAO : failed getAllSurveys : error : ' + err);
                callback(err, null);
            }
        }
    });
};

/*
 * Update survey details
 */
var updateSurveyById = function(req, res, callback) {
    logger.info('survey : DAO : received request : updateSurveyById : (surveyId: ' + req.params.id + ', body: ' + JSON.stringify(req.body) + ')');
    /* Callback function after getting original record to update with new values. */
    var callbackUpdate = function(err, data) {
        if (err) {
            logger.error('survey : DAO : failed updateSurveyById : error :' + err);
            callback(err, null);
        } else if (data != null) {
            /*
             *	Compare updatable fields values in db with request data
             *	Add those fields in temproary object which are having new values
             */
        	var survey = data;
			var updatableFields = [
			                       "surveyURL","surveyImageURL","phone","fax","email","adminFullName","adminMobile","adminEmail","status",
			                       "adminMobileVerified","adminEmailVerified"
			                      ];
			var updatedData = [];
			var json = {};
			var reqBodyKeys = Object.keys(req.body);
			for(var i = 0; i < reqBodyKeys.length; i++) {
				if(updatableFields.indexOf(reqBodyKeys[i]) > -1 && survey[reqBodyKeys[i]] != req.body[reqBodyKeys[i]]) {
					json[reqBodyKeys[i]] = req.body[reqBodyKeys[i]];
					var obj = {};
					obj.column = reqBodyKeys[i];
					obj.oldValue = survey[reqBodyKeys[i]];
					obj.newValue = req.body[reqBodyKeys[i]];
					obj.identifier = 'Platform_survey_'+req.params.id;
					obj.modifiedBy = 'admin';
					obj.modifiedOn = new Date();
					updatedData.push(obj);
				}
			}			
            /* Update the data to database */
            if (Object.keys(json).length != 0) {
                json.updatedOn = new Date();
                json.updatedBy = req.headers.username;
                logger.info('survey : DAO : updateSurveyById : updating data : ' + JSON.stringify(json));
                Survey.findOneAndUpdate({
                    'surveyId': req.params.id
                }, json, {
                    'new': true		// returns updated entity if update successful, if false then old entry
                }, function(err, data) {
                    if (err) {
                        logger.error('survey : DAO : failed updateSurveyById : error :' + err);
                        callback(err, null);
                    } else {
                        if (data != null) {
                            logger.info('survey : DAO : updateSurveyById successful !');
                            /* Call audit function for changed data */
                            audit(req, res, updatedData);
                            /* Call function to send response to client */
                            callback(null, data);
                        } else {
                            var err = new Error('Bad request data');
                            logger.error('survey : DAO : failed updateSurveyById : error :' + err);
                            callback(err, null);
                        }
                    }
                });
            } else {
                var err = new Error('Cannot update data');
                logger.error('survey : DAO : failed updateSurveyById : error :' + err);
                callback(err, null);
            }
        } else {
            var err = new Error('Failed to get survey details');
            logger.error('survey : DAO : failed updateSurveyById : error :' + err);
            callback(err, null);
        }
    }

    /*
     * Get the original record from db before update.
     */
    getSurveyById(req, res, callbackUpdate);
};

/*
 * Delete survey details
 */
var deleteSurveyById = function(req, res, callback) {
    logger.info('survey : DAO : received request : deleteSurveyById : id : ' + req.params.id);
    var callbackDelete = function(err, data) {
        if (err) {
            logger.error('survey : DAO : failed deleteSurveyById : error :' + err);
            callback(err, null);
        } else if (data != null) {
            var survey = data;
            var updatedData = [];
            if (survey.status != 'DELETED') {
                var json = {
                    'status': 'DELETED',
                    'updatedOn': new Date(),
                	'updatedBy': req.headers.username
                };
                Survey.findOneAndUpdate({
                    'surveyId': req.params.id
                }, json, {
                    'new': true
                }, function(err, data) {
                    if (err) {
                        logger.error('survey : DAO : failed deleteSurveyById : error :' + err);
                        callback(err, null);
                    } else if (data != null) {
                        logger.info('survey : DAO : deleteSurveyById successful !');
                        var obj = {};
                        obj.column = 'status';
                        obj.oldValue = survey['status'];
                        obj.newValue = data.status;
                        obj.identifier = 'Platform_survey_' + req.params.id;
                        obj.modifiedBy = 'admin';
                        obj.modifiedOn = new Date();
                        updatedData.push(obj);
                        /*
                         *	Call audit function for changed data
                         */
                        audit(req, res, updatedData);
                        /*
                         *	Call function to send response to client
                         */
                        callback(null, data);
                    } else {
                        var err = new Error('Invalid compnay id');
                        logger.error('survey : DAO : failed deleteSurveyById : error :' + err);
                        callback(err, null);
                    }
                });
            } else {
                var err = new Error('Already deleted');
                logger.error('survey : DAO : failed deleteSurveyById : error :' + err);
                callback(err, null);
            }
        } else {
            var err = new Error('Failed to get survey details');
            logger.error('survey : DAO : failed deleteSurveyById : error :' + err);
            callback(err, null)
        }
    }

    /*
     * Get the original record from db before update.
     */
    getSurveyById(req, res, callbackDelete);

};


module.exports.addNewSurvey = addNewSurvey;
module.exports.getSurveyById = getSurveyById;
module.exports.getAllSurveys = getAllSurveys;
//module.exports.updateSurveyById = updateSurveyById;
//module.exports.deleteSurveyById = deleteSurveyById;