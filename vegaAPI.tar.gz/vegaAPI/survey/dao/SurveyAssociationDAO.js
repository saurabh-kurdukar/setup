var SurveyAssociation = require('../models/SurveyAssociation');
var Survey = require('../models/Survey');
var SurveyResponse = require('../models/SurveyResponse');
var SurveyQuestion = require('../models/SurveyQuestion');
var async = require('async');

//var AppGroup = require('../../appgroup/models/AppGroup');
var logger = require('../../common/logger').log;
var audit = require('../../common/Audit').audit;

/*
 * logging format followed: logger.info(<module_name>: <component name> : <description> : [<long_description>] : <data/params/errors>);
 */

/*
 * Add new surveyAssociation details
 */
var addNewSurveyAssociation = function (req, res, callback) {
	logger.info('surveyAssociation : DAO : received request : addNewSurveyAssociation : body : ' + JSON.stringify(req.body));
	var reqBody = req.body;

	reqBody.surveyResponses = []; //this will contain response structure of survey association initialized value to 0.
	reqBody.surveyAverages = []; //this will contain response structure of survey association initialized average to 0.
	var surveyAssociation = new SurveyAssociation();

	/*
	  initializes all all responses to 0.
	   iterates loop length of answerOptions times.
	*/

	var fillSurveyResponses = function (data) {

		data.forEach(function (question, index, array) {

			var obj = {
				questionId: question.surveyQuestionId,
				answers: []
			}

			for (var i = 0; i < question.answerOptions.length; i++) {
				obj.answers.push({
					"answerOption": (i + 1),
					"responses": 0
				});

			}
			reqBody.surveyResponses.push(obj);
			if (index == (array.length - 1)) {
				saveSurveyAssociation();
			}

		});

	};

	SurveyQuestion.find({
		'surveyId': reqBody.surveyId
	}, function (err, data) {

		if (err) {
			logger.error('surveyAssociation : DAO : failed getSurveyQuestionsBySurveyId : error : ' + err);
			callback(err, null);
		} else {
			if (data.length != 0) {

				//fills average for each wuestion id and initializes its value to 0.
				data.forEach(function (question, index, array) {
					reqBody.surveyAverages.push({
						"questionId": question.surveyQuestionId,
						"average": 0
					});

					var obj = {
						questionId: question.surveyQuestionId,
						answers: []
					}

					if (index == (array.length - 1))
						fillSurveyResponses(data);

				});

				logger.info('surveyAssociation : DAO : getSurveyQuestionsBySurveyId successful !');
				//callback(null, data[0]);
			} else {
				var err = new Error('No Questions Associated with this survey id');
				err.status = 404;
				logger.error('surveyAssociation : DAO : failed getSurveyQuestionsBySurveyId : error : ' + err);
				callback(err, null);
			}
		}
	});

	var saveSurveyAssociation = function () {

		surveyAssociation.setSurveyId(reqBody.surveyId);
		surveyAssociation.setSurveyEntityType(reqBody.surveyEntityType);
		surveyAssociation.setSurveyEntityTypeReF(reqBody.surveyEntityTypeReF);
		surveyAssociation.setSurveyResponses(reqBody.surveyResponses);
		surveyAssociation.setSurveyAverages(reqBody.surveyAverages);
		surveyAssociation.setTotalSurveyResponses(0);
		
		surveyAssociation.setCreatedOn(new Date());
		surveyAssociation.setCreatedBy(req.headers.username);
		surveyAssociation.setUpdatedOn(new Date());
		surveyAssociation.setUpdatedBy(req.headers.username);
	    
		surveyAssociation.save(function (err, data) {
			if (err) {
				logger.error('surveyAssociation : DAO : failed addNewSurveyAssociation : error : ' + err);
				callback(err, null);
			} else if (data != null) {
				logger.info('surveyAssociation : DAO : addNewSurveyAssociation successful !');
				callback(null, data);
			} else {
				var err = new Error('Failed to add new surveyAssociation details');
				logger.error('surveyAssociation : DAO : failed addNewSurveyAssociation : error : ' + err);
				callback(err, null);
			}
		});

	};

	// }

};

/*
 * Get surveyAssociation by surveyAssociation id
 */
var getSurveyAssociationById = function (req, res, callback) {

    var surveyAssociationId = req.params.id;
	if (!surveyAssociationId)
		surveyAssociationId = req.body.surveyAssociationId;

	logger.info('surveyAssociation : DAO : received request : getSurveyAssociationById : id : ' + req.params.id);
	SurveyAssociation.find({
		'surveyAssociationId': surveyAssociationId
	}, function (err, data) {
		if (err) {
			logger.error('surveyAssociation : DAO : failed getSurveyAssociationById : error : ' + err);
			callback(err, null);
		} else {
			if (data.length != 0) {
				logger.info('surveyAssociation : DAO : getSurveyAssociationById successful !');
				callback(null, data[0]);
			} else {
				var err = new Error('Invalid surveyAssociation id');
				err.status = 404;
				logger.error('surveyAssociation : DAO : failed getSurveyAssociationById : error : ' + err);
				callback(err, null);
			}
		}
	});
};

/*
 * Get surveyAssociations
 */
var getAllSurveyAssociations = function (req, res, callback) {
	logger.info('surveyAssociation : DAO : received request : getAllSurveyAssociations : query params : ' + JSON.stringify(req.query));
	var obj = {};
	if(req.query.surveyId) {
		obj.surveyId = req.query.surveyId;
	}
	if(req.query.surveyEntityType) {
		obj.surveyEntityType = req.query.surveyEntityType;
	}
	if(req.query.surveyEntityTypeReF) {
		obj.surveyEntityTypeReF = req.query.surveyEntityTypeReF;
	}
	SurveyAssociation.find(obj, function (err, data) {
		if (err) {
			logger.error('surveyAssociation : DAO : failed getAllSurveyAssociations : error : ' + err);
			callback(err, null);
		} else {
			if (data.length != 0) {
				logger.info('surveyAssociation : DAO : getAllSurveyAssociations successful !');
				callback(null, data);
			} else {
				var err = new Error('No records found');
				err.status = 404;
				logger.error('surveyAssociation : DAO : failed getAllSurveyAssociations : error : ' + err);
				callback(err, null);
			}
		}
	});
};

/*
 * Update surveyAssociation details
 */
var updateSurveyAssociationById = function (req, res, callback) {
	logger.info('surveyAssociation : DAO : received request : updateSurveyAssociationById : (surveyAssociationId: ' + req.params.id + ', body: ' + JSON.stringify(req.body) + ')');

	var resRecived = req.body.answers; //fetches answers recived in request.

	/*
	 * Callback function after getting original record to update with new values.
	 */
	var callbackUpdate = function (err, data) {
		if (err) {
			logger.error('surveyAssociation : DAO : failed updateSurveyAssociationById : error :' + err);
			callback(err, null);
		} else if (data != null) {
			/*
			 *	Compare updatable fields values in db with request data
			 *	Add those fields in temproary object which are having new values
			 */
			//var surveyAssociation = data;
			var json = {};
			var updatedData = [];
			var averages = data.surveyAverages; //takes existing averages
			var responses = data.surveyResponses; //takes existing responses
			var totalResponses = data.totalSurveyResponses; //fetches current response count
            ++totalResponses; //increments total response count.

			//this fcn saves values to db after processing
			var updateValues = function (surveyResponses, surveyAverages) {
				json['surveyResponses'] = surveyResponses;
				json['surveyAverages'] = surveyAverages;
				json["totalSurveyResponses"] = totalResponses;
				json.updatedOn = new Date();
				json.updatedBy = req.headers.username;
				SurveyAssociation.findOneAndUpdate({
					'surveyAssociationId': data.surveyAssociationId
				}, json, {
					'new': true
						// returns updated entity if update successful, if false then old entry
				}, function (err, data) {
					if (err) {
						logger.error('surveyAssociation : DAO : failed updateSurveyAssociationById : error :' + err);
						callback(err, null);
					} else {
						if (data != null) {
							logger.info('surveyAssociation : DAO : updateSurveyAssociationById successful !');
							/* Call audit function for changed data */
							audit(req, res, updatedData);
							/* Call function to send response to client */
							callback(null, data);
						} else {
							var err = new Error('Bad request data');
							logger.error('surveyAssociation : DAO : failed updateSurveyAssociationById : error :' + err);
							callback(err, null);
						}
					}
				});
			}

			/* Update the data to database */
			if (Object.keys(data).length > 0) { //temprory inverted the cond
				/*json.updatedOn = new Date();
				json.updatedBy = req.headers.username;
				logger.info('surveyAssociation : DAO : updateSurveyAssociationById : updating data : ' + JSON.stringify(json));*/
				var updateRating = function () {
					if(resRecived && resRecived.length) {
						for (var i = 0; i < resRecived.length; i++) { //iterates through each fetched answer
							for (var j = 0; j < responses.length; j++) { //iterates through each existing response
								if ( resRecived[i].questionId == responses[j].questionId ) {
									var options = responses[j].answers;
									var totalHits = 0;  //stores sum of existing response of that question
									var answer = 0;
									for (var k = 0; k < options.length; k++) {
										totalHits += parseInt(options[k].responses);
										 if ( options[k].answerOption == resRecived[i].answer[0] ) {
										 	 options[k].responses++;
	                                         resRecived[i].answer.forEach( function ( ans ) {
	                                           if(  !isNaN( parseInt(ans) ) )
	                                             answer += parseInt(ans);
	                                         });
	                                         //answer = resRecived[i].answer[0]; //doubt how to calculate multiple answers
										}                                    
									}
									var questionIndex = 0;
									averages.forEach(function (avg, index, array) {
	
										if (avg.questionId == resRecived[i].questionId) {
											updateAverage(questionIndex, answer, totalHits);
	                                        return;
										}
										++questionIndex;
									});
									// }//end function callUpdateAverages
								}
							}
						}
					}
				};
				var updateAverage = function (questionIndex, answer, totalHits) {
					answer = parseInt(answer);
					averages[questionIndex].average = ( ((parseFloat(averages[questionIndex].average) * totalHits) + answer) / (totalHits + 1) ).toFixed(3);
				}
				async.parallel([    
				    function (callback) {                   
						updateRating();        
						callback(null,  'data',  'converted to array');                        
					}, function(callback) {                        
						//  updateAverage();
						// async code to create a directory to store a file in
						// this is run at the same time as getting the data						        
						callback(null,  'folder');    
					}],
					function (err,  results) {
						updateValues(responses, averages); 
					});
			} else {
				var err = new Error('Cannot update data');
				logger.error('surveyAssociation : DAO : failed updateSurveyAssociationById : error :' + err);
				callback(err, null);
			}
			//};
			// updateSurveyAssociation(data);
		} else {
			var err = new Error('Failed to get surveyAssociation details');
			logger.error('surveyAssociation : DAO : failed updateSurveyAssociationById : error :' + err);
			callback(err, null);
		}
	}
	
	/* Get the original record from db before update. */
	getSurveyAssociationById(req, res, callbackUpdate);
};

/*
 * Delete surveyAssociation details
 */
var deleteSurveyAssociationById = function (req, res, callback) {
	logger.info('surveyAssociation : DAO : received request : deleteSurveyAssociationById : id : ' + req.params.id);
	var callbackDelete = function (err, data) {
		if (err) {
			logger.error('surveyAssociation : DAO : failed deleteSurveyAssociationById : error :' + err);
			callback(err, null);
		} else if (data != null) {
			var surveyAssociation = data;
			var updatedData = [];
			if (surveyAssociation.status != 'DELETED') {
				var json = {
					'status': 'DELETED',
                    'updatedOn': new Date(),
                	'updatedBy': req.headers.username
				};
				SurveyAssociation.findOneAndUpdate({
					'surveyAssociationId': req.params.id
				}, json, {
					'new': true
				}, function (err, data) {
					if (err) {
						logger.error('surveyAssociation : DAO : failed deleteSurveyAssociationById : error :' + err);
						callback(err, null);
					} else if (data != null) {
						logger.info('surveyAssociation : DAO : deleteSurveyAssociationById successful !');
						var obj = {};
						obj.column = 'status';
						obj.oldValue = surveyAssociation['status'];
						obj.newValue = data.status;
						obj.identifier = 'Platform_surveyAssociation_' + req.params.id;
						obj.modifiedBy = 'admin';
						obj.modifiedOn = new Date();
						updatedData.push(obj);
						/*
						 *	Call audit function for changed data
						 */
						audit(req, res, updatedData);
						/*
						 *	Call function to send response to client
						 */
						callback(null, data);
					} else {
						var err = new Error('Invalid compnay id');
						logger.error('surveyAssociation : DAO : failed deleteSurveyAssociationById : error :' + err);
						callback(err, null);
					}
				});
			} else {
				var err = new Error('Already deleted');
				logger.error('surveyAssociation : DAO : failed deleteSurveyAssociationById : error :' + err);
				callback(err, null);
			}
		} else {
			var err = new Error('Failed to get surveyAssociation details');
			logger.error('surveyAssociation : DAO : failed deleteSurveyAssociationById : error :' + err);
			callback(err, null)
		}
	}

	/*
	 * Get the original record from db before update.
	 */
	getSurveyAssociationById(req, res, callbackDelete);

};





module.exports.addNewSurveyAssociation = addNewSurveyAssociation;
module.exports.getSurveyAssociationById = getSurveyAssociationById;
module.exports.getAllSurveyAssociations = getAllSurveyAssociations;
module.exports.updateSurveyAssociationById = updateSurveyAssociationById;
//module.exports.deleteSurveyAssociationById = deleteSurveyAssociationById;






