var SurveyQuestion = require('../models/SurveyQuestion');
var Survey = require('../models/Survey');

//var AppGroup = require('../../appgroup/models/AppGroup');
var logger = require('../../common/logger').log;
var audit = require('../../common/Audit').audit;

/*
 * logging format followed: logger.info(<module_name>: <component name> : <description> : [<long_description>] : <data/params/errors>);
 */


/*
 * Add new surveyQuestion details
 */
var addNewSurveyQuestion = function(req, res, callback) {
    logger.info('surveyQuestion : DAO : received request : addNewSurveyQuestion : body : ' + JSON.stringify(req.body));
    var reqBody = req.body;
    var surveyQuestion = new SurveyQuestion();
    var isValidSurveyID = false;
    var foundSurveyInSurveyQuestion = "pending";
    var existingSurveyQuestions = undefined;

    Survey.find({
        'surveyId': reqBody.surveyId
    }, function(err, data) {
        if (err) {
            logger.error('surveyQuestion : DAO : failed getSurveyById : error : ' + err);
            callback(err, null);
        } else {
            if (data.length != 0) {
                isValidSurveyID = true;
                if (foundSurveyInSurveyQuestion != "pending")
                    insertSurvey(isValidSurveyID, foundSurveyInSurveyQuestion, existingSurveyQuestions);
                logger.info('surveyQuestion : DAO : getSurveyById successful !');
                //callback(null, data[0]);
            } else {
                var err = new Error('Invalid survey id');
                err.status = 404;
                logger.error('surveyQuestion : DAO : failed getSurveyById : error : ' + err);
                callback(err, null);
            }
        }
    });

    SurveyQuestion.find({
        'surveyId': reqBody.surveyId
    }, function(err, data) {
        if (err) {
            logger.error('surveyQuestion : DAO : failed getSurveyQuestionBySurveyId : error : ' + err);
            callback(err, null);
        } else {
            if (data.length != 0) {
                foundSurveyInSurveyQuestion = "true";
                existingSurveyQuestions = data;
                if (isValidSurveyID)
                    insertSurvey(isValidSurveyID, foundSurveyInSurveyQuestion, data);
                logger.info('surveyQuestion : DAO : getSurveyQuestionBySurveyId successful !');

                //callback(null, data[0]);
            } else {
                logger.info('surveyQuestion : DAO : getSurveyQuestionBySurveyId failed !');
                foundSurveyInSurveyQuestion = "false";
                if (isValidSurveyID)
                    insertSurvey(isValidSurveyID, foundSurveyInSurveyQuestion);
            }
        }
    });




    var insertSurvey = function(isValidSurveyID, foundSurveyInSurveyQuestion, data) {

        if ((isValidSurveyID == false) || (foundSurveyInSurveyQuestion == "pending")) {
            return;
        } else {

            surveyQuestion.setSurveyQuestion(reqBody.surveyQuestion);
            surveyQuestion.setSurveyId(reqBody.surveyId);
            surveyQuestion.setAnswerType(reqBody.answerType);
            
            surveyQuestion.setCreatedOn(new Date());
            surveyQuestion.setCreatedBy(req.headers.username);
            surveyQuestion.setUpdatedOn(new Date());
            surveyQuestion.setUpdatedBy(req.headers.username);
            
            if ((reqBody.answerType == "Text") || (reqBody.answerType == "TextArea"))
                surveyQuestion.setAnswerOptions([]);
            else {
                if (reqBody.answerOptions.length == 0) {
                    var err = new Error('answerOptions are required for answerType "CheckBox" and "RadioButton" ');
                    logger.error('surveyQuestion : DAO : failed addNewSurveyQuestion : error : ' + err);
                    callback(err, null)
                }
                surveyQuestion.setAnswerOptions(reqBody.answerOptions);
            }

            if (foundSurveyInSurveyQuestion == "true")
                surveyQuestion.setQuestionNumber(data.length + 1);
            else
                surveyQuestion.setQuestionNumber(1);

            //console.log("saving:-", surveyQuestion.questionNumber);

            surveyQuestion.save(function(err, data) {
                if (err) {

                    logger.error('surveyQuestion : DAO : failed addNewSurveyQuestion : error : ' + err);
                    callback(err, null);
                } else if (data != null) {
                    logger.info('surveyQuestion : DAO : addNewSurveyQuestion successful !');
                    callback(null, data);
                } else {
                    var err = new Error('Failed to add new surveyQuestion details');
                    logger.error('surveyQuestion : DAO : failed addNewSurveyQuestion : error : ' + err);
                    callback(err, null);
                }
            });


        }


    };

};

/*
 * Get surveyQuestion by surveyQuestion id
 */
var getSurveyQuestionById = function(req, res, callback) {
    /*var surveyQuestionId = req.swagger.params.id.value;
	console.log(surveyQuestionId);*/
    logger.info('surveyQuestion : DAO : received request : getSurveyQuestionById : id : ' + req.params.id);
    SurveyQuestion.find({
        'surveyQuestionId': req.params.id
    }, function(err, data) {
        if (err) {
            logger.error('surveyQuestion : DAO : failed getSurveyQuestionById : error : ' + err);
            callback(err, null);
        } else {
            if (data.length != 0) {
                logger.info('surveyQuestion : DAO : getSurveyQuestionById successful !');
                callback(null, data[0]);
            } else {
                var err = new Error('Invalid surveyQuestion id');
                err.status = 404;
                logger.error('surveyQuestion : DAO : failed getSurveyQuestionById : error : ' + err);
                callback(err, null);
            }
        }
    });
};

/*
 * Get all surveyQuestions
 */
var getAllSurveyQuestions = function(req, res, callback) {
    logger.info('surveyQuestion : DAO : received request : getAllSurveyQuestions : status : ' + req.query.status);
    var obj = {};    
    SurveyQuestion.find(obj, function(err, data) {
        if (err) {
            logger.error('surveyQuestion : DAO : failed getAllSurveyQuestions : error : ' + err);
            callback(err, null);
        } else {
            if (data.length != 0) {
                logger.info('surveyQuestion : DAO : getAllSurveyQuestions successful !');
                callback(null, data);
            } else {
                var err = new Error('No records found');
                err.status = 404;
                logger.error('surveyQuestion : DAO : failed getAllSurveyQuestions : error : ' + err);
                callback(err, null);
            }
        }
    });
};

/*
 * Update surveyQuestion details
 */
var updateSurveyQuestionById = function(req, res, callback) {
    logger.info('surveyQuestion : DAO : received request : updateSurveyQuestionById : (surveyQuestionId: ' + req.params.id + ', body: ' + JSON.stringify(req.body) + ')');

    /*
     * Callback function after getting original record to update with new values.
     */
    var callbackUpdate = function(err, data) {
        if (err) {
            logger.error('surveyQuestion : DAO : failed updateSurveyQuestionById : error :' + err);
            callback(err, null);
        } else if (data != null) {
            /*
             *	Compare updatable fields values in db with request data
             *	Add those fields in temproary object which are having new values
             */
            var surveyQuestion = data;
            var json = {};
            var updatedData = [];
            if (req.body.surveyQuestionURL && surveyQuestion['surveyQuestionURL'] != req.body.surveyQuestionURL) {
                json.surveyQuestionURL = req.body.surveyQuestionURL;
                var obj = {};
                obj.column = 'surveyQuestionURL';
                obj.oldValue = surveyQuestion['surveyQuestionURL'];
                obj.newValue = req.body.surveyQuestionURL;
                obj.identifier = 'Platform_surveyQuestion_' + req.params.id;
                obj.modifiedBy = 'admin';
                obj.modifiedOn = new Date();
                updatedData.push(obj);
            }
            if (req.body.surveyQuestionImageURL && surveyQuestion['surveyQuestionImageURL'] != req.body.surveyQuestionImageURL) {
                json.surveyQuestionImageURL = req.body.surveyQuestionImageURL;
                var obj = {};
                obj.column = 'surveyQuestionImageURL';
                obj.oldValue = surveyQuestion['surveyQuestionImageURL'];
                obj.newValue = req.body.surveyQuestionImageURL;
                obj.identifier = 'Platform_surveyQuestion_' + req.params.id;
                obj.modifiedBy = 'admin';
                obj.modifiedOn = new Date();
                updatedData.push(obj);
            }
            if (req.body.phone && surveyQuestion['phone'] != req.body.phone) {
                json.phone = req.body.phone;
                var obj = {};
                obj.column = 'phone';
                obj.oldValue = surveyQuestion['phone'];
                obj.newValue = req.body.phone;
                obj.identifier = 'Platform_surveyQuestion_' + req.params.id;
                obj.modifiedBy = 'admin';
                obj.modifiedOn = new Date();
                updatedData.push(obj);
            }
            if (req.body.fax && surveyQuestion['fax'] != req.body.fax) {
                json.fax = req.body.fax;
                var obj = {};
                obj.column = 'fax';
                obj.oldValue = surveyQuestion['fax'];
                obj.newValue = req.body.fax;
                obj.identifier = 'Platform_surveyQuestion_' + req.params.id;
                obj.modifiedBy = 'admin';
                obj.modifiedOn = new Date();
                updatedData.push(obj);
            }
            if (req.body.email && surveyQuestion['email'] != req.body.email) {
                json.email = req.body.email;
                var obj = {};
                obj.column = 'email';
                obj.oldValue = surveyQuestion['email'];
                obj.newValue = req.body.email;
                obj.identifier = 'Platform_surveyQuestion_' + req.params.id;
                obj.modifiedBy = 'admin';
                obj.modifiedOn = new Date();
                updatedData.push(obj);
            }
            if (req.body.adminFullName && surveyQuestion['adminFullName'] != req.body.adminFullName) {
                json.adminFullName = req.body.adminFullName;
                var obj = {};
                obj.column = 'adminFullName';
                obj.oldValue = surveyQuestion['adminFullName'];
                obj.newValue = req.body.adminFullName;
                obj.identifier = 'Platform_surveyQuestion_' + req.params.id;
                obj.modifiedBy = 'admin';
                obj.modifiedOn = new Date();
                updatedData.push(obj);
            }
            if (req.body.adminMobile && surveyQuestion['adminMobile'] != req.body.adminMobile) {
                json.adminMobile = req.body.adminMobile;
                var obj = {};
                obj.column = 'adminMobile';
                obj.oldValue = surveyQuestion['adminMobile'];
                obj.newValue = req.body.adminMobile;
                obj.identifier = 'Platform_surveyQuestion_' + req.params.id;
                obj.modifiedBy = 'admin';
                obj.modifiedOn = new Date();
                updatedData.push(obj);
            }
            if (req.body.adminEmail && surveyQuestion['adminEmail'] != req.body.adminEmail) {
                json.adminEmail = req.body.adminEmail;
                var obj = {};
                obj.column = 'adminEmail';
                obj.oldValue = surveyQuestion['adminEmail'];
                obj.newValue = req.body.adminEmail;
                obj.identifier = 'Platform_surveyQuestion_' + req.params.id;
                obj.modifiedBy = 'admin';
                obj.modifiedOn = new Date();
                updatedData.push(obj);
            }
            if (req.body.status && surveyQuestion['status'] != req.body.status) {
                json.status = req.body.status;
                var obj = {};
                obj.column = 'status';
                obj.oldValue = surveyQuestion['status'];
                obj.newValue = req.body.status;
                obj.identifier = 'Platform_surveyQuestion_' + req.params.id;
                obj.modifiedBy = 'admin';
                obj.modifiedOn = new Date();
                updatedData.push(obj);
            }
            if (req.body.adminMobileVerified && surveyQuestion['adminMobileVerified'] != req.body.adminMobileVerified) {
                json.adminMobileVerified = req.body.adminMobileVerified;
                var obj = {};
                obj.column = 'adminMobileVerified';
                obj.oldValue = surveyQuestion['adminMobileVerified'];
                obj.newValue = req.body.adminMobileVerified;
                obj.identifier = 'Platform_surveyQuestion_' + req.params.id;
                obj.modifiedBy = 'admin';
                obj.modifiedOn = new Date();
                updatedData.push(obj);
            }
            if (req.body.adminEmailVerified && surveyQuestion['adminEmailVerified'] != req.body.adminEmailVerified) {
                json.adminEmailVerified = req.body.adminEmailVerified;
                var obj = {};
                obj.column = 'adminEmailVerified';
                obj.oldValue = surveyQuestion['adminEmailVerified'];
                obj.newValue = req.body.adminEmailVerified;
                obj.identifier = 'Platform_surveyQuestion_' + req.params.id;
                obj.modifiedBy = 'admin';
                obj.modifiedOn = new Date();
                updatedData.push(obj);
            }

            /*
             *	Update the data to database
             */
            if (Object.keys(json).length != 0) {
                json.updatedOn = new Date();
                json.updatedBy = req.headers.username;
                logger.info('surveyQuestion : DAO : updateSurveyQuestionById : updating data : ' + JSON.stringify(json));
                SurveyQuestion.findOneAndUpdate({
                    'surveyQuestionId': req.params.id
                }, json, {
                    'new': true
                        // returns updated entity if update successful, if false then old entry
                }, function(err, data) {
                    if (err) {
                        logger.error('surveyQuestion : DAO : failed updateSurveyQuestionById : error :' + err);
                        callback(err, null);
                    } else {
                        if (data != null) {
                            logger.info('surveyQuestion : DAO : updateSurveyQuestionById successful !');
                            /*
                             *	Call audit function for changed data
                             */
                            audit(req, res, updatedData);
                            /*
                             *	Call function to send response to client
                             */
                            callback(null, data);
                        } else {
                            var err = new Error('Bad request data');
                            logger.error('surveyQuestion : DAO : failed updateSurveyQuestionById : error :' + err);
                            callback(err, null);
                        }
                    }
                });
            } else {
                var err = new Error('Cannot update data');
                logger.error('surveyQuestion : DAO : failed updateSurveyQuestionById : error :' + err);
                callback(err, null);
            }
        } else {
            var err = new Error('Failed to get surveyQuestion details');
            logger.error('surveyQuestion : DAO : failed updateSurveyQuestionById : error :' + err);
            callback(err, null);
        }
    }

    /*
     * Get the original record from db before update.
     */
    getSurveyQuestionById(req, res, callbackUpdate);
};

/*
 * Delete surveyQuestion details
 */
var deleteSurveyQuestionById = function(req, res, callback) {
    logger.info('surveyQuestion : DAO : received request : deleteSurveyQuestionById : id : ' + req.params.id);
    var callbackDelete = function(err, data) {
        if (err) {
            logger.error('surveyQuestion : DAO : failed deleteSurveyQuestionById : error :' + err);
            callback(err, null);
        } else if (data != null) {
            var surveyQuestion = data;
            var updatedData = [];
            if (surveyQuestion.status != 'DELETED') {
                var json = {
                    'status': 'DELETED',
                    'updatedOn': new Date(),
                	'updatedBy': req.headers.username
                };
                SurveyQuestion.findOneAndUpdate({
                    'surveyQuestionId': req.params.id
                }, json, {
                    'new': true
                }, function(err, data) {
                    if (err) {
                        logger.error('surveyQuestion : DAO : failed deleteSurveyQuestionById : error :' + err);
                        callback(err, null);
                    } else if (data != null) {
                        logger.info('surveyQuestion : DAO : deleteSurveyQuestionById successful !');
                        var obj = {};
                        obj.column = 'status';
                        obj.oldValue = surveyQuestion['status'];
                        obj.newValue = data.status;
                        obj.identifier = 'Platform_surveyQuestion_' + req.params.id;
                        obj.modifiedBy = 'admin';
                        obj.modifiedOn = new Date();
                        updatedData.push(obj);
                        /*
                         *	Call audit function for changed data
                         */
                        audit(req, res, updatedData);
                        /*
                         *	Call function to send response to client
                         */
                        callback(null, data);
                    } else {
                        var err = new Error('Invalid compnay id');
                        logger.error('surveyQuestion : DAO : failed deleteSurveyQuestionById : error :' + err);
                        callback(err, null);
                    }
                });
            } else {
                var err = new Error('Already deleted');
                logger.error('surveyQuestion : DAO : failed deleteSurveyQuestionById : error :' + err);
                callback(err, null);
            }
        } else {
            var err = new Error('Failed to get surveyQuestion details');
            logger.error('surveyQuestion : DAO : failed deleteSurveyQuestionById : error :' + err);
            callback(err, null)
        }
    }

    /*
     * Get the original record from db before update.
     */
    getSurveyQuestionById(req, res, callbackDelete);

};


module.exports.addNewSurveyQuestion = addNewSurveyQuestion;
module.exports.getSurveyQuestionById = getSurveyQuestionById;
module.exports.getAllSurveyQuestions = getAllSurveyQuestions;
//module.exports.updateSurveyQuestionById = updateSurveyQuestionById;
//module.exports.deleteSurveyQuestionById = deleteSurveyQuestionById;