var mongoose = require('../../common/MongoDbConnection').mongoose;
var autoIncrement = require('mongoose-auto-increment');
var logger = require('../../common/logger').log;
var connection = mongoose.connection;
autoIncrement.initialize(connection);
/*
 * logging format followed: logger.info(<module_name>: <component name> :
 * <description> : <long_description> : <data/params/errors>);
 */


/*
 * Define schema
 */
var surveySchema = mongoose.Schema({
    surveyId: Number,
    surveyName: {
        type: String,
        unique: true,
        required: true
    },
    surveyDescription: {
        type: String,
        required: true
    },
    noOfQuestions: {
        type: Number,
        required: true
    },
    surveyType: {
        type: String,
        enum: ['poll', 'rating', 'survey', 'feedback'],
        required: true
    },
    surveyFeedback: {
        type: String,
        required: false
    },
    surveyStatus: {
        type: String,
        enum: ['active', 'draft', 'inactive', 'expired']
    },
    surveyStartDate: {
        type: Date
    },
    surveyEndDate: {
        type: Date
    },
    createdOn: {
        type: Date
    },
    createdBy: {
        type: String
    },
    updatedOn: {
        type: Date
    },
    updatedBy: {
        type: String
    }
});


logger.info('survey : model : created schema : Surveys :' + JSON.stringify(surveySchema.paths));


surveySchema.path('surveyName').validate(function(value, fn) {
    var Survey = mongoose.model('Surveys');
    Survey.find({
        'surveyName': value
    }, function(err, data) {
        fn(err || data.length === 0);
    });
}, 'Survey name is already taken');

surveySchema.pre('findOneAndUpdate', function(next) {
    this.options.runValidators = true;
    next();
});

surveySchema.path('surveyName').validate(function(v) {
    return v.length <= 100;
}, 'data too long for field surveyName');

/*
 * Add Auto increment plugin for field surveyId
 */
surveySchema.plugin(autoIncrement.plugin, {
    model: 'Surveys',
    field: 'surveyId', startAt: 1
});


/*
 * Setters
 */
surveySchema.methods.setSurveyId = function(surveyId) {
    this.surveyId = surveyId;
};

surveySchema.methods.setSurveyName = function(surveyName) {
    this.surveyName = surveyName;
};

surveySchema.methods.setSurveyDescription = function(surveyDescription) {
    this.surveyDescription = surveyDescription;
};

surveySchema.methods.setNoOfQuestions = function(noOfQuestions) {
    this.noOfQuestions = noOfQuestions;
};

surveySchema.methods.setSurveyType = function(surveyType) {
    this.surveyType = surveyType;
};

surveySchema.methods.setSurveyFeedback = function(surveyFeedback) {
    this.surveyFeedback = surveyFeedback;
};

surveySchema.methods.setSurveyStartDate = function(surveyStartDate) {
    this.surveyStartDate = surveyStartDate;
};

surveySchema.methods.setSurveyEndDate = function(surveyEndDate) {
    this.surveyEndDate = surveyEndDate;
};

surveySchema.methods.setCreatedOn = function(createdOn) {
    this.createdOn = createdOn;
};

surveySchema.methods.setCreatedBy = function(createdBy) {
    this.createdBy = createdBy;
};

surveySchema.methods.setUpdatedOn = function(updatedOn) {
    this.updatedOn = updatedOn;
};

surveySchema.methods.setUpdatedBy = function(updatedBy) {
    this.updatedBy = updatedBy;
};

surveySchema.methods.setSurveyStatus = function(surveyStatus) {
    this.surveyStatus = surveyStatus;
};

/*
 * Getters
 */
surveySchema.methods.getSurveyId = function() {
    return this.surveyId;
};

surveySchema.methods.getSurveyName = function() {
    return this.surveyName;
};

surveySchema.methods.getSurveyDescription = function() {
    return this.surveyDescription;
};

surveySchema.methods.getNoOfQuestions = function() {
    return this.noOfQuestions;
};

surveySchema.methods.getSurveyName = function() {
    return this.surveyName;
};

surveySchema.methods.getSurveyType = function() {
    return this.surveyType;
};

surveySchema.methods.getSurveyFeedback = function() {
    return this.surveyFeedback;
};

surveySchema.methods.getSurveyStartDate = function() {
    return this.surveyStartDate;
};

surveySchema.methods.getSurveyEndDate = function() {
    return this.surveyEndDate;
};

surveySchema.methods.getSurveyStatus = function() {
    return this.surveyStatus;
};
/*
 * Create collection/model in mongo db using Schema
 */
var Survey = mongoose.model('Surveys', surveySchema);
logger.info('survey : model : created model : Surveys : ' + Survey);



module.exports = Survey;