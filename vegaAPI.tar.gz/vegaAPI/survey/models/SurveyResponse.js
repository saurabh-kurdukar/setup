var mongoose = require('../../common/MongoDbConnection').mongoose;
var autoIncrement = require('mongoose-auto-increment');
var connection = mongoose.connection;
autoIncrement.initialize(connection);
/*
 * logging format followed: logger.info(<module_name>: <component name> :
 * <description> : <long_description> : <data/params/errors>);
 */


/*
 * Define schema
 */

var responseSchema = mongoose.Schema({
    questionId: Number,
    answer: [String]
});

var surveyResponseSchema = mongoose.Schema({
    surveyResponseId: Number,
    surveyAssociationId: {
        type: Number,
        required: 'Field surveyAssociationId is required'
    },
    userId: {
        type: String,
        required: 'Field userId is required'
    },
    surveyId: {
        type: Number,
        required: 'Field surveyId is required'
    },
    surveyEntityType: {
        type: String,
        required: 'Field surveyEntityType is required'
    },
    surveyEntityTypeReF: {
        type: Number,
        required: 'Field surveyEntityTypeReF is required'
    },
    answers: {
        type: [responseSchema],
        required: 'Field answers is required'
    },
    createdOn: {
        type: Date
    },
    createdBy: {
        type: String
    },
    updatedOn: {
        type: Date
    },
    updatedBy: {
        type: String
    }
});



/*
surveyResponseSchema.path('surveyResponse').validate(function(value, fn) {
	  var SurveyResponse = mongoose.model('SurveyResponses');
	  SurveyResponse.find({'surveyResponse': value}, function (err, data) {
	    fn(err || data.length === 0);
	  });
}, 'SurveyResponse name is already taken');*/

/*surveyResponseSchema.pre('findOneAndUpdate', function(next) {
	  this.options.runValidators = true;
	  next();
});

surveyResponseSchema.path('surveyResponse').validate(function (v) {
	  return v.length <= 100;
}, 'data too long for field surveyResponse'); */

/*
 * Add Auto increment plugin for field surveyResponseId
 */
surveyResponseSchema.plugin(autoIncrement.plugin, {
    model: 'SurveyResponses',
    field: 'surveyResponseId', startAt: 1
});


/*
 * Setters
 */
surveyResponseSchema.methods.setSurveyResponseId = function(surveyResponseId) {
    this.surveyResponseId = surveyResponseId;
};

surveyResponseSchema.methods.setSurveyAssociationId = function(surveyAssociationId) {
    this.surveyAssociationId = surveyAssociationId;
};

surveyResponseSchema.methods.setUserId = function(userId) {
    this.userId = userId;
};

surveyResponseSchema.methods.setSurveyId = function(surveyId) {
    this.surveyId = surveyId;
};

surveyResponseSchema.methods.setSurveyEntityType = function(surveyEntityType) {
    this.surveyEntityType = surveyEntityType;
};

surveyResponseSchema.methods.setSurveyEntityTypeReF = function(surveyEntityTypeReF) {
    this.surveyEntityTypeReF = surveyEntityTypeReF;
};

surveyResponseSchema.methods.setAnswers = function(answers) {
    this.answers = answers;
};

surveyResponseSchema.methods.setCreatedOn = function(createdOn) {
    this.createdOn = createdOn;
};

surveyResponseSchema.methods.setCreatedBy = function(createdBy) {
    this.createdBy = createdBy;
};

surveyResponseSchema.methods.setUpdatedOn = function(updatedOn) {
    this.updatedOn = updatedOn;
};

surveyResponseSchema.methods.setUpdatedBy = function(updatedBy) {
    this.updatedBy = updatedBy;
};

/*
 * Getters
 */
surveyResponseSchema.methods.getSurveyResponseId = function() {
    return this.surveyResponseId;
};

surveyResponseSchema.methods.getSurveyAssociationId = function() {
    return this.surveyAssociationId;
};

surveyResponseSchema.methods.getUserId = function() {
    return this.userId;
};

surveyResponseSchema.methods.getAnswers = function() {
    return this.answers;
};

/*
 * Create collection/model in mongo db using Schema
 */
var SurveyResponse = mongoose.model('SurveyResponses', surveyResponseSchema);



module.exports = SurveyResponse;