var mongoose = require('../../common/MongoDbConnection').mongoose;
var autoIncrement = require('mongoose-auto-increment');
var logger = require('../../common/logger').log;
var connection = mongoose.connection;
autoIncrement.initialize(connection);
/*
 * logging format followed: logger.info(<module_name>: <component name> :
 * <description> : <long_description> : <data/params/errors>);
 */


/*
 * Define schema
 */

var responseSchema = mongoose.Schema({
    questionId: Number,
    answers: [{
        answerOption: Number,
        responses: Number
    }]
});

var averageSchema = mongoose.Schema({
    questionId: Number,
    average: Number
});


var surveyAssociationSchema = mongoose.Schema({
    surveyAssociationId: Number,
    surveyId: {
        type: Number,
        required: true
    },
    surveyEntityType: {
        type: String,
        required: true
    },
    surveyEntityTypeReF: {
        type: Number,
        required: true
    },
    surveyResponses: {
        type: [responseSchema],
        required: false
    },
    surveyAverages: {
        type: [averageSchema]
    },
    totalSurveyResponses: {
        type: Number,
        required: false
    },
    createdOn: {
        type: Date
    },
    createdBy: {
        type: String
    },
    updatedOn: {
        type: Date
    },
    updatedBy: {
        type: String
    }
});


logger.info('surveyAssociation : model : created schema : SurveyAssociations :' + JSON.stringify(surveyAssociationSchema.paths));

/*
surveyAssociationSchema.path('surveyAssociationName').validate(function(value, fn) {
	  var SurveyAssociation = mongoose.model('SurveyAssociations');
	  SurveyAssociation.find({'surveyAssociationName': value}, function (err, data) {
	    fn(err || data.length === 0);
	  });
}, 'SurveyAssociation name is already taken');

surveyAssociationSchema.pre('findOneAndUpdate', function(next) {
	  this.options.runValidators = true;
	  next();
});

surveyAssociationSchema.path('surveyAssociationName').validate(function (v) {
	  return v.length <= 100;
}, 'data too long for field surveyAssociationName');
*/
/*
 * Add Auto increment plugin for field surveyAssociationId
 */
surveyAssociationSchema.plugin(autoIncrement.plugin, {
    model: 'SurveyAssociations',
    field: 'surveyAssociationId', startAt: 1
});


/*
 * Setters
 */
surveyAssociationSchema.methods.setSurveyAssociationId = function(surveyAssociationId) {
    this.surveyAssociationId = surveyAssociationId;
};

surveyAssociationSchema.methods.setSurveyId = function(surveyId) {
    this.surveyId = surveyId;
};

surveyAssociationSchema.methods.setSurveyEntityType = function(surveyEntityType) {
    this.surveyEntityType = surveyEntityType;
};

surveyAssociationSchema.methods.setSurveyEntityTypeReF = function(surveyEntityTypeReF) {
    this.surveyEntityTypeReF = surveyEntityTypeReF;
};

surveyAssociationSchema.methods.setSurveyResponses = function(surveyResponses) {
    this.surveyResponses = surveyResponses;
};

surveyAssociationSchema.methods.setSurveyAverages = function(surveyAverages) {
    this.surveyAverages = surveyAverages;
};

surveyAssociationSchema.methods.setTotalSurveyResponses = function(totalSurveyResponses) {
    this.totalSurveyResponses = totalSurveyResponses;
};

surveyAssociationSchema.methods.setCreatedOn = function(createdOn) {
    this.createdOn = createdOn;
};

surveyAssociationSchema.methods.setCreatedBy = function(createdBy) {
    this.createdBy = createdBy;
};

surveyAssociationSchema.methods.setUpdatedOn = function(updatedOn) {
    this.updatedOn = updatedOn;
};

surveyAssociationSchema.methods.setUpdatedBy = function(updatedBy) {
    this.updatedBy = updatedBy;
};

/*
 * Getters
 */
surveyAssociationSchema.methods.getSurveyAssociationId = function() {
    return this.surveyAssociationId;
};

surveyAssociationSchema.methods.getSurveyId = function() {
    return this.surveyId;
};

surveyAssociationSchema.methods.getSurveyEntityType = function() {
    return this.surveyEntityType;
};

surveyAssociationSchema.methods.getSurveyEntityTypeReF = function() {
    return this.surveyEntityTypeReF;
};

surveyAssociationSchema.methods.getSurveyResponses = function() {
    return this.surveyResponses;
};

surveyAssociationSchema.methods.getSurveyAverages = function() {
    return this.surveyAverages;
};

surveyAssociationSchema.methods.getTotalSurveyResponses = function() {
    return this.totalSurveyResponses;
};


/*
 * Create collection/model in mongo db using Schema
 */
var SurveyAssociation = mongoose.model('SurveyAssociations', surveyAssociationSchema);
logger.info('surveyAssociation : model : created model : SurveyAssociations : ' + SurveyAssociation);



module.exports = SurveyAssociation;