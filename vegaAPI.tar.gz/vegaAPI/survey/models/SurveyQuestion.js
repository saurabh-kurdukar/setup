var mongoose = require('../../common/MongoDbConnection').mongoose;
var autoIncrement = require('mongoose-auto-increment');
var logger = require('../../common/logger').log;
var connection = mongoose.connection;
autoIncrement.initialize(connection);
/*
 * logging format followed: logger.info(<module_name>: <component name> :
 * <description> : <long_description> : <data/params/errors>);
 */


/*
 * Define schema
 */
var surveyQuestionSchema = mongoose.Schema({
    surveyQuestionId: {
        type: Number
    },
    surveyId: {
        type: Number,
        required: true
    },
    surveyQuestion: {
        type: String,
        required: true
    },
    answerType: {
        type: String,
        enum: ['RadioButton', 'CheckBox', 'Text', 'TextArea'],
        required: true
    },
    answerOptions: {
        type: [String],
        required: false
    },
    questionNumber: {
        type: Number
    },
    createdOn: {
        type: Date
    },
    createdBy: {
        type: String
    },
    updatedOn: {
        type: Date
    },
    updatedBy: {
        type: String
    }

});


logger.info('surveyQuestion : model : created schema : SurveyQuestions :' + JSON.stringify(surveyQuestionSchema.paths));

/*
surveyQuestionSchema.path('surveyQuestion').validate(function(value, fn) {	  
	  var SurveyQuestion = mongoose.model('SurveyQuestions');
	  SurveyQuestion.find({'surveyQuestion': value}, function (err, data) {
	    fn(err || data.length === 0);
	  });
}, 'SurveyQuestion name is already taken');*/

surveyQuestionSchema.pre('findOneAndUpdate', function(next) {
    this.options.runValidators = true;
    next();
});

surveyQuestionSchema.path('surveyQuestion').validate(function(v) {
    return v.length <= 100;
}, 'data too long for field surveyQuestion');

/*
 * Add Auto increment plugin for field surveyQuestionId
 */
surveyQuestionSchema.plugin(autoIncrement.plugin, {
    model: 'SurveyQuestions',
    field: 'surveyQuestionId', startAt: 1
});


/*
 * Setters
 */
surveyQuestionSchema.methods.setSurveyQuestionId = function(surveyQuestionId) {
    this.surveyQuestionId = surveyQuestionId;
};

surveyQuestionSchema.methods.setSurveyId = function(surveyId) {
    this.surveyId = surveyId;
};

surveyQuestionSchema.methods.setSurveyQuestion = function(surveyQuestion) {
    this.surveyQuestion = surveyQuestion;
};

surveyQuestionSchema.methods.setAnswerType = function(answerType) {
    this.answerType = answerType;
};

surveyQuestionSchema.methods.setAnswerOptions = function(answerOptions) {
    this.answerOptions = answerOptions;
};

surveyQuestionSchema.methods.setQuestionNumber = function(questionNumber) {
    this.questionNumber = questionNumber;
};

surveyQuestionSchema.methods.setCreatedOn = function(createdOn) {
    this.createdOn = createdOn;
};

surveyQuestionSchema.methods.setCreatedBy = function(createdBy) {
    this.createdBy = createdBy;
};

surveyQuestionSchema.methods.setUpdatedOn = function(updatedOn) {
    this.updatedOn = updatedOn;
};

surveyQuestionSchema.methods.setUpdatedBy = function(updatedBy) {
    this.updatedBy = updatedBy;
};

/*
 * Getters
 */
surveyQuestionSchema.methods.setSurveyQuestionId = function(surveyQuestionId) {
    return this.surveyQuestionId;
};

surveyQuestionSchema.methods.getSurveyId = function() {
    return this.surveyId;
};

surveyQuestionSchema.methods.getSurveyQuestion = function() {
    return this.surveyQuestion;
};

surveyQuestionSchema.methods.getAnswerType = function() {
    return this.answerType;
};

surveyQuestionSchema.methods.getAnswerOptions = function() {
    return this.answerOptions;
};

surveyQuestionSchema.methods.getQuestionNumber = function() {
    return this.questionNumber;
};

/*
 * Create collection/model in mongo db using Schema
 */
var SurveyQuestion = mongoose.model('SurveyQuestions', surveyQuestionSchema);
logger.info('surveyQuestion : model : created model : SurveyQuestions : ' + SurveyQuestion);



module.exports = SurveyQuestion;