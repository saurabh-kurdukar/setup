var express = require('express');
var surveyAssociationController = require('./controller/SurveyAssociationController');
var logger = require('../common/logger').log;
var ErrorResponse = require('../common/ErrorResponse').ErrorResponse;
var router = express.Router();

/*
 * logging format followed: logger.info(<module_name>: <component name> : <description> : [<long_description>] : <data/params/errors>);
 */

/*
 * Add new surveyAssociation details
 */
router.post('/', function(req, res) {
	logger.info('surveyAssociation : router : received request : addNewSurveyAssociation : body : '+JSON.stringify(req.body));	
	if(req.headers['username']) {
		surveyAssociationController.addNewSurveyAssociation(req, res, function(err, data) {
	        if(err) {
	        	logger.error('surveyAssociation : router : failed addNewSurveyAssociation : error : '+err);     
	        	var error = new ErrorResponse();
	        	if(err.name == 'ValidationError'){
	        		error.setErrorMessage(err.errors[Object.keys(err.errors)[0]].message);
	        	} else {
	        		error.setErrorMessage(err.message);
	        	}
	        	error.setErrorCode("SA0001");        	
	        	error.setHttpResponseCode(500);        	
	        	res.status(500).end(JSON.stringify(error));        
	        } else {        	
	        	logger.info("surveyAssociation : router : addNewSurveyAssociation successful !");
	        	res.status(200).end(JSON.stringify(data));
	        }
	    });
	} else {
		var error = new ErrorResponse();
		error.setErrorCode("SA0001");
		error.setErrorMessage('missing username in header.');
		error.setHttpResponseCode(400);
		res.status(400).send(JSON.stringify(error));
	}
});

/*
 * Get surveyAssociation by surveyAssociation id
 */
router.get('/:id', function (req, res) {
	logger.info('surveyAssociation : router : received request : getSurveyAssociationById : id : '+req.params.id);
	surveyAssociationController.getSurveyAssociationById(req, res, function(err, data) {
        if(err){
        	logger.error('surveyAssociation : router : failed getSurveyAssociationById : error : '+err);  
        	var error = new ErrorResponse();
        	error.setErrorCode("SA0002");
        	error.setErrorMessage(err.message);
        	error.setHttpResponseCode(500);
            res.status(500).end(JSON.stringify(error));
        }else{        	
        	logger.info("surveyAssociation : router : getSurveyAssociationById successful !") ;
        	res.status(200).end(JSON.stringify(data));
        }
    });
});

/*
 * Get surveyAssociations
 */
router.get('/', function (req, res) {	
	logger.info('surveyAssociation : router : received request : getAllSurveyAssociations : query params : '
			+ JSON.stringify(req.query));
	surveyAssociationController.getAllSurveyAssociations(req, res, function(err, data) {
        if(err){
        	logger.error('surveyAssociation : router : failed getAllSurveyAssociations : error : '+err);   
        	var error = new ErrorResponse();
        	error.setErrorCode("SA0003");
        	error.setErrorMessage(err.message);
        	error.setHttpResponseCode(500);
            res.status(500).end(JSON.stringify(error));
        }else{        	
        	logger.info("surveyAssociation : router : getAllSurveyAssociations successful !");
        	res.status(200).end(JSON.stringify(data));
        }
    });
});

/*
 * Update surveyAssociation details
*/
router.put('/:id', function(req, res){	 
	logger.info('surveyAssociation : router : received request : updateSurveyAssociationById : (surveyAssociationId: '+req.params.id+', body: '+JSON.stringify(req.body)+')');
	if(req.headers['username']) {
		surveyAssociationController.updateSurveyAssociationById(req, res, function(err, data) {
	        if(err){
	        	logger.error('surveyAssociation : router : failed updateSurveyAssociationById : error : '+err);   
	        	var error = new ErrorResponse();
	        	if(err.name == 'ValidationError'){
	        		error.setErrorMessage(err.errors[Object.keys(err.errors)[0]].message);
	        	} else {
	        		error.setErrorMessage(err.message);
	        	}
	        	error.setErrorCode("SA0004");        	
	        	error.setHttpResponseCode(500);
	            res.status(500).end(JSON.stringify(error));
	        }else{        	
	        	logger.info("surveyAssociation : router : updateSurveyAssociationById successful !");
	        	res.status(200).end(JSON.stringify(data));
	        }
	    });
	} else {
		var error = new ErrorResponse();
		error.setErrorCode("SA0004");
		error.setErrorMessage('missing username in header.');
		error.setHttpResponseCode(400);
		res.status(400).send(JSON.stringify(error));
	}
}); 


/*
 * Delete surveyAssociation details
 
router.delete('/:id', function(req, res){
	logger.info('surveyAssociation : router : received request : deleteSurveyAssociationById : id : '+req.params.id);
	surveyAssociationController.deleteSurveyAssociationById(req, res, function(err, data) {
        if(err){
        	logger.error('surveyAssociation : router : failed deleteSurveyAssociationById : error : '+err); 
        	var error = new ErrorResponse();
        	error.setErrorCode("A0002");
        	error.setErrorMessage(err.message);
        	error.setHttpResponseCode(500);
            res.status(500).end(JSON.stringify(error));
        }else{        	
        	logger.info("surveyAssociation : router : deleteSurveyAssociationById successful !");
        	res.status(200).end(JSON.stringify(data));
        }
    });
});*/




module.exports = router;







