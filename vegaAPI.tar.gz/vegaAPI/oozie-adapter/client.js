'use strict';

var logger = require('./../common/logger').log
.child({module : 'Oozie', type : 'Adapter'}),
config = require('./../common/Config'),
PlatformError = require('./../common/platform-error'),
WorkflowConfigurations = require('./dto/workflow-configurations'),
request = require('request');

const APPLICATION_JSON = 'json',
APPLICATION_XML = 'xml',
IMAGE = 'image';

function sendRequestToOozie(httpMethod, relativeUrl, dataType, content, cb) {

	var requestOptions = {
			method: httpMethod,
			url: `${config.OOZIE_BASE_URL}${relativeUrl}`
	};

	if(dataType === APPLICATION_JSON) {
		requestOptions.json = true;
		requestOptions.body = content;
	} else if(dataType === APPLICATION_XML) {
		requestOptions.body = content;
		requestOptions.headers = {
			'Content-Type' : 'application/xml'
		};
	} else if(dataType === IMAGE) {
		requestOptions.headers = {
			'Content-Type' : 'image/png'
		};
		requestOptions.encoding = null;
	}

	request(requestOptions, function (err, res, body) {
		cb(err, res, body);
	});
}

function getJobStatus(jobId, cb) {

	var processResponse = function (err, res, body) {

		if (err) {
			logger.debug(`Error occurred while retrieving job status from Oozie : ${jobId}`, err);
			cb(new PlatformError('OZWK002', [jobId], 500, err));
		} else if(res.statusCode === 200 && body) {
			cb(null, JSON.parse(body));
		} else {
			cb(new PlatformError('OZWK001', [], 500, body));
		}
	};

	sendRequestToOozie(
			'get',
			'job/' + jobId,
			APPLICATION_XML,
			null,
			processResponse
	);
}

function getJobGraph(jobId, cb) {

	var processResponse = function (err, res, body) {

		if (err) {
			logger.debug(`Error occurred while retrieving job graph from Oozie : ${jobId}`, err);
			cb(new PlatformError('OZWK004', [jobId], 500, err));
		} else if(res.statusCode === 200 && body) {
			cb(null,  body);
		} else {
			cb(new PlatformError('OZWK001', [], 500, body));
		}
	};

	sendRequestToOozie(
			'get',
			'job/' + jobId + '?show=graph&show-kill=true',
			IMAGE,
			null,
			processResponse
	);
}

function processWorkflow(pipeline, cb) {

	var processResponse = function (err, res, body) {

		if (err) {
			logger.debug(`Error occurred while processing oozie workflow for data pipeline : ${pipeline.id}`, err);
			cb(new PlatformError('OZWK003', [pipeline.id], 500, err));
		} else if(res.statusCode === 201 && body) {
			cb(null, JSON.parse(body));
		} else {
			cb(new PlatformError('OZWK001', [], 500, body));
		}
	};

	sendRequestToOozie(
			'post',
			'jobs?action=start',
			APPLICATION_XML,
			new WorkflowConfigurations(pipeline).convertToXml(),
			processResponse
	);
}

module.exports = {
		processWorkflow : processWorkflow,
		getJobStatus : getJobStatus,
		getJobGraph : getJobGraph
};
