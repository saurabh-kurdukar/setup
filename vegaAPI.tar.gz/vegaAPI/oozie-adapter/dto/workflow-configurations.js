'use strict';

var xml2js = require('xml2js');

function WorkflowConfigurations(workflow) {

  let workflowConfigurations = {
    'configuration' : {
      'property' : []
    }
  };

  workflowConfigurations.initialize = function() {

    workflow.configurations.forEach(function(configuration) {
      workflowConfigurations.configuration.property.push(configuration);
    });
  };

  workflowConfigurations.convertToXml = function() {
    return new xml2js.Builder().buildObject(
      JSON.parse(
        JSON.stringify(
          workflowConfigurations)));
  };

  workflowConfigurations.initialize();

  return workflowConfigurations;
}

module.exports = WorkflowConfigurations;
