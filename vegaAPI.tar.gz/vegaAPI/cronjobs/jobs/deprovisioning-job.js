var dao = require('../../provision/dao/provision-experience-dao');
var controller= require('../../provision/controller/provision-experience');
var PlatformError = require('../../common/platform-error');
var logger = require('../../common/logger').log
.child(
        {module : 'cronjobs', 
        type : 'DeprovisioningJob'}
      );



/*
    Function to Log Error Messages
*/
function logErrorMessage(failureLog, err) {
	   
        if (err) {
		    if(err instanceof PlatformError) {
			logger.error(`${failureLog} Stack trace : \n ${err.stack}`);
        } else {
			logger.error(`${failureLog} Root cause : \n ${JSON.stringify(err)}`);
				
		}
	} 
};

/*
Function to De-Provision Expired Jobs
*/
function deProvisionJobs(records){
    
    records.forEach(function(data){
                    logger.debug(` DE-PROVISIONING REQUEST # ${data._id} `);
                    controller.deprovision(data._id,function(err, data){
                    if(err){
                    logErrorMessage(`FAILED: UNABLE TO DE-PROVISION REQUEST # ${data._id} `, err);
                    }else{
                        logger.info(`SUCCESS: #${data._id} REQUEST GOT DE-PROVISIONED`);
                    };                           
                    
                    });
              });
};


/*
Main Process method to invoke De-provioning
*/
var process= function(){    
    
logger.info(`Deprovisioning JOB in process` +new Date());
        
    dao.getAllExpiredProvisionedRequests(function(err,records){
            if(err) {
                logErrorMessage('FAILED: UNABLE TO FETCH RECORDS FROM DATASTORE ', err);
            }else{                         
            logger.info(` RECORDS FOUND FOR DE-PROVISIONG`);
              deProvisionJobs(records);         
            };     
    });
 };

var complete= function(){
 
   logger.info(`  DE-PROVISIONING REQUEST GOT COMPLETED AT:  ` + new Date());
};  

exports.process=process;
exports.complete=complete;