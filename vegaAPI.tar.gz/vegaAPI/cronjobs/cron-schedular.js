//loading required modules
var cronJobs= require('cron').CronJob;
var cronConfig= require('../common/jobs-Config.json');
config = require('../common/Config');
var jobsDirPath= config.CRONJOBS_DIR_PATH;
var logger = require('../common/logger').log
.child(
        {module : 'cronjobs', 
        type : 'cronSchedular'}
      );


/*
Getting job configuration from json
starting the job  
*/
var scheduleJobs = function(){
        
    cronConfig.jobs.forEach(function(job){
            
            var jobFile = jobsDirPath + '/'+job.jobName+'.js';
            var cronJob= require(jobFile);
      
            logger.debug(`Creating instance of cronJob: `+job.jobName);
         //constructor(cronTime, onTick, onComplete, start, timezone, context, runOnInit)
            var cronJobInstance = new cronJobs(job.cronTime, 
                   function(){
                    cronJob.process();
                }, function(){
                    cronJob.complete();
                },false);    
        
        logger.debug("Starting the cronJob := "+ job.jobName);
        cronJobInstance.start();
    });
};

//scheduleJobs();
module.exports.scheduleJobs= scheduleJobs;
     
                        
