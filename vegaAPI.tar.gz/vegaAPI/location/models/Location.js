var mongoose = require('../../common/MongoDbConnection').mongoose;
var autoIncrement = require('mongoose-auto-increment');
var connection = mongoose.connection;
autoIncrement.initialize(connection);

/*
 * Define schema
 */
var locationSchema = mongoose.Schema({
	LocationId: Number,
	companyId: Number,
	appGroupId: Number,
	appId: Number,
	LocationName: {type: String, minLength: 0, maxLength: 100},
    Summary:   {type: String, minLength: 0, maxLength: 300},
	Lat:       {type: Number, minLength: 0, maxLength: 10},
	Long:      {type: Number, minLength: 0, maxLength: 10},
	Address1:  {type: String, minLength: 0, maxLength: 100},
	Address2:  {type: String, minLength: 0, maxLength: 100},
	City:      {type: String, minLength: 0, maxLength: 100},
	State:     {type: String, minLength: 0, maxLength: 100},
	Country:   {type: String, minLength: 0, maxLength: 100},
	ZipCode:   {type: String, minLength: 0, maxLength: 100},
	Type:      {type: String, minLength: 0, maxLength: 100},
	CreatedBy: {type: String, minLength: 0, maxLength: 50},
	Status:	   {type: String, minLength: 0, maxLength: 50},
	CreatedOn :{ type: Date, default: Date.now },
	UpdatedBy: {type: String, minLength: 0, maxLength: 50},	
	UpdatedOn: { type: Date, default: Date.now },		
	             
});

locationSchema.plugin(autoIncrement.plugin, { model: 'Locations', field: 'LocationId', startAt: 1 });

/*
 * Setters
 */
locationSchema.methods.setcompanyId=function(companyId){
	this.companyId=companyId;
}

locationSchema.methods.setappGroupId=function(appGroupId){
	this.appGroupId=appGroupId;
}

locationSchema.methods.setappId=function(appId){
	this.appId=appId;
}
locationSchema.methods.setLocationId=function(LocationId){
	this.LocationId=LocationId;
}

locationSchema.methods.setLocationName=function(LocationName){
	this.LocationName=LocationName;
}

locationSchema.methods.setSummary=function(Summary){
	this.Summary=Summary;
}

locationSchema.methods.setLat=function(Lat){
	this.Lat=Lat;
}

locationSchema.methods.setLong=function(Long){
	this.Long=Long;
}

locationSchema.methods.setAddress1=function(Address1){
	this.Address1=Address1;
}

locationSchema.methods.setAddress2=function(Address2){
	this.Address2=Address2;
}
locationSchema.methods.setCity=function(City){
	this.City=City;
}

locationSchema.methods.setState=function(State){
	this.State=State;
}

locationSchema.methods.setCountry=function(Country){
	this.Country=Country;
}

locationSchema.methods.setZipCode=function(ZipCode){
	this.ZipCode=ZipCode;
}
locationSchema.methods.setType=function(Type){
	this.Type=Type;
}

locationSchema.methods.setCreatedBy=function(CreatedBy){
	this.CreatedBy=CreatedBy;
}

locationSchema.methods.setCreatedOn=function(CreatedOn){
	this.CreatedOn=CreatedOn;
}

locationSchema.methods.setUpdatedBy=function(UpdatedBy){
	this.UpdatedBy=UpdatedBy;
}

locationSchema.methods.setUpdatedOn=function(UpdatedOn){
	this.UpdatedOn=UpdatedOn;
}

locationSchema.methods.setStatus=function(Status){
	this.Status=Status;
}
/*
 * Getters
 */
locationSchema.methods.getLocationId=function(){
	return this.LocationId;
}

locationSchema.methods.getcompanyId=function(){
	return this.companyId;
}

locationSchema.methods.getappGroupId=function(){
	return this.appGroupId;
}

locationSchema.methods.getappId=function(){
	return this.appId;
}


locationSchema.methods.getLocationName=function(){
	return this.LocationName;
}

locationSchema.methods.getSummary=function(){
	return this.Summary;
}

locationSchema.methods.getLat=function(){
	return this.Lat;
}

locationSchema.methods.getLong=function(){
	return this.Long;
}

locationSchema.methods.getAddress1=function(){
	return this.Address1;
}

locationSchema.methods.getAddress2=function(){
	return this.Address2;
}
locationSchema.methods.getCity=function(){
	return this.City;
}

locationSchema.methods.getState=function(){
	return this.State;
}

locationSchema.methods.getCountry=function(){
	return this.Country;
}

locationSchema.methods.getZipCode=function(){
	return this.ZipCode;
}


locationSchema.methods.getType=function(){
	return this.Type;
}

locationSchema.methods.getCreatedBy=function(){
	return this.CreatedBy;
}

locationSchema.methods.getCreatedOn=function(){
	return this.CreatedOn;
}

locationSchema.methods.getUpdatedBy=function(){
	return this.UpdatedBy;
}

locationSchema.methods.getUpdatedOn=function(){
	return this.UpdatedOn;
}

locationSchema.methods.getStatus=function(){
	return this.Status;
}

/*
 * Create collection/model in mongo db using Schema
 */
var Location = mongoose.model('Locations', locationSchema);


/*
 * Insert records in collection
 */
/*var smtpServer = new SMTPServer({ SMTPServerId: 1, SMTPServerName: 'SMTPServer', CompanyId: 1, IPAddress:'IP4' ,
	Port: 8000 , Type: 'STMP' , Username: 'Admin' , Password: 'Admin' , MessageQueueName: 'queueName' ,
	MessageRetries: 2 , Attribute1: 'attr1' , Attribute1Value: 'attr1val' , Attribute2: 'attr2' , Attribute2Value: 'attr2val' ,
	Attribute3: 'attr3' , Attribute3Value: 'attr3val' , Attribute4: 'attr4' , Attribute4Value: 'attr4val' ,
	Attribute5: 'attr5' , Attribute5Value: 'attr5val' , CreatedBy: 'Admin' ,UpdatedBy: 'Admin' });

smtpServer.save(function (err, data) {
  if (err) 
	  return console.error(err);
  else
	  console.log('data inserted: '+data.CompanyId);
});*/


module.exports = Location;