var db = require('../../common/MongoDbConnection');
var Location = require('../models/Location');
var Application = require('../../application/models/App');

var mongoose = db.mongoose;

/*
 * Add new SMTP Server details
 */
var addNewLocation = function(req, res, callback) {	
	
	var reqBody = req.body;
	var location = new Location();
	var companyId=req.headers['companyid']; 
	console.log(companyId);		
	location.setcompanyId(companyId);		
	var appGroupId =reqBody.appGroupId;
	location.setappGroupId(appGroupId);
	var appId =reqBody.appId;
	location.setappId(appId);	
	location.setCity(reqBody.City);	
	location.setLocationName(reqBody.LocationName);	
	location.setSummary(reqBody.Summary); 
	location.setLat(reqBody.Lat);
	location.setLong(reqBody.Lang);
	location.setAddress1(reqBody.Address1);
	location.setAddress2(reqBody.Address2);
	location.setCity(reqBody.City);
	location.setState(reqBody.state);
	location.setCountry(reqBody.Country);
	location.setZipCode(reqBody.zipCode);	
	location.setType(reqBody.Type);
	location.setCreatedBy('Admin');
	location.setCreatedOn(new Date());
	location.setUpdatedBy('Admin');
	location.setUpdatedOn(new Date());
	location.setStatus('ACTIVE');
	
	Application.find({
		'companyId' : companyId,
		'appGroupId':appGroupId,
		'appId':appId }, function(err, data) {
		if (err) {
			callback(err, data);
		} else {
			if (data.length != 0) {
				//callback(err, data);
				location.save(function(err, data) {
					if (err) {
						callback(err, data);
					} else {
						callback(err, data);
					}
				});
			} else {
				var err = new Error('Invalid companyId or appGroupId or appId ');
				err.status = 404;
				callback(err, data);
			}
		}
	});

		
};

/*
 * Get All Location 
 */
var getAllLocations = function(req, res, callback) {
	Location.find({'Status' : { $ne : 'DELETED'}}, function(err, data) {
		if (err) {
			callback(err, data);
		} else {
			if (data.length != 0) {
				callback(err, data);
			} else {
				var err = new Error('No recoard found');
				err.status = 404;
				callback(err, data);
			}
		}
	});
};



/*
 * Get Location by location id
 */
var getLocationById = function(req, res, callback) {
	Location.find({
		'LocationId' : req.params.id,
		'Status' : { $ne : 'DELETED'}
	}, function(err, data) {
		if (err) {
			callback(err, data);
		} else {
			if (data.length != 0) {
				callback(err, data);
			} else {
				var err = new Error('Invalid Location id');
				err.status = 404;
				callback(err, data);
			}
		}
	});
};

/*
 * Delete Location by id
 */
var deleteLocationByID =function (req,res,callback){
	var callbackDelete = function(err, data) {
		if (err) {
			callback(err, data);
		} else {
			Location.update({
				'LocationId' : req.params.id,
				'Status' : { $ne : 'DELETED'}
			},{
				$set:{'Status':'DELETED'}
			}, function(err, data) {
				if (err) {
					callback(err, data);
				} else {
					callback(err, data);
				}
			});
		}
	};

	getLocationById(req, res, callbackDelete);
};

/*
 * Update Location 
 */
var updateLocationById = function(req, res, callback) {
	var callbackUpdate = function(err, data) {
		if (err) {
			callback(err, data);
		} else {
			
			console.log(req.params.id);
			var json = req.body;
			console.log(JSON.stringify(json));
			json.UpdatedOn = new Date();
			json.UpdatedBy = 'Admin';			
			Location.update({
				'LocationID' : req.params.id				
			}, json, function(err, data) {
				if (err) {
					callback(err, data);
				} else {
					callback(err, data);
				}
			});
		}
	};
	
};


module.exports.addNewLocation = addNewLocation;
module.exports.getAllLocations = getAllLocations;
module.exports.getLocationById = getLocationById;
module.exports.deleteLocationByID = deleteLocationByID;
module.exports.updateLocationById=updateLocationById;
