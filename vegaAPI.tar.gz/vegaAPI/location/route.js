var express = require('express');
var locationController=require('./controller/LocationController');
var logger = require('../common/logger').log;
var router = express.Router();



/*
 * Add new Location Server details
 */
router.post('/', function(req, res){
	locationController.addNewLocation(req, res, function(err, data) {
        if(err){
        	console.log("sending 500 response back from route.");
        	var errorObj = {
        		"error": err.message	
        	};
            res.status(500).end(JSON.stringify(errorObj));
        }else{
        	console.log("sending 200 response back from route.");
        	res.status(200).end(JSON.stringify(data));
        }
    });
});

/*
 * Get All location 
 */
router.get('/', function (req, res) {	
	locationController.getAllLocations(req, res, function(err, data) {
        if(err){
        	console.log("sending 500 response back from route.");
        	var errorObj = {
        		"error": err.message	
        	};
            res.status(500).end(JSON.stringify(errorObj));
        }else{
        	console.log("sending 200 response back from route.");
        	res.status(200).end(JSON.stringify(data));
        }
    });
});

/*
 * Get Location 
 */
router.get('/:id(\\d+)', function (req, res) {	
	
	locationController.getLocationById(req, res, function(err, data) {
        if(err){
        	console.log("sending 500 response back from route.");
        	var errorObj = {
        		"error": err.message	
        	};
            res.status(500).end(JSON.stringify(errorObj));
        }else{
        	console.log("sending 200 response back from route.");
        	res.status(200).end(JSON.stringify(data));
        }
    });
});


/*
 * Delete Locatin by id
 */
router.delete('/:id(\\d+)', function(req, res) {
	logger.info('Received request to delete location details');
	
	locationController.deleteLocationById(req, res, function(err, data) {
        if(err){
        	logger.error('Error to delete location details: '+err.stack);        	
        	var errorObj = {
        		"error": err.message	
        	};
            res.status(500).end(JSON.stringify(errorObj));
        }else{        	
        	logger.info("Request to delete location details successful !");
        	res.status(200).end(JSON.stringify(data));
        }
    });
});


/*
 * Update Location details
 */
router.put('/:id(\\d+)', function(req, res){	  
	locationController.updateSMTPServerById(req, res, function(err, data) {
        if(err){
        	console.log("sending 500 response back from route.");
        	var errorObj = {
        		"error": err.message	
        	};
            res.status(500).end(JSON.stringify(errorObj));
        }else{
        	console.log("sending 200 response back from route.");
        	res.status(200).end(JSON.stringify(data));
        }
    });
});

/*
 * Options method
 */
router.options('/', function(req, res) {
	res.header('Allow-Access-Allow-Origin', '*');
	res.header('Access-Control-Allow-Headers', '*');
	res.header('Access-Control-Allow-Methods', 'GET,POST,DELETE,OPTIONS');
	res.header('Connection', 'keep-alive');
	res.header('Content-Type', 'application/json;charset=UTF-8');
	res.end();
});

router.all('/*', function (req, res) {		
	res.status(404).send(JSON.stringify({'error':'No matching resource for url: '+req.originalUrl}));	  	
});


module.exports = router;