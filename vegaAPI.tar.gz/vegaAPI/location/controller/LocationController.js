var locationDao = require('../dao/LocationDAO');

/*
 * Add new Location details
 */
var addNewLocation = function(req, res, callback) {
	locationDao.addNewLocation(req, res, callback);
};

/*
 * Get All Locations
 */
var getAllLocations = function(req, res, callback) {	
	locationDao.getAllLocations(req, res ,callback);
};

/*
 * Get Location by LocationId
 */
var getLocationById = function(req, res, callback) {	
	locationDao.getLocationById(req, res ,callback);
};


/*
 * Update Location details
 */
var updateSMTPServerById = function(req, res, callback) {
	locationDao.updateSMTPServerById(req, res, callback);
};

/*
 * Delete Location details
 */

var deleteLocationById = function(req,res,callback){
	locationDao.deleteLocationByID(req, res, callback);
};

module.exports.addNewLocation = addNewLocation;
module.exports.getAllLocations = getAllLocations;
module.exports.deleteLocationById = deleteLocationById;
module.exports.getLocationById = getLocationById ;



