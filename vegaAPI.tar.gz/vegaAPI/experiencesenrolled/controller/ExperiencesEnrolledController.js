var experiencesEnrolledDao = require('../dao/ExperiencesEnrolledDAO');
var logger = require('../../common/logger').log;

/*
 * Add new ExperiencesEnrolled
 */
var addExperiencesEnrolledStatus = function(req, res, callback) {
	logger.info('ExperiencesEnrolled : controller : received request : addExperiencesEnrolledStatus : body : '+JSON.stringify(req.body));
	experiencesEnrolledDao.addExperiencesEnrolledStatus(req, res, callback);
};

/*
 * Get ExperiencesEnrolled by ExperiencesEnrolled id
 */
var getExperiencesStatusByEnrolledId = function(req, res, callback) {
	logger.info('ExperiencesEnrolled : controller : received request : getExperiencesStatusByEnrolledId : ExperiencesEnrolled Id:'+req.params.enrolledId);
	experiencesEnrolledDao.getExperiencesStatusByEnrolledId(req, res, callback);
};


/*
 * Get ExperiencesEnrolled by Company ID
 */
var getExperiencesEnrolledByComapnyId = function(req, res, callback) {
	logger.info('ExperiencesEnrolled : controller : received request : getExperiencesEnrolledByComapnyId : CompanyId:'+req.params.id);
	experiencesEnrolledDao.getExperiencesEnrolledByComapnyId(req, res, callback);
};


/*
 * Get ExperiencesEnrolled by Company ID and STATUS
 */
var getExperiencesEnrolledByComapnyIdAndStatus = function(req, res, callback) {
	logger.info('ExperiencesEnrolled : controller : received request : getExperiencesEnrolledByComapnyIdAndStatus :'+JSON.stringify(req.query));
	experiencesEnrolledDao.getExperiencesEnrolledByComapnyIdAndStatus(req, res, callback);
};


/*
 * Edit/Update ExperiencesEnrolled
 */
var updateExperiencesStatusByEnrolledId = function(req, res, callback) {
	logger.info('ExperiencesEnrolled : controller : received request : updateExperiencesStatusByEnrolledId : ExperiencesEnrolled Id:'+req.params.enrolledId);
	experiencesEnrolledDao.updateExperiencesStatusByEnrolledId(req, res, callback);
};

/*
* Delete ExperiencesEnrolled details
*/
var deleteExperiencesStatusByEnrolledId = function(req, res, callback) {
	logger.info('ExperiencesEnrolled : controller : received request : deleteExperiencesStatusByEnrolledId : Id : '+req.params.enrolledId);
	experiencesEnrolledDao.deleteExperiencesStatusByEnrolledId(req, res, callback);
};

module.exports.addExperiencesEnrolledStatus = addExperiencesEnrolledStatus;
module.exports.getExperiencesStatusByEnrolledId = getExperiencesStatusByEnrolledId;
module.exports.getExperiencesEnrolledByComapnyId = getExperiencesEnrolledByComapnyId;
module.exports.getExperiencesEnrolledByComapnyIdAndStatus = getExperiencesEnrolledByComapnyIdAndStatus;
module.exports.updateExperiencesStatusByEnrolledId = updateExperiencesStatusByEnrolledId;
module.exports.deleteExperiencesStatusByEnrolledId = deleteExperiencesStatusByEnrolledId;
