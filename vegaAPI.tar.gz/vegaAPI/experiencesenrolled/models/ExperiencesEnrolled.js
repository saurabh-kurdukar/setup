var mongoose = require('../../common/MongoDbConnection').mongoose;
var autoIncrement = require('mongoose-auto-increment');
var logger = require('../../common/logger').log;
var connection = mongoose.connection;
autoIncrement.initialize(connection);

/*
 * Define ExperiencesEnrolled schema
 */
var experiencesEnrolledSchema = mongoose.Schema({
	enrolledId : Number,
	experienceId : { type: Number, required: true , minLength: 1, maxLength: 25},
	companyId :	{ type: Number, required: true , minLength: 1, maxLength: 25},
	status : {type: String, required: true, minLength: 1, maxLength: 25},	
	createdBy : {type: String, default: ''},
	createdOn : { type: Date, default: Date.now },
	updatedBy : {type: String, default: ''},
	updatedOn : { type: Date, default: Date.now }
});

logger.info('ExperiencesEnrolled : model : created schema : ExperiencesEnrolleds :'+JSON.stringify(experiencesEnrolledSchema.paths));

experiencesEnrolledSchema.pre('findOneAndUpdate', function(next) {
	  this.options.runValidators = true;
	  next();
});


experiencesEnrolledSchema.plugin(autoIncrement.plugin, { model: 'ExperiencesEnrolleds', field: 'enrolledId', startAt: 1 });

/*
 * Setters
 */
experiencesEnrolledSchema.methods.setEnrolledId = function(enrolledId) {	
	this.enrolledId = enrolledId;
};

experiencesEnrolledSchema.methods.setExperienceId = function(experienceId) {
	this.experienceId = experienceId;
};

experiencesEnrolledSchema.methods.setCompanyId = function(companyId) {
	this.companyId = companyId;
};

experiencesEnrolledSchema.methods.setStatus = function(status) {
	this.status = status;
};

experiencesEnrolledSchema.methods.setCreatedBy = function(createdBy) {
	this.createdBy = createdBy;
};

experiencesEnrolledSchema.methods.setCreatedOn = function(createdOn) {
	this.createdOn = createdOn;
};

experiencesEnrolledSchema.methods.setUpdatedBy = function(updatedBy) {
	this.updatedBy = updatedBy;
};

experiencesEnrolledSchema.methods.setUpdatedOn = function(updatedOn) {
	this.updatedOn = updatedOn;
};


/*
 * Getters
 */
experiencesEnrolledSchema.methods.getEnrolledId = function() {	
	return this.enrolledId;
};

experiencesEnrolledSchema.methods.getExperienceId = function() {
	return this.experienceId;
};

experiencesEnrolledSchema.methods.getCompanyId = function() {
	return this.companyId;
};

experiencesEnrolledSchema.methods.getStatus = function() {
	return this.status;
};

experiencesEnrolledSchema.methods.getCreatedBy = function() {
	return this.createdBy;
};

experiencesEnrolledSchema.methods.getCreatedOn = function() {
	return this.createdOn;
};

experiencesEnrolledSchema.methods.getUpdatedBy = function() {
	return this.updatedBy;
};

experiencesEnrolledSchema.methods.getUpdatedOn = function() {
	return this.updatedOn;
};


/*
 * Create collection/model in mongo db using Schema
 */
var ExperiencesEnrolled = mongoose.model('ExperiencesEnrolleds', experiencesEnrolledSchema);
logger.info('ExperiencesEnrolled : model : created model : ExperiencesEnrolled : ' + ExperiencesEnrolled);


module.exports = ExperiencesEnrolled;