var db = require('../../common/MongoDbConnection');
var ExperiencesEnrolled = require('../models/ExperiencesEnrolled');
var Experience = require('../../experience/models/Experience');
var logger = require('../../common/logger').log;
var audit = require('../../common/Audit').audit;
var Enum = require('enum');

//ExperiencesEnrolled Status ENUM 
var ExperiencesEnrolledSTATUS = new Enum({
	'PROVISIONING':'PROVISIONING',
	'ACTIVE':'ACTIVE',
	'EXPIRED':'EXPIRED',
	'DELETED':'DELETED'
});


/*
 * Add new experiencesEnrolled Status
 */
var addExperiencesEnrolledStatus = function(req, res, callback) {
	logger.info('ExperiencesEnrolled : DAO : received request : addExperiencesEnrolledStatus : body : '+JSON.stringify(req.body));
	
	Experience.find({ 'id' : req.body.experienceId }, function(err, data) {
		if (err) {
			logger.error('ExperiencesEnrolled : DAO : failed to find Experience : error : ' + err);
			callback(err, null);
		} else {
			if (data.length != 0) {				
				var reqBody = req.body;
				
				var experiencesEnrolled = new ExperiencesEnrolled();
				experiencesEnrolled.setExperienceId(reqBody.experienceId);
				experiencesEnrolled.setCompanyId(reqBody.companyId);
				experiencesEnrolled.setStatus(ExperiencesEnrolledSTATUS.get(reqBody.status.toUpperCase()));
								
				experiencesEnrolled.setCreatedOn(new Date());
				experiencesEnrolled.setCreatedBy(req.headers.username);

				experiencesEnrolled.save(function(err, data) {
					if (err) {
						logger.error('ExperiencesEnrolled : DAO : failed addExperiencesEnrolledStatus : error : ' + err);
						callback(err, null);
					} else {
						logger.info('ExperiencesEnrolled : DAO : addExperiencesEnrolledStatus successful !');
						callback(null, data);
					}
				});
				
			} else {
				var err1 = new Error('Invalid Experience Id!');
				logger.error('ExperiencesEnrolled : DAO : Experience : error : ' + err1);
				callback(err1, null);
			}
		}
	});
};

/*
 * Get experiencesEnrolled by EnrolledId
 */
var getExperiencesStatusByEnrolledId = function(req, res, callback) {
	logger.info('ExperiencesEnrolled : DAO : received request : getExperiencesStatusByEnrolledId : EnrolledId:'+req.params.enrolledId);
	
	ExperiencesEnrolled.find( { 'enrolledId' : req.params.enrolledId }, function(err, data) {
		if (err) {
			logger.error('ExperiencesEnrolled : DAO : failed getExperiencesStatusByEnrolledId : error : ' + err);
			callback(err, null);
		} else {
			if (data.length != 0) {
				logger.info('ExperiencesEnrolled : DAO : getExperiencesStatusByEnrolledId successful!');
				callback(null, data[0]);
			} else {
				var err1 = new Error('Invalid ExperiencesEnrolled Id!');
				logger.error('ExperiencesEnrolled : DAO : failed getExperiencesStatusByEnrolledId : error : ' + err1);
				callback(err1, null);
			}
		}
	});
};


/*
 * Get ExperiencesEnrolled by Company ID
 */
var getExperiencesEnrolledByComapnyId = function(req, res, callback) {
	logger.info('ExperiencesEnrolled : DAO : received request : getExperiencesEnrolledByComapnyId : CompanyId: '+req.params.id);
	
	ExperiencesEnrolled.find({ 'companyId' : req.params.id }, function(err, data) {
		if (err) {
			logger.error('ExperiencesEnrolled : DAO : failed getExperiencesEnrolledByComapnyId : error : ' + err);
			callback(err, null);
		} else {
			if (data.length != 0) {
				logger.info('ExperiencesEnrolled : DAO : getExperiencesEnrolledByComapnyId successful!');
				callback(null, data);
			} else {
				var err1 = new Error('Invalid Company Id.');
				logger.error('ExperiencesEnrolled : DAO : failed getExperiencesEnrolledByComapnyId : error : ' + err1);
				callback(err1, null);
			}
		}
	});
};


/*
 * Get ExperiencesEnrolled by Company ID and STATUS
 */
var getExperiencesEnrolledByComapnyIdAndStatus = function(req, res, callback) {
	logger.info('ExperiencesEnrolled : DAO : received request : getExperiencesEnrolledByComapnyIdAndStatus : EnrolledId: '+JSON.stringify(req.query));
	
	var queryParam = {};
	queryParam.companyId = req.query.companyId;
	queryParam.status = ExperiencesEnrolledSTATUS.get(req.query.status.toUpperCase());
	
	ExperiencesEnrolled.find(queryParam, function(err, data) {
		if (err) {
			logger.error('ExperiencesEnrolled : DAO : failed getExperiencesEnrolledByComapnyIdAndStatus : error : ' + err);
			callback(err, null);
		} else {
			if (data.length != 0) {
				logger.info('ExperiencesEnrolled : DAO : getExperiencesEnrolledByComapnyIdAndStatus successful!');
				callback(null, data);
			} else {
				var err1 = new Error('Invalid Company Id and / or STATUS.');
				logger.error('ExperiencesEnrolled : DAO : failed getExperiencesEnrolledByComapnyIdAndStatus : error : ' + err1);
				callback(err1, null);
			}
		}
	});
};


/*
 * Edit/Update experiencesEnrolled
 */
var updateExperiencesStatusByEnrolledId = function(req, res, callback) {
	logger.info('ExperiencesEnrolled : DAO : received request : updateExperiencesStatusByEnrolledId : experiencesEnrolled Id:'+req.params.enrolledId);
	
	/*
	 * Callback function after getting original record to update with new values.
	 */
	var callbackUpdate = function(err, data) {	
		if(err) {
			logger.error('ExperiencesEnrolled : DAO : failed updateExperiencesStatusByEnrolledId : error : ' + err);
			callback(err, null);
		} else if (data != null) {
			var experiencesEnrolled = data;
			var json = {};
			var updatedData = [];
			var obj = {};
			if (req.body.status && experiencesEnrolled['status'] != req.body.status) {
				var newStatus = ExperiencesEnrolledSTATUS.get(req.body.status.toUpperCase());
				json.status = newStatus;		
				obj.column = 'status';
				obj.oldValue = ExperiencesEnrolledSTATUS.get(experiencesEnrolled['status'].toUpperCase());
				obj.newValue = newStatus;
				obj.identifier = 'Platform_ExperiencesEnrolled_'+req.params.enrolledId;
				obj.modifiedBy = req.headers.username;
				obj.modifiedOn = new Date();
				updatedData.push(obj);
			}
			
			if (Object.keys(json).length != 0) {
				json.updatedBy = req.headers.username;
				json.updatedOn = new Date();
				logger.info('ExperiencesEnrolled : DAO : updateExperiencesStatusByEnrolledId : updating data : ' + JSON.stringify(json));
				
				ExperiencesEnrolled.findOneAndUpdate( {	'enrolledId' : req.params.enrolledId }, json, {	'new' : true }, function(err, data) {
					if (err) {
						logger.error('ExperiencesEnrolled : DAO : failed updateExperiencesStatusByEnrolledId : error : ' + err);
						callback(err, null);
					} else {
						if (data != null) {
							logger.info('ExperiencesEnrolled : DAO : updateExperiencesStatusByEnrolledId successful !');
							/*
							 *	Call audit function for changed data 
							 */
							audit(req, res, updatedData);
							/*
							 *	Call function to send response to client 
							 */
							callback(null, data);
						} else {
							var err1 = new Error('Invalid ExperiencesEnrolled Id!');
							logger.error('ExperiencesEnrolled : DAO : failed updateExperiencesStatusByEnrolledId : error : ' + err1);
							callback(err1, null);
						}
					}
				});
			} else {
				var err2 = new Error('Cannot update data');
				logger.error('ExperiencesEnrolled : DAO : failed updateExperiencesStatusByEnrolledId : error : ' + err2);
				callback(err2, null);
			}
		} else {
			var err3 = new Error('Failed to get ExperiencesEnrolled details.');
			logger.error('ExperiencesEnrolled : DAO : failed updateExperiencesStatusByEnrolledId : error : ' + err3);
			callback(err3, null);
		}		
	};
	
	/*
	 * Get the original record from db before update.
	 */
	getExperiencesStatusByEnrolledId(req, res, callbackUpdate);
	
};

/*
 * Delete ExperiencesEnrolled details
 */
var deleteExperiencesStatusByEnrolledId = function(req, res, callback) {
	logger.info('ExperiencesEnrolled : DAO : received request : deleteExperiencesStatusByEnrolledId : experiencesEnrolled Id:'+req.params.enrolledId);
	
	/*
	 * Callback function after getting original record to update STATUS with 'DELETED'.
	 */
	var callbackUpdate = function(err, data) {	
		if(err) {
			logger.error('ExperiencesEnrolled : DAO : failed deleteExperiencesStatusByEnrolledId : error : ' + err);
			callback(err, null);
		} else if (data != null) {
			var experiencesEnrolled = data;
			var json = {};
			var updatedData = [];
			var obj = {};
			
			json.status = ExperiencesEnrolledSTATUS.get('DELETED');
			obj.column = 'status';
			obj.oldValue = ExperiencesEnrolledSTATUS.get(experiencesEnrolled['status'].toUpperCase());
			obj.newValue = ExperiencesEnrolledSTATUS.get('DELETED');
			obj.identifier = 'Platform_ExperiencesEnrolled_'+req.params.enrolledId;
			obj.modifiedBy = req.headers.username;
			obj.modifiedOn = new Date();
			updatedData.push(obj);
			
			if (Object.keys(json).length != 0) {
				json.updatedBy = req.headers.username;
				json.updatedOn = new Date();
				logger.info('ExperiencesEnrolled : DAO : deleteExperiencesStatusByEnrolledId : updating data : ' + JSON.stringify(json));
				
				ExperiencesEnrolled.findOneAndUpdate( {	'enrolledId' : req.params.enrolledId }, json, {	'new' : true }, function(err, data) {
					if (err) {
						logger.error('ExperiencesEnrolled : DAO : failed deleteExperiencesStatusByEnrolledId : error : ' + err);
						callback(err, null);
					} else {
						if (data != null) {
							logger.info('ExperiencesEnrolled : DAO : deleteExperiencesStatusByEnrolledId successful !');
							/*
							 *	Call audit function for changed data 
							 */
							audit(req, res, updatedData);
							/*
							 *	Call function to send response to client 
							 */
							callback(null, data);
						} else {
							var err1 = new Error('Invalid ExperiencesEnrolled Id!');
							logger.error('ExperiencesEnrolled : DAO : failed deleteExperiencesStatusByEnrolledId : error : ' + err1);
							callback(err1, null);
						}
					}
				});
			} else {
				var err2 = new Error('Cannot update data');
				logger.error('ExperiencesEnrolled : DAO : failed deleteExperiencesStatusByEnrolledId : error : ' + err2);
				callback(err2, null);
			}
		} else {
			var err3 = new Error('Failed to get ExperiencesEnrolled details.');
			logger.error('ExperiencesEnrolled : DAO : failed deleteExperiencesStatusByEnrolledId : error : ' + err3);
			callback(err3, null);
		}		
	};
	
	/*
	 * Get the original record from db before STATUS Update.
	 */
	getExperiencesStatusByEnrolledId(req, res, callbackUpdate);
	
};

module.exports.addExperiencesEnrolledStatus = addExperiencesEnrolledStatus;
module.exports.getExperiencesStatusByEnrolledId = getExperiencesStatusByEnrolledId;
module.exports.getExperiencesEnrolledByComapnyId = getExperiencesEnrolledByComapnyId;
module.exports.getExperiencesEnrolledByComapnyIdAndStatus = getExperiencesEnrolledByComapnyIdAndStatus;
module.exports.updateExperiencesStatusByEnrolledId = updateExperiencesStatusByEnrolledId;
module.exports.deleteExperiencesStatusByEnrolledId = deleteExperiencesStatusByEnrolledId;
