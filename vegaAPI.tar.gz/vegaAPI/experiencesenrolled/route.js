var express = require('express');
var experiencesEnrolledController = require('./controller/ExperiencesEnrolledController');
var logger = require('../common/logger').log;
var ErrorResponse = require('../common/ErrorResponse').ErrorResponse;
var router = express.Router();


/*
 * Add new ExperiencesEnrolled Status
 */
router.post('/', function(req, res) {
	logger.info('ExperiencesEnrolled : router : received request : addExperiencesEnrolledStatus : body : '+JSON.stringify(req.body));
	if (req.body.experienceId != null && req.body.companyId != null) {
		experiencesEnrolledController.addExperiencesEnrolledStatus(req, res, function(err, data) {
			if (err) {
				logger.error('ExperiencesEnrolled : router : failed addExperiencesEnrolledStatus : error : '+err);   
				var error = new ErrorResponse();
				if (err.name == 'ValidationError') {
					error.setErrorMessage(err.errors[Object.keys(err.errors)[0]].message);
					error.setErrorCode("EE0001");
					error.setHttpResponseCode(400);
					res.status(400).end(JSON.stringify(error));
				} else {
					error.setErrorMessage(err.message);
					error.setErrorCode("EE0003");
					error.setHttpResponseCode(500);
					res.status(500).end(JSON.stringify(error));
				}
			} else {
				logger.info("ExperiencesEnrolled : router : addExperiencesEnrolledStatus successful !");
				res.status(200).end(JSON.stringify(data));
			}
		});
	} else {
		var error = new ErrorResponse();
		error.setErrorMessage('Experience Id and Company Id are not set');
		error.setErrorCode("EE0001");
		error.setHttpResponseCode(400);
		logger.error('ExperiencesEnrolled : router : failed addExperiencesEnrolledStatus : error : '+JSON.stringify(error));
		res.status(400).end(JSON.stringify(error));
	}
});

/*
 * Get ExperiencesEnrolled by EnrolledId
 */
router.get('/:enrolledId', function(req, res) {
	logger.info('ExperiencesEnrolled : router : received request : getExperiencesStatusByEnrolledId : Enrolled Id : '+req.params.enrolledId);

	experiencesEnrolledController.getExperiencesStatusByEnrolledId(req, res, function(err, data) {
		if (err) {
			logger.error('ExperiencesEnrolled : router : failed getExperiencesStatusByEnrolledId : error : '+err);
			var error = new ErrorResponse();
			error.setErrorMessage(err.message);
			error.setErrorCode("EE0003");
			error.setHttpResponseCode(500);
			res.status(500).end(JSON.stringify(error));
		} else {
			logger.info("ExperiencesEnrolled : router : getExperiencesStatusByEnrolledId successful !");
			res.status(200).end(JSON.stringify(data));
		}
	});
 
});

/*
 * Get ExperiencesEnrolled by Company ID and STATUS
 */
router.get('/', function(req, res) {
	logger.info('ExperiencesEnrolled : router : received request : getExperiencesEnrolledByComapnyIdAndStatus : Query : '+JSON.stringify(req.query));
	if (req.query.companyId != null && req.query.status != null) {
		experiencesEnrolledController.getExperiencesEnrolledByComapnyIdAndStatus(req, res, function(err, data) {
			if (err) {
				logger.error('ExperiencesEnrolled : router : failed getExperiencesEnrolledByComapnyIdAndStatus : error : '+err);
				var error = new ErrorResponse();
				error.setErrorMessage(err.message);
				error.setErrorCode("EE0003");
				error.setHttpResponseCode(500);
				res.status(500).end(JSON.stringify(error));
			} else {
				logger.info("ExperiencesEnrolled : router : getExperiencesEnrolledByComapnyIdAndStatus successful !");
				res.status(200).end(JSON.stringify(data));
			}
		});
	} else {
		var error = new ErrorResponse();
		error.setErrorMessage('Company Id and STATUS are not set');
		error.setErrorCode("EE0001");
		error.setHttpResponseCode(400);
		logger.error('ExperiencesEnrolled : router : failed getExperiencesEnrolledByComapnyIdAndStatus : error : '+JSON.stringify(error));
		res.status(400).end(JSON.stringify(error));
	}
 
});

/*
 * Edit/Update ExperiencesEnrolled Status
 */
router.put('/:enrolledId', function(req, res) {
	logger.info('ExperiencesEnrolled : router : received request : updateExperiencesStatusByEnrolledId : Id :'+req.params.enrolledId);
	
	experiencesEnrolledController.updateExperiencesStatusByEnrolledId(req, res, function(err, data) {
		if (err) {
			logger.error('ExperiencesEnrolled : router : failed updateExperiencesStatusByEnrolledId : error : '+err);
			var error = new ErrorResponse();
			error.setErrorMessage(err.message);
			error.setErrorCode("EE0003");
			error.setHttpResponseCode(500);
			res.status(500).end(JSON.stringify(error));
		} else {
			logger.info("ExperiencesEnrolled : router : updateExperiencesStatusByEnrolledId successful !");
			res.status(200).end(JSON.stringify(data));
		}
	});
	
});

/*
 * Delete a ExperiencesEnrolled 
 */

router.delete('/:enrolledId', function(req, res){
	logger.info('ExperiencesEnrolled : router : received request : deleteExperiencesStatusByEnrolledId : Id : '+req.params.enrolledId);
	experiencesEnrolledController.deleteExperiencesStatusByEnrolledId(req, res, function(err, data) {
        if(err){
        	logger.error('ExperiencesEnrolled : router : failed deleteExperiencesStatusByEnrolledId : error : '+err); 
        	var error = new ErrorResponse();
        	error.setErrorMessage(err.message);
			error.setErrorCode("EE0003");
			error.setHttpResponseCode(500);
			res.status(500).end(JSON.stringify(error));
        }else{        	
        	logger.info("ExperiencesEnrolled : router : deleteExperiencesStatusByEnrolledId successful !");
        	res.status(200).end(JSON.stringify(data));
        }
    });
});


/*
 * Options for ExperiencesEnrolled APIs
 */
router.options('/', function(req, res) {
	logger.info('ExperiencesEnrolled : router : received request : Options call ExperiencesEnrolled APIs');
	res.header('Allow-Access-Allow-Origin', '*');
	res.header('Access-Control-Allow-Headers', '*');
	res.header('Access-Control-Allow-Methods', 'GET,POST,DELETE,PUT,OPTIONS');
	res.header('Connection', 'keep-alive');
	res.header('Content-Type', 'application/json;charset=UTF-8');
	res.end();
	logger.info('ExperiencesEnrolled : router : Options call ExperiencesEnrolled APIs processed !');
});

router.all('/*', function(req, res) {
	logger.info('ExperiencesEnrolled : router : received request : with URL : ' + req.originalUrl);
	logger.error('ExperiencesEnrolled : router : No matching resource for URL : ' + req.originalUrl);
	var error = new ErrorResponse();
	error.setErrorCode("EE0002");
	error.setErrorMessage('No matching resource for URL: ' + req.originalUrl);
	error.setHttpResponseCode(404);
	res.status(404).send(JSON.stringify(error));
});

module.exports = router;