var mongoose = require('../../common/MongoDbConnection').mongoose;
var autoIncrement = require('mongoose-auto-increment');
var logger = require('../../common/logger').log;
var connection = mongoose.connection;
autoIncrement.initialize(connection);
/*
 * logging format followed: logger.info(<module_name>: <component name> :
 * <description> : <long_description> : <data/params/errors>);
 */


/*
 * Define schemas
 */
var applicationSchema = mongoose.Schema({	
      
      "id": Number,
      "name": {type: String, required: true},
      "displayName" : {type: String},
      "type" : {type: String},
      "summary" : String,
      "description": {type: String},      
      "version": {type: String},
      "fileName": {type: String},
      "logo" : {type: String},
      "screenshots" : [],		//image files
      "distribution": {type: String},
      "url" : String,
      "swaggerUrl" : {type: String},
      "boundFromPort" : Number,
      "boundToPort" : Number,
      "directDeploy" : String,
      "deployOptionFlag" : { type: String },
      "hostLinkLocation" : { type: String },
      "supportedDevices" : [],
      "mandatoryFlag" : { type: Boolean },
      "attributes" : [{
 		 attributeKey: String,		 
 		 attributeValue: String
      }]
      
});

var serviceSchema = mongoose.Schema({
	
	"id": Number,
	"name" : {type: String, required: true},
	"displayName" : String,
	"summary" : String,
    "description" : String,    
    "logo" : String, 
    "fileName": {type: String},
    "boundFromPort" : Number,
    "boundToPort" : Number,
    "order" : String,
    "seedDataLocation" : String,
    "testScriptLocation" : String,
    "url" : String,
    "swaggerURL" : String,
    "serviceDeployOption" : { type: String },
    "execScriptLocation" : { type : String },
    "attributes" : [{
		 attributeKey: String,		 
		 attributeValue: String
     }]
});

var componentSchema = mongoose.Schema({
	
	"id" : Number,
	"name" : {type: String, required: true},
    "description" : {type: String},
    "summary" : String, 
    "logo" : String
    
});

var documentSchema = mongoose.Schema({	
    
	id: Number,
	name: { type: String, required: 'Document name is required' },
	appId: Number, 
	serviceId: Number, 
	experienceId: { type:Number, required: 'field experienceId is required' },
	summary: { type: String },
	description: { type: String },
	logo: { type: String },
	mediaFile: { type: String },
	authors: [ ],
	publishers: [ ],
	ISBN: { type: String },	
	tags: [ ],
	version: { type: String },
	status: { type: String, default: 'ACTIVE' }
    
});

var manifestSchema = mongoose.Schema({
	  
	  "id" : Number,
	  "experienceId": Number,
	  "name": {type: String, required: true},
	  "description": {type: String},
	  "version" : {type: String},
	  "owner" : {type: String},
	  "domain" : {type: String},
	  "documents" : [ documentSchema ],
	  "components" : [ componentSchema ],
	  "applications": [ applicationSchema ],	  
	  "services":  [ serviceSchema ],
	  "classification": [ ],
	  "deviceSupported": [ ],
	  "status": { type: String },
	  "vmDetails": {
		    "provider" : String,
		    "osFamily" : String,
		    "osVersion" : String,
		    "size": String
	  },
	  "attributes" : [{
 		 attributeKey: String,		 
 		 attributeValue: String
      }],
	  "createdOn": { type: Date, default: Date.now },
	  "createdBy": {type: String},
	  "updatedOn": { type: Date, default: Date.now },
	  "updatedBy": {type: String}
	
});


logger.info('manifest : model : created schema : Manifests :'+JSON.stringify(manifestSchema.paths));


manifestSchema.path('name').validate(function (v) {
	  return (v.length > 0 && v.length <= 100);
}, 'data too long/short for field name'); 


/*
 * Add Auto increment plugin for field
 */
manifestSchema.plugin(autoIncrement.plugin, { model: 'Manifests', field: 'id', startAt: 1 });



/*
 * Setters for manifestSchema
 */
manifestSchema.methods.setId = function(id) {	
	this.id = id;
};

manifestSchema.methods.setExperienceId = function(experienceId) {	
	this.experienceId = experienceId;
};

manifestSchema.methods.setName = function(name) {	
	this.name = name;
};

manifestSchema.methods.setDescription = function(description) {
	this.description = description;
};

manifestSchema.methods.setVersion = function(version) {
	this.version = version;
};

manifestSchema.methods.setOwner = function(owner) {
	this.owner = owner;
};

manifestSchema.methods.setDomain = function(domain) {
	this.domain = domain;
};

manifestSchema.methods.addDocument = function(document) {
	this.documents.push(document)
};

manifestSchema.methods.addComponent = function(component) {
	this.components.push(component)
};

manifestSchema.methods.addApplication = function(application) {
	this.applications.push(application)
};

manifestSchema.methods.addService = function(service) {
	this.services.push(service)
};

manifestSchema.methods.setStatus = function(status) {
	this.status = status;
};

manifestSchema.methods.setVMDetails = function(vmDetails) {
	this.vmDetails = vmDetails;
};


/*
 * Create collection/model in mongo db using Schema
 */
var Manifest = mongoose.model('Manifests', manifestSchema);
logger.info('manifest : model : created model : Manifests : ' + Manifest);



module.exports = Manifest;