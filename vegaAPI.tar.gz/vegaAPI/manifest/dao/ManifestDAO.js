var Manifest = require('../models/Manifest');
var logger = require('../../common/logger').log;
var audit = require('../../common/Audit').audit;
const MODULE_NAME = "manifest";


/*
 * logging format followed: logger.info(<module_name>: <component name> : <description> : [<long_description>] : <data/params/errors>);
 */


/*
 * Add new manifest
 */
var addNewManifest = function(req, res, callback) {
	logger.info(MODULE_NAME + ' : DAO : received request : addNewManifest : body : '
			+ JSON.stringify(req.body));
	var reqBody = req.body;
	var manifest = new Manifest();
	manifest.setExperienceId(reqBody.experienceId);
	manifest.setName(reqBody.name);
	manifest.setDescription(reqBody.description);
	manifest.setVersion(reqBody.version);
	manifest.setOwner(reqBody.owner);
	manifest.setCategory(reqBody.category);
	var dist = {};
	dist.docker = {};
	dist.applications = {};
	try {
		dist.docker.username = reqBody.dist.docker.username;
		dist.docker.password = reqBody.dist.docker.password;
		dist.docker.host = reqBody.dist.docker.host;
		dist.docker.port = reqBody.dist.docker.port;
		dist.docker.path = reqBody.dist.docker.path;
	} catch (err) {
		logger.error(MODULE_NAME + ' : DAO : error : ' + err);
	}
	try {
		dist.applications.username = reqBody.dist.applications.username;
		dist.applications.password = reqBody.dist.applications.password;
		dist.applications.host = reqBody.dist.applications.host;
		dist.applications.port = reqBody.dist.applications.port;
		dist.applications.path = reqBody.dist.applications.path;
	} catch (err) {
		logger.error(MODULE_NAME + ' : DAO : error : ' + err);
	}
	manifest.setDist(dist);

	/*	set mobile applications   */
	if(reqBody.mobileApplications) {
		var mobileApplication = {};
		var obj = null;
		var i = 0, j=0;
		for(i = 0; i < reqBody.mobileApplications.length; i++) {
			obj = reqBody.mobileApplications[i];
			mobileApplication.id = i+1;
			mobileApplication.name = obj.name;
			mobileApplication.type = obj.type;
			mobileApplication.description = obj.description;
			mobileApplication.version = obj.version;
			mobileApplication.fileName = obj.fileName;
			mobileApplication.icon = obj.icon;
			mobileApplication.dist = obj.dist;
			mobileApplication.service = obj.service;
			if(obj.screenshots) {
				mobileApplication.screenshots = [];
				for(j = 0; j < obj.screenshots.length; j++) {
					mobileApplication.screenshots.push(obj.screenshots[j]);
				}
			}
			manifest.addMobileApplication(mobileApplication);
		}
	}
	/*	set web applications   */
	if(reqBody.webApplications) {
		var webApplication = {};
		obj = null;
		for(i = 0; i < reqBody.webApplications.length; i++) {
			obj = reqBody.webApplications[i];
			webApplication.id = i+1;
			webApplication.name = obj.name;
			webApplication.relativeUrl = obj.relativeUrl;
			webApplication.service = obj.service;
			manifest.addWebApplication(webApplication);
		}
	}
	/*	set services   */
	if(reqBody.services) {
		var service = {};
		service.subImages = [];
		service.test = [];
		obj = null, subImage = {};
		var test = {};
		test.response = {};
		for(i = 0; i < reqBody.services.length; i++) {
			obj = reqBody.services[i];
			service.name = obj.name;
			service.description = obj.description;
			service.longDescription = obj.longDescription;
			service.logo = obj.logo;
			service.swaggerURL = obj.swaggerURL;
			service.imageType = obj.imageType;
			service.dockerImage = obj.dockerImage;
			service.boundFromPort = obj.boundFromPort;
			service.boundToPort = obj.boundToPort;
			if(obj.subImages) {
				for(j = 0; j < obj.subImages.length; j++) {
					subImage.name = obj.subImages[j].name;
					subImage.dockerImage = obj.subImages[j].dockerImage;
					subImage.boundFromPort = obj.subImages[j].boundFromPort;
					subImage.boundToPort = obj.subImages[j].boundToPort;
					subImage.spawn_vm = obj.subImages[j].spawn_vm;
					service.subImages.push(subImage);
				}
			}
			if(obj.test) {
				for(k = 0; k < obj.test.length; k++) {
					test.url = obj.test[k].url;
					test.statusCode = obj.test[k].statusCode;
					test.response.matchType = obj.test[k].response.matchType;
					test.response.text = obj.test[k].response.text;
					service.test.push(test);
				}
			}
			manifest.addService(service);
		}
	}
	if(reqBody.components) {
		var component = {};
		for(i = 0; i < reqBody.components.length; i++) {
			component.name = reqBody.components[i].name;
			component.description = reqBody.components[i].description;
			component.longDescription = reqBody.components[i].longDescription;
			component.logo = reqBody.components[i].logo;
			manifest.addComponent(component);
		}
	}
	if(reqBody.vm) {
		var vm = {};
		vm.type = reqBody.vm.type;
		vm.os = reqBody.vm.os;
		vm.size = reqBody.vm.size;
		manifest.setVM(vm);
	}

	manifest.save(function(err, data) {
		if (err) {
			logger.error(MODULE_NAME + ' : DAO : failed addNewManifest : error : ' + err);
			callback(err, null);
		} else if(data != null){
			logger.info(MODULE_NAME + ' : DAO : addNewManifest successful !');
			callback(null, data);
		} else {
			var err = new Error('Failed to add new manifest details');
			logger.error(MODULE_NAME + ' : DAO : failed addNewManifest : error : '+ err);
			callback(err, null);
		}
	});
};

/*
 * Get manifests by id
 */
var getManifestById = function(req, res, callback) {
	logger.info(MODULE_NAME + ' : DAO : received request : getManifestById : id : '+req.params.id);
	Manifest.find({
		'id' : req.params.id
	}, function(err, data) {
		if (err) {
			logger.error(MODULE_NAME + ' : DAO : failed getManifestById : error : ' + err);
			callback(err, null);
		} else {
			if (data.length != 0) {
				logger.info(MODULE_NAME + ' : DAO : getManifestById successful !');
				callback(null, data[0]);
			} else {
				var err = new Error('no record exist for manifest id');
				err.status = 404;
				logger.error(MODULE_NAME + ' : DAO : failed getManifestById : error : '+ err);
				callback(err, null);
			}
		}
	});
};

/*
 * Get manifests by id
 */
var getManifestByExperienceId = function(req, res, callback) {
	logger.info(MODULE_NAME + ' : DAO : received request : getManifestById : id : '+req.params.id);
	Manifest.findOne({
		'experienceId' : req.params.id
	}, function(err, data) {
		if (err) {
			logger.error(MODULE_NAME + ' : DAO : failed getManifestById : error : ' + err);
			callback(err, null);
		} else {
			if (data != null) {
				logger.info(MODULE_NAME + ' : DAO : getManifestById successful !');
				callback(null, data);
			} else {
				var err = new Error('no manifest exist for experience id');
				err.status = 404;
				logger.error(MODULE_NAME + ' : DAO : failed getManifestById : error : '+ err);
				callback(err, null);
			}
		}
	});
};

var getManifestByExpId = function(experienceId, callback) {
	logger.info(MODULE_NAME + ' : DAO : received request : getManifestById : id : '+ experienceId);
	Manifest.findOne({
		'experienceId' : experienceId,
		'status' : 'PUBLISHED'
	}, function(err, data) {
		if (err) {
			logger.error(MODULE_NAME + ' : DAO : failed getManifestById : error : ' + err);
			callback(err, null);
		} else {
			if (data != null) {
				logger.info(MODULE_NAME + ' : DAO : getManifestById successful !');
				callback(null, data);
			} else {
				var err = new Error('no manifest exist for experience id');
				err.status = 404;
				logger.error(MODULE_NAME + ' : DAO : failed getManifestById : error : '+ err);
				callback(err, null);
			}
		}
	});
};


/*
 * Get manifests by id
 */
var getManifestByExperienceIdAndStatus = function(req, callback) {
	logger.info(MODULE_NAME + ' : DAO : received request : getManifestByExperienceIdAndStatus : id : '+req.params.id);
	Manifest.findOne({
		'experienceId' : req.params.id,
		'status' : 'PUBLISHED'
	}, function(err, data) {
		if (err) {
			logger.error(MODULE_NAME + ' : DAO : failed getManifestByExperienceIdAndStatus : error : ' + err);
			callback(err);
		} else if (data) {
				logger.info(MODULE_NAME + ' : DAO : getManifestByExperienceIdAndStatus successful !');
				callback(null, data);
		} else {
			var err = new Error('no manifest exist for experience id & status');				
			logger.error(MODULE_NAME + ' : DAO : failed getManifestByExperienceIdAndStatus : error : '+ err);
			callback(err);
		}		
	});
};


var updateManifest = function(id, json, callback) {
	Manifest.update({ 'id' : id }, json,
		function(err, data) {
			if (err) {
				logger.error(MODULE_NAME+' : DAO : failed updateManifest : error : ' + err);
				return callback(err);
			}
			logger.info(MODULE_NAME+' : DAO : updateManifest : status changed : ' + JSON.stringify(json));
			callback(null, data);    								
    	}
	);
}

var saveManifest = function(json, callback) {
	Manifest.create(json, function (err, data) {
		if (err) {
			return callback(err);
		}
		callback(null, data);
 	});
}


/*
 * Get all experiences using filters
 */
var getExperiencesUsingFilters = function(req, callback) {
	logger.info(MODULE_NAME+' : DAO : received request : getExperiencesUsingFilters : body : '+JSON.stringify(req.body)
			+'query params: '+JSON.stringify(req.query));
	var obj = {
		'status' : 'PUBLISHED'
	};	
	if(req.query.status && req.query.status.length) {
		obj.status = req.query.status;
	}
	if(req.body.deviceSupported && req.body.deviceSupported.length) {
		obj.deviceSupported = { 
			$in: req.body.deviceSupported
		}
	}
	if(req.body.domains && req.body.domains.length) {
		obj.domain = { 
			$in: req.body.domains 
		}
	}
	if(req.body.classification && req.body.classification.length) {
		obj.classification = {
			$in: req.body.classification 
		}
	}
	if(req.body.platforms && req.body.platforms.length) {
		obj["applications.type"] = {};
		obj["applications.type"] = { 
			$in: req.body.platforms
		}
	}
	//console.log('obj='+JSON.stringify(obj));
	Manifest.find(obj, {'experienceId':1, '_id': 0}, function(err, data) {
		if (err) {
			err.status = 500;
			logger.error(MODULE_NAME+' : DAO : failed getExperiencesUsingFilters : error : ' + err);
			callback(err);
		} else {
			if (data.length) {				
				logger.info(MODULE_NAME+' : DAO : getExperiencesUsingFilters successful !');
				callback(null, data);
			} else {
				var err = new Error('No records found');
				err.status = 200;
				logger.error(MODULE_NAME+' : DAO : failed getExperiencesUsingFilters : error : ' + err);
				callback(err);
			}
		}
	});
};


/*
 * Get all experiences using filters in query params
 */
var getExperiencesUsingFiltersInQuery = function(req, callback) {
	logger.info(MODULE_NAME+' : DAO : received request : getExperiencesUsingFiltersInQuery : query params: '+JSON.stringify(req.query));
	var obj = {
		'status' : 'PUBLISHED'
	};	
	if(req.query.status && req.query.status.length) {
		obj.status = req.query.status;
	}
	if(req.query.deviceSupported) {
		var deviceSupported = req.query.deviceSupported.split(',');
		if(deviceSupported.length)
		{
			obj.deviceSupported = { 
				$in: deviceSupported
			}
		}
	}
	if(req.query.domains) {
		var domains = req.query.domains.split(',');
		if(domains.length)
		{
			obj.domain = { 
				$in: domains
			}
		}
	}
	if(req.query.classification) {
		var classification = req.query.classification.split(',');
		if(classification.length)
		{
			obj.classification = {
				$in: classification
			}
		}
	}
	if(req.query.platforms) {
		var platforms = req.query.platforms.split(',');
		if(platforms.length)
		{
			obj["applications.type"] = {};
			obj["applications.type"] = { 
				$in: platforms
			}
		}
	}
	//console.log('obj='+JSON.stringify(obj));
	Manifest.find(obj, {'experienceId':1, '_id': 0}, function(err, data) {
		if (err) {
			err.status = 500;
			logger.error(MODULE_NAME+' : DAO : failed getExperiencesUsingFiltersInQuery : error : ' + err);
			callback(err);
		} else {
			if (data.length) {				
				logger.info(MODULE_NAME+' : DAO : getExperiencesUsingFiltersInQuery successful !');
				callback(null, data);
			} else {
				var err = new Error('No records found');
				err.status = 200;
				logger.error(MODULE_NAME+' : DAO : failed getExperiencesUsingFiltersInQuery : error : ' + err);
				callback(err);
			}
		}
	});
};







module.exports.addNewManifest = addNewManifest;
module.exports.getManifestById = getManifestById;
module.exports.getManifestByExperienceId = getManifestByExperienceId;
module.exports.getManifestByExpId = getManifestByExpId;
module.exports.getManifestByExperienceIdAndStatus = getManifestByExperienceIdAndStatus;
module.exports.updateManifest = updateManifest;
module.exports.saveManifest = saveManifest;
module.exports.getExperiencesUsingFilters = getExperiencesUsingFilters;
module.exports.getExperiencesUsingFiltersInQuery = getExperiencesUsingFiltersInQuery;









