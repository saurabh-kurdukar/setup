var manifestDao = require('../dao/ManifestDAO');
var logger = require('../../common/logger').log;
const MODULE_NAME = "manifest";

/*
 * logging format followed: logger.info(<module_name>: <component name> : <description> : [<long_description>] : <data/params/errors>);
 */


/*
 * Add new company details
 */
var addNewManifest = function(req, res, callback) {
	logger.info(MODULE_NAME + ' : controller : received request : addNewCompany : body : '+JSON.stringify(req.body));
	manifestDao.addNewManifest(req, res, callback);
};

/*
 * Get manifest by id
 */
var getManifestById = function(req, res, callback) {
	logger.info(MODULE_NAME + ' : controller : received request : getCompanyById : id : '+req.params.id);
	manifestDao.getManifestById(req, res, callback);
};

/*
 * Get manifest by experience id
 */
var getManifestByExperienceId = function(req, res, callback) {
	logger.info(MODULE_NAME + ' : controller : received request : getCompanyById : id : '+req.params.id);
	manifestDao.getManifestByExperienceId(req, res, callback);
};


module.exports.addNewManifest = addNewManifest;
module.exports.getManifestById = getManifestById;
module.exports.getManifestByExperienceId = getManifestByExperienceId; 