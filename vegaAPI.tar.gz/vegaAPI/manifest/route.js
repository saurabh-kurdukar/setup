var express = require('express');
var manifestController = require('./controller/ManifestController');
var logger = require('../common/logger').log;
var ErrorResponse = require('../common/ErrorResponse').ErrorResponse;
var router = express.Router();
const MODULE_NAME = "manifest";
/*
 * logging format followed: logger.info(<module_name>: <component name> : <description> : [<long_description>] : <data/params/errors>);
 */

/*
 * Add new manifest
 */
router.post('/', function(req, res) {
	logger.info(MODULE_NAME + ' : router : received request : addNewManifest : body : '+JSON.stringify(req.body));	
	manifestController.addNewManifest(req, res, function(err, data) {
        if(err) {
        	logger.error(MODULE_NAME + ' : router : failed addNewManifest : error : '+err);     
        	var error = new ErrorResponse();
        	if(err.name == 'ValidationError'){
        		error.setErrorMessage(err.errors[Object.keys(err.errors)[0]].message);
        	} else {
        		error.setErrorMessage(err.message);
        	}
        	error.setErrorCode("M0001");        	
        	error.setHttpResponseCode(500);        	
        	res.status(500).end(JSON.stringify(error));        
        } else {        	
        	logger.info(MODULE_NAME + ' : router : addNewManifest successful !');
        	res.status(200).end(JSON.stringify(data));
        }
    });
});

/*
 * Get manifest by id
 */
router.get('/:id', function (req, res) {
	logger.info(MODULE_NAME + ' : router : received request : getManifestById : id : '+req.params.id);
	if(Number(req.params.id)) {
		manifestController.getManifestById(req, res, function(err, data) {
	        if(err){
	        	logger.error(MODULE_NAME + ' : router : failed getManifestById : error : '+err);  
	        	var error = new ErrorResponse();
	        	error.setErrorCode("M0002");
	        	error.setErrorMessage(err.message);
	        	error.setHttpResponseCode(500);
	            res.status(500).end(JSON.stringify(error));
	        }else{        	
	        	logger.info(MODULE_NAME + ' : router : getManifestById successful !') ;
	        	res.status(200).end(JSON.stringify(data));
	        }
	    });
	} else {
		var error = new ErrorResponse();
    	error.setErrorCode("M0002");
    	error.setErrorMessage('Invalid manifest id');
    	error.setHttpResponseCode(500);
        res.status(500).end(JSON.stringify(error));
	}
});


module.exports = router;
