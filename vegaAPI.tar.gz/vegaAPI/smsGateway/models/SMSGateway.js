var mongoose = require('../../common/MongoDbConnection').mongoose;
var autoIncrement = require('mongoose-auto-increment');
var connection = mongoose.connection;
autoIncrement.initialize(connection);

/*
 * Define schema
 */
var SmsgatewaySchema = mongoose.Schema({
	
	 SMSGatewayId:{type:Number,unique: true},
	 SMSGatewayName:{type:String,unique: true, minLength: 0, maxLength: 100},
	 CompanyId:{type:Number, required: true},
	 SMSGwatewayURL:{type:String,minLength: 0, maxLength: 150},
	 HTTPMethod:{type:String,minLength: 0, maxLength: 10},	
	// Username:{type:String,minLength: 0, maxLength: 100},
	 //Password:{type:String,minLength: 0, maxLength: 100},
	 messageQueueName:{type:String,minLength: 0, maxLength: 100},
	 MessageRetries:{type:Number,minLength: 0, maxLength: 2},	
	 contentType: {type:String,minLength: 0, maxLength: 100},
	 attributes: [{
		 attributeKey: String,
		 attributeParamType: String,
		 attributeValue: String,
		 mappedTo: String,					// for toNumber, messageBody fields
		 usePlusPrefix: Boolean				// for toNumber field
	 }] ,	                                     
	 CreatedBy:{type:String,minLength: 0, maxLength: 50},
	 CreatedOn: { type: Date, default: Date.now },
	 UpdatedBy:{type:String,minLength: 0, maxLength: 50},
	 UpdatedOn: { type: Date, default: Date.now }
	
}); 


/*
 * Add Auto increment for field id
 */
SmsgatewaySchema.plugin(autoIncrement.plugin, { model: 'SmsGateway', field: 'SMSGatewayId', startAt: 1 });



SmsgatewaySchema.path('SMSGatewayName').validate(function(value, fn) {	  
	  var SmsGateway = mongoose.model('SmsGateway');
	  SmsGateway.find({'SMSGatewayName': value}, function (err, data) {
	    fn(err || data.length === 0);
	  });
}, 'SMSGateway name is already taken');

SmsgatewaySchema.path('SMSGatewayName').validate(function (v) {
	  return v.length <= 100;
}, 'data too long for field SMSGatewayName'); 

SmsgatewaySchema.path('SMSGwatewayURL').validate(function (v) {
	  return v.length <= 150;
}, 'data too long for field SMSGwatewayURL'); 

SmsgatewaySchema.path('HTTPMethod').validate(function (v) {
	  return v.length <= 10;
}, 'data too long for field HTTPMethod'); 

SmsgatewaySchema.path('messageQueueName').validate(function (v) {
	  return v.length <= 100;
}, 'data too long for field messageQueueName'); 


SmsgatewaySchema.path('CreatedBy').validate(function (v) {
	  return v.length <= 50;
}, 'data too long for field CreatedBy'); 

SmsgatewaySchema.path('UpdatedBy').validate(function (v) {
	  return v.length <= 50;
}, 'data too long for field UpdatedBy'); 

/*
 * Setters
 */
SmsgatewaySchema.methods.setSMSGatewayId = function(SMSGatewayId) {	
	this.SMSGatewayId = SMSGatewayId;
};

SmsgatewaySchema.methods.setSMSGatewayName = function(SMSGatewayName) {	
	this.SMSGatewayName = SMSGatewayName;
};

SmsgatewaySchema.methods.setCompanyId = function(CompanyId) {	
	this.CompanyId = CompanyId;
};

SmsgatewaySchema.methods.setSMSGwatewayURL = function(SMSGwatewayURL) {	
	this.SMSGwatewayURL = SMSGwatewayURL;
};

SmsgatewaySchema.methods.setHTTPMethod = function(HTTPMethod) {	
	this.HTTPMethod = HTTPMethod;
};


SmsgatewaySchema.methods.setmessageQueueName = function(messageQueueName) {
	this.messageQueueName = messageQueueName;
};

SmsgatewaySchema.methods.setMessageRetries = function(MessageRetries) {
	this.MessageRetries = MessageRetries;
};

SmsgatewaySchema.methods.setcontentType = function(contentType) {
	 this.contentType= contentType;
};

SmsgatewaySchema.methods.setattributes = function(attributes) {
	 this.attributes= attributes;
};

SmsgatewaySchema.methods.setCreatedBy = function(CreatedBy) {	
	this.CreatedBy = CreatedBy;
};

SmsgatewaySchema.methods.setCreatedOn = function(CreatedOn) {
	this.CreatedOn = CreatedOn;
};

SmsgatewaySchema.methods.setUpdatedBy = function(UpdatedBy) {
	this.UpdatedBy = UpdatedBy;
};


SmsgatewaySchema.methods.setUpdatedOn = function(UpdatedOn) {
	this.UpdatedOn = UpdatedOn;
};


/*
 * Getters
 */
SmsgatewaySchema.methods.getSMSGatewayId = function() {
	return this.SMSGatewayId;
};

SmsgatewaySchema.methods.getSMSGatewayName = function() {
	return this.SMSGatewayName;
};
SmsgatewaySchema.methods.getCompanyId = function() {
	return this.CompanyId;
};

SmsgatewaySchema.methods.getSMSGwatewayURL = function() {
	return this.SMSGwatewayURL;
};

SmsgatewaySchema.methods.getHTTPMethod = function() {
	return this.HTTPMethod;
};


SmsgatewaySchema.methods.getmessageQueueName = function() {
	return this.messageQueueName;
};
SmsgatewaySchema.methods.getMessageRetries = function() {
	return this.MessageRetries;
};

SmsgatewaySchema.methods.getcontentType = function() {
	 return this.contentType;
};

SmsgatewaySchema.methods.getattributes = function() {
	return this.attributes;
};

SmsgatewaySchema.methods.getCreatedBy = function() {	
	return this.CreatedBy;
};

SmsgatewaySchema.methods.getCreatedOn = function() {
	return this.CreatedOn ;
};

SmsgatewaySchema.methods.getUpdatedBy = function() {
	return this.UpdatedBy ;
};


SmsgatewaySchema.methods.getUpdatedOn = function() {
	return this.UpdatedOn;
};



/*
 * Create collection/model in mongo db using Schema
 */
var SmsGateway = mongoose.model('SmsGateway', SmsgatewaySchema);

/*
 * Insert records in collection
 */
/*var smsgateway = new SmsGateway({ SMSGatewayId: 1 });
smsgateway.save(function (err, data) {
  if (err) 
	  return console.error(err);
  else
	  console.log('data inserted: '+data.SMSGatewayId);
});*/


module.exports = SmsGateway;
