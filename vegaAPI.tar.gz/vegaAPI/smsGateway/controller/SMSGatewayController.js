var smsgatewayDao = require('../dao/SMSGatewayDAO');
var logger = require('../../common/logger').log;
/*
 * logging format followed: logger.info(<module_name>: <component name> : <description> : [<long_description>] : <data/params/errors>);
 */

/*
 *Add new SMS Gateway Info
 */

var addNewSMSGatewayInfo = function(req, res, callback) {
	logger.info('smsGateway : controller : received request : addNewSMSGatewayInfo : body : '+JSON.stringify(req.body));
	smsgatewayDao.addNewSMSGatewayInfo(req, res, callback);
};


/*
 * 	Get SMS Gateway Info by company id and apiMgrId
 */
var getSMSGatewayInfo = function(req, res, callback) {
	logger.info('smsGateway : controller : received request : getSMSGatewayInfo : id : '+req.params.id);
	smsgatewayDao.getSMSGatewayInfo(req, res, callback);
};

/*
 * Update SMS Gateway Info
 */
var updateSMSGatewayInfo = function(req, res, callback) {
	logger.info('smsGateway : controller : received request : updateSMSGatewayInfo : id : '+req.params.id);
	smsgatewayDao.updateSMSGatewayInfo(req, res, callback);
};



module.exports.addNewSMSGatewayInfo = addNewSMSGatewayInfo;
module.exports.getSMSGatewayInfo = getSMSGatewayInfo;
module.exports.updateSMSGatewayInfo = updateSMSGatewayInfo;