var express = require('express');
var smsGatewayController = require('./controller/SMSGatewayController');
var logger = require('../common/logger').log;
var ErrorResponse = require('../common/ErrorResponse').ErrorResponse;
var router = express.Router();

/*
 * logging format followed: logger.info(<module_name>: <component name> : <description> : [<long_description>] : <data/params/errors>);
 */

/*
 *Add new SMS Gateway Info
 */
router.post('/', function(req, res){
	logger.info('smsGateway : router : received request : addNewSMSGatewayInfo : body : '+JSON.stringify(req.body));
	smsGatewayController.addNewSMSGatewayInfo(req, res, function(err, data) {
        if(err){
        	logger.error('smsGateway : router : failed addNewSMSGatewayInfo : error : '+err);
        	var error = new ErrorResponse();
        	if(err.name == 'ValidationError'){
        		error.setErrorMessage(err.errors[Object.keys(err.errors)[0]].message);
        	} else {
        		error.setErrorMessage(err.message);
        	}
        	error.setErrorCode("SG001");        	
        	error.setHttpResponseCode(500);
            res.status(500).end(JSON.stringify(error));
        }else{
        	
        	logger.info("smsGateway : router : addNewSMSGatewayInfo successful !");
        	res.status(200).end(JSON.stringify(data));
        }
    });
});





/*
 * 	Get SMS Gateway Info by company id and SMSGatewayId
 */
router.get('/:id(\\d+)', function (req, res) {	
	logger.info('smsGateway : router : received request : getSMSGatewayInfo : id : '+req.params.id);
	smsGatewayController.getSMSGatewayInfo(req, res, function(err, data) {
        if(err){
        	logger.error('smsGateway : router : failed getSMSGatewayInfo : error : '+err);
        	var error = new ErrorResponse();
        	error.setErrorCode("SG002");
        	error.setErrorMessage(err.message);
        	error.setHttpResponseCode(500);
            res.status(500).end(JSON.stringify(error));
        }else{
        	
        	logger.info("smsGateway : router : getSMSGatewayInfo successful !");
        	res.status(200).end(JSON.stringify(data));
        }
    });
});



/*
 * Update SMS Gateway Info
 */
router.put('/:id(\\d+)', function(req, res){	
	logger.info('smsGateway : router : received request : updateSMSGatewayInfo : id : '+req.params.id);
	smsGatewayController.updateSMSGatewayInfo(req, res, function(err, data) {
        if(err){
        	logger.error('smsGateway : router : failed updateSMSGatewayInfo : error : '+err);
        	var error = new ErrorResponse();
        	if(err.name == 'ValidationError'){
        		error.setErrorMessage(err.errors[Object.keys(err.errors)[0]].message);
        	} else {
        		error.setErrorMessage(err.message);
        	}
        	error.setErrorCode("SG003");
        	error.setErrorMessage(err.message);
        	error.setHttpResponseCode(500);  
            res.status(500).end(JSON.stringify(error));
        }else{
        	
        	logger.info("smsGateway : router : updateSMSGatewayInfo successful !");
        	res.status(200).end(JSON.stringify(data));
        }
    });
});


router.options('/', function(req, res) {
	logger.info('smsGateway : router : received request : Options call smsGateway APIs');
	res.header('Allow-Access-Allow-Origin', '*');
	res.header('Access-Control-Allow-Headers', '*');
	res.header('Access-Control-Allow-Methods', 'GET,POST,DELETE,PUT,OPTIONS');
	res.header('Connection', 'keep-alive');
	res.header('Content-Type', 'application/json;charset=UTF-8');
	res.end();
	logger.info('smsGateway : router : received request : headers sent !');
});


router.all('/*', function (req, res) {	
	logger.info('smsGateway : router : received request : with URL : ' + req.originalUrl);
	logger.error('smsGateway : router : No matching resource for URL : ' + req.originalUrl);
	var error = new ErrorResponse();
	error.setErrorCode("SG004");
	error.setErrorMessage('No matching resource for URL: ' + req.originalUrl);
	error.setHttpResponseCode(404);
	res.status(404).send(JSON.stringify(error));
});


module.exports = router;