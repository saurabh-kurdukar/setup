var db = require('../../common/MongoDbConnection');
var SMSGateway = require('../models/SMSGateway');
var Company=require('../../company/models/Company');
var logger = require('../../common/logger').log;
var encdec = require('../../common/EncryptDecrypt');
var audit = require('../../common/Audit').audit;
/*
 * logging format followed: logger.info(<module_name>: <component name> : <description> : [<long_description>] : <data/params/errors>);
 */

var mongoose = db.mongoose;


/*
 *Add new SMS Gateway Info
 */
var addNewSMSGatewayInfo = function(req, res, callback) {
	logger.info('smsGateway : DAO : received request : addNewSMSGatewayInfo : body : '+ JSON.stringify(req.body));
	var reqBody = req.body;
	var smsgateway = new SMSGateway();
	
	var companyid = req.headers['companyid']; 
	var usernm=req.headers['username']; 
	var attributes=req.body.attributes;
	//iterate over attributes
	 for(var i = 0; i < attributes.length; i++) {					 
		var obj = attributes[i];
		if(obj.attributeKey == "password" || obj.mappedTo == "password") {
			var encryptedPwd= encdec.encryption(attributes[i].attributeValue);
		    req.body.attributes[i].attributeValue= encryptedPwd;
   		}
	 }	
	
	
	//smsgateway.setSMSGatewayId(reqBody.SMSGatewayId);
	smsgateway.setSMSGatewayName(reqBody.SMSGatewayName);
	smsgateway.setCompanyId(companyid);
	smsgateway.setSMSGwatewayURL(reqBody.SMSGwatewayURL);
	smsgateway.setHTTPMethod(reqBody.HTTPMethod);		
	smsgateway.setcontentType(reqBody.contentType);
	smsgateway.setmessageQueueName(reqBody.messageQueueName);
	smsgateway.setMessageRetries(reqBody.MessageRetries);
	smsgateway.setattributes(reqBody.attributes);
	smsgateway.setCreatedBy(usernm);
	smsgateway.setCreatedOn(new Date());
	smsgateway.setUpdatedBy(usernm);
	smsgateway.setUpdatedOn(new Date());
		
	Company.find({
			'companyId' : companyid
		}, function(err, data) {
			if (err) {
				callback(err, data);
			} else {
				if (data.length != 0) {
					//callback(err, data);
					smsgateway.save(function(err, data) {
						if (err) {
							logger.error('smsGateway : DAO : failed addNewSMSGatewayInfo : error : ' + err);
							callback(err, null);
						} else {
							logger.info('smsGateway : DAO : addNewSMSGatewayInfo successful !');
							callback(null, data);
						}
					});
				} else {
					var err = new Error('Invalid company id');
					err.status = 404;
					logger.error('smsGateway : DAO : failed addNewSMSGatewayInfo : error : '+ err);
					callback(err, null);
				}
			}
		});
	};
	
	

	/*
	 * 	Get  SMS Gateway   by company id
	 */
	var getSMSGateway = function(req, res, callback) {				
		logger.info('smsGateway : DAO : received request : getSMSGateway : id : '+req.params.id);
		SMSGateway.find({
			'CompanyId' : req.params.id
		}, function(err, data) {
			if (err) {
				logger.error('smsGateway : DAO : failed getSMSGateway : error : ' + err);
				callback(err, null);
			} else {
				if (data.length != 0) {
					logger.info('smsGateway : DAO : getSMSGateway successful !');
					callback(null, data);
				} else {
					var err = new Error('Invalid company id');
					err.status = 404;
					logger.error('smsGateway : DAO : failed getSMSGateway : error : '+ err);
					callback(err, null);
				}
			}
		});
	};
	
	
	/*
	 * 	Get SMS Gateway Info by company id and SMSGatewayId
	 */
	var getSMSGatewayInfo = function(req, res, callback) {
		
		logger.info('smsGateway : DAO : received request : getSMSGatewayInfo : id : '+req.params.id);
		var companyid = req.headers['companyid']; 
				
		SMSGateway.find({
			'CompanyId' : companyid,
			'SMSGatewayId':req.params.id
		}, function(err, data) {
			if (err) {
				logger.error('smsGateway : DAO : failed getSMSGatewayInfo : error : ' + err);
				callback(err, null);
			} else {
				if (data.length != 0) {
					logger.info('smsGateway : DAO : getSMSGatewayInfo successful !');
					callback(null, data);
				} else {
					var err = new Error('Invalid company id');
					err.status = 404;
					logger.error('smsGateway : DAO : failed getSMSGatewayInfo : error : '+ err);
					callback(err, null);
				}
			}
		});
	};
	
	
	/*
	 * Update SMS Gateway Info
	 */
	
	
	var updateSMSGatewayInfo = function(req, res, callback) {
		logger.info('smsGateway : DAO : received request : updateSMSGatewayInfo : (id: '+req.params.id+', body: '+JSON.stringify(req.body)+')');
		/*
		 * Callback function after getting original record to update with new values.
		 */ 
		var callbackUpdate = function(err, data) {	
			if(err) {
				logger.error('smsGateway : DAO : failed updateSMSGatewayInfo : error :' + err);
				callback(err, null);
			} else if(data != null) {
				/*
				 *	Compare updatable fields values in db with request data
				 *	Add those fields in temproary object which are having new values
				 */			
				var smsgateway = data;
				var json = {};
				var updatedData = [];
				
				var companyid = req.headers['companyid'];
				var usernm=req.headers['username']; 
				
				//console.log(usernm);
				
				if (req.body.CompanyId && smsgateway['CompanyId'] != req.body.CompanyId) {
					json.CompanyId = req.body.CompanyId;
					var obj = {};				
					obj.column = 'CompanyId';
					obj.oldValue = smsgateway['CompanyId'];
					obj.newValue = req.body.CompanyId;
					obj.identifier = 'Platform_smsGateway_'+req.params.id;
					obj.modifiedBy = 'admin';
					obj.modifiedOn = new Date();
					updatedData.push(obj);
				}
				if (req.body.SMSGwatewayURL && smsgateway['SMSGwatewayURL'] != req.body.SMSGwatewayURL) {
					json.SMSGwatewayURL = req.body.SMSGwatewayURL;
					var obj = {};				
					obj.column = 'SMSGwatewayURL';
					obj.oldValue = smsgateway['SMSGwatewayURL'];
					obj.newValue = req.body.SMSGwatewayURL;
					obj.identifier = 'Platform_smsGateway_'+req.params.id;
					obj.modifiedBy = 'admin';
					obj.modifiedOn = new Date();
					updatedData.push(obj);
				}
				if (req.body.HTTPMethod && smsgateway['HTTPMethod'] != req.body.HTTPMethod) {
					json.HTTPMethod = req.body.HTTPMethod;
					var obj = {};				
					obj.column = 'HTTPMethod';
					obj.oldValue = smsgateway['HTTPMethod'];
					obj.newValue = req.body.HTTPMethod;
					obj.identifier = 'Platform_smsGateway_'+req.params.id;
					obj.modifiedBy = 'admin';
					obj.modifiedOn = new Date();
					updatedData.push(obj);
				}
				if (req.body.MessageRetries && smsgateway['MessageRetries'] != req.body.MessageRetries) {
					json.MessageRetries = req.body.MessageRetries;
					var obj = {};				
					obj.column = 'MessageRetries';
					obj.oldValue = smsgateway['MessageRetries'];
					obj.newValue = req.body.MessageRetries;
					obj.identifier = 'Platform_smsGateway_'+req.params.id;
					obj.modifiedBy = 'admin';
					obj.modifiedOn = new Date();
					updatedData.push(obj);
				}
				if (req.body.contentType && smsgateway['contentType'] != req.body.contentType) {
					json.contentType = req.body.contentType;
					var obj = {};				
					obj.column = 'contentType';
					obj.oldValue = smsgateway['contentType'];
					obj.newValue = req.body.contentType;
					obj.identifier = 'Platform_smsGateway_'+req.params.id;
					obj.modifiedBy = 'admin';
					obj.modifiedOn = new Date();
					updatedData.push(obj);
				}
				
				if (req.body.attributes && smsgateway['attributes'] != req.body.attributes) {
					json.attributes = req.body.attributes;
					var obj = {};				
					obj.column = 'attributes';
					obj.oldValue = smsgateway['attributes'];
					obj.newValue = req.body.attributes;
					obj.identifier = 'Platform_smsGateway_'+req.params.id;
					obj.modifiedBy = 'admin';
					obj.modifiedOn = new Date();
					updatedData.push(obj);
				}
				
				/*
				 *	Update the data to database 
				 */
				if (Object.keys(json).length != 0) {
					json.UpdatedBy = usernm;
					json.UpdatedOn = new Date();
	
					logger.info('smsGateway : DAO : updateSMSGatewayInfo : updating data : ' + JSON.stringify(json));
					SMSGateway.findOneAndUpdate({
						'CompanyId' : companyid,
						'SMSGatewayId' : req.params.id
					}, json, {
						'new' : true
					// returns updated entity if update successful, if false then old entry
					}, function(err, data) {
						if (err) {
							logger.error('smsGateway : DAO : failed updateSMSGatewayInfo : error :' + err);
							callback(err, null);
						} else {
							if(data != null) {
								logger.info('smsGateway : DAO : updateSMSGatewayInfo successful !');		
								/*
								 *	Call audit function for changed data 
								 */
								audit(req, res, updatedData);
								/*
								 *	Call function to send response to client 
								 */
								callback(null, data);
							} else {
								var err = new Error('Bad request data');
								logger.error('smsGateway : DAO : failed updateSMSGatewayInfo : error :' + err);
								callback(err, null);
							}
						}
					});
				} else {
					var err = new Error('Cannot update data');
					logger.error('smsGateway : DAO : failed updateSMSGatewayInfo : error :' + err);
					callback(err, null);
				}
			} else {
				var err = new Error('Failed to get smsgateway details');
				logger.error('smsGateway : DAO : failed updateSMSGatewayInfo : error :' + err);
				callback(err, null);
			}
		}
		
		/*
		 * Get the original record from db before update.
		 */ 
		getSMSGatewayInfo(req, res, callbackUpdate);
		

	};

	
	

	/*
	 * get SMS Server Details by company id from header
	 */
	var getSMSServerDetails = function(req, res, callback) {
		logger.info('smsGateway : DAO : received request : getSMSServerDetails : id : '+req.params.id);
		var companyid = req.headers['companyid']; 	
		SMSGateway.findOne({
			'CompanyId' : companyid
		}, function(err, data) {
			if (err) {
				logger.error('smsGateway : DAO : failed getSMSServerDetails : error : ' + err);
				callback(err, data);
			} else {
				if (data) {
					logger.info('smsGateway : DAO : getSMSServerDetails successful !');
					callback(err, data);
				} else {
					var err = new Error('Invalid company id');
					err.status = 404;
					logger.error('smsGateway : DAO : failed getSMSServerDetails : error : '+ err);
					callback(err, data);
				}
			}
		});
	};
	
	
	/*
	 * get SMS Server Details by company id from header
	 */
	var getSMSServerDetailsBySMSGatewayId = function(smsGatewayId, callback) {
		logger.info('smsGateway : DAO : received request : getSMSServerDetailsBySMSGatewayId : smsGatewayId : '+smsGatewayId);		 	
		SMSGateway.findOne({
			'SMSGatewayId' : smsGatewayId
		}, function(err, data) {
			if (err) {
				err.status = 500;
				logger.error('smsGateway : DAO : failed getSMSServerDetailsBySMSGatewayId : error : ' + err);
				callback(err);
			} else {
				if (data) {
					logger.info('smsGateway : DAO : getSMSServerDetailsBySMSGatewayId successful !');
					callback(err, data);
				} else {
					var err = new Error('SMS Gateway Id not exist');
					err.status = 404;
					logger.error('smsGateway : DAO : failed getSMSServerDetailsBySMSGatewayId : error : '+ err);
					callback(err);
				}
			}
		});
	};
	
	
	
module.exports.addNewSMSGatewayInfo = addNewSMSGatewayInfo;
module.exports.getSMSGateway = getSMSGateway;
module.exports.getSMSGatewayInfo = getSMSGatewayInfo;
module.exports.updateSMSGatewayInfo = updateSMSGatewayInfo;
module.exports.getSMSServerDetails = getSMSServerDetails;
module.exports.getSMSServerDetailsBySMSGatewayId = getSMSServerDetailsBySMSGatewayId;





