var serviceDao = require('../dao/ServiceDAO');
var logger = require('../../common/logger').log;
var documentDao = require('../../documents/dao/DocumentDAO');
var attributesDao = require('../../attributes/dao/AttributesDAO');


/*
 * Add new Service
 */
var addNewService = function(req, res, callback) {
	logger.info('Service : controller : received request : addNewService : body : '+JSON.stringify(req.body));
	serviceDao.addNewService(req, res, callback);
};

/*
 * Get Service by Service id
 */
var getServiceById = function(req, res, callback) {
	logger.info('Service : controller : received request : getServiceById : Service Id:'+req.params.id);
	serviceDao.getServiceById(req, res, callback);
};

/*
 * Get Services by Experience id
 */
var getServicesByExperienceId = function(req, res, callback) {
	logger.info('Service : controller : received request : getServicesByExperienceId : Experience Id:'+req.params.id);
	serviceDao.getServicesByExperienceId(req, res, callback);
};

/*
 * Get All Services
 */
var getAllServices = function(req, res, callback) {
	logger.info('Service : controller : received request : getAllServices');
	serviceDao.getAllServices(req, res, callback);
};

/*
 * Edit/Update Service
 */
var updateServiceById = function(req, res, callback) {
	logger.info('Service : controller : received request : updateServiceById : Service Id:'+req.params.id);
	serviceDao.updateServiceById(req, res, callback);
};

/*
* Delete Service details
*/
var deleteServiceById = function(req, res, callback) {
	logger.info('Service : controller : received request : deleteServiceById : id : '+req.params.id);
	serviceDao.deleteServiceById(req, res, callback);
};

/*
* Delete Service details
*/
var getDocumentsByServiceId = function(req, callback) {
	logger.info('Service : controller : received request : getDocumentsByServiceId : id : '+req.params.id);
	documentDao.getDocumentsByServiceId(req.params.id, callback);
};

/*
 * Get attributes by Service id
 */
var getAllAttributes = function(req, callback) {
	logger.info('Service : controller : received request : getAllAttributes : id : '+req.params.id);
	serviceDao.getServiceById(req, null, function(err, data) {
		if(err){
			return callback(err);
		}
		req.params.serviceId = req.params.id; 
		attributesDao.getAllAttributes(req, callback);
	});
	
};

module.exports.addNewService = addNewService;
module.exports.getServiceById = getServiceById;
module.exports.getServicesByExperienceId = getServicesByExperienceId;
module.exports.getAllServices = getAllServices;
module.exports.updateServiceById = updateServiceById;
module.exports.deleteServiceById = deleteServiceById;
module.exports.getDocumentsByServiceId = getDocumentsByServiceId;
module.exports.getAllAttributes = getAllAttributes;




