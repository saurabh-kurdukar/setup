var db = require('../../common/MongoDbConnection');
var Service = require('../models/Service');
var Experience = require('../../experience/models/Experience');
var logger = require('../../common/logger').log;
var audit = require('../../common/Audit').audit;

/*
 * Add new service
 */
var addNewService = function(req, res, callback) {
	logger.info('Service : DAO : received request : addNewService : body : '+JSON.stringify(req.body));
	
	Experience.find({ 'id' : req.body.experienceId }, function(err, data) {
		if (err) {
			logger.error('Service : DAO : failed to find Experience : error : ' + err);
			callback(err, null);
		} else {
			if (data.length != 0) {
				
				var reqBody = req.body;
				
				var service = new Service();
				service.setName(reqBody.name);
				service.setDisplayName(reqBody.displayName);
				service.setSummary(reqBody.summary);
				service.setDescription(reqBody.description);
				service.setLogo(reqBody.logo);
				service.setVersion(reqBody.version);
				service.setBaseURL(reqBody.baseURL);
				service.setSwaggerURL(reqBody.swaggerURL);				
				service.setStatus(reqBody.status);
				service.setExperienceId(reqBody.experienceId);
				
				service.setFileName(reqBody.fileName);
				service.setBoundFromPort(reqBody.boundFromPort);
				service.setBoundToPort(reqBody.boundToPort);
				service.setOrder(reqBody.order);
				service.setSeedDataLocation(reqBody.seedDataLocation);
				service.setTestScriptLocation(reqBody.testScriptLocation);	
				
				service.setCreatedOn(new Date());
				service.setCreatedBy(reqBody.createdBy);
				service.setUpdatedOn(new Date());
				service.setUpdatedBy(reqBody.updatedBy);
				service.setServiceDeployOption(reqBody.serviceDeployOption);
				service.setExecScriptLocation(reqBody.execScriptLocation);
				
				service.save(function(err, data) {
					if (err) {
						logger.error('Service : DAO : failed addNewService : error : ' + err);
						callback(err, null);
					} else {
						logger.info('Service : DAO : addNewService successful !');
						callback(null, data);
					}
				});
				
			} else {
				var err1 = new Error('Invalid Experience Id!');
				logger.error('Service : DAO : Experience : error : ' + err1);
				callback(err1, null);
			}
		}
	});
};

/*
 * Get service by service id
 */
var getServiceById = function(req, res, callback) {
	logger.info('Service : DAO : received request : getServiceById : serviceId:'+req.params.id);
	
	Service.find( { 'id' : req.params.id }, function(err, data) {
		if (err) {
			logger.error('Service : DAO : failed getServiceById : error : ' + err);
			callback(err, null);
		} else {
			if (data.length != 0) {
				logger.info('Service : DAO : getServiceById successful!');
				callback(null, data[0]);
			} else {
				var err1 = new Error('Invalid Service Id!');
				logger.error('Service : DAO : failed getServiceById : error : ' + err1);
				callback(err1, null);
			}
		}
	});
};

/*
 * Edit/Update service
 */
var updateServiceById = function(req, res, callback) {
	logger.info('Service : DAO : received request : updateServiceById : service Id:'+req.params.id);
	
	/*
	 * Callback function after getting original record to update with new values.
	 */
	var callbackUpdate = function(err, data) {	
		if(err) {
			logger.error('Service : DAO : failed updateServiceById : error : ' + err);
			callback(err, null);
		} else if (data != null) {
			var service = data;
			var updatingUser;			
			if(req.body.updatedBy){
				updatingUser = req.body.updatedBy;
			} else if(req.headers.username){
				updatingUser = req.headers.username;
			} else {
				updatingUser = 'admin';
			}
			
			var json = {};
			var updatedData = [];
			var obj = {};
			if (req.body.summary && service['summary'] != req.body.summary) {
				json.summary = req.body.summary;		
				obj.column = 'summary';
				obj.oldValue = service['summary'];
				obj.newValue = req.body.summary;
				obj.identifier = 'Platform_Service_'+req.params.id;
				obj.modifiedBy = updatingUser;
				obj.modifiedOn = new Date();
				updatedData.push(obj);
			}
			if (req.body.displayName && service['displayName'] != req.body.displayName) {
				json.displayName = req.body.displayName;		
				obj.column = 'displayName';
				obj.oldValue = service['displayName'];
				obj.newValue = req.body.displayName;
				obj.identifier = 'Platform_Service_'+req.params.id;
				obj.modifiedBy = updatingUser;
				obj.modifiedOn = new Date();
				updatedData.push(obj);
			}
			if (req.body.description && service['description'] != req.body.description) {
				obj = {};
				json.description = req.body.description;		
				obj.column = 'description';
				obj.oldValue = service['description'];
				obj.newValue = req.body.description;
				obj.identifier = 'Platform_Service_'+req.params.id;
				obj.modifiedBy = updatingUser;
				obj.modifiedOn = new Date();
				updatedData.push(obj);
			}
			if (req.body.logo && service['logo'] != req.body.logo) {
				obj = {};
				json.logo = req.body.logo;
				obj.column = 'logo';
				obj.oldValue = service['logo'];
				obj.newValue = req.body.logo;
				obj.identifier = 'Platform_Service_'+req.params.id;
				obj.modifiedBy = updatingUser;
				updatedData.push(obj);
			}
			if (req.body.version && service['version'] != req.body.version) {
				obj = {};
				json.version = req.body.version;
				obj.column = 'version';
				obj.oldValue = service['version'];
				obj.newValue = req.body.version;
				obj.identifier = 'Platform_Service_'+req.params.id;
				obj.modifiedBy = updatingUser;
				updatedData.push(obj);
			}
			if (req.body.baseURL && service['baseURL'] != req.body.baseURL) {
				obj = {};
				json.baseURL = req.body.baseURL;
				obj.column = 'baseURL';
				obj.oldValue = service['baseURL'];
				obj.newValue = req.body.baseURL;
				obj.identifier = 'Platform_Service_'+req.params.id;
				obj.modifiedBy = updatingUser;
				updatedData.push(obj);
			}
			if (req.body.swaggerURL && service['swaggerURL'] != req.body.swaggerURL) {
				obj = {};
				json.swaggerURL = req.body.swaggerURL;
				obj.column = 'swaggerURL';
				obj.oldValue = service['swaggerURL'];
				obj.newValue = req.body.swaggerURL;
				obj.identifier = 'Platform_Service_'+req.params.id;
				obj.modifiedBy = updatingUser;
				updatedData.push(obj);
			}			
			if (req.body.status && service['status'] != req.body.status) {
				obj = {};
				json.status = req.body.status;
				obj.column = 'status';
				obj.oldValue = service['status'];
				obj.newValue = req.body.status;
				obj.identifier = 'Platform_Service_'+req.params.id;
				obj.modifiedBy = updatingUser;
				updatedData.push(obj);
			}
			if (req.body.fileName && service['fileName'] != req.body.fileName) {
				obj = {};
				json.fileName = req.body.fileName;
				obj.column = 'fileName';
				obj.oldValue = service['fileName'];
				obj.newValue = req.body.fileName;
				obj.identifier = 'Platform_Service_'+req.params.id;
				obj.modifiedBy = updatingUser;
				updatedData.push(obj);
			}
			if (req.body.boundFromPort && service['boundFromPort'] != req.body.boundFromPort) {
				obj = {};
				json.boundFromPort = req.body.boundFromPort;
				obj.column = 'boundFromPort';
				obj.oldValue = service['boundFromPort'];
				obj.newValue = req.body.boundFromPort;
				obj.identifier = 'Platform_Service_'+req.params.id;
				obj.modifiedBy = updatingUser;
				updatedData.push(obj);
			}
			if (req.body.boundToPort && service['boundToPort'] != req.body.boundToPort) {
				obj = {};
				json.boundToPort = req.body.boundToPort;
				obj.column = 'boundToPort';
				obj.oldValue = service['boundToPort'];
				obj.newValue = req.body.boundToPort;
				obj.identifier = 'Platform_Service_'+req.params.id;
				obj.modifiedBy = updatingUser;
				updatedData.push(obj);
			}
			if (req.body.order && service['order'] != req.body.order) {
				obj = {};
				json.order = req.body.order;
				obj.column = 'order';
				obj.oldValue = service['order'];
				obj.newValue = req.body.order;
				obj.identifier = 'Platform_Service_'+req.params.id;
				obj.modifiedBy = updatingUser;
				updatedData.push(obj);
			}
			if (req.body.seedDataLocation && service['seedDataLocation'] != req.body.seedDataLocation) {
				obj = {};
				json.seedDataLocation = req.body.seedDataLocation;
				obj.column = 'seedDataLocation';
				obj.oldValue = service['seedDataLocation'];
				obj.newValue = req.body.seedDataLocation;
				obj.identifier = 'Platform_Service_'+req.params.id;
				obj.modifiedBy = updatingUser;
				updatedData.push(obj);
			}
			if (req.body.testScriptLocation && service['testScriptLocation'] != req.body.testScriptLocation) {
				obj = {};
				json.testScriptLocation = req.body.testScriptLocation;
				obj.column = 'testScriptLocation';
				obj.oldValue = service['testScriptLocation'];
				obj.newValue = req.body.testScriptLocation;
				obj.identifier = 'Platform_Service_'+req.params.id;
				obj.modifiedBy = updatingUser;
				updatedData.push(obj);
			}
			if (req.body.serviceDeployOption && service['serviceDeployOption'] != req.body.serviceDeployOption) {
				obj = {};
				json.serviceDeployOption = req.body.serviceDeployOption;
				obj.column = 'serviceDeployOption';
				obj.oldValue = service['serviceDeployOption'];
				obj.newValue = req.body.serviceDeployOption;
				obj.identifier = 'Platform_Service_'+req.params.id;
				obj.modifiedBy = updatingUser;
				updatedData.push(obj);
			}			
			if (req.body.execScriptLocation && service['execScriptLocation'] != req.body.execScriptLocation) {
				obj = {};
				json.execScriptLocation = req.body.execScriptLocation;
				obj.column = 'execScriptLocation';
				obj.oldValue = service['execScriptLocation'];
				obj.newValue = req.body.execScriptLocation;
				obj.identifier = 'Platform_Service_'+req.params.id;
				obj.modifiedBy = updatingUser;
				updatedData.push(obj);
			}
			if (Object.keys(json).length != 0) {
				json.updatedBy = updatingUser;
				json.updatedOn = new Date();
				logger.info('Service : DAO : updateServiceById : updating data : ' + JSON.stringify(json));
				
				Service.findOneAndUpdate( {	'id' : req.params.id }, json, {	'new' : true }, function(err, data) {
					if (err) {
						logger.error('Service : DAO : failed updateServiceById : error : ' + err);
						callback(err, null);
					} else {
						if (data != null) {
							logger.info('Service : DAO : updateServiceById successful !');
							/*
							 *	Call audit function for changed data 
							 */
							audit(req, res, updatedData);
							/*
							 *	Call function to send response to client 
							 */
							callback(null, data);
						} else {
							var err1 = new Error('Invalid Service id!');
							logger.error('Service : DAO : failed updateServiceById : error : ' + err1);
							callback(err1, null);
						}
					}
				});
			} else {
				var err2 = new Error('No fields modified');
				logger.error('Service : DAO : failed updateServiceById : error : ' + err2);
				callback(err2, null);
			}
		} else {
			var err3 = new Error('Failed to get Service details.');
			logger.error('Service : DAO : failed updateServiceById : error : ' + err3);
			callback(err3, null);
		}		
	};
	
	/*
	 * Get the original record from db before update.
	 */
	getServiceById(req, res, callbackUpdate);
	
};

/*
 * Delete Service details
 */
var deleteServiceById = function(req, res, callback) {
	logger.info('Service : DAO : received request : deleteServiceById : id : ' + req.params.id);
	var callbackDelete = function(err, data) {
		if(err) {
			logger.error('Service : DAO : failed deleteServiceById : error :' + err);
			callback(err, null);
		} else if(data != null) {
			var updatedData = [];			

			logger.info('Service : DAO : deleteServiceById successful !');
			var obj = {};
			obj.column = 'status';
			obj.oldValue = 'Service Record EXISTS';
			obj.newValue = 'Service Record DELETED';
			obj.identifier = 'Platform_service_'+req.params.id;
			obj.modifiedBy = 'admin';
			updatedData.push(obj);
			/*
			 *	Call audit function for changed data 
			 */
			audit(req, res, updatedData);
			/*
			 *	Call function to send response to client 
			 */
			callback(null, data);	 
		} else {
			var err2 = new Error('Failed to get Service details');	
			logger.error('Service : DAO : failed deleteServiceById : error :' + err2);
			callback(err2, null);
		}		
	};
	
	/*
	 * Delete Service by Service ID.
	 */ 
	Service.findOneAndRemove( {	'id' : req.params.id }, callbackDelete);

};


/*
 * Get Services for given Experience Id
 */
var getServicesByExperienceId = function(req, res, callback) {
	logger.info('Service : DAO : received request : getServicesByExperienceId : ExperienceId:'+req.params.id);
		
	Service.find( {'experienceId' : req.params.id	}, function(err, data) {
		if (err) {
			logger.error('Service : DAO : failed getServicesByExperienceId : error : ' + err);
			callback(err, null);
		} else {
			if (data.length != 0) {
				logger.info('Service : DAO : getServicesByExperienceId successful !');
				callback(null, data);
			} else {
				var err = new Error('No records found');
				logger.error('Service : DAO : failed getServicesByExperienceId : error : ' + err);
				callback(err, null);
			}
		}
	});
};

/*
 * Get All Services
 */
var getAllServices = function(req, res, callback) {
	logger.info('Service : DAO : received request : getAllServices : serviceId:'+req.params.id);
	
	Service.find({}, function(err, data) {
		if (err) {
			logger.error('Service : DAO : failed getAllServices : error : ' + err);
			callback(err, null);
		} else {
			logger.info('Service : DAO : getAllServices successful!');
			callback(null, data);
		}
	});
};

var existServiceId = function(id, callback) {
	Service.count({id: id}, function (err, count){ 
	    if(err){
	        return callback(err);
	    }
	    if(count > 0) {
	    	return callback();
	    }
	    var err = new Error('no record exist for service id');
	    err.status = 200;
	    callback(err);
	}); 
}


module.exports.addNewService = addNewService;
module.exports.getServiceById = getServiceById;
module.exports.updateServiceById = updateServiceById;
module.exports.deleteServiceById = deleteServiceById;
module.exports.getServicesByExperienceId = getServicesByExperienceId;
module.exports.getAllServices = getAllServices;
module.exports.existServiceId = existServiceId;

