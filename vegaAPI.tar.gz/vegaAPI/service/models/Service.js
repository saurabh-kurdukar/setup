var mongoose = require('../../common/MongoDbConnection').mongoose;
var autoIncrement = require('mongoose-auto-increment');
var logger = require('../../common/logger').log;
var connection = mongoose.connection;
autoIncrement.initialize(connection);

/*
 * Define schema
 */
var serviceSchema = mongoose.Schema({
	id : Number,
	name : { type: String, unique: true, required: true },
	displayName : { type: String },
	summary : { type: String },
	description : { type: String },
	logo : {type: String},
	version : {type: String},
	baseURL : {type: String},
	swaggerURL : {type: String},
	status : {type: String, default: 'ACTIVE'},
	experienceId : { type: Number, required: true },
	
	fileName : { type: String },
	boundFromPort : { type: Number },
	boundToPort : { type: Number },
	order : { type: Number },
	seedDataLocation : { type: String },
	testScriptLocation : { type: String },	
	
	createdBy : {type: String, default: 'ADMIN'},
	createdOn : { type: Date, default: Date.now },
	updatedBy : {type: String, default: 'ADMIN'},
	updatedOn : { type: Date, default: Date.now },
	serviceDeployOption : { type: String, enum: [ 'DOCKER', 'HOSTED', 'SCRIPT' ] },
	execScriptLocation : { type: String }
});


logger.info('Service : model : created schema : Services :'+JSON.stringify(serviceSchema.paths));

serviceSchema.path('name').validate(function(value, fn) {	  
	  var Service = mongoose.model('Services');
	  Service.find({'name': value}, function (err, data) {
	    fn(err || data.length === 0);
	  });
}, 'Service name is already taken');


serviceSchema.pre('findOneAndUpdate', function(next) {
	  this.options.runValidators = true;
	  next();
});

serviceSchema.path('name').validate(function (v) {
	  return (v.length > 0 && v.length <= 100);
}, 'data length not suitable for field name'); 

serviceSchema.path('displayName').validate(function (v) {
	  return (v.length > 0 && v.length <= 100);
}, 'data length not suitable for field displayName'); 

serviceSchema.path('summary').validate(function (v) {
	  return (v.length > 0 && v.length <= 255);
}, 'data length not suitable for field summary'); 

serviceSchema.path('description').validate(function (v) {
	  return (v.length > 0 && v.length <= 255);
}, 'data length not suitable for field description'); 

serviceSchema.path('logo').validate(function (v) {
	  return (v.length > 0 && v.length <= 255);
}, 'data length not suitable for field logo'); 

serviceSchema.path('version').validate(function (v) {
	  return (v.length > 0 && v.length <= 30);
}, 'data length not suitable for field version'); 

serviceSchema.path('baseURL').validate(function (v) {
	  return (v.length > 0 && v.length <= 255);
}, 'data length not suitable for field baseURL'); 

serviceSchema.path('swaggerURL').validate(function (v) {
	  return (v.length > 0 && v.length <= 255);
}, 'data length not suitable for field swaggerURL'); 

serviceSchema.path('status').validate(function (v) {
	  return (v.length > 0 && v.length <= 25);
}, 'data length not suitable for field status'); 

serviceSchema.path('fileName').validate(function (v) {
	  return v.length <= 255;
}, 'data to long for field fileName'); 

/*serviceSchema.path('boundFromPort').validate(function (v) {
	  return v.length <= 20;
}, 'data to long for field boundFromPort'); */

/*serviceSchema.path('boundToPort').validate(function (v) {
	 return v.length <= 20;
}, 'data to long for field boundToPort');*/  

/*serviceSchema.path('order').validate(function (v) {
	 return v.length <= 100;
}, 'data to long for field order');  */

serviceSchema.path('seedDataLocation').validate(function (v) {
	 return v.length <= 255;
}, 'data to long for field seedDataLocation');  

serviceSchema.path('testScriptLocation').validate(function (v) {
	 return v.length <= 255;
}, 'data to long for field testScriptLocation');  

serviceSchema.path('createdBy').validate(function (v) {
	  return (v.length > 0 && v.length <= 100);
}, 'data length not suitable for field createdBy'); 

serviceSchema.path('updatedBy').validate(function (v) {
	  return (v.length > 0 && v.length <= 100);
}, 'data length not suitable for field updatedBy'); 

serviceSchema.plugin(autoIncrement.plugin, { model: 'Services', field: 'id', startAt: 1 });

/*
 * Setters
 */
serviceSchema.methods.setId = function(id) {	
	this.id = id;
};

serviceSchema.methods.setName = function(name) {
	this.name = name;
};

serviceSchema.methods.setDisplayName = function(displayName) {
	this.displayName = displayName;
};

serviceSchema.methods.setSummary = function(summary) {
	this.summary = summary;
};

serviceSchema.methods.setDescription = function(description) {
	this.description = description;
};

serviceSchema.methods.setLogo = function(logo) {
	this.logo = logo;
};

serviceSchema.methods.setVersion = function(version) {
	this.version = version;
};

serviceSchema.methods.setBaseURL = function(baseURL) {
	this.baseURL = baseURL;
};

serviceSchema.methods.setSwaggerURL = function(swaggerURL) {
	this.swaggerURL = swaggerURL;
};

serviceSchema.methods.setStatus = function(status) {
	this.status = status;
};

serviceSchema.methods.setExperienceId = function(experienceId) {
	this.experienceId = experienceId;
};

serviceSchema.methods.setFileName = function(fileName) {
	this.fileName = fileName;
};

serviceSchema.methods.setBoundFromPort = function(boundFromPort) {
	this.boundFromPort = boundFromPort;
};

serviceSchema.methods.setBoundToPort = function(boundToPort) {
	this.boundToPort = boundToPort;
};

serviceSchema.methods.setOrder = function(order) {
	this.order = order;
};

serviceSchema.methods.setSeedDataLocation = function(seedDataLocation) {
	this.seedDataLocation = seedDataLocation;
};

serviceSchema.methods.setTestScriptLocation = function(testScriptLocation) {
	this.testScriptLocation = testScriptLocation;
};


serviceSchema.methods.setCreatedBy = function(createdBy) {
	this.createdBy = createdBy;
};

serviceSchema.methods.setCreatedOn = function(createdOn) {
	this.createdOn = createdOn;
};

serviceSchema.methods.setUpdatedBy = function(updatedBy) {
	this.updatedBy = updatedBy;
};

serviceSchema.methods.setUpdatedOn = function(updatedOn) {
	this.updatedOn = updatedOn;
};

serviceSchema.methods.setServiceDeployOption = function(serviceDeployOption) {
	this.serviceDeployOption = serviceDeployOption;
};

serviceSchema.methods.setExecScriptLocation = function(execScriptLocation) {
	this.execScriptLocation = execScriptLocation;
};

/*
 * Getters
 */
serviceSchema.methods.getId = function() {	
	return this.id;
};

serviceSchema.methods.getName = function() {
	return this.name;
};

serviceSchema.methods.getSummary = function() {
	return this.summary;
};

serviceSchema.methods.getDescription = function() {
	return this.description;
};

serviceSchema.methods.getLogo = function() {
	return this.logo;
};

serviceSchema.methods.getVersion = function() {
	return this.version;
};

serviceSchema.methods.getBaseURL = function() {
	return this.baseURL;
};

serviceSchema.methods.getSwaggerURL = function() {
	return this.swaggerURL;
};

serviceSchema.methods.getStatus = function() {
	return this.status;
};

serviceSchema.methods.getExperienceId = function() {
	return this.experienceId;
};

serviceSchema.methods.getFileName = function() {
	return this.fileName;
};

serviceSchema.methods.getBoundFromPort = function() {
	return this.boundFromPort;
};

serviceSchema.methods.getBoundToPort = function() {
	return this.boundToPort;
};

serviceSchema.methods.getOrder = function() {
	return this.order;
};

serviceSchema.methods.getSeedDataLocation = function() {
	return this.seedDataLocation;
};

serviceSchema.methods.getTestScriptLocation = function() {
	return this.testScriptLocation;
};

serviceSchema.methods.getCreatedBy = function() {
	return this.createdBy;
};

serviceSchema.methods.getCreatedOn = function() {
	return this.createdOn;
};

serviceSchema.methods.getUpdatedBy = function() {
	return this.updatedBy;
};

serviceSchema.methods.getUpdatedOn = function() {
	return this.updatedOn;
};


/*
 * Create collection/model in mongo db using Schema
 */
var Service = mongoose.model('Services', serviceSchema);
logger.info('Service : model : created model : Services : ' + Service);


module.exports = Service;
