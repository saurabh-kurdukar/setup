var express = require('express');
var serviceController = require('./controller/ServiceController');
var logger = require('../common/logger').log;
var ErrorResponse = require('../common/ErrorResponse').ErrorResponse;
var router = express.Router();


/*
 * Add new Service
 */
router.post('/', function(req, res) {
	logger.info('Service : router : received request : addNewService : body : '+JSON.stringify(req.body));
	if (req.body.experienceId != null) {
		serviceController.addNewService(req, res, function(err, data) {
			if (err) {
				logger.error('Service : router : failed addNewService : error : '+err);   
				var error = new ErrorResponse();
				if (err.name == 'ValidationError') {
					error.setErrorMessage(err.errors[Object.keys(err.errors)[0]].message);
					error.setErrorCode("S0001");
					error.setHttpResponseCode(400);
					res.status(400).end(JSON.stringify(error));
				} else {
					error.setErrorMessage(err.message);
					error.setErrorCode("S0001");
					error.setHttpResponseCode(500);
					res.status(500).end(JSON.stringify(error));
				}
			} else {
				logger.info("Service : router : addNewService successful !");
				res.status(200).end(JSON.stringify(data));
			}
		});
	} else {
		var error = new ErrorResponse();
		error.setErrorCode("S0001");
		error.setHttpResponseCode(400);
		error.setErrorMessage('Experience Id not set');
		logger.error('Service : router : failed addNewService : error : '+JSON.stringify(error));
		res.status(400).end(JSON.stringify(error));
	}
});

/*
 * Get Service by Service id
 */
router.get('/:id', function(req, res) {
	logger.info('Service : router : received request : getServiceById : Service Id : '+req.params.id);

	serviceController.getServiceById(req, res, function(err, data) {
		if (err) {
			logger.error('Service : router : failed getServiceById : error : '+err);
			var error = new ErrorResponse();
			error.setErrorCode("S0002");
			error.setErrorMessage(err.message);
			error.setHttpResponseCode(500);
			res.status(500).end(JSON.stringify(error));
		} else {
			logger.info("Service : router : getServiceById successful !");
			res.status(200).end(JSON.stringify(data));
		}
	});
 
});

/*
 * Get All Services
 */

/*
router.get('/', function(req, res) {
	logger.info('Service : router : received request : getAllServices : Service Id');

	serviceController.getAllServices(req, res, function(err, data) {
		if (err) {
			logger.error('Service : router : failed getAllServices : error : '+err);
			var error = new ErrorResponse();
			error.setErrorCode("S0003");
			error.setErrorMessage(err.message);
			error.setHttpResponseCode(500);
			res.status(500).end(JSON.stringify(error));
		} else {
			logger.info("Service : router : getAllServices successful !");
			res.status(200).end(JSON.stringify(data));
		}
	});
});

*/

/*
 * Edit/Update Service
 */
router.put('/:id', function(req, res) {
	logger.info('Service : router : received request : updateServiceById : Id :'+req.params.id);
	
	serviceController.updateServiceById(req, res, function(err, data) {
		if (err) {
			logger.error('Service : router : failed updateServiceById : error : '+err);
			var error = new ErrorResponse();
			error.setErrorCode("S0003");
			error.setErrorMessage(err.message);
			error.setHttpResponseCode(500);
			res.status(500).end(JSON.stringify(error));
		} else {
			logger.info("Service : router : updateServiceById successful !");
			res.status(200).end(JSON.stringify(data));
		}
	});
	
});

/*
 * Delete a Service 
 */

router.delete('/:id', function(req, res){
	logger.info('Service : router : received request : deleteServiceById : id : '+req.params.id);
	serviceController.deleteServiceById(req, res, function(err, data) {
        if(err){
        	logger.error('Service : router : failed deleteServiceById : error : '+err); 
        	var error = new ErrorResponse();
        	error.setErrorCode("S0004");
        	error.setErrorMessage(err.message);
        	error.setHttpResponseCode(500);
            res.status(500).end(JSON.stringify(error));
        }else{        	
        	logger.info("Service : router : deleteServiceById successful !");
        	res.status(200).end(JSON.stringify(data));
        }
    });
});


/*
 * Get documents by Service id
 */
router.get('/:id/documents', function(req, res) {
	logger.info('Service : router : received request : getDocumentsByServiceId : Service Id : '+req.params.id);
	serviceController.getDocumentsByServiceId(req, function(err, data) {
		if (err) {
			logger.error('Service : router : failed getDocumentsByServiceId : error : '+err);
			var error = new ErrorResponse();
			error.setErrorCode("S0005");
			error.setErrorMessage(err.message);
			error.setHttpResponseCode(err.status);
			return res.status(err.status).end(JSON.stringify(error));
		}
		logger.info("Service : router : getDocumentsByServiceId successful !");
		res.status(200).end(JSON.stringify(data));		
	});
 
});


/*
 * Get attributes by Service id
 */
router.get('/:id(\\d+)/attributes', function(req, res) {
	logger.info('Service : router : received request : getAllAttributes : Service Id : '+req.params.id);
	serviceController.getAllAttributes(req, function(err, data) {
		if (err) {
			logger.error('Service : router : failed getAllAttributes : error : '+err);
			var error = new ErrorResponse();
			error.setErrorCode("S0006");
			error.setErrorMessage(err.message);
			error.setHttpResponseCode(500);
			return res.status(500).end(JSON.stringify(error));
		}
		logger.info("Service : router : getAllAttributes successful !");
		res.status(200).end(JSON.stringify(data));		
	});
 
});


module.exports = router;




