/*
 * logging format followed: logger.info(<module_name>: <component name> : <description> : [<long_description>] : <data/params/errors>);
 */
var async = require('async');
var attributesDao = require('../dao/AttributesDAO');
var experienceDao = require('../../experience/dao/ExperienceDAO');
var appDao = require('../../application/dao/AppDAO');
var serviceDao = require('../../service/dao/ServiceDAO');
var logger = require('../../common/logger').log;

/*
 *Add new Attributes
 */
var addNewAttributes = function(req, callback) {
	logger.info('attributes : controller : received request : addNewAttributes : body : '+JSON.stringify(req.body));	
	var appId = req.body.appId;
	var serviceId = req.body.serviceId;
	var experienceId = req.body.experienceId;
	if(experienceId) {
		async.parallel([
			  function(cb) {					  
				  experienceDao.existExperienceId(experienceId, cb);	    	  
			  },
		      function(cb) {	
				  if(appId)
					  appDao.existAppId(appId, cb);
				  else
					  cb();
		      },
		      function(cb) {
		    	  if(serviceId)
		    		  serviceDao.existServiceId(serviceId, cb);	
		    	  else
					  cb();
		      },
		      function(cb) {			    	  
		    	  if(appId || serviceId) {
		    		  req.params.appId = appId;
		    		  req.params.serviceId = serviceId;
			    	  attributesDao.getAllAttributes(req, function(err, data) {
			    		  if(data) {
			    			  cb(new Error('attributes already exist for app/service id.'));
			    		  } else {
			    			  if(err.status == 500)
			    				  cb(err);
			    			  else 
			    				  cb();
			    		  }		    		  
			    	  });
		    	  } else {
		    		  req.params.experienceId = experienceId;
		    		  attributesDao.getAllExperienceAttributes(experienceId, function(err, data) {
			    		  if(data) {
			    			  cb(new Error('attributes already exist for experience id.'));
			    		  } else {
			    			  if(err.status == 500)
			    				  cb(err);
			    			  else 
			    				  cb();
			    		  }
			    	  });
		    	  }
		      }
		],
		function(err, data) {
			if(err) {
				err.status = 500;
				return callback(err);
			}
			attributesDao.addNewAttributes(req, callback);
		});		
	} else {
		var err = new Error('experience id is mandatory.');
		err.status = 400;
		callback(err);
	}
};

/*
 *Add new Attributes
 */
var updateAttributesById = function(req, callback) {
	logger.info('attributes : controller : received request : updateAttributesById : (id:'+req.params.id+', body : '+JSON.stringify(req.body)+')');	
	attributesDao.getAttributesById(req.params.id, function(err, data) {
		if(err) {
			err.status = 500;
			return callback(err);
		}
		var attributes = data.attributes;		
		var updatedData = [];	
		var updateDoc = false;
		if(req.body.attributes && req.body.attributes.length) {
			for(i = 0; i < req.body.attributes.length; i++) {
				for(j = 0; j < attributes.length; j++) {
					if((req.body.attributes[i].attributeKey == attributes[j].attributeKey) 
							&& (req.body.attributes[i].attributeValue != attributes[j].attributeValue)) {
						updateDoc = true;
						attributes[j].attributeValue = req.body.attributes[i].attributeValue;
					}
				}
			}
		}		
		if (updateDoc) {
			data.updatedOn = new Date();
			data.updatedBy = req.header('username');			
			data.markModified();
			data.save(callback);      
		} else {
			var err = new Error('no fields modified');
			logger.error('attributes : DAO : failed updateAttributesById : error : ' + err);
			callback(err, null);
		}
	});
};


module.exports.addNewAttributes = addNewAttributes;
module.exports.updateAttributesById = updateAttributesById;


