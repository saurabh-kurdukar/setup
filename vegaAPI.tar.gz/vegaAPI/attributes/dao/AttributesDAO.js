var db = require('../../common/MongoDbConnection');
var Attributes = require('../models/Attributes');
var logger = require('../../common/logger').log;
var audit = require('../../common/Audit').audit;
var mongoose = db.mongoose;
/*
 * logging format followed: logger.info(<module_name>: <component name> : <description> : [<long_description>] : <data/params/errors>);
 */

/*
 *Add new SMS Gateway Info
 */
var addNewAttributes = function(req, callback) {
	logger.info('attributes : DAO : received request : addNewAttributes : body : '+ JSON.stringify(req.body));

	var attributes = new Attributes(req.body);
	attributes.createdOn = new Date();
	attributes.createdBy = req.headers['username'];
	attributes.updatedOn = new Date();
	attributes.updatedBy = req.headers['username'];
	
	attributes.save(function(err, data) {
		if (err) {
			logger.error('attributes : DAO : failed addNewAttributes : error : ' + err);
			callback(err);
		} else {
			logger.info('attributes : DAO : addNewAttributes successful !');
			callback(err, data);
		}
	});
};
	
var getAttributesById = function(attributeId, callback) {
	logger.info('attributes : DAO : received request : getAttributesById : (attributeId: '+attributeId+')');
	Attributes.findOne({id: attributeId}, function(err, data) {
		if (err) {
			logger.error('attributes : DAO : failed getAttributesById : error : ' + err);
			callback(err);
		} else {
			if (data) {
				logger.info('attributes : DAO : getAttributesById successful !');
				callback(null, data);
			} else {
				var err = new Error('attribute id not exist.');
				err.status = 400;
				logger.error('attributes : DAO : failed getAttributesById : error : ' + err);
				callback(err);
			}
		}
	});
};

var getAllAttributes = function(req, callback) {
	logger.info('attributes : DAO : received request : getAllAttributes : id : '+ JSON.stringify(req.params.id));
	var query = {};
	if(req.params.experienceId) {
		query.experienceId = req.params.experienceId;
	}
	if(req.params.appId) {
		query.appId = req.params.appId;
	}
	if(req.params.serviceId) {
		query.serviceId = req.params.serviceId;
	}
	logger.info('attributes : DAO : received request : getAllAttributes : db query : '+ JSON.stringify(query));
	Attributes.find(query, function(err, data) {
		if (err) {
			logger.error('attributes : DAO : failed getAllAttributes : error : ' + err);
			err.status = 500;
			callback(err);
		} else {
			if (data.length != 0) {
				logger.info('attributes : DAO : getAllAttributes successful !');
				callback(null, data);
			} else {
				var err = new Error('no attributes exist.');
				err.status = 404;
				logger.error('attributes : DAO : failed getAllAttributes : error : ' + err);
				callback(err);
			}
		}
	});
};

var getAllExperienceAttributes = function(experienceId, callback) {
	logger.info('attributes : DAO : received request : getAllExperienceAttributes : experienceId : '+ experienceId);
	var query = {
		experienceId: experienceId,
		appId: { $exists: false },
		serviceId: { $exists: false }
	};	
	Attributes.findOne(query, function(err, data) {
		if (err) {
			logger.error('attributes : DAO : failed getAllExperienceAttributes : error : ' + err);
			err.status = 500;
			callback(err);
		} else {
			if (data) {
				logger.info('attributes : DAO : getAllExperienceAttributes successful !');
				callback(null, data);
			} else {
				var err = new Error('no attributes exist.');
				err.status = 404;
				logger.error('attributes : DAO : failed getAllExperienceAttributes : error : ' + err);
				callback(err);
			}
		}
	});
};
		
module.exports.addNewAttributes = addNewAttributes;
module.exports.getAttributesById = getAttributesById;
module.exports.getAllAttributes = getAllAttributes;
module.exports.getAllExperienceAttributes = getAllExperienceAttributes;




