var mongoose = require('../../common/MongoDbConnection').mongoose;
var autoIncrement = require('mongoose-auto-increment');
var logger = require('../../common/logger').log;
var connection = mongoose.connection;
autoIncrement.initialize(connection);

/*
 * logging format followed: logger.info(<module_name>: <component name> :
 * <description> : <long_description> : <data/params/errors>);
 */


/*
 * Define schema
 */
var attributesSchema = mongoose.Schema({
	id: Number,
	experienceId: {type: Number, required: true},
	appId: Number,
	serviceId: Number,
	attributes: [{
		 attributeKey: String,		 
		 attributeValue: String
	}],
	createdOn: { type: Date },
	createdBy: { type: String },
	updatedOn: { type: Date },
	updatedBy: { type: String }
});

/*
 * Add auto increment plugin for id
 */
attributesSchema.plugin(autoIncrement.plugin, { model: 'attributes', field: 'id', startAt: 1 });



/*
 * Create collection/model in mongo db using Schema
 */
var Attributes = mongoose.model('attributes', attributesSchema);

module.exports = Attributes;