var express = require('express');
var logger = require('../common/logger').log;
var traceController = require('./controller/TraceController');
var ErrorResponse = require('../common/ErrorResponse').ErrorResponse;
var router = express.Router();


/*
 * Add new trace details
 */
router.post('/', function(req, res) {
  logger.info('Trace : router : received request : addNewTrace : body : ' + JSON.stringify(req.body));
  traceController.addNewTrace(req, res, function(err, data) {
    if (err) {
      logger.error('Trace : router : failed addNewTrace : error : ' + err);
      var error = new ErrorResponse();
      if (err.name == 'ValidationError') {
        error.setErrorMessage(err.errors[Object.keys(err.errors)[0]].message);
      } else {
        error.setErrorMessage(err.message);
      }
      error.setErrorCode("T0001");
      error.setHttpResponseCode(500);
      res.status(500).end(JSON.stringify(error));

    } else {
      logger.info("Trace : router : addNewTrace successful !");
      res.status(200).end(JSON.stringify(data));
    }
  });
});

/*
 * Get Trace details
 */
router.get('/', function(req, res) {
  logger.info('Trace : router : received request : getTraceDetails : expID: '+ req.query.expID);
  traceController.getTraceDetails(req, res, function(err, data) {
    if (err) {
      logger.error('Trace : router : failed getTraceDetails : error : ' + err);
      var error = new ErrorResponse();
      error.setErrorCode("T0002");
      error.setErrorMessage(err.message);
      error.setHttpResponseCode(500);
      res.status(500).end(JSON.stringify(error));
    } else {
      logger.info("Trace : router : getTraceDetails successful !");
      res.status(200).end(JSON.stringify(data));
    }
  });
});


module.exports = router;
