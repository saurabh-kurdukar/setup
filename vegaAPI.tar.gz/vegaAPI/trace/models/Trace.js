var mongoose = require('../../common/MongoDbConnection').mongoose;
var autoIncrement = require('mongoose-auto-increment');
var logger = require('../../common/logger').log;
var connection = mongoose.connection;
autoIncrement.initialize(connection);

/*
 * Define schema
 */
var traceSchema = mongoose.Schema({
  id: Number,  
  expID: Number,  
  api: String,
  targetApi: String,
  requestHeader: String,
  requestBody: Object,
  requestType: String,
  userID: String,
  responseCode: Number,
  responseHeader: String,
  responseBody: Object,
  timestamp: {type: Date}
}, {
  versionKey: false
});

logger.info('Trace : model : created schema : Trace :' + JSON.stringify(traceSchema.paths));

traceSchema.methods.toJSON = function() {
  var obj = this.toObject();
  delete obj._id;  
  return obj;
}

/*
 * Add Auto increment plugin for field id
 */
traceSchema.plugin(autoIncrement.plugin, {
  model: 'traces',
  field: 'id',
  startAt: 1
});

/*
 * Setters
 */
traceSchema.methods.setId = function(id) {
  this.id = id;
}

traceSchema.methods.setexpID = function(expID) {
  this.expID = expID;
}

traceSchema.methods.setApi = function(api) {
  this.api = api;
}

traceSchema.methods.setRequestHeader = function(requestHeader) {
  this.requestHeader = requestHeader;
}

traceSchema.methods.setRequestBody = function(requestBody) {
  this.requestBody = requestBody;
}

traceSchema.methods.setRequestType = function(requestType) {
  this.requestType = requestType;
}

traceSchema.methods.setUserID = function(userID) {
  this.userID = userID;
}

traceSchema.methods.setResponseCode = function(responseCode) {
  this.responseCode = responseCode;
}

traceSchema.methods.setResponseHeader = function(responseHeader) {
  this.responseHeader = responseHeader;
}

traceSchema.methods.setResponseBody = function(responseBody) {
  this.responseBody = responseBody;
}

traceSchema.methods.setTimestamp = function(timestamp) {
  this.timestamp = timestamp;
}

traceSchema.methods.setTargetApi = function(targetApi) {
  this.targetApi = targetApi;
}

/*
 * Getters
 */
traceSchema.methods.getId = function() {
  return this.id;
}

traceSchema.methods.getExpID = function() {
  return this.expID;
}

traceSchema.methods.getApi = function() {
  return this.api;
}

traceSchema.methods.getRequestHeader = function() {
  return this.requestHeader;
}

traceSchema.methods.getRequestBody = function() {
  return this.requestBody;
}

traceSchema.methods.getRequestType = function() {
  return this.requestType;
}

traceSchema.methods.getUserID = function() {
  return this.userID;
}

traceSchema.methods.getResponseCode = function() {
  return this.responseCode;
}

traceSchema.methods.getResponseHeader = function() {
  return this.responseHeader;
}

traceSchema.methods.getResponseBody = function() {
  return this.responseBody;
}

traceSchema.methods.getTimestamp = function() {
  return this.timestamp;
}

traceSchema.methods.getTargetApi = function() {
  return this.targetApi;
}


/*
 * Create collection/model in mongo db using Schema
 */
var Trace = mongoose.model('traces', traceSchema);

module.exports = Trace;
