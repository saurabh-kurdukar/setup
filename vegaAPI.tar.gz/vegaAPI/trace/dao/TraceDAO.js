var db = require('../../common/MongoDbConnection');
var Trace = require('../models/Trace');
var logger = require('../../common/logger').log;
var config = require('../../common/Config');
var async = require('async');

/*
 * Add new trace details
 */
var addNewTrace = function(req, res, callback) {
  logger.info('Trace: DAO : received request : addNewTrace  ');

  var reqBody = req.body;
  var trace = new Trace();

  trace.setexpID(reqBody.expID);
  trace.setApi(reqBody.api);
  trace.setTargetApi(reqBody.targetApi)
  trace.setRequestHeader(reqBody.requestHeader);
  trace.setRequestBody(reqBody.requestBody);
  trace.setRequestType(reqBody.requestType);
  trace.setUserID(reqBody.userID);
  trace.setResponseCode(reqBody.responseCode);
  trace.setResponseHeader(reqBody.responseHeader);
  trace.setResponseBody(reqBody.responseBody);
  trace.setTimestamp(reqBody.timestamp);
  trace.setTimestamp(new Date());

  trace.save(function(err, data) {
    if (err) {
      logger.error('Trace : DAO : failed addNewTrace : error : ' + err);
      callback(err, null);
    } else if (data != null) {
      logger.info('Trace : DAO : addNewTrace successful !');	  
      callback(null, data);
    } else {
      var err = new Error('Failed to add new trace details');
      logger.error('Trace : DAO : failed addNewTrace : error : ' + err);
      callback(err, null);
    }
  });
};

/*
 * Get Trace details
 */
var getTraceDetails = function(req, res, callback) {
  logger.info('Trace : DAO : received request : getTraceDetails : expID : ' + req.query.expID);

  var top = config.TRACE_API_TOP_VAL;
  Trace.find({'expID':req.query.expID}).sort('-timestamp').limit(top).exec(function(err, data) {
    if (err) {
      logger.error('Trace : DAO : failed getTraceDetails : error : ' + err);
      callback(err, null);
    } else {
      if (data.length != 0) {
        logger.info('Trace : DAO : getTraceDetails successful !');		
        callback(null, data);
      } else {
        var err = new Error('no records found');
        err.status = 404;
        logger.error('Trace : DAO : failed getTraceDetails : error : ' + err);
        callback(err, null);
      }
    }

  })
};

module.exports.addNewTrace = addNewTrace;
module.exports.getTraceDetails = getTraceDetails;
