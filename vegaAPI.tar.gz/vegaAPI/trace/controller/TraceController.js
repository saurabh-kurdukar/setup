var traceDao = require('../dao/TraceDAO');
var logger = require('../../common/logger').log;

/*
 * Add new trace details
 */
var addNewTrace = function(req, res, callback) {
  logger.info('Trace : controller : received request : addNewTrace : body : ' + JSON.stringify(req.body));
  traceDao.addNewTrace(req, res, callback);
};

/*
 * Get Trace details
 */
var getTraceDetails = function(req, res, callback) {
  logger.info('Trace : controller : received request : getTraceDetails : expID : ' + req.query.expID);
  traceDao.getTraceDetails(req, res, callback);
};

module.exports.addNewTrace = addNewTrace;
module.exports.getTraceDetails = getTraceDetails;
