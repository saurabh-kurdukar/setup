var db = require('../../common/MongoDbConnection');
var ResAccGrp = require('../models/ResAccGrp');
var logger = require('../../common/logger').log;
var audit = require('../../common/Audit').audit;
var request = require('request');
const MODULE_NAME = 'ResAccGrp';

/*
 * Add new resAccGrp
 */
var addNewresAccGrp = function(req, res, callback) {
	logger.info(MODULE_NAME + ' : DAO : received request : addNewresAccGrp : body : '+JSON.stringify(req.body));
	var reqBody = req.body;
	var resAccGrp = new ResAccGrp();
	resAccGrp.setEndPoint(reqBody.endPoint);
	resAccGrp.setAllowedMethods(reqBody.allowedMethods);
	resAccGrp.setAccessGrp(reqBody.accessGrp);
	resAccGrp.setCreatedBy(req.header('username'));	
	resAccGrp.setUpdatedBy(req.header('username'));

	resAccGrp.save(function(err, data) {
		if (err) {
			logger.error(MODULE_NAME + ' : DAO : failed addNewresAccGrp : error : ' + err);
			callback(err, null);
		} else {
			logger.info(MODULE_NAME + ' : DAO : addNewresAccGrp successful !');
			callback(null, data);
		}
	});
};

/*
 * Get all resAccGrps created under given resAccGrp Type
 */
var getresAccGrpsAll = function(req, res, callback) {
	logger.info(MODULE_NAME + ' : DAO : received request : getresAccGrpsAll : (resAccGrpType:'+req+')');
	ResAccGrp.find({
		'status' : 'ACTIVE'
	}, function(err, data) {
		if (err) {
			logger.error(MODULE_NAME + ' : DAO : failed getresAccGrps : error : ' + err);
			callback(err, null);
		} else {
			if (data.length != 0) {
				logger.info(MODULE_NAME + ' : DAO : getresAccGrps successful !');
				callback(null, data);
			} else {
				var err = new Error('No resAccGrps exist');
				err.status = 404;
				logger.error(MODULE_NAME + ' : DAO : failed getresAccGrps : error : ' + err);
				callback(err, null);
			}
		}
	});
};

/*
 * Edit/Update app
 */
var updateResAccGrpById = function(req, res, callback) {
	logger.info(MODULE_NAME + ' : DAO : received request : updateResAccGrpById : (appId:'+req.params.id+', body:'+JSON.stringify(req.body)+')');

	/*
	 * Callback function after getting original record to update with new values.
	 */
	var callbackUpdate = function(err, data) {
		if(err) {
			logger.error(MODULE_NAME + ' : DAO : failed updateResAccGrpById : error : ' + err);
			callback(err, null);
		} else if (data != null) {

			var app = data;
			var updatableFields = ["accessGrp", "endPoint", "allowedMethods","status"];
			var updatedData = [];
			var json = {};			
			var reqBodyKeys = Object.keys(req.body);
			for(var i = 0; i < reqBodyKeys.length; i++) {				
				if(updatableFields.indexOf(reqBodyKeys[i]) > -1 && app[reqBodyKeys[i]] != req.body[reqBodyKeys[i]]) {					
					json[reqBodyKeys[i]] = req.body[reqBodyKeys[i]];
					var obj = {};
					obj.column = reqBodyKeys[i];
					obj.oldValue = app[reqBodyKeys[i]];
					obj.newValue = req.body[reqBodyKeys[i]];
					obj.identifier = 'Platform_app_'+req.params.id;
					obj.modifiedBy = 'admin';
					obj.modifiedOn = new Date();
					updatedData.push(obj);
				}
			}
			if(req.body.allowedMethods && req.body.allowedMethods.length) {			
				json.allowedMethods = req.body.allowedMethods;							
			}
			
			var updateDoc = false;
			if(Object.keys(json).length != 0) {
				updateDoc = true;
			}
			
			if (updateDoc) {
				json.updatedOn = new Date();
				json.updatedBy = req.header('username');
				logger.info(MODULE_NAME + ' : DAO : updateResAccGrpById : updating data : ' + JSON.stringify(json));
				ResAccGrp.findOneAndUpdate({
					'id' : req.params.id
				}, json, {
					'new' : true				
				}, function(err, data) {
					if (err) {
						logger.error(MODULE_NAME + ' : DAO : failed updateResAccGrpById : error : ' + err);
						callback(err, null);
					} else {
						if (data != null) {
							logger.info(MODULE_NAME + ' : DAO : updateResAccGrpById successful !');
							/* Call audit function for changed data */
							audit(req, res, updatedData);
							/* Call function to send response to client */
							callback(null, data);
						} else {
							var err = new Error('No record exist for app id');
							logger.error(MODULE_NAME + ' : DAO : failed updateResAccGrpById : error : ' + err);
							callback(err, null);
						}
					}
				});
			} else {
				var err = new Error('No fields modified');
				logger.error(MODULE_NAME + ' : DAO : failed updateResAccGrpById : error : ' + err);
				callback(err, null)
			}
		} else {
			var err = new Error('No record exist for app id');
			logger.error(MODULE_NAME + ' : DAO : failed updateResAccGrpById : error : ' + err);
			callback(err, null);
		}
	}

	/*
	 * Get the original record from db before update.
	 */
	getResAccGrpById(req, res, callbackUpdate);
};

/*
 * Get app by app id
 */
var getResAccGrpById = function(req, res, callback) {
	logger.info(MODULE_NAME + ' : DAO : received request : getResAccGrpById : (appId:'+req.params.id+')');
	ResAccGrp.findOne({
		'id' : req.params.id,
	}, function(err, data) {
		if (err) {
			logger.error(MODULE_NAME + ' : DAO : failed getResAccGrpById : error : ' + err);
			callback(err, null);
		} else {
			if (data != null) {
				logger.info(MODULE_NAME + ' : DAO : getResAccGrpById successful !');
				callback(null, data);
			} else {
				var err = new Error('No record exist for app id');
				err.status = 404;
				logger.error(MODULE_NAME + ' : DAO : failed getResAccGrpById : error : ' + err);
				callback(err, null);
			}
		}
	});
};


/*
 * Delete resAccGrpsById 
 */
var deleteresAccGrpsById = function(req, res, callback) {
	logger.info(MODULE_NAME + ' : DAO : received request : deleteresAccGrpsById : id : ' + req.params.id);
	var callbackDelete = function(err, data) {
		if(err) {
			logger.error(MODULE_NAME + ' : DAO : failed deleteresAccGrpsById : error :' + err);
			callback(err, null);
		} else if(data != null) {
			var resAccGrp = data;
			var updatedData = [];
			if(resAccGrp.status != 'DELETED') {
					var json = {
						'status' : 'DELETED'
					};
					ResAccGrp.findOneAndUpdate({
						'id' : req.params.id
					}, json, {
						'new' : true
					}, function(err, data) {
						if (err) {
							logger.error(MODULE_NAME + ' : DAO : failed deleteresAccGrpsById : error :' + err);
							callback(err, null);
						} else if(data != null){
							logger.info(MODULE_NAME + ' : DAO : deleteresAccGrpsById successful !');
							var obj = {};
							obj.column = 'status';
							obj.oldValue = resAccGrp['status'];
							obj.newValue = data.status;
							obj.identifier = 'Platform_resAccGrp_'+req.params.id;
							obj.modifiedBy = 'admin';
							obj.modifiedOn = new Date();
							updatedData.push(obj);
							/*
							 *	Call audit function for changed data
							 */
							audit(req, res, updatedData);
							/*
							 *	Call function to send response to client
							 */
							callback(null, data);
						} else {
							var err = new Error('Invalid compnay id');
							logger.error(MODULE_NAME + ' : DAO : failed deleteresAccGrpsById : error :' + err);
							callback(err, null);
						}
					});
			} else {
				var err = new Error('Already deleted');
				logger.error(MODULE_NAME + ' : DAO : failed deleteresAccGrpsById : error :' + err);
				callback(err, null);
			}
		} else {
			var err = new Error('Failed to get resAccGrp details');
			logger.error(MODULE_NAME + ' : DAO : failed deleteresAccGrpsById : error :' + err);
			callback(err, null)
		}
	}

	/*
	 * Get the original record from db before update.
	 */
	getResAccGrpById(req, res, callbackDelete);

};

module.exports.addNewresAccGrp = addNewresAccGrp;
module.exports.getresAccGrpsAll = getresAccGrpsAll;
module.exports.updateResAccGrpById = updateResAccGrpById;
module.exports.getResAccGrpById = getResAccGrpById;
module.exports.deleteresAccGrpsById = deleteresAccGrpsById;
