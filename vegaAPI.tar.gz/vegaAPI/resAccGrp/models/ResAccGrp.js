var mongoose = require('../../common/MongoDbConnection').mongoose;
var autoIncrement = require('mongoose-auto-increment');
var logger = require('../../common/logger').log;
var connection = mongoose.connection;
autoIncrement.initialize(connection);
const MODULE_NAME = 'ResAccGrp';

/*
 * Define schema
 */
var resAccGrpSchema = mongoose.Schema({
	id : Number,
    endPoint : { type: String },
    allowedMethods : [],
    accessGrp : {type: String},
    status: {type: String, default: 'ACTIVE'},
    createdOn: { type: Date, default: Date.now },
	createdBy: {type: String},
	updatedOn: { type: Date, default: Date.now },
	updatedBy: {type: String}
});


logger.info(MODULE_NAME + ' : model : created schema : resAccGrps :'+JSON.stringify(resAccGrpSchema.paths));

resAccGrpSchema.pre('findOneAndUpdate', function(next) {
	  this.options.runValidators = true;
	  next();
});

resAccGrpSchema.pre('update', function(next) {
	  this.options.runValidators = true;
	  next();
});

/*
 *  Add autoincrement for resAccGrp Id
 */
resAccGrpSchema.plugin(autoIncrement.plugin, { model: 'resAccGrps', field: 'id', startAt: 1 });

/*
 * Setters
 */
resAccGrpSchema.methods.setId = function(id) {	
	this.id = id;
};

resAccGrpSchema.methods.setEndPoint = function(endPoint) {
	this.endPoint = endPoint;
};

resAccGrpSchema.methods.setAllowedMethods = function(allowedMethods) {
	this.allowedMethods = allowedMethods;
};

resAccGrpSchema.methods.addAllowedMethods = function(allowedMethod) {
	this.allowedMethods.push(allowedMethod);
};

resAccGrpSchema.methods.setAccessGrp = function(accessGrp) {
	this.accessGrp = accessGrp;
};

resAccGrpSchema.methods.setStatus = function(status) {
	this.status = status;
};

resAccGrpSchema.methods.setCreatedOn = function(createdOn) {
	this.createdOn = createdOn;
};

resAccGrpSchema.methods.setCreatedBy = function(createdBy) {
	this.createdBy = createdBy;
};

resAccGrpSchema.methods.setUpdatedOn = function(updatedOn) {
	this.updatedOn = updatedOn;
};

resAccGrpSchema.methods.setUpdatedBy = function(updatedBy) {
	this.updatedBy = updatedBy;
};

resAccGrpSchema.methods.getStatus = function() {
	return this.status;
};


/*
 * Create collection/model in mongo db using Schema
 */
var resAccGrp = mongoose.model('resAccGrps', resAccGrpSchema);
logger.info(MODULE_NAME + ' : model : created model : resAccGrps : ' + resAccGrp);


module.exports = resAccGrp;