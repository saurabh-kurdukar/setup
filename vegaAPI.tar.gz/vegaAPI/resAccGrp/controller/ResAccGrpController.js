var resAccGrpDao = require('../dao/ResAccGrpDAO');
var logger = require('../../common/logger').log;
const MODULE_NAME = 'ResAccGrp';

/*
 * Add new resAccGrp
 */
var addNewresAccGrp = function(req, res, callback) {
	logger.info(MODULE_NAME + ' : controller : received request : addNewresAccGrp : body : '+JSON.stringify(req.body));
	resAccGrpDao.addNewresAccGrp(req, res, callback);
};

/*
 * Get resAccGrps by resAccGrp id
 */
var getresAccGrpsAll = function(req, res,callback) {
	logger.info(MODULE_NAME + ' : controller : received request : getresAccGrpsAll : (type:'+req+')');
	resAccGrpDao.getresAccGrpsAll(req , res, callback);
};

/*
 * Edit/Update app
 */
var updateResAccGrpById = function(req, res, callback) {
	logger.info(MODULE_NAME + ' : controller : received request : updateAppById : (appId:'+req.params.id+', body:'+JSON.stringify(req.body)+')');
	resAccGrpDao.updateResAccGrpById(req, res, callback);
};

/*
* Delete company details
*/
var deleteresAccGrpsById = function(req, res, callback) {
	logger.info(MODULE_NAME + ' : controller : received request : deleteresAccGrpsById : id : '+req.params.id);
	resAccGrpDao.deleteresAccGrpsById(req, res, callback);
};


module.exports.addNewresAccGrp = addNewresAccGrp;
module.exports.getresAccGrpsAll = getresAccGrpsAll;
module.exports.updateResAccGrpById = updateResAccGrpById;
module.exports.deleteresAccGrpsById = deleteresAccGrpsById;
