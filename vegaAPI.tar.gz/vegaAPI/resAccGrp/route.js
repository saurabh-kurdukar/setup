var express = require('express');
var resAccGrpController = require('./controller/ResAccGrpController');
var logger = require('../common/logger').log;
var ErrorResponse = require('../common/ErrorResponse').ErrorResponse;
var router = express.Router();
const MODULE_NAME = 'ResAccGrp';

/*
* Get all resAccGrps by type
*/
router.get('/', function (req, res) {
	logger.info(MODULE_NAME + ' : router : received request : getresAccGrpsByType : type : '
			+ req.query.type);
	resAccGrpController.getresAccGrpsAll(req, res, function(err, data) {
		if(err){
			logger.error(MODULE_NAME + ' : router : failed getresAccGrpsByType : error : '+err);
			var error = new ErrorResponse();
			error.setErrorCode("AP0001");
			error.setErrorMessage(err.message);
			error.setHttpResponseCode(err.status);
			res.status(err.status).end(JSON.stringify(error));
		}else{
			logger.info(MODULE_NAME + " : router : getresAccGrpsByType successful !");
			res.status(200).end(JSON.stringify(data));
		}
	});
});


/*
 * Add new resAccGrp
 */
router.post('/', function(req, res) {
	logger.info(MODULE_NAME + ' : router : received request : addNewresAccGrp : body : '+JSON.stringify(req.body));
	if (req.body.endPoint != null && req.body.allowedMethods != null && req.body.accessGrp != null) {
		resAccGrpController.addNewresAccGrp(req, res, function(err, data) {
			if (err) {
				logger.error(MODULE_NAME + ' : router : failed addNewresAccGrp : error : '+err);   
				var error = new ErrorResponse();
				if (err.name == 'ValidationError') {
					error.setErrorMessage(err.errors[Object.keys(err.errors)[0]].message);
				} else {
					error.setErrorMessage(err.message);
				}
				error.setErrorCode("AP0002");
				error.setHttpResponseCode(500);
				res.status(500).end(JSON.stringify(error));
			} else {
				logger.info(MODULE_NAME + " : router : addNewresAccGrp successful !");
				res.status(200).end(JSON.stringify(data));
			}
		});
	} else {
		var error = new ErrorResponse();
		error.setErrorCode("AP0002");
		error.setErrorMessage('endPoint,allowedMethods and accessGrp are mandatory fields');
		error.setHttpResponseCode(500);
		logger.error(MODULE_NAME + ' : router : failed addNewresAccGrp : error : '+JSON.stringify(error));
		res.status(500).end(JSON.stringify(error));
	}
});

/*
 * Edit/Update app
 */
router.put('/:id', function(req, res) {
	logger.info(MODULE_NAME + ' : router : received request : updateresAccGrpsById : (resourceId:'+req.params.id+', companyId:'+req.header('companyId')+', body:'+JSON.stringify(req.body)+')');
	resAccGrpController.updateResAccGrpById(req, res, function(err, data) {
		if (err) {
			logger.error(MODULE_NAME + ' : router : failed updateresAccGrpsById : error : '+err);
			var error = new ErrorResponse();
			if (err.name == 'ValidationError') {
				error.setErrorMessage(err.errors[Object.keys(err.errors)[0]].message);
			} else {
				error.setErrorMessage(err.message);
			}
			error.setErrorCode("AP0004");			
			error.setHttpResponseCode(500);
			res.status(500).end(JSON.stringify(error));
		} else {
			logger.info(MODULE_NAME + " : router : updateresAccGrpsById successful !");
			res.status(200).end(JSON.stringify(data));
		}
	});	
});

/*
* Delete company details
*/
router.delete('/:id', function(req, res){
	logger.info(MODULE_NAME + ' : router : received request : deleteresAccGrpsById : id : '+req.params.id);
	resAccGrpController.deleteresAccGrpsById(req, res, function(err, data) {
		if(err){
			logger.error(MODULE_NAME + ' : router : failed deleteresAccGrpsById : error : '+err);
			var error = new ErrorResponse();
			error.setErrorCode("C0005");
			error.setErrorMessage(err.message);
			error.setHttpResponseCode(500);
			res.status(500).end(JSON.stringify(error));
		}else{
			logger.info(MODULE_NAME + " : router : deleteresAccGrpsById successful !");
			res.status(200).end(JSON.stringify(data));
		}
	});
});



module.exports = router;