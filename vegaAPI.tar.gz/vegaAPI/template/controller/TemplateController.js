var templateDao = require('../dao/TemplateDAO');
var appgroupDao = require('../../appgroup/dao/AppGroupDAO');
var logger = require('../../common/logger').log;

/*
 * Add new template details
 */
var addNewTemplate = function(req, res, callback) {
	logger.info('template : controller : received request : addNewTemplate : body : '+JSON.stringify(req.body));
	templateDao.addNewTemplate(req, res, callback);
};

/*
 * Get template by template id
 */
var getTemplateById = function(req, res, callback) {
	logger.info('template : controller : received request : addNewCompany : body : '+req.params.id);
	templateDao.getTemplateById(req, res, callback);
};

/*
 * Get filled template by template id
 */
var getFilledTemplateById = function(req, res, callback) {
	logger.info('template : controller : received request : getFilledTemplateById : id : '+req.params.id);
	templateDao.getFilledTemplateById(req, res, callback);
};

/*
 * Get template by template name
 */
var getTemplateByName = function(req, res, callback) {
	logger.info('template : controller : received request : getTemplateByName : name : '+req.params.name);
	templateDao.getTemplateByName(req, res, callback);
};

/*
 * Get all companies
 */
var getAllTemplates = function(req, res, callback) {
	templateDao.getAllTemplates(req, res, callback);
};

/*
 * Update template details
 */
var updateTemplateById = function(req, res, callback) {
	logger.info('template : controller : received request : updateTemplateById : id : '+req.params.id);
	templateDao.updateTemplateById(req, res, callback);
};

/*
 * Delete template details
 */
var deleteTemplateById = function(req, res, callback) {
	logger.info('template : controller : received request : deleteTemplateById : id : '+req.params.id);
	templateDao.deleteTemplateById(req, res, callback);
};

module.exports.addNewTemplate = addNewTemplate;
module.exports.getTemplateById = getTemplateById;
module.exports.getFilledTemplateById = getFilledTemplateById;
module.exports.getTemplateByName = getTemplateByName;
module.exports.getAllTemplates = getAllTemplates;
module.exports.updateTemplateById = updateTemplateById;
module.exports.deleteTemplateById = deleteTemplateById;