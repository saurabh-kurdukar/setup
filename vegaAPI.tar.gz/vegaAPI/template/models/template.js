var mongoose = require('../../common/MongoDbConnection').mongoose;
var autoIncrement = require('mongoose-auto-increment');
var logger = require('../../common/logger').log;
var connection = mongoose.connection;
autoIncrement.initialize(connection);

/*
 * Define schema
 * embedded docs : http://mongoosejs.com/docs/2.7.x/docs/embedded-documents.html
 */
var versionDetails = mongoose.Schema({
	templateDescription: {type: String, minLength: 0, maxLength: 500},
	templateBody: {type: String, minLength: 0, maxLength: 3000},
	sampleJson: {type: String, minLength: 0, maxLength: 2000},
    version: {type: String},
	status: {type: String, minLength: 0, maxLength: 20},
	createdOn: { type: Date, default: Date.now },
	createdBy: {type: String, minLength: 0, maxLength: 100},
	updatedOn: { type: Date, default: Date.now },
	updatedBy: {type: String, minLength: 0, maxLength: 50}
});

var templateSchema = mongoose.Schema({
    templateId: Number,
    companyId: Number,
	status: {type: String, minLength: 0, maxLength: 20},
    appGroupId: Number,
	templateName: {type: String, unique: true},
	versionDetails:[versionDetails]	
});


logger.info('template : model : created schema : Template :'+JSON.stringify(templateSchema.paths));


templateSchema.path('templateName').validate(function(value, fn) {	  
	  var Template = mongoose.model('Templates');
	  Template.find({'templateName': value}, function (err, data) {
	    fn(err || data.length === 0);
	  });
}, 'Template name is already taken');

templateSchema.pre('findOneAndUpdate', function(next) {
	  this.options.runValidators = true;
	  next();
});

templateSchema.path('templateName').validate(function (v) {
	  return v.length <= 100;
}, 'data too long for field templateName'); 

//templateSchema.path('companyId').validate(function (v) {
//	  return v.length <= 100;
//}, 'data too long for field companyId'); 
//
//templateSchema.path('appGroupId').validate(function (v) {
//	  return v.length <= 100;
//}, 'data too long for field appGroupId'); 


templateSchema.plugin(autoIncrement.plugin, { model: 'Templates', field: 'templateId', startAt: 1 });

/*
 * Setters
 */

templateSchema.methods.setTemplateName = function(templateName) {
	this.templateName = templateName;
};

templateSchema.methods.setCompanyId = function(companyId) {
	this.companyId = companyId;
};

templateSchema.methods.setStatus = function(status) {
	this.status = status;
};

templateSchema.methods.setAppGroupId = function(appGroupId) {
	this.appGroupId = appGroupId;
};

templateSchema.methods.setVersionDetails = function(versionDetails) {
	this.versionDetails.push(versionDetails);
};


/*
 * Getters
 */
templateSchema.methods.getTemplateId = function() {
	return this.templateId;
};

templateSchema.methods.getTemplateName = function() {
	return this.templateName;
};

templateSchema.methods.getCompanyId = function() {
	return this.companyId;
};

templateSchema.methods.getStatus = function() {
	return this.status;
};

templateSchema.methods.getAppGroupId = function() {
	return this.appGroupId;
};

templateSchema.methods.getVersionDetails = function() {
	return this.versionDetails;
};

/*
 * Create collection/model in mongo db using Schema
 */
var Template = mongoose.model('Templates', templateSchema);


module.exports = Template;


