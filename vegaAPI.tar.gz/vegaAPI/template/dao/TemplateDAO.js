var db = require('../../common/MongoDbConnection');
var Template = require('../models/template');
var logger = require('../../common/logger').log;
var Dot = require('dot');

Dot.templateSettings = {
		  evaluate:    /\{\{([\s\S]+?)\}\}/g,
		  interpolate: /\{\{=([\s\S]+?)\}\}/g,
		  encode:      /\{\{!([\s\S]+?)\}\}/g,
		  use:         /\{\{#([\s\S]+?)\}\}/g,
		  define:      /\{\{##\s*([\w\.$]+)\s*(\:|=)([\s\S]+?)#\}\}/g,
		  conditional: /\{\{\?(\?)?\s*([\s\S]*?)\s*\}\}/g,
		  iterate:     /\{\{~\s*(?:\}\}|([\s\S]+?)\s*\:\s*([\w$]+)\s*(?:\:\s*([\w$]+))?\s*\}\})/g,
		  varname: 'object',
		  strip: true,
		  append: true,
		  selfcontained: false
		};

/*
 * Add new template details
 */
var addNewTemplate = function(req, res, callback) {
	logger.info('template : DAO : received request : addNewTemplate : body : '
			+ JSON.stringify(req.body) + ' companyId: ' + req.header('companyId') + 
			' appGroupId: ' + req.header('appGroupId') );
	var reqBody = req.body;
	var template = new Template();
	template.setTemplateName(reqBody.templateName);
	template.setCompanyId(req.header('companyId'));
	template.setAppGroupId(req.header('appGroupId'));
	template.setStatus('ACTIVE');
	versionDetails = {
		sampleJson: reqBody.sampleJson, 
		status: 'ACTIVE',
        templateDescription: reqBody.templateDescription,
        templateBody: reqBody.templateBody,
        version: reqBody.version,
        createdOn: new Date(),
        createdBy: reqBody.adminFullName,
        updatedOn:new Date(),
        updatedBy:reqBody.adminFullName
        
	};	
	logger.info('versionDetails body : '+ JSON.stringify(versionDetails));
	template.setVersionDetails(versionDetails);
	template.markModified('versionDetails');
	template.save(function(err, data) {
		if (err) {
			logger.error('company : DAO : failed addNewTemplate : error : ' + err);
			callback(err, data);
		} else {
			logger.info('company : DAO : addNewTemplate successful !');
			callback(err, data);
		}
	});
};
/*
 * Get filled template by template id and companyId
 */
var getFilledTemplateById = function(req, res, callback) {
	logger.info('template : DAO : received request : getFilledTemplateById :  id. : ' + req.params.id 
			+ 'companyId : ' + req.header('companyId') + ': body: ' + JSON.stringify(req.body));
	var reqBody = req.body;
	var jsonData = reqBody.jsonData;
	var givenVersion = reqBody.version;
	var templateId = req.params.id;
	var companyId = req.header('companyId');
	var queryParam = {
			'templateId' : templateId,
			'companyId' : companyId,
			'status' : { $ne : 'DELETED'}
		}
	logger.info('Query param formed : ' + JSON.stringify(queryParam));
	Template.findOne(queryParam, function(err, data) {
		if (err) {
			logger.error('company : DAO : failed getFilledTemplateById : error : ' + err);
			callback(err, data);
		} else {
			if (data != null) {
				logger.info('Data recieved : ' + JSON.stringify(data));
				for (i = 0; i < data['versionDetails'].length; i++) { 
					if ( data['versionDetails'][i]['status'] == "ACTIVE" && 
							data['versionDetails'][i]['version'] == givenVersion) {						
						var tempFn = Dot.template(data['versionDetails'][i]['templateBody']);	
						var filledTemplate = tempFn(jsonData);
					}	
					else{						
						console.log(data['versionDetails'][i]['status'] + "<br>");
						//data['versionDetails'][i].remove();
					}						
				}
				if (filledTemplate){
					logger.info('company : DAO : getFilledTemplateById successful !');			
					callback(err, filledTemplate);					
				}
				else{
					var err = new Error('No Matching Active version found for versionx :' + givenVersion );
					err.status = 404;
					logger.error('company : DAO : failed getFilledTemplateById : error : ' + err);
					callback(err, data);					
				}
				console.log(filledTemplate);
				logger.info('company : DAO : getFilledTemplateById successful !');			
				//callback(err, filledTemplate);
			} else {
				var err = new Error('Invalid combination of template id :' + templateId 
						+ ' and company id : ' + companyId + ' and version : ' + givenVersion);
				err.status = 404;
				logger.error('company : DAO : failed getFilledTemplateById : error : ' + err);
				callback(err, data);
			}
		}
	});
};

/*
 * Get template by template id
 */
var getTemplateById = function(req, res, callback) {
	logger.info('template : DAO : received request : getTemplateById : id : '
			+ req.params.id);

	Template.findOne({
		'templateId' : req.params.id,
		'companyId' : req.header('companyId'),
		'status' : { $ne : 'DELETED'}
	}, function(err, data) {
		if (err) {
			logger.error('company : DAO : failed getTemplateById : error : ' + err);
			callback(err, data);
		} else {
			if (data != null) {
				for (i = 0; i < data['versionDetails'].length; i++) { 
					if ( data['versionDetails'][i]['status'] !== "ACTIVE") {	
						data['versionDetails'][i].remove();
					}							
				}
				logger.info('company : DAO : getTemplateById successful !');
				callback(err, data);
			} else {
				var err = new Error('Invalid combination of template id and company id.');
				err.status = 404;
				logger.error('company : DAO : failed getTemplateById : error : ' + err);
				callback(err, data);
			}
		}
	});
};

/*
 * Get template by template name
 */
var getTemplateByName = function(req, res, callback) {
	logger.info('template : DAO : received request : getTemplateByName : id : '
			+ req.params.name);
	Template.findOne({
		'templateName' : req.params.name,
		'companyId' : req.header('companyId'),
		'status' : { $ne : 'DELETED'}
	}, function(err, data) {
		if (err) {
			logger.error('company : DAO : failed getTemplateByName : error : ' + err);
			callback(err, data);
		} else {
			logger.info('Data recived : ' + JSON.stringify(data));
			if (data != null) {
				for (i = 0; i < data['versionDetails'].length; i++) { 
					if ( data['versionDetails'][i]['status'] !== "ACTIVE") {				
						console.log(data['versionDetails'][i]['status'] + "<br>");
						data['versionDetails'][i].remove();
					}							
				}
				logger.info('company : DAO : getTemplateById successful !');
				callback(err, data);
			} else {
				var err = new Error('Invalid combination of template name and company id.');
				err.status = 404;
				logger.error('company : DAO : failed getTemplateById : error : ' + err);
				callback(err, data);
			}
		}
	});
};

/*
 * Get all templates
 */
var getAllTemplates = function(req, res, callback) {
	logger.info('template : DAO : received request : getAllTemplates');
	var queryParam = {'status' : { $ne : 'DELETED'}};
	queryParam.companyId = req.header('companyId');
	if (req.query.templateVersion){
		logger.error("template version :" + req.query.templateVersion);
		queryParam.templateVersion = req.query.templateVersion;
	} 
	if (req.header('appGroupId')){
		logger.error("appGroupId present :" + req.header('appGroupId'));	
		queryParam.appGroupId = req.header('appGroupId');
	}
	else{
		logger.info("appGroupID not present :");	
	}
	logger.error('query :' , JSON.stringify(queryParam));	
	Template.find(queryParam, function(err, data) {
		if (err) {
			logger.error('company : DAO : failed getAllTemplates : error : ' + err);
			callback(err, data);
		} else {
			if (data != null) {
				var responseData = [];				
				for (i = 0; i < data.length; i++) { 
						var dataNode = {};
						var currentData = data[i]; 
						dataNode['templateName'] = currentData['templateName'];
						dataNode['companyId'] = currentData['companyId'];
						dataNode['appGroupId'] = currentData['appGroupId'];
						dataNode['templateId'] = currentData['templateId'];
						dataNode['_id'] = currentData['_id'];
						responseData.push(dataNode);
						
						//console.log('Befor: #######', data[i]);
						//delete data[i]['templateName'];
						//console.log('after: #######', data[i]);
						//data[i].remove('versionDetails');
						//data.save();
						//data[i]['versionDetails'].remove();	
						//data[i].markModified('versionDetails');
				}
				//console.log('#######', responseData[i]);
				//console.log('--', data[i]['versionDetails']);
				logger.info('company : DAO : getAllTemplates successful !');
				callback(err, responseData);
			} else {
				var err = new Error('No records found');
				err.status = 404;
				logger.error('company : DAO : failed getAllTemplates : error : ' + err);
				callback(err, data);
			}
		}
	});
};

/*
 * Update template details
 */
var updateTemplateById = function(req, res, callback) {
	logger.info('template : DAO : received request : updateTemplateById : id : '
		+ req.params.id + ' compnay id: ' + req.header('companyId'));
	var reqBody = req.body;
	var givenVersion = reqBody.version;
	var givenVersion = reqBody.version;
	versionDetails = {
		sampleJson: reqBody.sampleJson, 
		status: 'ACTIVE',
        templateDescription: reqBody.templateDescription,
        templateBody: reqBody.templateBody,
        version: givenVersion,
        createdOn: new Date(),
        createdBy: reqBody.adminFullName,
        updatedOn:new Date(),
        updatedBy:reqBody.adminFullName
        
	};	
	logger.info('versionDetails body : '+ JSON.stringify(versionDetails));	
	var queryParam = {
			'templateId' : req.params.id,
			'status':  { $ne : 'DELETED'},
			'companyId' : req.header('companyId'),
			'versionDetails.version':  { $ne : givenVersion}
			};
	var setBlock = { 
			$set : {"templateName": reqBody.templateName},
			$push: {"versionDetails": versionDetails}
	} ;
	logger.info('queryParam : '+ JSON.stringify(queryParam));
	Template.findOneAndUpdate(queryParam, setBlock, {'new':true},
		function(err, data) {
		if (err) {
			logger.error('template : DAO : failed updateTemplateById : error : ' + err);
			callback(err, data);
		} else {
			if (data != null) {
				logger.info('template : DAO : updateCompanyById successful !');
				//audit(req, res, updatedData);
				callback(null, data);
			} else {
				var err = new Error('Bad request data, Invalid combination of template-id/company-id/version ');
				logger.error('template : DAO : failed updateCompanyById : error :' + err);
				callback(err, null);				
			}
		}
	});
};

/*
 * Update template details new
 */
var updateTemplateById_new = function(req, res, callback) {
	logger.info('template : DAO : received request : updateTemplateById : id : '
		+ req.params.id);
	var reqBody = req.body;
	givenVersion = reqBody.version;
	versionDetails = {
		sampleJson: reqBody.sampleJson, 
		status: 'ACTIVE',
        templateDescription: reqBody.templateDescription,
        templateBody: reqBody.templateBody,
        version: givenVersion,
        createdOn: new Date(),
        createdBy: reqBody.adminFullName,
        updatedOn:new Date(),
        updatedBy:reqBody.adminFullName
        
	};	
	logger.info('versionDetails body : '+ JSON.stringify(versionDetails));
	var queryParam = {
			'templateId' : req.params.id,
			'status':  { $ne : 'DELETED'},
			'companyId' : req.header('companyId'),
			'versionDetails.version':  { $ne : givenVersion}
			};
	var setBlock = { 
			"templateName": reqBody.templateName,
			$push: {"versionDetails": versionDetails}
	} ;
	logger.info('UserParam : ' + JSON.stringify(queryParam) + ' setblock : ' + JSON.stringify(queryParam));
	Template.update(queryParam, setBlock, function(err, data) {
		if (err) {
			logger.error('company : DAO : failed deleteTemplateById : error : ' + err);
			callback(err, data);
		} else {
			logger.info('company : DAO : deleteTemplateById successful !');
			callback(err, data);
		}
	});
};


/*
 * Delete template details
 */
var deleteTemplateById = function(req, res, callback) {
	logger.info('template : DAO : received request : deleteTemplateById : id : '
			+ req.params.id );
	var queryParam = {
			'templateId' : req.params.id,
			'companyId' : req.header('companyId'),
			'status':  { $ne : 'DELETED'}
			};
	var setBlock = {};
	if (req.query.templateVersion){
		templateVersion = req.query.templateVersion;
		queryParam['versionDetails.version'] = templateVersion;
		setBlock = { $set : { "versionDetails.$.status" : "INACTIVE"} };		
	} 
	else{
		setBlock = { "status" : "DELETED"} ;	
	}
	logger.info('UserParam : ' + JSON.stringify(queryParam) + ' setblock : ' + JSON.stringify(queryParam));
	Template.update(queryParam, setBlock, function(err, data) {
		if (err) {
			logger.error('company : DAO : failed deleteTemplateById : error : ' + err);
			callback(err, data);
		} else {
			logger.info('company : DAO : deleteTemplateById successful !');
			callback(err, data);
		}
	});

};


module.exports.addNewTemplate = addNewTemplate;
module.exports.getTemplateById = getTemplateById;
module.exports.getFilledTemplateById = getFilledTemplateById;
module.exports.getTemplateByName = getTemplateByName;
module.exports.getAllTemplates = getAllTemplates;
module.exports.updateTemplateById = updateTemplateById;
module.exports.deleteTemplateById = deleteTemplateById;