var express = require('express');
var templateController = require('./controller/TemplateController');
var logger = require('../common/logger').log;
var router = express.Router();


/*
 * Add new template details
 */
router.post('/', function(req, res){
	logger.info('template : router : received request : addNewTemplate : body : '+JSON.stringify(req.body));
	templateController.addNewTemplate(req, res, function(err, data) {
        if(err){
        	console.log("sending 500 response back from route at "+new Date());
        	var errorObj = {
        		"error": err.message	
        	};
            res.status(500).end(JSON.stringify(errorObj));
        }else{
        	console.log("sending 200 response back from route at "+new Date());
        	res.status(200).end(JSON.stringify(data));
        }
    });
});

/*
 * Get template by template id
 */
router.get('/:id(\\d+)/', function (req, res) {	
	logger.info('template : router : received request : getTemplateById : id : '+req.params.id);
	templateController.getTemplateById(req, res, function(err, data) {
        if(err){
        	console.log("sending 500 response back from route at "+new Date());
        	var errorObj = {
        		"error": err.message	
        	};
            res.status(500).end(JSON.stringify(errorObj));
        }else{
        	console.log("sending 200 response back from route at "+new Date());
        	res.status(200).end(JSON.stringify(data));
        }
    });
});


/*
 * Get content details of template by id
 */
router.post('/:id(\\d+)/getContent', function(req, res){
	logger.info('template : router : received request : getTemplateById : id : '+req.params.id);
	templateController.getFilledTemplateById(req, res, function(err, data) {
        if(err){
        	console.log("sending 500 response back from route at "+new Date());
        	var errorObj = {
        		"error": err.message	
        	};
            res.status(500).end(JSON.stringify(errorObj));
        }else{
        	console.log("sending 200 response back from route at "+new Date());
        	res.status(200).end(JSON.stringify(data));
        }
    });
});

/*
 * Get template by template name
 */
router.get('/:name', function (req, res) {		
	logger.info('template : router : received request : getTemplateByName : body : '+req.params.name);
	templateController.getTemplateByName(req, res, function(err, data) {
        if(err){
        	console.log("sending 500 response back from route at "+new Date());
        	var errorObj = {
        		"error": err.message	
        	};
            res.status(500).end(JSON.stringify(errorObj));
        }else{
        	console.log("sending 200 response back from route at "+new Date());
        	res.status(200).end(JSON.stringify(data));
        }
    });
});

/*
 * Get all templates
 */
router.get('/', function (req, res) {
	logger.info('template : router : received request : getAllTemplates');
	console.log('req.query.templateVersion=' + req.query.status);
	templateController.getAllTemplates(req, res, function(err, data) {
        if(err){
        	console.log("sending 500 response back from route at "+new Date());
        	var errorObj = {
        		"error": err.message	
        	};
            res.status(500).end(JSON.stringify(errorObj));
        }else{
        	console.log("sending 200 response back from route at "+new Date());
        	res.status(200).end(JSON.stringify(data));
        }
    });
});

/*
 * Update template details
 */
router.put('/:id(\\d+)', function(req, res){	  
	logger.info('template : router : received request : updateTemplateById : body : '+req.params.id);
	templateController.updateTemplateById(req, res, function(err, data) {
        if(err){
        	console.log("sending 500 response back from route at "+new Date());
        	var errorObj = {
        		"error": err.message	
        	};
            res.status(500).end(JSON.stringify(errorObj));
        }else{
        	console.log("sending 200 response back from route at "+new Date());
        	res.status(200).end(JSON.stringify(data));
        }
    });
});

/*
 * Delete template details
 */
router.delete('/:id(\\d+)', function(req, res){
	logger.info('template : router : received request : deleteTemplateById : id : '+req.params.id);
	templateController.deleteTemplateById(req, res, function(err, data) {
        if(err){
        	console.log("sending 500 response back from route at "+new Date());
        	var errorObj = {
        		"error": err.message	
        	};
            res.status(500).end(JSON.stringify(errorObj));
        }else{
        	console.log("sending 200 response back from route at "+new Date());
        	res.status(200).end(JSON.stringify(data));
        }
    });
});

/*
 * Options for templates APIs
 */
router.options('/', function(req, res) {
	logger.info('template : router : received request : option call templates');
	res.header('Allow-Access-Allow-Origin', '*');
	res.header('Access-Control-Allow-Headers', '*');
	res.header('Access-Control-Allow-Methods', 'GET,POST,DELETE,PUT,OPTIONS');
	res.header('Connection', 'keep-alive');
	res.header('Content-Type', 'application/json;charset=UTF-8');
	res.end();
});


router.all('/*', function (req, res) {		
	res.status(404).send(JSON.stringify({'error':'No matching resource for url: '+req.originalUrl}));	  	
});

module.exports = router;