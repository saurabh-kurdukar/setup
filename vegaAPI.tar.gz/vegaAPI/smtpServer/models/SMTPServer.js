var mongoose = require('../../common/MongoDbConnection').mongoose;
var autoIncrement = require('mongoose-auto-increment');
var logger = require('../../common/logger').log;
var connection = mongoose.connection;
autoIncrement.initialize(connection);

/*
 * Define schema
 */
var smtpServerSchema = mongoose.Schema({
	SMTPServerId: Number,
	SMTPServerName: {type: String, minLength: 0, maxLength: 100 , unique: true },
    CompanyId: {type:Number, required: true},
    IPAddress: {type: String, minLength: 0, maxLength: 30},
	Port: {type: Number, minLength: 0, maxLength: 10},
	Type: {type: String, minLength: 0, maxLength: 10 , default: 'SMTP'},
	Username: {type: String, minLength: 0, maxLength: 100},
	Password: {type: String, minLength: 0, maxLength: 100},
	MessageQueueName: {type: String, minLength: 0, maxLength: 100},
	MessageRetries: {type: Number, minLength: 0, maxLength: 2},
	Attribute1: {type: String, minLength: 0, maxLength: 100},
	Attribute1Value: {type: String, minLength: 0, maxLength: 100},
	Attribute2: {type: String, minLength: 0, maxLength: 100},
	Attribute2Value: {type: String, minLength: 0, maxLength: 100},	
	Attribute3: {type: String, minLength: 0, maxLength: 100},
	Attribute3Value: {type: String, minLength: 0, maxLength: 100},	
	Attribute4: {type: String, minLength: 0, maxLength: 100},
	Attribute4Value: {type: String, minLength: 0, maxLength: 100},
	Attribute5: {type: String, minLength: 0, maxLength: 100},
	Attribute5Value: {type: String, minLength: 0, maxLength: 100},
	CreatedBy: {type: String, minLength: 0, maxLength: 50},
	CreatedOn :  { type: Date, default: Date.now },
	UpdatedBy: {type: String, minLength: 0, maxLength: 50},	
	UpdatedOn: { type: Date, default: Date.now },		
	             
});

logger.info('SMTP Server : model : created schema : SMTP Server :'+JSON.stringify(smtpServerSchema.paths));

/*
 * Add Auto increment plugin for field SMTPServerId
 */
smtpServerSchema.plugin(autoIncrement.plugin, { model: 'SMTPServers', field: 'SMTPServerId', startAt: 1 });



smtpServerSchema.path('SMTPServerName').validate(function (v) {
	  return v.length <= 100;
}, 'data too long for field SMTPServerName'); 

smtpServerSchema.path('IPAddress').validate(function (v) {
	  return v.length <= 30;
}, 'data too long for field IPAddress'); 

smtpServerSchema.path('Type').validate(function (v) {
	  return v.length <= 10;
}, 'data too long for field Type'); 

smtpServerSchema.path('Username').validate(function (v) {
	  return v.length <= 100;
}, 'data too long for field Username'); 

smtpServerSchema.path('Password').validate(function (v) {
	  return v.length <= 100;
}, 'data too long for field Password'); 

smtpServerSchema.path('MessageQueueName').validate(function (v) {
	  return v.length <= 100;
}, 'data too long for field MessageQueueName'); 

smtpServerSchema.path('Attribute1').validate(function (v) {
	  return v.length <= 100;
}, 'data too long for field Attribute1'); 

smtpServerSchema.path('Attribute1Value').validate(function (v) {
	  return v.length <= 100;
}, 'data too long for field Attribute1Value'); 

smtpServerSchema.path('Attribute2').validate(function (v) {
	  return v.length <= 100;
}, 'data too long for field Attribute2'); 

smtpServerSchema.path('Attribute2Value').validate(function (v) {
	  return v.length <= 100;
}, 'data too long for field Attribute2Value'); 

smtpServerSchema.path('Attribute3').validate(function (v) {
	  return v.length <= 100;
}, 'data too long for field Attribute3'); 

smtpServerSchema.path('Attribute3Value').validate(function (v) {
	  return v.length <= 100;
}, 'data too long for field Attribute3Value'); 

smtpServerSchema.path('Attribute4').validate(function (v) {
	  return v.length <= 100;
}, 'data too long for field Attribute4'); 

smtpServerSchema.path('Attribute4Value').validate(function (v) {
	  return v.length <= 100;
}, 'data too long for field Attribute4Value'); 

smtpServerSchema.path('Attribute5').validate(function (v) {
	  return v.length <= 100;
}, 'data too long for field Attribute5'); 

smtpServerSchema.path('Attribute5Value').validate(function (v) {
	  return v.length <= 100;
}, 'data too long for field Attribute5Value'); 

smtpServerSchema.path('CreatedBy').validate(function (v) {
	  return v.length <= 50;
}, 'data too long for field CreatedBy'); 

smtpServerSchema.path('UpdatedBy').validate(function (v) {
	  return v.length <= 50;
}, 'data too long for field UpdatedBy'); 


/*
 * Setters
 */
smtpServerSchema.methods.setSMTPServerId=function(SMTPServerId){
	this.SMTPServerId=SMTPServerId;
}

smtpServerSchema.methods.setSMTPServerName=function(SMTPServerName){
	this.SMTPServerName=SMTPServerName;
}

smtpServerSchema.methods.setCompanyId=function(CompanyId){
	this.CompanyId=CompanyId;
}

smtpServerSchema.methods.setIPAddress=function(IPAddress){
	this.IPAddress=IPAddress;
}

smtpServerSchema.methods.setPort=function(Port){
	this.Port=Port;
}

smtpServerSchema.methods.setType=function(Type){
	this.Type=Type;
}

smtpServerSchema.methods.setUsername=function(Username){
	this.Username=Username;
}
smtpServerSchema.methods.setPassword=function(Password){
	this.Password=Password;
}

smtpServerSchema.methods.setMessageQueueName=function(MessageQueueName){
	this.MessageQueueName=MessageQueueName;
}

smtpServerSchema.methods.setMessageRetries=function(MessageRetries){
	this.MessageRetries=MessageRetries;
}

smtpServerSchema.methods.setAttribute1=function(Attribute1){
	this.Attribute1=Attribute1;
}

smtpServerSchema.methods.setAttribute1Value=function(Attribute1Value){
	this.Attribute1Value=Attribute1Value;
}

smtpServerSchema.methods.setAttribute2=function(Attribute2){
	this.Attribute2=Attribute2;
}
smtpServerSchema.methods.setAttribute2Value=function(Attribute2Value){
	this.Attribute2Value=Attribute2Value;
}

smtpServerSchema.methods.setAttribute3=function(Attribute3){
	this.Attribute3=Attribute3;
}

smtpServerSchema.methods.setAttribute3Value=function(Attribute3Value){
	this.Attribute3Value=Attribute3Value;
}

smtpServerSchema.methods.setAttribute4=function(Attribute4){
	this.Attribute4=Attribute4;
}

smtpServerSchema.methods.setAttribute4Value=function(Attribute4Value){
	this.Attribute4Value=Attribute4Value;
}

smtpServerSchema.methods.setAttribute5=function(Attribute5){
	this.Attribute5=Attribute5;
}

smtpServerSchema.methods.setAttribute5Value=function(Attribute5Value){
	this.Attribute5Value=Attribute5Value;
}

smtpServerSchema.methods.setCreatedBy=function(CreatedBy){
	this.CreatedBy=CreatedBy;
}

smtpServerSchema.methods.setCreatedOn=function(CreatedOn){
	this.CreatedOn=CreatedOn;
}

smtpServerSchema.methods.setUpdatedBy=function(UpdatedBy){
	this.UpdatedBy=UpdatedBy;
}

smtpServerSchema.methods.setUpdatedOn=function(UpdatedOn){
	this.UpdatedOn=UpdatedOn;
}


/*
 * Getters
 */
smtpServerSchema.methods.getSMTPServerId=function(){
	return this.SMTPServerId;
}

smtpServerSchema.methods.getSMTPServerName=function(){
	return this.SMTPServerName;
}

smtpServerSchema.methods.getCompanyId=function(){
	return this.CompanyId;
}

smtpServerSchema.methods.getIPAddress=function(){
	return this.IPAddress;
}

smtpServerSchema.methods.getPort=function(){
	return this.Port;
}

smtpServerSchema.methods.getType=function(){
	return this.Type;
}

smtpServerSchema.methods.getUsername=function(){
	return this.Username;
}
smtpServerSchema.methods.getPassword=function(){
	return this.Password;
}

smtpServerSchema.methods.getMessageQueueName=function(){
	return this.MessageQueueName;
}

smtpServerSchema.methods.getMessageRetries=function(){
	return this.MessageRetries;
}

smtpServerSchema.methods.getAttribute1=function(){
	return this.Attribute1;
}

smtpServerSchema.methods.getAttribute1Value=function(){
	return this.Attribute1Value;
}

smtpServerSchema.methods.getAttribute2=function(){
	return this.Attribute2;
}
smtpServerSchema.methods.getAttribute2Value=function(){
	return this.Attribute2Value;
}

smtpServerSchema.methods.getAttribute3=function(){
	return this.Attribute3;
}

smtpServerSchema.methods.getAttribute3Value=function(){
	return this.Attribute3Value;
}

smtpServerSchema.methods.getAttribute4=function(){
	return this.Attribute4;
}

smtpServerSchema.methods.getAttribute4Value=function(){
	return this.Attribute4Value;
}

smtpServerSchema.methods.getAttribute5=function(){
	return this.Attribute5;
}

smtpServerSchema.methods.getAttribute5Value=function(){
	return this.Attribute5Value;
}

smtpServerSchema.methods.getCreatedBy=function(){
	return this.CreatedBy;
}

smtpServerSchema.methods.getCreatedOn=function(){
	return this.CreatedOn;
}

smtpServerSchema.methods.getUpdatedBy=function(){
	return this.UpdatedBy;
}

smtpServerSchema.methods.getUpdatedOn=function(){
	return this.UpdatedOn;
}


/*
 * Create collection/model in mongo db using Schema
 */
var SMTPServer = mongoose.model('SMTPServers', smtpServerSchema);


/*
 * Insert records in collection
 */
/*var smtpServer = new SMTPServer({ SMTPServerId: 1, SMTPServerName: 'SMTPServer', CompanyId: 1, IPAddress:'IP4' ,
	Port: 8000 , Type: 'STMP' , Username: 'Admin' , Password: 'Admin' , MessageQueueName: 'queueName' ,
	MessageRetries: 2 , Attribute1: 'attr1' , Attribute1Value: 'attr1val' , Attribute2: 'attr2' , Attribute2Value: 'attr2val' ,
	Attribute3: 'attr3' , Attribute3Value: 'attr3val' , Attribute4: 'attr4' , Attribute4Value: 'attr4val' ,
	Attribute5: 'attr5' , Attribute5Value: 'attr5val' , CreatedBy: 'Admin' ,UpdatedBy: 'Admin' });

smtpServer.save(function (err, data) {
  if (err) 
	  return console.error(err);
  else
	  console.log('data inserted: '+data.CompanyId);
});*/


module.exports = SMTPServer;