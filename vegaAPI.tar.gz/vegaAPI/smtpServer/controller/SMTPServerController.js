var smtpServerDao = require('../dao/SMTPServerDAO');
var logger = require('../../common/logger').log;
/*
 * Add new SMTP Server details
 */
var addNewSMTPServer = function(req, res, callback) {
	logger.info('SMTP Server : controller : received request : addNewSMTPServer : body : '+JSON.stringify(req.body));			
	smtpServerDao.addNewSMTPServer(req, res, callback);
}; 	

/*
 * Get smtp servers by SMTPServer id
 */
var getSMTPServersBySMTPServerId = function(req, res, callback) {	
	logger.info('SMTP Server : controller : received request : getSMTPServersBySMTPServerId : id : '+req.params.id);
	smtpServerDao.getSMTPServersBySMTPServerId(req, res ,callback);
};


/*
 * Update SMTP server details
 */
var updateSMTPServerById = function(req, res, callback) {
	logger.info('SMTP Server : controller : received request : updateSMTPServerById : id : '+req.params.id);
	smtpServerDao.updateSMTPServerById(req, res, callback);
};


module.exports.addNewSMTPServer = addNewSMTPServer;
module.exports.getSMTPServersBySMTPServerId=getSMTPServersBySMTPServerId;
module.exports.updateSMTPServerById=updateSMTPServerById;
