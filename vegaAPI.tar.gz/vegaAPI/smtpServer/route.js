var express = require('express');
var logger = require('../common/logger').log;
var smtpServerController=require('./controller/SMTPServerController');
var ErrorResponse = require('../common/ErrorResponse').ErrorResponse;
var router = express.Router();


/*
 * Add new SMTP Server details
 */
router.post('/', function(req, res){
	logger.info('SMTP Server : router : received request : addNewSMTPServer : body : '+JSON.stringify(req.body));
	smtpServerController.addNewSMTPServer(req, res, function(err, data) {
        if(err){
        	logger.error('SMTP Server : router : failed addNewSMTPServer : error : '+err);             	     
        	var error = new ErrorResponse();
        	if(err.name == 'ValidationError'){
        		error.setErrorMessage(err.errors[Object.keys(err.errors)[0]].message);
        	} else {
        		error.setErrorMessage(err.message);
        	}
        	error.setErrorCode("SS001");        	
        	error.setHttpResponseCode(500);        	
        	res.status(500).end(JSON.stringify(error));        
        
        } else {        	
        	logger.info("SMTP Server : router : addNewSMTPServer successful !");
        	res.status(200).end(JSON.stringify(data));
        }
    });
});

/*
 * Get SMTP Servers by SMTP Server id
 */
router.get('/:id(\\d+)', function (req, res) {	
	logger.info('SMTP Server : router : received request : getAllSMTPServers : id : '+req.params.id);
	smtpServerController.getSMTPServersBySMTPServerId(req, res, function(err, data) {
        if(err){
        	logger.error('SMTP Server : router : failed getAllSMTPServers : error : '+err);   
        	var error = new ErrorResponse();
        	error.setErrorCode("SS002");
        	error.setErrorMessage(err.message);
        	error.setHttpResponseCode(500);
            res.status(500).end(JSON.stringify(error));
        }else{
        	logger.info("SMTP Server : router : getAllSMTPServers successful !");
        	res.status(200).end(JSON.stringify(data));
        }
    });
});

/*
 * Update SMTP server details
 */
router.put('/:id(\\d+)', function(req, res){	 
	logger.info('SMTP Server : router : received request : updateSMTPServerById : id : '+req.params.id);
	smtpServerController.updateSMTPServerById(req, res, function(err, data) {
        if(err){
        	logger.error('SMTP Server : router : failed updateSMTPServerById : error : '+err);   
        	var error = new ErrorResponse();
        	if(err.name == 'ValidationError'){
        		error.setErrorMessage(err.errors[Object.keys(err.errors)[0]].message);
        	} else {
        		error.setErrorMessage(err.message);
        	}
        	error.setErrorCode("SS003");        	
        	error.setHttpResponseCode(500);
            res.status(500).end(JSON.stringify(error));
        
        }else{
        	logger.info("SMTP Server : router : updateSMTPServerById successful !");
        	res.status(200).end(JSON.stringify(data));
        }
    });
});

/*
 * Options method
 */
router.options('/', function(req, res) {
	logger.info('SMTP Server : router : received request : Options call SMTP Servers APIs');
	res.header('Allow-Access-Allow-Origin', '*');
	res.header('Access-Control-Allow-Headers', '*');
	res.header('Access-Control-Allow-Methods', 'GET,POST,DELETE,PUT,OPTIONS');
	res.header('Connection', 'keep-alive');
	res.header('Content-Type', 'application/json;charset=UTF-8');
	res.end();
	logger.info('SMTP Server : router : Options call SMTP Servers APIs processed !');
});

router.all('/*', function (req, res) {		
	res.status(404).send(JSON.stringify({'error':'No matching resource for url: '+req.originalUrl}));	  	
});


module.exports = router;