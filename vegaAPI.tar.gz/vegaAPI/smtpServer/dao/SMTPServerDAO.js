var db = require('../../common/MongoDbConnection');
var SMTPServer = require('../models/SMTPServer');
var Company = require('../../company/models/Company');
var logger = require('../../common/logger').log;
var encryptdecrypt= require('../../common/EncryptDecrypt');
var audit = require('../../common/Audit').audit;

/*
 * Add new SMTP Server details
 */
var addNewSMTPServer = function(req, res, callback) {	
	logger.info('SMTP Server : DAO : received request : addNewSMTPServer : body : '
			+ JSON.stringify(req.body));
	
	var CompanyID = req.headers['companyid'];	
	var Username = req.headers['username'];
	
	//encrypt password
	var encpassword=encryptdecrypt.encryption(req.body.Password);
	
	var reqBody = req.body;
	var smtpServer = new SMTPServer();
	
	smtpServer.setSMTPServerId(reqBody.SMTPServerId);
	smtpServer.setSMTPServerName(reqBody.SMTPServerName);
	smtpServer.setCompanyId(parseInt(CompanyID));
	smtpServer.setIPAddress(reqBody.IPAddress);
	smtpServer.setPort(reqBody.Port);
	//smtpServer.setType(reqBody.Type);
	smtpServer.setUsername(Username);
	smtpServer.setPassword(encpassword);
	smtpServer.setMessageQueueName(reqBody.MessageQueueName);
	smtpServer.setMessageRetries(reqBody.MessageRetries);
	smtpServer.setAttribute1(reqBody.Attribute1);
	smtpServer.setAttribute1Value(reqBody.Attribute1Value);
	smtpServer.setAttribute2(reqBody.Attribute2);
	smtpServer.setAttribute2Value(reqBody.Attribute2Value);
	smtpServer.setAttribute3(reqBody.Attribute3);
	smtpServer.setAttribute3Value(reqBody.Attribute3Value);
	smtpServer.setAttribute4(reqBody.Attribute4);
	smtpServer.setAttribute4Value(reqBody.Attribute4Value);
	smtpServer.setAttribute5(reqBody.setAttribute5);
	smtpServer.setAttribute5Value(reqBody.Attribute5Value);
	smtpServer.setCreatedBy(Username);
	smtpServer.setCreatedOn(new Date());
	smtpServer.setUpdatedBy(Username);
	smtpServer.setUpdatedOn(new Date());
	
	
	Company.find({
		'companyId' : CompanyID
	}, function(err, data) {
		if (err) {
			callback(err, data);
		} else {
			if (data.length != 0) {				
				smtpServer.save(function(err, data) {
					if (err) {
						callback(err, data);
					} else {
						callback(err, data);
					}
				});
			} else {
				var err = new Error('Invalid company id');
				err.status = 404;
				callback(err, data);
			}
		}
	});
		
};

/*
 * Get SMTP Servers by company id
 */
var getSMTPServersByCompanyId = function(req, res, callback) {
	logger.info('SMTP Server : DAO : received request : getSMTPServersById : id : '+req.params.id);
	SMTPServer.find({
		'CompanyId' : req.params.id
	}, function(err, data) {
		if (err) {
			callback(err, data);
		} else {
			if (data.length != 0) {
				callback(err, data);
			} else {
				var err = new Error('Invalid company id');
				err.status = 404;
				callback(err, data);
			}
		}
	});
};


/*
 * Get smtp servers by SMTPServer id
 */
var getSMTPServersBySMTPServerId = function(req, res, callback) {
	logger.info('SMTP Server : DAO : received request : getSMTPServersBySMTPServerId : id : '+req.params.id);
	var CompanyID = req.headers['companyid'];	
	
	SMTPServer.find({
		'SMTPServerId' : req.params.id,
		'CompanyId' : CompanyID
	}, function(err, data) {
		if (err) {
			callback(err, data);
		} else {
			if (data.length != 0) {
				callback(err, data);
			} else {
				var err = new Error('Invalid SMTP server id or Company id');
				err.status = 404;
				callback(err, data);
			}
		}
	});
};

/*
 * Update SMTP Server details
 */
var updateSMTPServerById = function(req, res, callback) {
	logger.info('SMTP Server : DAO : received request : updateSMTPServerById : (SMTPServerId: '+req.params.id+', body: '+JSON.stringify(req.body)+')');
	
	/*
	 * Callback function after getting original record to update with new values.
	 */ 
	var callbackUpdate = function(err, data) {	
		if(err) {
			logger.error('SMTP Server : DAO : failed updateSMTPServerById : error :' + err);
			callback(err, null);
		} else if(data != null) {
			/*
			 *	Compare updatable fields values in db with request data
			 *	Add those fields in temproary object which are having new values
			 */			
			var smtpServer = data;
			var json = {};
			var updatedData = [];
			var Username = req.headers['username'];
			var CompanyID = req.headers['companyid'];							
			
			if (req.body.CompanyId && smtpServer['CompanyId'] != req.body.CompanyId) {
				json.CompanyId = req.body.CompanyId;
				var obj = {};				
				obj.column = 'CompanyId';
				obj.oldValue = smtpServer['CompanyId'];
				obj.newValue = req.body.CompanyId;
				obj.identifier = 'Platform_smtpServer_'+req.params.id;
				obj.modifiedBy = 'admin';
				obj.modifiedOn = new Date();
				updatedData.push(obj);
			}
			if (req.body.IPAddress && smtpServer['IPAddress'] != req.body.IPAddress) {
				json.IPAddress = req.body.IPAddress;
				var obj = {};
				obj.column = 'IPAddress';
				obj.oldValue = smtpServer['IPAddress'];
				obj.newValue = req.body.IPAddress;
				obj.identifier = 'Platform_smtpServer_'+req.params.id;
				obj.modifiedBy = 'admin';
				obj.modifiedOn = new Date();
				updatedData.push(obj);
			}
			if (req.body.Port && smtpServer['Port'] != req.body.Port) {
				json.Port = req.body.Port;
				var obj = {};
				obj.column = 'Port';
				obj.oldValue = smtpServer['Port'];
				obj.newValue = req.body.Port;
				obj.identifier = 'Platform_smtpServer_'+req.params.id;
				obj.modifiedBy = 'admin';
				obj.modifiedOn = new Date();
				updatedData.push(obj);
			}
			if (req.body.Type && smtpServer['Type'] != req.body.Type) {
				json.Type = req.body.Type;
				var obj = {};
				obj.column = 'Type';
				obj.oldValue = smtpServer['Type'];
				obj.newValue = req.body.Type;
				obj.identifier = 'Platform_smtpServer_'+req.params.id;
				obj.modifiedBy = 'admin';
				obj.modifiedOn = new Date();
				updatedData.push(obj);
			}
			
			if (req.body.Password && smtpServer['Password'] != req.body.Password) {
				//encrypt password
				var encpassword=encryptdecrypt.encryption(req.body.Password);
				json.Password = encpassword;
				var obj = {};
				obj.column = 'Password';
				obj.oldValue = smtpServer['Password'];
				obj.newValue = encpassword;
				obj.identifier = 'Platform_smtpServer_'+req.params.id;
				obj.modifiedBy = 'admin';
				obj.modifiedOn = new Date();
				updatedData.push(obj);
			}
			if (req.body.MessageRetries && smtpServer['MessageRetries'] != req.body.MessageRetries) {
				json.MessageRetries = req.body.MessageRetries;
				var obj = {};
				obj.column = 'MessageRetries';
				obj.oldValue = smtpServer['MessageRetries'];
				obj.newValue = req.body.MessageRetries;
				obj.identifier = 'Platform_smtpServer_'+req.params.id;
				obj.modifiedBy = 'admin';
				obj.modifiedOn = new Date();
				updatedData.push(obj);
			}
			if (req.body.Attribute1 && smtpServer['Attribute1'] != req.body.Attribute1) {
				json.Attribute1 = req.body.Attribute1;
				var obj = {};
				obj.column = 'Attribute1';
				obj.oldValue = smtpServer['Attribute1'];
				obj.newValue = req.body.Attribute1;
				obj.identifier = 'Platform_smtpServer_'+req.params.id;
				obj.modifiedBy = 'admin';
				obj.modifiedOn = new Date();
				updatedData.push(obj);
			}
			if (req.body.Attribute1Value && smtpServer['Attribute1Value'] != req.body.Attribute1Value) {
				json.Attribute1Value = req.body.Attribute1Value;
				var obj = {};
				obj.column = 'Attribute1Value';
				obj.oldValue = smtpServer['Attribute1Value'];
				obj.newValue = req.body.Attribute1Value;
				obj.identifier = 'Platform_smtpServer_'+req.params.id;
				obj.modifiedBy = 'admin';
				obj.modifiedOn = new Date();
				updatedData.push(obj);
			}
			if (req.body.Attribute2 && smtpServer['Attribute2'] != req.body.Attribute2) {
				json.Attribute2 = req.body.Attribute2;
				var obj = {};
				obj.column = 'Attribute2';
				obj.oldValue = smtpServer['Attribute2'];
				obj.newValue = req.body.Attribute2;
				obj.identifier = 'Platform_smtpServer_'+req.params.id;
				obj.modifiedBy = 'admin';
				obj.modifiedOn = new Date();
				updatedData.push(obj);
			}
			if (req.body.Attribute2Value && smtpServer['Attribute2Value'] != req.body.Attribute2Value) {
				json.Attribute2Value = req.body.Attribute2Value;
				var obj = {};
				obj.column = 'Attribute2Value';
				obj.oldValue = smtpServer['Attribute2Value'];
				obj.newValue = req.body.Attribute2Value;
				obj.identifier = 'Platform_smtpServer_'+req.params.id;
				obj.modifiedBy = 'admin';
				obj.modifiedOn = new Date();
				updatedData.push(obj);
			}
			if (req.body.Attribute3 && smtpServer['Attribute3'] != req.body.Attribute3) {
				json.Attribute3 = req.body.Attribute3;
				var obj = {};
				obj.column = 'Attribute3';
				obj.oldValue = smtpServer['Attribute3'];
				obj.newValue = req.body.Attribute3;
				obj.identifier = 'Platform_smtpServer_'+req.params.id;
				obj.modifiedBy = 'admin';
				obj.modifiedOn = new Date();
				updatedData.push(obj);
			}
			if (req.body.Attribute3Value && smtpServer['Attribute3Value'] != req.body.Attribute3Value) {
				json.Attribute3Value = req.body.Attribute3Value;
				var obj = {};
				obj.column = 'Attribute3Value';
				obj.oldValue = smtpServer['Attribute3Value'];
				obj.newValue = req.body.Attribute3Value;
				obj.identifier = 'Platform_smtpServer_'+req.params.id;
				obj.modifiedBy = 'admin';
				obj.modifiedOn = new Date();
				updatedData.push(obj);
			}
			if (req.body.Attribute4 && smtpServer['Attribute4'] != req.body.Attribute4) {
				json.Attribute4 = req.body.Attribute4;
				var obj = {};
				obj.column = 'Attribute4';
				obj.oldValue = smtpServer['Attribute4'];
				obj.newValue = req.body.Attribute4;
				obj.identifier = 'Platform_smtpServer_'+req.params.id;
				obj.modifiedBy = 'admin';
				obj.modifiedOn = new Date();
				updatedData.push(obj);
			}			
			if (req.body.Attribute4Value && smtpServer['Attribute4Value'] != req.body.Attribute4Value) {
				json.Attribute4Value = req.body.Attribute4Value;
				var obj = {};
				obj.column = 'Attribute4Value';
				obj.oldValue = smtpServer['Attribute4Value'];
				obj.newValue = req.body.Attribute4Value;
				obj.identifier = 'Platform_smtpServer_'+req.params.id;
				obj.modifiedBy = 'admin';
				obj.modifiedOn = new Date();
				updatedData.push(obj);
			}			
			if (req.body.Attribute5 && smtpServer['Attribute5'] != req.body.Attribute5) {
				json.Attribute5 = req.body.Attribute5;
				var obj = {};
				obj.column = 'Attribute5';
				obj.oldValue = smtpServer['Attribute5'];
				obj.newValue = req.body.Attribute5;
				obj.identifier = 'Platform_smtpServer_'+req.params.id;
				obj.modifiedBy = 'admin';
				obj.modifiedOn = new Date();
				updatedData.push(obj);
			}
			if (req.body.Attribute5Value && smtpServer['Attribute5Value'] != req.body.Attribute5Value) {
				json.Attribute5Value = req.body.Attribute5Value;
				var obj = {};
				obj.column = 'Attribute5Value';
				obj.oldValue = smtpServer['Attribute5Value'];
				obj.newValue = req.body.Attribute5Value;
				obj.identifier = 'Platform_smtpServer_'+req.params.id;
				obj.modifiedBy = 'admin';
				obj.modifiedOn = new Date();
				updatedData.push(obj);
			}
			
			/*
			 *	Update the data to database 
			 */
			if (Object.keys(json).length != 0) {
				
				json.UpdatedOn = new Date();
				json.UpdatedBy = Username;
				json.Username= Username;
												
				logger.info('SMTP Server : DAO : updateSMTPServerById : updating data : ' + JSON.stringify(json));
				SMTPServer.findOneAndUpdate({
					'CompanyId' : CompanyID,
					'SMTPServerId' : req.params.id,
				}, json, {
					'new' : true
				// returns updated entity if update successful, if false then old entry
				}, function(err, data) {
					if (err) {
						logger.error('SMTP Server : DAO : failed updateSMTPServerById : error :' + err);
						callback(err, null);
					} else {
						if(data != null) {
							logger.info('SMTP Server : DAO : updateSMTPServerById successful !');		
							/*
							 *	Call audit function for changed data 
							 */
							audit(req, res, updatedData);
							/*
							 *	Call function to send response to client 
							 */
							callback(null, data);
						} else {
							var err = new Error('Bad request data');
							logger.error('SMTP Server : DAO : failed updateSMTPServerById : error :' + err);
							callback(err, null);
						}
					}
				});
			} else {
				var err = new Error('Cannot update data');
				logger.error('SMTP Server : DAO : failed updateSMTPServerById : error :' + err);
				callback(err, null);
			}
		} else {
			var err = new Error('Failed to get SMTP Server details');
			logger.error('SMTP Server : DAO : failed updateSMTPServerById : error :' + err);
			callback(err, null);
		}
	}
	
	/*
	 * Get the original record from db before update.
	 */ 
	getSMTPServersBySMTPServerId(req, res, callbackUpdate);
	};



/*var updateSMTPServerById = function(req, res, callback) {
	logger.info('SMTP Server: DAO : received request : updateSMTPServerById : id : '
			+ req.params.id + ' & body: ' + JSON.stringify(req.body));
	
	var json = {};
	var Username = req.headers['username'];
	var CompanyID = req.headers['companyid'];	
	
	if (req.body.CompanyId) {
		json.CompanyId = req.body.CompanyId;
	}
	if (req.body.IPAddress) {
		json.IPAddress = req.body.IPAddress;
	}
	if (req.body.Port) {
		json.Port = req.body.Port;
	}
	if (req.body.MessageRetries) {
		json.MessageRetries = req.body.MessageRetries;
	}
	if (req.body.Attribute1) {
		json.Attribute1 = req.body.Attribute1;
	}
	if (req.body.Attribute1Value) {
		json.Attribute1Value = req.body.Attribute1Value;
	}
	if (req.body.Attribute2) {
		json.Attribute2 = req.body.Attribute2;
	}
	if (req.body.Attribute2Value) {
		json.Attribute2Value = req.body.Attribute2Value;
	}
	if (req.body.Attribute3) {
		json.Attribute3 = req.body.Attribute3;
	}
	if (req.body.Attribute3Value) {
		json.Attribute3Value = req.body.Attribute3Value;
	}
	if (req.body.Attribute4) {
		json.Attribute4 = req.body.Attribute4;
	}
	if (req.body.Attribute4Value) {
		json.Attribute4Value = req.body.Attribute4Value;
	}
	if (req.body.Attribute5) {
		json.Attribute5 = req.body.Attribute5;
	}
	if (req.body.Attribute5Value) {
		json.Attribute5Value = req.body.Attribute5Value;
	}
	
	
	if (Object.keys(json).length != 0) {
		json.updatedOn = new Date();
		json.updatedBy = Username;
		logger.info('SMTP Server : DAO : updateSMTPServerById : updating data : ' + JSON.stringify(json));
		SMTPServer.findOneAndUpdate({
			'CompanyId' : CompanyID,
			'SMTPServerId' : req.params.id,
		}, json, {
			'new' : true
		// returns updated entity if update successful
		}, function(err, data) {
			if (err) {
				logger.error('SMTP Server : DAO : failed updateSMTPServerById : error :' + err);
				callback(err, null);
			} else {
				if(data != null) {
					logger.info('SMTP Server : DAO : updateSMTPServerById successful !');
					callback(null, data);
				} else {
					var err = new Error('Bad request data');
					logger.error('SMTP Server : DAO : failed updateSMTPServerById : error :' + err);
					callback(err, null);
				}
			}
		});
	} else {
		var err = new Error('Cannot update data');
		logger.error('SMTP Server : DAO : failed updateSMTPServerById : error :' + err);
		callback(err, null);
	}		
};*/

/*
 * Get smtp servers by company id from header
 */
var getSMTPServerDetails = function(req, res, callback) {
	logger.info('SMTP Server : DAO : received request : getSMTPServerDetails : id : ');
	var CompanyId = req.headers['companyid'];	
	SMTPServer.findOne({
		'CompanyId' : CompanyId	
	}, function(err, data) {
		if (err) {
			callback(err, data);
		} else {
			if (data) {
				callback(err, data);
			} else {
				var err = new Error('Invalid company id');
				err.status = 404;
				callback(err, data);
			}
		}
	});
};


module.exports.addNewSMTPServer = addNewSMTPServer;
module.exports.getSMTPServersByCompanyId = getSMTPServersByCompanyId;
module.exports.getSMTPServersBySMTPServerId=getSMTPServersBySMTPServerId;
module.exports.updateSMTPServerById=updateSMTPServerById;
module.exports.getSMTPServerDetails= getSMTPServerDetails;
