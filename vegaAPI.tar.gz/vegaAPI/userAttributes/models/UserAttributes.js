var mongoose = require('../../common/MongoDbConnection').mongoose;
var autoIncrement = require('mongoose-auto-increment');
var logger = require('../../common/logger').log;
var connection = mongoose.connection;
autoIncrement.initialize(connection);

/*
 * logging format followed: logger.info(<module_name>: <component name> :
 * <description> : <long_description> : <data/params/errors>);
 */


/*
 * Define schema
 */
var userAttributesSchema = mongoose.Schema({
    id: Number,
	username: { type: String, unique: true},
	 attributes: [{
		 attributeKey: String,		 
		 attributeValue: String
	 }] 
});

/*
 * Add Auto increment plugin for field companyId
 */
userAttributesSchema.plugin(autoIncrement.plugin, { model: 'user_attributes', field: 'id', startAt: 1 });

/*
 * Setters
 */
userAttributesSchema.methods.setUsername = function(username) {
	this.username = username;
};

userAttributesSchema.methods.setAttributes = function(attributes) {
	this.attributes = attributes;
};

/*
 * Getters
 */
userAttributesSchema.methods.getUsername = function() {
	return this.username;
};

userAttributesSchema.methods.getAttributes = function() {
	return this.attributes;
};

/*
 * Create collection/model in mongo db using Schema
 */
var UserAttributes = mongoose.model('user_attributes', userAttributesSchema);

module.exports = UserAttributes;