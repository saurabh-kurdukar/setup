var userAttributeDao = require('../dao/UserAttributeDAO');
var logger = require('../../common/logger').log;
/*
 * logging format followed: logger.info(<module_name>: <component name> : <description> : [<long_description>] : <data/params/errors>);
 */

/*
 *Add new User Attributes
 */
var addNewUserAttributes = function(req, res, callback) {
	logger.info('UserAttributes : controller : received request : addNewUserAttributes : body : '+JSON.stringify(req.body));
	userAttributeDao.addNewUserAttributes(req, res, callback);
};

/*
* 	Get  user Attributes by username and attribute name
*/
var getUserAttributeByAttributeName = function(req, res, callback) {
	logger.info('UserAttributes : controller : received request : getUserAttributeByAttributeName : username : '+req.query.username);
	userAttributeDao.getUserAttributeByAttributeName(req, res, callback);
};

/*
* 	Get  user Attributes by username
*/
var getUserAttributeByUsername = function(req, res, callback) {
	logger.info('UserAttributes : controller : received request : getUserAttributeByUsername : username : '+req.params.username);
	userAttributeDao.getUserAttributeByUsername(req, res, callback);
};

/*
 * Update User Attribute details
 */
var updateUserAttributeByUsername = function(req, res, callback) {
	logger.info('UserAttributes : controller : received request : updateUserAttributeByUsername : username : '+req.params.username);
	userAttributeDao.updateUserAttributeByUsername(req, res, callback);
};

module.exports.addNewUserAttributes = addNewUserAttributes;
module.exports.getUserAttributeByAttributeName= getUserAttributeByAttributeName;
module.exports.getUserAttributeByUsername= getUserAttributeByUsername;
module.exports.updateUserAttributeByUsername= updateUserAttributeByUsername;
