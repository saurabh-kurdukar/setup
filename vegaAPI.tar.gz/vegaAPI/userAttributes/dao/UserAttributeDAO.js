var db = require('../../common/MongoDbConnection');
var UserAttributes = require('../models/UserAttributes');
var logger = require('../../common/logger').log;
var audit = require('../../common/Audit').audit;
var mongoose = db.mongoose;
/*
 * logging format followed: logger.info(<module_name>: <component name> : <description> : [<long_description>] : <data/params/errors>);
 */

/*
 *Add new SMS Gateway Info
 */
var addNewUserAttributes = function(req, res, callback) {
	logger.info('UserAttributes : DAO : received request : addNewUserAttributes : body : '+ JSON.stringify(req.body));
	
	var userattributes = new UserAttributes();
	
	userattributes.setUsername(req.body.username);
	userattributes.setAttributes(req.body.attributes)
		
	userattributes.save(function(err, data) {
						if (err) {
							logger.error('UserAttributes : DAO : failed addNewUserAttributes : error : ' + err);
							callback(err, null);
						} else {
							logger.info('UserAttributes : DAO : addNewUserAttributes successful !');
							callback(null, data);
						}
					});
	};
	
/*
* 	Get  user Attributes by username and attribute name
*/
	var getUserAttributeByAttributeName = function(req, res, callback) {				
		logger.info('UserAttributes : DAO : received request : getUserAttributeByAttributeName : username : '+req.query.username);
		UserAttributes.findOne({
			'username' : req.query.username,
			'attributes.attributeKey': req.query.attribute
		}, function(err, data) {
			if (err) {
				logger.error('UserAttributes : DAO : failed getUserAttributeByAttributeName : error : ' + err);
				callback(err, null);
			} else {
				if (data!= null) {
					logger.info('UserAttributes : DAO : getUserAttributeByAttributeName successful !');
					callback(null, data);
				} else {
					var err = new Error('Invalid username or attribute name');
					err.status = 404;
					logger.error('UserAttributes : DAO : failed getUserAttributeByAttributeName : error : '+ err);
					callback(err, null);
				}
			}
		});
	};	
	
/*
* 	Get  user Attributes by username
*/
	var getUserAttributeByUsername = function(req, res, callback) {				
		logger.info('UserAttributes : DAO : received request : getUserAttributeByUsername : username : '+req.params.username);
		UserAttributes.findOne({
			'username' : req.params.username,			
		}, function(err, data) {
			if (err) {
				logger.error('UserAttributes : DAO : failed getUserAttributeByUsername : error : ' + err);
				callback(err, null);
			} else {
				if (data!= null) {
					logger.info('UserAttributes : DAO : getUserAttributeByUsername successful !');
					callback(null, data);
				} else {
					var err = new Error('Invalid username');
					err.status = 404;
					logger.error('UserAttributes : DAO : failed getUserAttributeByUsername : error : '+ err);
					callback(err, null);
				}
			}
		});
	};		

/*
 * Update User Attribute details
 */
var updateUserAttributeByUsername = function(req, res, callback) {
	logger.info('UserAttributes : DAO : received request : updateUserAttributeByUsername : (username: '+req.params.username+', body: '+JSON.stringify(req.body)+')');
	
	/*
	 * Callback function after getting original record to update with new values.
	 */ 
	var callbackUpdate = function(err, data) {	
		if(err) {
			logger.error('UserAttributes : DAO : failed updateUserAttributeByUsername : error :' + err);
			callback(err, null);
		} else if(data != null) {
			/*
			 *	Compare updatable fields values in db with request data
			 *	Add those fields in temproary object which are having new values
			 */			
			var userattributes = data;
			var json = {};
			var updatedData = [];
			if (req.body.attributes && userattributes['attributes'] != req.body.attributes) {
				json.attributes = req.body.attributes;
				var obj = {};				
				obj.column = 'attributes';
				obj.oldValue = userattributes['attributes'];
				obj.newValue = req.body.attributes;
				obj.identifier = 'Platform_userattributes_'+req.params.username;
				obj.modifiedBy = 'admin';
				obj.modifiedOn = new Date();
				updatedData.push(obj);
			}
			
			/*
			 *	Update the data to database 
			 */
			if (Object.keys(json).length != 0) {				
				logger.info('UserAttributes : DAO : updateUserAttributeByUsername : updating data : ' + JSON.stringify(json));
				UserAttributes.findOneAndUpdate({
					'username' : req.params.username
				}, json, {
					'new' : true
				// returns updated entity if update successful, if false then old entry
				}, function(err, data) {
					if (err) {
						logger.error('UserAttributes : DAO : failed updateUserAttributeByUsername : error :' + err);
						callback(err, null);
					} else {
						if(data != null) {
							logger.info('UserAttributes : DAO : updateUserAttributeByUsername successful !');		
							/*
							 *	Call audit function for changed data 
							 */
							audit(req, res, updatedData);
							/*
							 *	Call function to send response to client 
							 */
							callback(null, data);
						} else {
							var err = new Error('Bad request data');
							logger.error('UserAttributes : DAO : failed updateUserAttributeByUsername : error :' + err);
							callback(err, null);
						}
					}
				});
			} else {
				var err = new Error('Cannot update data');
				logger.error('UserAttributes : DAO : failed updateUserAttributeByUsername : error :' + err);
				callback(err, null);
			}
		} else {
			var err = new Error('Failed to get UserAttributes details');
			logger.error('UserAttributes : DAO : failed updateUserAttributeByUsername : error :' + err);
			callback(err, null);
		}
	}
	
	/*
	 * Get the original record from db before update.
	 */ 
	getUserAttributeByUsername(req, res, callbackUpdate);
	
};	
		
module.exports.addNewUserAttributes = addNewUserAttributes;
module.exports.getUserAttributeByAttributeName= getUserAttributeByAttributeName;
module.exports.getUserAttributeByUsername= getUserAttributeByUsername;
module.exports.updateUserAttributeByUsername= updateUserAttributeByUsername;





