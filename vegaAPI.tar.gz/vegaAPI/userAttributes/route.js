var express = require('express');
var userAttributeController = require('./controller/UserAttributeController');
var logger = require('../common/logger').log;
var ErrorResponse = require('../common/ErrorResponse').ErrorResponse;
var router = express.Router();

/*
 * logging format followed: logger.info(<module_name>: <component name> : <description> : [<long_description>] : <data/params/errors>);
 */

/*
 *Add new User Attributes
 */
router.post('/', function(req, res){
	logger.info('UserAttributes : router : received request : addNewUserAttributes : body : '+JSON.stringify(req.body));
	userAttributeController.addNewUserAttributes(req, res, function(err, data) {
        if(err){
        	logger.error('UserAttributes : router : failed addNewUserAttributes : error : '+err);
        	var error = new ErrorResponse();
        	if(err.name == 'ValidationError'){
        		error.setErrorMessage(err.errors[Object.keys(err.errors)[0]].message);
        	} else {
        		error.setErrorMessage(err.message);
        	}
        	error.setErrorCode("UA001");        	
        	error.setHttpResponseCode(500);
            res.status(500).end(JSON.stringify(error));
        }else{
        	
        	logger.info("UserAttributes : router : addNewUserAttributes successful !");
        	res.status(200).end(JSON.stringify(data));
        }
    });
});

/*
* 	Get  user Attributes by username and attribute name
*/
router.get('/', function(req, res){
	logger.info('UserAttributes : router : received request : getUserAttributeByAttributeName : username : '+req.query.username);
	userAttributeController.getUserAttributeByAttributeName(req, res, function(err, data) {
        if(err){
        	logger.error('UserAttributes : router : failed getUserAttributeByAttributeName : error : '+err);
        	var error = new ErrorResponse();
        	if(err.name == 'ValidationError'){
        		error.setErrorMessage(err.errors[Object.keys(err.errors)[0]].message);
        	} else {
        		error.setErrorMessage(err.message);
        	}
        	error.setErrorCode("UA002");        	
        	error.setHttpResponseCode(500);
            res.status(500).end(JSON.stringify(error));
        }else{
        	
        	logger.info("UserAttributes : router : getUserAttributeByAttributeName successful !");
        	res.status(200).end(JSON.stringify(data));
        }
    });
});

/*
* 	Get  user Attributes by username
*/
router.get('/:username', function(req, res){
	logger.info('UserAttributes : router : received request : getUserAttributeByUsername : username : '+req.params.username);
	userAttributeController.getUserAttributeByUsername(req, res, function(err, data) {
        if(err){
        	logger.error('UserAttributes : router : failed getUserAttributeByUsername : error : '+err);
        	var error = new ErrorResponse();
        	if(err.name == 'ValidationError'){
        		error.setErrorMessage(err.errors[Object.keys(err.errors)[0]].message);
        	} else {
        		error.setErrorMessage(err.message);
        	}
        	error.setErrorCode("UA003");        	
        	error.setHttpResponseCode(500);
            res.status(500).end(JSON.stringify(error));
        }else{
        	
        	logger.info("UserAttributes : router : getUserAttributeByUsername successful !");
        	res.status(200).end(JSON.stringify(data));
        }
    });
});

/*
 * Update User Attribute details
 */
 router.put('/:username', function(req, res){
	logger.info('UserAttributes : router : received request : updateUserAttributeByUsername : username : '+req.params.username);
	userAttributeController.updateUserAttributeByUsername(req, res, function(err, data) {
        if(err){
        	logger.error('UserAttributes : router : failed updateUserAttributeByUsername : error : '+err);
        	var error = new ErrorResponse();
        	if(err.name == 'ValidationError'){
        		error.setErrorMessage(err.errors[Object.keys(err.errors)[0]].message);
        	} else {
        		error.setErrorMessage(err.message);
        	}
        	error.setErrorCode("UA004");        	
        	error.setHttpResponseCode(500);
            res.status(500).end(JSON.stringify(error));
        }else{
        	
        	logger.info("UserAttributes : router : updateUserAttributeByUsername successful !");
        	res.status(200).end(JSON.stringify(data));
        }
    });
});
 
module.exports = router;