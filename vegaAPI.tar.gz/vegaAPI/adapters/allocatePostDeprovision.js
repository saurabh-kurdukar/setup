var cartDao = require('../cart/dao/CartDAO');
var logger = require('../common/logger').log;

/**
 * New node file
 */
function processMethod(req, callback) {
	logger.info('adapters : allocatePostDeprovision : in processMethod : (orgId:'+req.orgId+', experienceId:'+req.experienceId+')');	
	if(req.orgId && req.experienceId) {
		req.body = {
			orgId : req.orgId,
			expId : req.experienceId
		};
		cartDao.AddCartItemByOrgId(req, null, function(err, cartRes) {
			if(err) {
				logger.error('adapter : failed allocatePostDeprovision : error : '+JSON.stringify(err));			
			} else {
				logger.info('adapters : allocatePostDeprovision : added experience back to cart.');
			}
			callback(null, 'completed processMethod for allocatePostDeprovision');
		});	
	} else {
		callback(null, 'completed processMethod for allocatePostDeprovision');
	}
}

module.exports.processMethod = processMethod;