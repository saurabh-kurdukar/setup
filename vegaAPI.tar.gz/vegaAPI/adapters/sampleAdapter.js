/**
 * New node file
 */
function processMethod(req, callback) {
	console.log('in processMethod for addUserPostProcess' );
	req.someValue = "someValue";
	callback(null, 'completed processMethod for addUserPostProcess');
}

module.exports.processMethod = processMethod;