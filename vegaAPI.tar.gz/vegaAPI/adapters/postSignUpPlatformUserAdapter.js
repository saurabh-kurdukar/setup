/**
 * New node file
 */

var logger = require('../common/logger').log;
var config = require('../common/Config');
var companyDAO = require('../company/dao/CompanyDAO');
var provisionGroup = require('../provision/controller/provision-group');
var provisionUser = require('../provision/controller/provision-user');
var userRoleDao= require('../userRoles/dao/UserRoleDAO');
var ForgeRockGetToken = require('../common/ForgeRockGetToken');
var userRoleDelegate= require('../userRoles/delegate/UserRoleDelegate');
var radiaHelper = require('../radia-adapter/client');

var mandatoryApps = config.MANDATORY_APPS;
var roles = ["SuperAdmin", "Admin"];


function addCompany(req, callback) {		
	logger.info('adapters : postSignUpPlatformUserAdapter : in addCompany');
	companyDAO.addNewCompanyForPlatformUser(req, null, function(err, company) {
        if (err) {
          logger.info('adapters : postSignUpPlatformUserAdapter : failed addCompany : err :'+JSON.stringify(err));
          callback(err);
        } else {
        	logger.info('adapters : postSignUpPlatformUserAdapter : addCompany successful!')
        	req.company = company;
        	callback(null, company);
        }
    });	
}

function addUserOnRadia(req, callback) {
	var company = req.company;
    var referenceCompanyId = req.referenceCompanyId;
    provisionGroup.provisionGroup(company, function(err) {
        if (err) {
        	logger.error('adapters : postSignUpPlatformUserAdapter : failed provisionGroup : error : ' + err);
        	return callback(err);
        } else {
			  //console.log("provision group successfull");
			  //radia to add user
			  var json = {};
			  json.username = req.body.username;
			  json.userpassword = req.body.userpassword;
			  json.mail = req.body.mail;
			  json.givenName = req.body.givenName;
			  json.sn = req.body.sn;
			  json.telephoneNumber = req.body.telephoneNumber;
			  json.companyId = referenceCompanyId;					
			  provisionUser.provisionUser(json, function(err) {
			        if (err) {
			              logger.error('adapters : postSignUpPlatformUserAdapter : failed provisionUser : error : ' + err);
			              //console.log(err);
			              var error = new Error('User already register with radia');
			              error.status = 409;
			              return callback(error);
			        } else {
			        	  //console.log("provision user successful");
			        	  return callback(null, 'add user on radia successful');
			        }
			  });
        }
     });
}

function assignAdditionalRoles(req, callback) {	  
	  if(roles.length) {
		  roles.forEach(function(roleName, index, array){
		  getUserReq = req;
		  getUserReq.params.rolename = roleName;
		  userRoleDao.getUsersByRoleName(getUserReq, null, function(err, getUsersResponse){
			if(err) {
				logger.error('adapters : postSignUpPlatformUserAdapter : assignAdditionalRoles : failed getUsersByRoleName: error : ' + err);
				return callback(err);
			} else {
				//console.log("PlatformUser : Controller : Get Users By RoleName : " + JSON.stringify(getUsersResponse));
				//update on forgerock & then in db
				ForgeRockGetToken.getToken(function(err, tokenData) {
					if(err) {
						logger.error('adapters : postSignUpPlatformUserAdapter : assignAdditionalRoles : failed ForgeRockGetToken : error : ' + err);
						return callback(err);
					} else {
						//logger.info("PlatformUser : Controller : ForgeRockGetTokenData " + tokenData);
						var usernamesArray=[];
						//console.log('req.body.username='+JSON.stringify(req.body.username));
						usernamesArray = getUsersResponse[0].username;
						usernamesArray.push(req.body.username);
						//console.log('usernamesArray='+usernamesArray);
						var updateRoleReq = req;
						updateRoleReq.headers['access-token'] = tokenData.tokenId ;
						updateRoleReq.params.rolename = roleName;
						updateRoleReq.body.usernamesArray = usernamesArray;				
						//console.log('updateRoleReq.body.usernamesArray='+JSON.stringify(updateRoleReq.body.usernamesArray));
						userRoleDelegate.updateRoleUsersByRoleName(updateRoleReq, null, function(err, updateroleresponse){
							if(err) {
								logger.error('PlatformUser : Controller : failed updateRoleUsersByRoleName: error : ' + err);
								return callback(err);
							} else {								
								var updateRequest=req;
								updateRequest.body.usernamesArray= updateroleresponse.groupUsers;
								updateRequest.params.rolename= updateroleresponse.groupName;		  
								userRoleDao.updateRoleUsersByRoleName(updateRequest, null, function(err, data){
									if(err) {
										logger.error('PlatformUser : Controller : failed updateRoleUsersByRoleName: error : ' + err);
										return callback(err);
									}
									if(index === array.length-1) {
										logger.info('PlatformUser : Controller : updateRoleUsersByRoleName successful !');	
										return callback(null, 'assign roles to user successful');
									}
								});
							}
						});
						}
						});
					}
		  		});
		  });
	  } else {
		  callback(null, 'no additional roles to assign.');
	  }
}

function associateMandatoryAppsOnRadia(req, callback) {    
    //EDR:1787 : Mandatory Apps assignment to the group
	req.body.mandatoryApps = mandatoryApps.filter(function(e){ return e.replace(/(\r\n|\n|\r)/gm,"")});
	//console.log("Mandatory req : ", req.body);
	radiaHelper.associateMandatoryApplicationsInRadia(req.body, function(err, data) {
		if(err) {
			logger.error('adapters : postSignUpPlatformUserAdapter : failed associate mandatory app : error : ' + err);
			return callback(err);
		} else {
			logger.info('adapters : postSignUpPlatformUserAdapter : associate mandatory apps successful!');
			return callback(null, 'association successful');
		}
   });
}


module.exports.addCompany = addCompany;
module.exports.addUserOnRadia = addUserOnRadia;
module.exports.assignAdditionalRoles = assignAdditionalRoles;
module.exports.associateMandatoryAppsOnRadia = associateMandatoryAppsOnRadia;











