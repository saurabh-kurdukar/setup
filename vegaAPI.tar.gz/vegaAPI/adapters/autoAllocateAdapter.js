var experienceDao = require('../experience/dao/ExperienceDAO');
var cartDao = require('../cart/dao/CartDAO');
var logger = require('../common/logger').log;
	
/**
 * New node file
 */
function processMethod(req, callback) {
	//console.log('req.orgId='+req.orgId);
	logger.info('adapters : autoAllocateAdapter : in processMethod for addPlatformUserPostProcess');	
	experienceDao.getExperiencesByStatus('PUBLISHED', function(err, experiences) {
		if(err) {
			logger.error('adapters : autoAllocateAdapter : processMethod : error : '+JSON.stringify(err));
			return callback(null, 'processMethod: no experiences exist.');			
		}
		var addToCart = [];		
		experiences.forEach(function(experience, index, array) {
			var addexperience = {};
			addexperience.expId = experience.id;
			addexperience.orgId = req.orgId;
			addToCart.push(addexperience);		
		});	
		logger.info('adapters : autoAllocateAdapter : processMethod : experiences to add to cart : '+JSON.stringify(addToCart));
		cartDao.AddMultipleCartItemByOrgId(addToCart, function(err, data) {
			if(err) {
				logger.error('adapters : autoAllocateAdapter : processMethod : error : '+JSON.stringify(err));
				return callback(null, 'processMethod: failed to add to cart.');				
			}
			callback(null, 'processMethod for addPlatformUserPostProcess completed.');
		});
	});	
}

module.exports.processMethod = processMethod;