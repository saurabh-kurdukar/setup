var express = require('express');
var messageController = require('./controller/MessageController');
var logger = require('../common/logger').log;
var ErrorResponse = require('../common/ErrorResponse').ErrorResponse;
var router = express.Router();
var upload = require('./helpers/uploadFile');
var config = require('../common/Config');

/*
 * logging format followed: logger.info(<module_name>: <component name> : <description> : [<long_description>] : <data/params/errors>);
 */

/*
 * Add new message details
 */
router.post('/', upload.any(), function(req, res) {

	if(req.fileValidationError) {
		logger.info('SampleMsg : router : received request : addNewMessage : error : ' + req.fileValidationError);
		var error = new ErrorResponse();
		error.setErrorMessage(req.fileValidationError);
		error.setErrorCode("SMG0001");
		error.setHttpResponseCode(500);
		res.status(500).end(JSON.stringify(error));
	}
	else if(req.files.length == 0) {
		logger.info('SampleMsg : router : received request : addNewMessage : error : No file found');
		var error = new ErrorResponse();
		error.setErrorMessage("No file found");
		error.setErrorCode("SMG0001");
		error.setHttpResponseCode(500);
		res.status(500).end(JSON.stringify(error));
	}
	else {
		var messageFile = req.files[0];
		var messageFileLocation = "";
		messageFileLocation = config.BINARY_STORAGE.BASE_URL + config.BINARY_STORAGE.MESSAGE + messageFile.filename;
		req.body.messageFileLocation = messageFileLocation;

		logger.info('SampleMsg : router : received request : addNewMessage : body : ' + JSON.stringify(req.body));
		messageController.addNewMessage(req, res, function(err, data) {
			if(err) {
				logger.error('SampleMsg router : failed addNewMessage : error : '+err);
				var error = new ErrorResponse();
				if(err.name == 'ValidationError'){
					error.setErrorMessage(err.errors[Object.keys(err.errors)[0]].message);
				} else {
					error.setErrorMessage(err.message);
				}
				error.setErrorCode("SMG0001");
				var errorStatus = 500;
				if(err.status) {
					errorStatus = err.status;
				}
				error.setHttpResponseCode(errorStatus);
				res.status(errorStatus).end(JSON.stringify(error));
			}
			else {
				logger.info('SampleMsg : router : addNewMessage successful !');
				res.status(200).end(JSON.stringify(data));
			}
		});
	}
});

/*
 * Get all messages
 */
router.get('/', function(req, res) {
	logger.info('SampleMsg : router : received request : getAllMessages');
	messageController.getAllMessages(req, res, function(err, data) {
		if(err) {
			logger.error('SampleMsg : router : failed getAllMessages : error : ' + err);
			var error = new ErrorResponse();
			error.setErrorCode("SMG0002");
			error.setErrorMessage(err.message);
			var errorStatus = 500;
			if(err.status) {
				errorStatus = err.status;
			}
			error.setHttpResponseCode(errorStatus);
			res.status(errorStatus).end(JSON.stringify(error));
		}
		else {
			logger.info('SampleMsg : router : getAllMessages successful!');
			res.status(200).end(JSON.stringify(data));
		}
	})
})

/*
 * Search sample messages
 */
router.get('/search', function(req, res) {
	logger.info('SampleMsg : router : received request : searchMessages : text : ' + req.query.text);
	messageController.searchMessages(req, res, function(err, data) {
		if(err) {
			logger.error('SampleMsg : router : failed searchMessages : error : ' + err);
			var error = new ErrorResponse();
			error.setErrorCode("SMG0006");
			error.setErrorMessage(err.message);
			var errorStatus = 500;
			if(err.status) {
				errorStatus = err.status;
			}
			error.setHttpResponseCode(errorStatus);
			res.status(errorStatus).end(JSON.stringify(error));
		}
		else {
			logger.info('SampleMsg : router : searchMessages successful!');
			res.status(200).end(JSON.stringify(data));
		}
	})
})

/*
 * Get message by id
 */
router.get('/:id', function(req, res) {
	logger.info('SampleMsg : router : received request : getMessageById : id : ' + req.params.id);
	messageController.getMessageById(req, res, function(err, data) {
		if(err) {
			logger.error('SampleMsg : router : failed getMessageById : error : ' + err);
			var error = new ErrorResponse();
			error.setErrorCode("SMG0003");
			error.setErrorMessage(err.message);
			var errorStatus = 500;
			if(err.status) {
				errorStatus = err.status;
			}
			error.setHttpResponseCode(errorStatus);
			res.status(errorStatus).end(JSON.stringify(error));
		}
		else {
			logger.info('SampleMsg : router : getMessageById successful!');
			res.status(200).end(JSON.stringify(data));
		}
	})
})

/*
 * Update message by id
 */
router.put('/:id', upload.any(), function(req, res) {
	logger.info('SampleMsg : router : received request : updateMessageById : id : ' + req.params.id);
	messageController.updateMessageById(req, res, function(err, data) {
		if(err) {
			logger.error('SampleMsg : router : failed updateMessageById : error : ' + err);
			var error = new ErrorResponse();
			error.setErrorCode("SMG0004");
			error.setErrorMessage(err.message);
			var errorStatus = 500;
			if(err.status) {
				errorStatus = err.status;
			}
			error.setHttpResponseCode(errorStatus);
			res.status(errorStatus).end(JSON.stringify(error));
		}
		else {
			logger.info('SampleMsg : router : updateMessageById successful!');
			res.status(200).end(JSON.stringify(data));
		}
	})
})

/*
 * Delete message by id
 */
router.delete('/:id', function(req, res) {
	logger.info('SampleMsg : router : received request : deleteMessageById : id : ' + req.params.id);
	messageController.deleteMessageById(req, res, function(err, data) {
		if(err) {
			logger.error('SampleMsg : router : failed deleteMessageById : error : ' + err);
			var error = new ErrorResponse();
			error.setErrorCode("SMG0005");
			error.setErrorMessage(err.message);
			var errorStatus = 500;
			if(err.status) {
				errorStatus = err.status;
			}
			error.setHttpResponseCode(errorStatus);
			res.status(errorStatus).end(JSON.stringify(error));
		}
		else {
			logger.info('SampleMsg : router : deleteMessageById successful!');
			res.status(200).end(JSON.stringify(data));
		}
	})
})


module.exports = router;
