var messageDao = require('../dao/MessageDAO');
var logger = require('../../common/logger').log;

/*
 * logging format followed: logger.info(<module_name>: <component name> : <description> : [<long_description>] : <data/params/errors>);
 */


/*
 * Add new message details
 */
var addNewMessage = function(req, res, callback) {
	logger.info('SampleMsg controller : received request : addNewMessage : body : ' + JSON.stringify(req.body));
	messageDao.addNewMessage(req, res, callback);
};

/*
 * Get all messages
 */
var getAllMessages = function(req, res, callback) {
	logger.info('SampleMsg : controller : received request : getAllMessages');
	messageDao.getAllMessages(req, res, callback);
}

/*
 * Get message by id
 */
var getMessageById = function(req, res, callback) {
	logger.info('SampleMsg : controller : received request : getMessageById : id : ' + req.params.id);
	messageDao.getMessageById(req, res, callback);
}

/*
 * Update message by id
 */
var updateMessageById = function(req, res, callback) {
	logger.info('SampleMsg : controller : received request : updateMessageById : id : ' + req.params.id);
	messageDao.updateMessageById(req, res, callback);
}

/*
 * Delete message by id
 */
var deleteMessageById = function(req, res, callback) {
	logger.info('SampleMsg : controller : received request : deleteMessageById : id : ' + req.params.id);
	messageDao.deleteMessageById(req, res, callback);
}

/*
 * Search sample messages
 */
var searchMessages = function(req, res, callback) {
	logger.info('SampleMsg : controller : received request : searchMessages : text : ' + req.query.text);
	messageDao.searchMessages(req, res, callback);
}


module.exports.addNewMessage = addNewMessage;
module.exports.getAllMessages = getAllMessages;
module.exports.getMessageById = getMessageById;
module.exports.updateMessageById = updateMessageById;
module.exports.deleteMessageById = deleteMessageById;
module.exports.searchMessages = searchMessages;
