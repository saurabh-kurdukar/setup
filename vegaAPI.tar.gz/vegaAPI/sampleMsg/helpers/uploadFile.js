var multer  = require('multer');
var fs = require('fs');
var config = require('../../common/Config');

var filePath = config.BINARY_STORAGE.BASE_PATH;

if(!fs.existsSync(filePath)) {
  fs.mkdirSync(filePath);
}
if(!fs.existsSync(filePath + config.BINARY_STORAGE.MESSAGE)) {
  fs.mkdirSync(filePath + config.BINARY_STORAGE.MESSAGE);
}

var storage = multer.diskStorage({
  destination: function (req, file, cb) {
    cb(null, filePath + config.BINARY_STORAGE.MESSAGE);
  },
  filename: function (req, file, cb) {
  	var ext = file.originalname.split('.').pop();
  	var timestamp = new Date().getTime();
  	var fileName = "file_" + timestamp + "." + ext;
  	cb(null, fileName);
  }
});

function fileFilter(req, file, cb) {
	var ext = file.originalname.split('.').pop();
	if(!file.fieldname) {
    req.fileValidationError = 'No fieldname provided for the file';
	  cb(null, false);
	}
  else {
    cb(null, true);
  }
}

var upload = multer({ storage: storage,  fileFilter: fileFilter });

module.exports = upload;
