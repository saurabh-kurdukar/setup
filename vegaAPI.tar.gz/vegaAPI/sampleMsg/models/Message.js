var mongoose = require('../../common/MongoDbConnection').mongoose;
var autoIncrement = require('mongoose-auto-increment');
var logger = require('../../common/logger').log;
var connection = mongoose.connection;
autoIncrement.initialize(connection);
/*
 * logging format followed: logger.info(<module_name>: <component name> :
 * <description> : <long_description> : <data/params/errors>);
 */


/*
 * Define schema
 */
var messageSchema = mongoose.Schema({
  id: Number,
	name: { type : String , unique : true, required : true },
  description: String,
  version: String,
  tags: [ String ],
  messageFileLocation: String,
  createdBy: String,
  updatedBy: String,
  createdOn: { type: Date, default: Date.now },
  updatedOn: { type: Date, default: Date.now }
});


// logger.info('Message : model : created schema : Message :'+JSON.stringify(messageSchema.paths));

/*
 * Add Auto increment plugin for field message id
 */
messageSchema.plugin(autoIncrement.plugin, { model: 'Message', field: 'id', startAt: 1 });

// Create index for text search
messageSchema.index({name:"text", description: "text", tags: "text"});

/*
 * Create collection/model in mongo db using Schema
 */
var Message = mongoose.model('SampleMsg', messageSchema);
logger.info('Message : model : created model : Message : ' + Message);


module.exports = Message;
