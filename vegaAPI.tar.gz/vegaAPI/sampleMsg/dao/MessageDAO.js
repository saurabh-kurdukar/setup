var Message = require('../models/Message');
var logger = require('../../common/logger').log;
var config = require('../../common/Config');
var upload = require('../helpers/uploadFile');
var fs = require('fs');

/*
 * logging format followed: logger.info(<module_name>: <component name> : <description> : [<long_description>] : <data/params/errors>);
 */


/*
 * Add new message details
 */
var addNewMessage = function(req, res, callback) {
	logger.info('SampleMsg : DAO : received request : addNewMessage : body : ' + JSON.stringify(req.body));
	if(req.body.createdBy) {
		req.body.updatedBy = req.body.createdBy;
	}
	var message = new Message(req.body);

	var regex = new RegExp(['^', req.body.name, '$'].join(''), 'i');

	Message.findOne({
		name: regex
	}, function(err, data) {
		if(err) {
			logger.error('SampleMsg : DAO : failed addNewMessage : get by id : error : ' + err);
			callback(err, null);
		}
		else if(data) {
			var err = new Error('Message name already exists');
			err.status = 409;
			logger.error('SampleMsg : DAO : failed addNewMessage : error : Name already exists');
			callback(err, null);
		}
		else {
			message.save(function(err, data) {
				if (err) {
					logger.error('SampleMsg : DAO : failed addNewMessage : error : ' + err);
					callback(err, null);
				} else if(data != null){
					logger.info('SampleMsg : DAO : addNewMessage successful !');
					callback(null, data);
				} else {
					var err = new Error('Failed to add new message details');
					logger.error('SampleMsg : DAO : failed addNewMessage : error : '+ err);
					callback(err, null);
				}
			});
		}
	})
};

/*
 * Get all messages
 */
var getAllMessages = function(req, res, callback) {
	logger.info('SampleMsg : DAO : received request : getAllMessages');

	var query = {};
	var regex;
	if(req.query.name) {
		logger.info('SampleMsg : DAO : received request : getAllMessages : name : ' + req.query.name);
		var messageName = decodeURIComponent(req.query.name);
		regex = new RegExp(['^', messageName, '$'].join(''), 'i');
		query.name = regex;
	}

	Message.find(query, function(err, data) {
		if(err) {
			logger.error('SampleMsg : DAO : failed getAllMessages : error : ' + err);
			callback(err, null);
		}
		else {
			if (data.length != 0) {
				logger.info('SampleMsg : DAO : getAllMessages successful !');
				callback(null, data);
			} else {
				var err = new Error('No records found');
				err.status = 404;
				logger.error('SampleMsg : DAO : failed getAllMessages : error : ' + err);
				callback(err, null);
			}
		}
	})
}

/*
 * Get message by id
 */
var getMessageById = function(req, res, callback) {
	logger.info('SampleMsg : DAO : received request : getMessageById : id : ' + req.params.id);

	Message.findOne({
		id: req.params.id
	}, function(err, data) {
		if(err) {
			logger.error('SampleMsg : DAO : failed getMessageById : error : ' + err);
			callback(err, null);
		}
		else {
			if(data) {
				logger.info('SampleMsg : DAO : getMessageById successful !');
				callback(null, data);
			} else {
				var err = new Error('Invalid message id');
				err.status = 404;
				logger.error('SampleMsg : DAO : failed getMessageById : error : ' + err);
				callback(err, null);
			}
		}
	})
}

/*
 * Update message by id
 */
var updateMessageById = function(req, res, callback) {
	logger.info('SampleMsg : DAO : received request : updateMessageById : id : ' + req.params.id);

	var json = {};
	if(req.body.name) {
		json.name = req.body.name;
	}
	if(req.body.description) {
		json.description = req.body.description;
	}
	if(req.body.version) {
		json.version = req.body.version;
	}
	if(req.body.tags && req.body.tags.length > 0) {
		json.tags = req.body.tags;
	}
	if(req.body.updatedBy) {
		json.updatedBy = req.body.updatedBy;
	}
	if(req.files.length != 0) {
		var messageFile = req.files[0];
		json.messageFileLocation = config.BINARY_STORAGE.BASE_URL + config.BINARY_STORAGE.MESSAGE + messageFile.filename;
	}
	json.updatedOn = new Date();

	Message.findOne({
		id: req.params.id
	}, function(error, message) {
		if(error) {
			logger.error('SampleMsg : DAO : failed updateMessageById : get by id : error : ' + error);
			callback(error, null);
		}
		else {
			if(message) {
				Message.findOneAndUpdate({
					id: req.params.id
				}, json, {
					new: true
				}, function(err, data) {
					if(err) {
						logger.error('SampleMsg : DAO : failed updateMessageById : error : ' + err);
						callback(err, null);
					}
					else {
						if(data) {
							if(req.files.length != 0) {
								var filePath = config.BINARY_STORAGE.BASE_PATH + config.BINARY_STORAGE.MESSAGE + message.messageFileLocation.split('/').pop();
								deleteMessageFile(filePath, function(err, file) {
									if(err) {
										callback(err, null);
										return;
									}
								});
							}
							logger.info('SampleMsg : DAO : updateMessageById successful !');
							callback(null, data);
						}
						else {
							var err = new Error('Invalid message id');
							err.status = 404;
							logger.error('SampleMsg : DAO : failed updateMessageById : error : ' + err);
							callback(err, null);
						}
					}
				})
			} else {
				var err = new Error('Invalid message id');
				err.status = 404;
				logger.error('SampleMsg : DAO : failed updateMessageById : error : ' + err);
				callback(err, null);
			}
		}
	})
}

/*
 * Delete message by id
 */
var deleteMessageById = function(req, res, callback) {
	logger.info('SampleMsg : DAO : received request : deleteMessageById : id : ' + req.params.id);

	Message.findOne({
		id: req.params.id
	}, function(err, data) {
		if(err) {
			logger.error('SampleMsg : DAO : failed deleteMessageById : get message by id : error : ' + err);
			callback(err, null);
		}
		else {
			if(data) {
				var filePath = config.BINARY_STORAGE.BASE_PATH + config.BINARY_STORAGE.MESSAGE + data.messageFileLocation.split('/').pop();
				Message.remove({
					id: req.params.id
				}, function(err, data) {
					if(err) {
						logger.error('SampleMsg : DAO : failed deleteMessageById : error : ' + err);
						callback(err, null);
					}
					else {
						deleteMessageFile(filePath, function(err, data) {
							if(err) {
								callback(err, null);
							}
							else {
								logger.info('SampleMsg : DAO : deleteMessageById successful !');
								callback(null, "Message deleted successfully");
							}
						});
					}
				})
			} else {
				var err = new Error('Invalid message id');
				err.status = 404;
				logger.error('SampleMsg : DAO : failed getMessageById : error : ' + err);
				callback(err, null);
			}
		}
	})
}

/*
 * Delete message file
 */
var deleteMessageFile = function(file, callback) {
	logger.error('SampleMsg : DAO : deleteMessageFile : file : ' + file);
	if(fs.existsSync(file)) {
		fs.unlink(file, function(err) {
			if(err) {
				logger.error('SampleMsg : DAO : deleteMessageFile : error : ' + err);
				callback(err, null);
			}
			else {
				logger.error('SampleMsg : DAO : deleteMessageFile successful! ');
				callback(null, file);
			}
		})
	}
	else {
		logger.error('SampleMsg : DAO : deleteMessageFile : No sample message found to delete !');
		callback(null, file);
	}
}

/*
 * Search sample messages
 */
var searchMessages = function(req, res, callback) {
	logger.info('SampleMsg : DAO : received request : searchMessages : text : ' + req.query.text);

	if(!req.query.text) {
		var err = new Error('No tags found');
		logger.error('SampleMsg : DAO : failed searchMessages : error : No text found');
		callback(err, null);
	}
	else {
		var queryString = decodeURIComponent(req.query.text);
		var split = queryString.split(",");
		var searchString = "";
		split.forEach(function(word) {
			searchString += "\"" + word + "\" ";
		})

		Message.find({
			$text: {
				$search: req.query.text
			}
		}, function(err, data) {
			if(err) {
				logger.error('SampleMsg : DAO : failed searchMessages : error : ' + err);
				callback(err, null);
			}
			else {
				if(data.length > 0) {
					logger.info('SampleMsg : DAO : searchMessages successful !');
					callback(null, data);
				} else {
					var err = new Error('No records found');
					err.status = 404;
					logger.error('SampleMsg : DAO : failed searchMessages : error : ' + err);
					callback(err, null);
				}
			}
		})
	}
}


module.exports.addNewMessage = addNewMessage;
module.exports.getAllMessages = getAllMessages;
module.exports.getMessageById = getMessageById;
module.exports.updateMessageById = updateMessageById;
module.exports.deleteMessageById = deleteMessageById;
module.exports.searchMessages = searchMessages;
