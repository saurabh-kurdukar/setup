var logger = require('../../common/logger').log;
var request = require('request');
var config = require('../../common/Config');
var MODULE_NAME= "Reset Password";

/*
 * Reset Password
 */
var resetPassword = function(req, res, callback) {
  logger.info(MODULE_NAME+ ' : Delegate : received request : resetPassword : body : ' + JSON.stringify(req.body));

  var tokenId = req.headers['access-token'];
  
  var proxyurl = config.NETWORK_PROXY + ":" + config.NETWORK_PROXY_PORT;
  request({
        //'proxy':proxyurl ,
        url: config.FORGRROCK_URL+'/api/v1/users/'+req.params.username+'/reset-password',
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': tokenId
        },
        json: req.body
      }, function(error, response, body) {		  
        if (error) {
		  logger.error(MODULE_NAME +': Delegate : failed resetPassword : error : ' + error);
          callback(error, null);
        } else {		  
          if (response.statusCode == 200){
			logger.info(MODULE_NAME+': DAO : getUser successful !');
            callback(null, 'Password Changed Successfully');
		  }
          else {
			logger.error(MODULE_NAME +': Delegate : failed resetPassword : error : ' + body);  
        	if(response.statusCode == 404)
			{	
			var err = new Error('User not found');
            err.status = body.code;		  
            callback(err, null);           	
			}
			else if(response.statusCode == 409)
			{
			var err = new Error('Multiple users found');
            err.status = body.code;		  
            callback(err, null); 
			}
			else if(response.statusCode == 400)
			{
				var msg= body.message;
				if (msg.indexOf("Plug-in") !=-1) {
			var err = new Error('Old Password and New Password can not be same');
            err.status = body.code;		  
            callback(err, null); 
				}
				else
				{
			var err = new Error(body.message);
            err.status = body.code;		  
            callback(err, null);
				}
			}
			else if(response.statusCode == 410)
			{
			var err = new Error('Token is expired or already used');
            err.status = body.code;		  
            callback(err, null); 
			}
			else if(response.statusCode == 401)
			{
			var err = new Error('Access Denied');
            err.status = body.code;		  
            callback(err, null); 
			}
			else
			{
			var err = new Error('Error occured while resetting a password');
            err.status = body.code;		  
            callback(err, null);
			}
	               
		  }
        }
      });
};

module.exports.resetPassword = resetPassword;