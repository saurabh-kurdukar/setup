var async = require('async');
var provisionDao = require('../dao/ProvisionDAO');
var logger = require('../../common/logger').log;
var applicationProcessing = require('../services/ApplicationProcessing');
var servicesProcessing = require('../services/ServicesProcessing');
var companyDao= require('../../company/dao/CompanyDAO');


const MODULE_NAME = "provisionV2";

/*
 * Initiate Provision
 */
var provision = function(req, callback) {
	logger.info(MODULE_NAME+' : controller : received request : provision : body : '+JSON.stringify(req.body));	
	async.waterfall([
	                 async.apply(provisionDao.checkIfExperienceAlreadyProvisioned, req),
	                 provisionDao.createProvisioningRequest,
	                 provisionDao.getExperienceManifest,
	                 servicesProcessing.processServices,
	        	     applicationProcessing.processApps,
	        	     provisionDao.updateProvisionStatus,
	        	     provisionDao.updateProvisionState
	], 
	function(err, result) {
		if(err) {
			return callback(err);
		}
		
		//update provisionCount in company
		companyDao.incrementProvisionCounter(req.body.orgId);
						
		callback(null, 'provisioning complete.');
	});
	
};


module.exports.provision = provision;