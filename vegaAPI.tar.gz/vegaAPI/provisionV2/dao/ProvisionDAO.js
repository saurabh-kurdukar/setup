var logger = require('../../common/logger').log;
var audit = require('../../common/Audit').audit;
var Manifest = require('../../manifest/models/Manifest');
var ProvisionedExperience = require('../../provision/models/provisioned-experience').ProvisionedExperience; 
const MODULE_NAME = "provisionV2";


var checkIfExperienceAlreadyProvisioned = function(req, cb) {
	ProvisionedExperience.findOne({
		orgId:req.body.orgId, 
		experienceId: req.body.experienceId		
	},			
	function(err, data){
		if (err) {
			logger.error(MODULE_NAME+' : DAO : failed update provisioning status : error : ' + err);
			return cb(err);
		} 
		if(data) {
			return cb(new Error('Already provisioned'));
		}
		cb(null, req);			
	});	
}

var createProvisioningRequest = function(req, cb) {
	var reqBody = req.body;
	var provisionedExperience = new ProvisionedExperience({
		orgId: Number(reqBody.orgId),
		experienceId: reqBody.experienceId,
		createdBy : req.body.createdBy,		// username who provisioned experience
		created: new Date().getTime(),		
		state: 'START',
		status : 'IN-PROGRESS'		
	});
	
	provisionedExperience.save(function(err, data) {
		if (err) {
			logger.error(MODULE_NAME+' : DAO : failed createProvisioningRequest : error : ' + err);
			cb(err);
		} else {    
			req.provisioningId = data._id;
			cb(null, req);			
		}
	});
}

var getExperienceManifest = function getExperienceManifest(req, cb) {
	Manifest.findOne({
		'experienceId' : req.body.experienceId
	}, function(err, manifest) {
		if (err) {
			logger.error(MODULE_NAME + ' : DAO : failed get manifest by Id : error : ' + err);
			cb(err, null);
		} else {
			if (manifest) {
				logger.info(MODULE_NAME + ' : DAO : get manifest by Id successful !');
				cb(null, req, manifest);
			} else {
				var err = new Error('no record exist for manifest id');	            					
				logger.error(MODULE_NAME + ' : DAO : failed get manifest by Id : error : '+ err);
				cb(err, null);
			}
		}
	});
}

var updateProvisionStatus = function(id, cb) {
	ProvisionedExperience.update({_id:id},{status:'PROVISIONED'},function(err, data){
		if (err) {
			logger.error(MODULE_NAME+' : DAO : failed update provisioning status : error : ' + err);
			return cb(err);
		} 
		cb(null, id);				
	});	
}

var updateProvisionState = function(id, cb) {
	ProvisionedExperience.update({_id:id},{state:'PROVISIONED'},function(err, data){
		if (err) {
			logger.error(MODULE_NAME+' : DAO : failed update provisioning state : error : ' + err);
			return cb(err);
		} 
		cb(null, 'state updated');				
	});	
}

module.exports.checkIfExperienceAlreadyProvisioned = checkIfExperienceAlreadyProvisioned; 
module.exports.createProvisioningRequest = createProvisioningRequest;
module.exports.getExperienceManifest = getExperienceManifest;
module.exports.updateProvisionStatus = updateProvisionStatus;
module.exports.updateProvisionState = updateProvisionState;




