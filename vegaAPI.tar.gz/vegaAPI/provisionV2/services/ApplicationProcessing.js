//var async = require('async');
//var CompanyDAO = require('../../company/dao/CompanyDAO');
var Company = require('../../company/models/Company');
var config = require('../../common/Config');
var radiaJar = "java -jar ./radia/RadiaApi1.0.0.jar ";
var radiaConfig = "./radia/config.json ";
var assignAppToGroupFile = "./radia/assignAppToGroup.json";
var appListFile = "./radia/appList.json";
var fs = require('fs');
var cp = require('child_process');
var logger = require('../../common/logger').log;
var ProvisionedExperience = require('../../provision/models/provisioned-experience').ProvisionedExperience;
var App = require('../../application/models/App');


// var newprocessApps = function(req, manifest, cb){
//
// 	async.waterfall([
// 	      async.apply(CompanyDAO.getExperiencesByOrgId, req.body.orgId),
// 	      getProvisionedExperiences,
// 				getProvisionedApps,
// 	      getNewProvisionRequests,
// 	      assignAppToGroup
// 	],
// 	function(err, result) {
// 		if(err) {
// 			return callback(err);
// 		}
// 		callback(null, 'provisioning complete.');
// 	});
//
// }
//
//
// function getProvisionedExperiences(req, data, cb){
//
// }



var processApps = function(req, manifest, cb) {

	var allAssignApps = [];

	logger.info('ProvisionV2 : Services : received request : processApps : body : ' + JSON.stringify(req.body));

	var companyId = req.body.orgId;
	var apps = manifest.applications;
	var groupName = "";
	assignAppToGroupFile = "./radia/assignAppToGroup_" + companyId + ".json";

	Company.findOne({
		'companyId': companyId
	}, function(err, data) {
		if(err) {
			logger.error('ProvisionV2 : Services : failed Company.findOne : error : ' + err);
			callback(err, null);
		}
		else {
			logger.info('ProvisionV2 : Services : response : Company.findOne successful ! : res : ' + JSON.stringify(data));
			console.log("Company data ... " + JSON.stringify(data))
			groupName = data.companyName;

			// apps.forEach(function(app) {
			// 	if(app.deployOptionFlag === "DIRECT_DEPLOY") {
			// 		if (app.type == "ANDROID") {
		  //       allAssignApps.push("AA_AA_" + app.name.replace(/ /g,"_"));
		  //     }
		  //     else if (app.type == "IOS") {
		  //       allAssignApps.push("IA_IA_" + app.name.replace(/ /g,"_"));
		  //     }
			// 	}
			// })
			console.log("allAssingApps before checking provisioned apps ... " + allAssignApps);
			getProvisionedExperiences(req, companyId, groupName, cb, allAssignApps);
			console.log("allAssingApps after checking provisioned apps ... " + allAssignApps);
			logger.info('ProvisionV2 : Services : allAssignApps : ' + JSON.stringify(allAssignApps));
			// appListFunction(req, allAssignApps, groupName, cb);
		}
	});
};


function getProvisionedExperiences(req, companyId, group, callback, allAssignApps) {
	ProvisionedExperience.find({
		'orgId': companyId
	}, function(err, data) {
		if(err) {
			logger.error('ProvisionV2 : Services : failed getProvisionedExperiences : error : ' + err);
			callback(err, null);
		}
		else {

			console.log("ProExp ######", JSON.stringify(data));
			var expExists = false;
			var uniqueExp = [];
			// for(var i=0; i < data.length; i++) {
			// 	expExists = false;
			// 	for(var j=0; j < uniqueExp.length; j++) {
			// 		if(uniqueExp[j].experienceId == data[i].experienceId) {
			// 			expExists = true;
			// 			break;
			// 		}
			// 	}
			// 	if(!expExists) {
			// 		uniqueExp.push(data[i]);
			// 	}
			// }
			uniqueExp[0] = data[0];
			console.log("Unique", JSON.stringify(uniqueExp));
			data.forEach(function(exp ,index) {
				console.log("outside index:-",index);
		    var expExists = false;
				console.log("uniqueExp.length",uniqueExp.length );
				uniqueExp.forEach(function(unique ,index) {
					console.log("inside index:-",index);

	        if (exp.experienceId == unique.experienceId) {
						console.log(exp.experienceId+"/****found***/"+unique.experienceId);
						expExists = true;
	          return;
	        }
		    });
				if (!expExists) {
					uniqueExp.push(exp);
				}
				console.log("Unique", JSON.stringify(uniqueExp));
			});


			console.log("Provisioned Exps", JSON.stringify(uniqueExp));
			getApps(req, uniqueExp, group, allAssignApps, callback);
		}
	})
}

function getApps(req, experiences, group, allAssignApps, callback) {
	experiences.forEach(function(experience, index, array) {
		console.log("OuterIndex&&&&&&&&", index);
		console.log("Experience", JSON.stringify(experience));
		App.find({
			'experienceId': experience.experienceId
		}, function(err, data) {
			if(err) {
				logger.error('ProvisionV2 : Services : failed getProvisionedExperiences : error : ' + err);
				callback(err, null);
			}
			else {
				console.log("Before allAssignApps", JSON.stringify(allAssignApps));
				console.log("Apps @@@@@@@@@@@@@", JSON.stringify(data));
				data.forEach(function(app ,innerIndex) {
					console.log("In forEach", JSON.stringify(app));
					console.log("app.deployOptionFlag", app.deployOptionFlag);
					if(app.deployOptionFlag == "DIRECT_DEPLOY") {
						if (app.type == "ANDROID") {
			        allAssignApps.push("AA_AA_" + app.name.replace(/ /g,"_"));
			      }
			      else if (app.type == "IOS") {
			        allAssignApps.push("IA_IA_" + app.name.replace(/ /g,"_"));
			      }
					}
					console.log("InnerIndex**********", innerIndex);

				})
				if(index == array.length-1) {
					console.log("Before Index$$$$$$$$$$$$$$$$$$$", index);
					appListFunction(req, group, allAssignApps, callback);
					console.log("After Index$$$$$$$$$$$$$$$$$$$", index);
					console.log("After allAssignApps", JSON.stringify(allAssignApps));
				}
			}
		})
	})
}


var appListFunction = function(req, group, allAssignApps, callback) {

	logger.info('ProvisionV2 : Services : appListFunction : allAssignApps : ' + JSON.stringify(allAssignApps));

	fs.writeFileSync(appListFile, "");
	var command = radiaJar + "appList " + radiaConfig + appListFile;
	console.log("Executing appList command : " + command);
	cp.exec(command, function(err, stdout, stderr) {
		if(err) {
			logger.error('ProvisionV2 : Services : failed appListFunction : error : ' + err);
			callback(err, null);
		}
		else {
			var appListVar = JSON.parse(stdout);
			var existsApp = false;
			var assignApps = [];
			allAssignApps.forEach(function(assign) {
				appListVar.apps.forEach(function(app) {

					if(app.instancename) {
						if(app.instancename.toUpperCase() === assign.toUpperCase() ) {
							existsApp =true;
							return;
						}
					}
                                        else if(app.instanceName) {
						if(app.instanceName.toUpperCase() === assign.toUpperCase() ) {
							existsApp =true;
							return;
						}
					}
					else {
						logger.error('ProvisionV2 : Services : failed appListFunction instance name : error : No app.instancename field found');
						callback(new Error("No app.instancename field found"), null);
					}
				});
				if(existsApp) {
					console.log("App exists", assign);
					assignApps.push(assign);
				}
				else {
					console.log("App does not exist", assign);
				}
			});
			console.log("appListFunction successful");
			logger.info('ProvisionV2 : Services : appListFunction successful ! : res : ' + stdout);
			assignAppToGroupFunction(req, group, assignApps, callback);
		}
	});
}


var assignAppToGroupFunction = function(req, group, assignApps, callback) {
  var assignAppToGroupArray = [];
  var assignAppToGroupObj = {
    "groupName": group,
    "appsInstanceName": []
  }

	console.log("before assignAppToGroupFunction apps", assignApps);

	assignApps.forEach(function(app) {
		assignAppToGroupObj.appsInstanceName.push(app);
	});
  assignAppToGroupArray.push(assignAppToGroupObj);

	console.log("after assignAppToGroupFunction apps", JSON.stringify(assignAppToGroupArray));

  fs.writeFileSync(assignAppToGroupFile, JSON.stringify(assignAppToGroupArray));
  var command = radiaJar + "assignAppToGroup " + radiaConfig + assignAppToGroupFile;
  console.log("Executing assignAppToGroup command : " + command);

  cp.exec(command, function(err, stdout, stderr) {
    if(err) {
			logger.error('ProvisionV2 : Services : failed assignAppToGroupFunction : error : ' + err);
			callback(err, null);
    }
    else {
			console.log("assignAppToGroupFunction successful");
			logger.info('ProvisionV2 : Services : assignAppToGroupFunction successful ! : res : ' + stdout);
			callback(null, req.provisioningId);
    }
  });
}

module.exports.processApps = processApps;
