var express = require('express');
var provisionController = require('./controller/ProvisionController');
var logger = require('../common/logger').log;
var ErrorResponse = require('../common/ErrorResponse').ErrorResponse;
var router = express.Router();
const MODULE_NAME = "provisionV2";

/*
 * Initiate Provision
 */
router.post('/', function(req, res) {
	logger.info(MODULE_NAME+' : router : received request : provision : body : '+JSON.stringify(req.body));

	provisionController.provision(req, function(err, data) {
		if (err) {
			logger.error(MODULE_NAME+' : router : failed provision : error : '+err);
			var error = new ErrorResponse();
			if(err.name == 'ValidationError'){
        		error.setErrorMessage(err.errors[Object.keys(err.errors)[0]].message);
        	} else {
        		error.setErrorMessage(err.message);
        	}
        	error.setErrorCode("PROV20001");
        	error.setHttpResponseCode(500);
			res.status(500).end(JSON.stringify(error));
		} else {
			logger.info("experience : router : provision successful !");
			res.status(200).end(JSON.stringify(data));
		}
	});
});

module.exports = router;
