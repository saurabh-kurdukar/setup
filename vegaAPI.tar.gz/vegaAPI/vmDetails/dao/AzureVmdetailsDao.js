var db = require('../../common/MongoDbConnection');
var logger = require('../../common/logger').log;
var Provisionedvms= require('../../provision/models/provisioned-vm').ProvisionedVM;
var vmdetails= require('../../provision/models/vmdetails').VMDetails;
var ObjectId = require('mongoose').Types.ObjectId; 
var experirencedao= require('../../experience/dao/ExperienceDAO');
var async = require("async");
var componentdao= require('../../component/dao/ComponentDAO');
var request = require('request');
var config = require('../../common/Config');
var request= require('request');
const MODULE_NAME = "vmDetails";
var provisionexpdao= require('../../provision/dao/provision-experience-dao');

/*
 * Get vm details
 */
var getVmDetails = function(req, res, callback) {
	logger.info('Azure VM Details : DAO : received request : getVmDetails');
	var vmdetailsresponse = [];  
    var vmnames=[];    
    var queryParam = {'deleted': false};
    if (req.header('companyId')){		
        queryParam.orgId = req.header('companyId');
	}
	else{	
        logger.info('Azure VM Details : DAO : received request : queryParam'+JSON.stringify(queryParam));        
    }        
    logger.info('Azure VM Details : DAO : received request : queryParam'+JSON.stringify(queryParam));
    
    if (Object.keys(req.query).length == 0){
        getVmDetailsById(qurtyjosn,req,res,function(err,vmresponse){
						if(err)
							callback(err,null);
						else{						
						    var response={};
                            for(var j =0 ;j< vmresponse.length;j++){                            
                                var usageData= vmresponse[0].usageData;
                                var totalCost = 0;
                                //iterate over usageData to get total cost of VM										
                                var jsonData=JSON.stringify(usageData);
                                if(jsonData!= undefined || jsonData!= null){
                                    var jsonUsage = JSON.parse(jsonData);
                                for (var key in jsonUsage) {					  					  
                                    var val = jsonUsage[key];					  
                                    totalCost= totalCost+ val;					  					  
                                    }
                               }
                            response.fqdn=vmresponse[j].fqdn;
							response.status= vmresponse[j].status;
                            response.hostname= vmresponse[j].hostname;                                                
                            response.osType= vmresponse[j].osType;
                            response.osVersion= vmresponse[j].osVersion;
                            response.type= vmresponse[j].type;                            
                            response.diskSize= vmresponse[j].diskSize;
                            response.dateCreated=vmresponse[j].dateCreated;
                            response.tcpPorts=vmresponse[j].tcpPorts;
                            response.runningCost=totalCost;
                            response.currency="$";                            
                            vmnames.push(vmresponse[j].hostname);
                            vmdetailsresponse.push(response);							
                             }     
                         
                          getVmUsage(vmnames,req,res,function(err,data){
                                if(err)
                            callback(err,null);
                            else{	
                                for(var j=0;j<data.length;j++){
                                    for(var k=0;k<vmdetailsresponse.length;k++){
                                        if(data[j].vmName== vmdetailsresponse[k].hostname)
                                            {
                                            vmdetailsresponse[k].currentCPUUsage=data[j].cpuUsage+' %';
                                            vmdetailsresponse[k].currentDiskUsage= data[j].diskUsage+' %';
                                            vmdetailsresponse[k].currentNetworkUsage= data[j].networkUsage+' bytes';			
                                            logger.info(MODULE_NAME+' : DAO : getVMsByExperienceId successful !');
                                        }
                                }																
                            }
					callback(null,vmdetailsresponse);
                    }
                })     //callback(err,vmdetailsresponse);                    
			}
	     });
        			
    }else if(req.query.type =="COMPONENT"){
    var qurtyjosn={"type":req.query.type};
    logger.info("qurty josn:"+JSON.stringify(qurtyjosn));    
        getVmDetailsById(qurtyjosn,req,res,function(err,vmresponse){
						if(err)
							callback(err,null);
						else{							
                            for(var j =0 ;j< vmresponse.length;j++){  
								 var response={};
                                var usageData= vmresponse[j].usageData;
                                var totalCost = 0;
                                //iterate over usageData to get total cost of VM										
                                var jsonData=JSON.stringify(usageData);
                                if(jsonData!= undefined || jsonData!= null){
                                    var jsonUsage = JSON.parse(jsonData);
                                for (var key in jsonUsage) {					  					  
                                    var val = jsonUsage[key];					  
                                    totalCost= totalCost+ val;					  					  
                                    }
                               }
                            response.fqdn=vmresponse[j].fqdn;
							response.status= vmresponse[j].status;
                            response.hostname= vmresponse[j].hostname;                                                
                            response.osType= vmresponse[j].osType;
                            response.osVersion= vmresponse[j].osVersion;
                            response.type= vmresponse[j].type;                            
                            response.diskSize= vmresponse[j].diskSize;
                            response.dateCreated=vmresponse[j].dateCreated;
                            response.tcpPorts=vmresponse[j].tcpPorts;
                            response.runningCost=totalCost;
                            response.currency="$";                            
                            vmnames.push(vmresponse[j].hostname);
                            vmdetailsresponse.push(response);							
                             }     
                         
                          getVmUsage(vmnames,req,res,function(err,data){
                                if(err)
                            callback(err,null);
                            else{	
                                for(var j=0;j<data.length;j++){
                                    for(var k=0;k<vmdetailsresponse.length;k++){
                                        if(data[j].vmName== vmdetailsresponse[k].hostname)
                                            {
                                            vmdetailsresponse[k].currentCPUUsage=data[j].cpuUsage+' %';
                                            vmdetailsresponse[k].currentDiskUsage= data[j].diskUsage+' %';
                                            vmdetailsresponse[k].currentNetworkUsage= data[j].networkUsage+' bytes';			
                                            logger.info(MODULE_NAME+' : DAO : getVMsByExperienceId successful !');
                                        }
                                }																
                            }
					callback(null,vmdetailsresponse);
                    }
                })     //callback(err,vmdetailsresponse);                    
			}
	     });    
    }else if(req.query.type =="EXPERIENCE"){
    logger.info("qurty josn:"+JSON.stringify(queryParam));
    Provisionedvms.find(queryParam, function(err, data) {	
        if (err) {
            if(err.status!=404){
			callback(err, null);
            }else{
            callback();
            }
		} else {
			if (data&& data.length != 0) {				
				logger.info('Azure VM Details : DAO : vm id: '+data[0].vmId);
                async.each(data,function(item, callback){   
                    var vmRequestjson = {'_id':item.vmId};
                    var vmId= new ObjectId(item.vmId);                   
                     if (req.query.type){		
                       vmRequestjson.type = req.query.type;                    
                        }                        
                       logger.info("req"+JSON.stringify(vmRequestjson));                    
                       getVmDetailsById(vmId,req,res,function(err,vmresponse){
						if(err)
                        if(err.status!=404){
                        callback(err,null);
                        }else{
                        callback();
                        }							
						else{	                                
                                var usageData= vmresponse[j].usageData;
                                var totalCost = 0;
                                //iterate over usageData to get total cost of VM										
                                var jsonData=JSON.stringify(usageData);
                                if(jsonData!= undefined || jsonData!= null){
                                    var jsonUsage = JSON.parse(jsonData);
                                    for (var key in jsonUsage) {					  					  
                                        var val = jsonUsage[key];					  
                                        totalCost= totalCost+ val;					  					  
                                    }
                               }
						    var response={};
                            for(var j =0 ;j< vmresponse.length;j++){								
                            response.fqdn=vmresponse[j].fqdn;
							response.status= vmresponse[j].status;
                            response.hostname= vmresponse[j].hostname;                                                
                            response.osType= vmresponse[j].osType;
                            response.osVersion= vmresponse[j].osVersion;
                            response.type= vmresponse[j].type;
                            response.diskSize=vmresponse[j].diskSize;
                            response.dateCreated=vmresponse[j].dateCreated;
                            response.tcpPorts=vmresponse[j].tcpPorts;
                            response.runningCost=totalCost;
                            response.currency="$";
                            vmdetailsresponse.push(response);
                            vmnames.push(vmresponse[j].hostname);
                                    }     
                        callback();                       
																	
						}
					})	
				},  
				function(err){
                //Calling vmusage function              
              getVmUsage(vmnames,req,res,function(err,data){
				if(err)
					callback(err,null);
				else{	
					for(var j=0;j<data.length;j++)
					{
						for(var k=0;k<vmdetailsresponse.length;k++)
						{
						   if(data[j].vmName== vmdetailsresponse[k].hostname)
						   {
							   vmdetailsresponse[k].currentCPUUsage=data[j].cpuUsage+' %';
							   vmdetailsresponse[k].currentDiskUsage= data[j].diskUsage+' %';
							   vmdetailsresponse[k].currentNetworkUsage= data[j].networkUsage+' bytes';			
							   logger.info(MODULE_NAME+' : DAO : getVMsByExperienceId successful !');
						   }
						}																
					}
					callback(null,vmdetailsresponse);
				}
			})	
					//callback(err,vmdetailsresponse);
					}
		);											
			} else {
				var err = new Error('No record found...');
				err.status = 404;
				callback(err, null);												
			}
		}
	});//end of find
    }else{
     var err = new Error('No record found Please select proper query parameter');
				err.status = 400;
				callback(err, null);
     }
    
};

/*
 * Get vm details by vm id
 */
var getVmDetailsById = function(vmid,req, res, callback) {
	logger.info('Azure VM Details : DAO : received request : getVmDetailsById');
	
	vmdetails.find(vmid, function(err, data) {
		if (err) {
			callback(err, null);
		} else {
			if (data.length != 0) {				
				callback(null, data);
			}else {
				var err = new Error('No record found');
				err.status = 404;
				callback(err, null);												
			}
		}
	});
};

/*
 *  get vm usage
 */
var getVmUsage = function(vms,req, res, callback) {
  logger.info('Azure VM Details : Dao : received request : getVmUsage :'+vms);  
  var responseArray= [];  
  //azure call
  var proxyurl=config.NETWORK_PROXY+":"+config.NETWORK_PROXY_PORT;
  request({
	//'proxy':proxyurl ,
    url: config.AZURE_API_URL,
    method: 'GET',
    headers: {      
      'Authorization': config.AZURE_AUTHORIZATION
    }
  }, function(error, response, body) {
    if (error) {
		logger.error('Azure VM Details : DAO : failed getVmUsage : error : ' + error);
			var err = new Error('An error has occurred while calling Azure API');
				err.status = 500;
				callback(err, null);	  
    } else {		
    logger.info("error code "+response.statusCode);
		if(response.statusCode== 200)
		{		
			logger.info('Azure VM Details : Dao : getVmUsage Successfull');
			var jsonBody= JSON.parse(body);
			logger.info("jsonResponse"+JSON.stringify(jsonBody));
			//iterate over vm names array
			 async.each(vms,function(item, callback){
				 
				 var avgCpuUsage= 0;
				 var avgdiskusage= 0;
				 var avgnetworkusage=0;
				 var noOfCpuUsagepuVms= 0;
				 var noOfDiskUsagepuVms= 0;
				 var noOfNetworkUsageVms= 0;
					//iterate over json array data
					for(var i=0; i<jsonBody.length; i++)
					{		vmName	='';						
						if(jsonBody[i].GraphiteCounterName.indexOf('Azure.CloudServices.MetricsApi.'+item) > -1)
							{								
								var graphiteCounterName= jsonBody[i].GraphiteCounterName;
								if(graphiteCounterName.indexOf('Percentage_CPU') > -1)
								{																	  
								  avgCpuUsage= avgCpuUsage+jsonBody[i].Value;
								  noOfCpuUsagepuVms++;								 								  
								}
								else if(graphiteCounterName.indexOf('Disk_Read_Bytes_sec') > -1)
								{																	  
								  avgdiskusage= avgdiskusage+jsonBody[i].Value;
								  noOfDiskUsagepuVms++;								 								  
								}
								else if(graphiteCounterName.indexOf('Network_Out.Bytes')> -1)
								{
									avgnetworkusage= avgnetworkusage+ jsonBody[i].Value;
									noOfNetworkUsageVms++;
								}
							}
					}							
						var responseObject={};
						responseObject.vmName=item;
						responseObject.cpuUsage= avgCpuUsage/noOfCpuUsagepuVms;
						responseObject.diskUsage= avgdiskusage/noOfDiskUsagepuVms;
						responseObject.networkUsage= avgnetworkusage/noOfNetworkUsageVms;
						responseArray.push(responseObject);						
					callback();
			},
			function(err){	
                
		    logger.info(responseArray);
			callback(err,responseArray);				
					}
				);			
		}
		else{			
			var err = new Error('An error has occurred while calling Azure API');
				err.status = 500;
				callback(err, null);			
		}
    }
  });
};

/*
 * On or Off VM
 */
var startOrStopVm = function(req, res, callback) {
	logger.info(' Azure VM Details : DAO : received request : startOrStopVm : id : '+req.params.id);	
	 var proxyurl=config.NETWORK_PROXY+":"+config.NETWORK_PROXY_PORT;
			request({
				 //'proxy':proxyurl ,
					url: config.AZURE_SERVER_HOST + '/api/vm/docker/'+req.params.id+'?action='+req.query.action,
					method: 'PUT',					
				}, function(error, response, body) {
					if (error) {	
						logger.error('Azure VM Details : DAO : failed startOrStopVm : error : ' + error);
						callback(error,null);
					} else if(response.statusCode == 200){						
						logger.info('Azure VM Details : Dao : startOrStopVm Successfull');
						callback(null, JSON.parse(body));
					}
					else{
						var err = new Error('Enter a valid action');
						err.status = response.statusCode;
						callback(err, null);
					}
				
				
		});
	
};

/*
**get vm details associated with companyId
*/
var getVMsByCompanyId = function(req, res, callback) {
   logger.info('Azure VM Details : DAO : received request : getVMsByCompanyId');
	
   var vmdetailsresponse= [];
   var vmNames=[];
	
   Provisionedvms.find({
	'orgId' : req.params.id ,
	'deleted': false
   }, function(err, data) {
	if (err) {
	  logger.error('Azure VM Details : DAO : failed getVMsByCompanyId : error : ' + err);
	  callback(err, null);
	} else {
	  if (data.length != 0) {
		//iterate over multiple vmIds			
		async.each(data,function(item, callback){

		  var vmId= new ObjectId(item.vmId);
			provisionexpdao.getVmDetailsById(vmId,req,res,function(err,vmresponse){
				if(err)
				  {
					logger.error('Azure VM Details : DAO : failed getVMsByCompanyId : error : ' + err);
					if(err.status !=404)
					   callback(err,null);
					else
					   callback();
				  }
				  else{								
					var vmId= vmresponse[0]._id;
					var vmname= vmresponse[0].hostname;
					var vmtype= vmresponse[0].type;
					var fqdn= vmresponse[0].fqdn;						
					var usageData= vmresponse[0].usageData;
										
					var totalCost = 0;
					//iterate over usageData to get total cost of VM										
					 var jsonData=JSON.stringify(usageData);
					if(jsonData!= undefined || jsonData!= null)
					{
					var jsonUsage = JSON.parse(jsonData);
					for (var key in jsonUsage) {					  					  
					  var val = jsonUsage[key];					  
					  totalCost= totalCost+ val;					  					  
					}
					}
						
					var response={};
					//response.vmId= vmId;
					response.hostname= vmname;
					response.type= vmtype;
					response.fqdn= fqdn;
					response.username=vmresponse[0].username;
					response.osType= vmresponse[0].osType;
					response.osVersion= vmresponse[0].osVersion;
					response.status= vmresponse[0].status;
					response.diskSize= vmresponse[0].diskSize;
					response.dateCreated= vmresponse[0].dateCreated;
					response.ports= vmresponse[0].tcpPorts;
					response.runningCost= totalCost;	
					response.currency='$';

					//VM names array to be used for getting real time cpu and disk usage
					vmNames.push(vmname);
						
					vmdetailsresponse.push(response);						
					callback();
				  }
			})					
		},
		function(err){									
			//get real-time cpuUsage and diskusage
			getVmUsage(vmNames,req,res,function(err,data){
				if(err)
					callback(err,null);
				else{	
					for(var j=0;j<data.length;j++)
					{
						for(var k=0;k<vmdetailsresponse.length;k++)
						{
						   if(data[j].vmName== vmdetailsresponse[k].hostname)
						   {
							   vmdetailsresponse[k].currentCPUUsage=data[j].cpuUsage+' %';
							   vmdetailsresponse[k].currentDiskUsage= data[j].diskUsage+' %';
							   vmdetailsresponse[k].currentNetworkUsage= data[j].networkUsage+' bytes';			
							   logger.info('Azure VM Details : DAO : getVMsByExperienceId successful !');
						   }
						}																
					}
					callback(null,vmdetailsresponse);
				}
			})					
		}
		);
	  } else {
		var err = new Error('No record found');
		err.status = 404;
		callback(err, null);
		}
	  }
	});
};
module.exports.getVmDetails = getVmDetails;
module.exports.getVmDetailsById = getVmDetailsById;
module.exports.getVmUsage= getVmUsage;
module.exports.startOrStopVm= startOrStopVm;
module.exports.getVMsByCompanyId= getVMsByCompanyId;


