var azureVmDao = require('../dao/AzureVmdetailsDao');
var logger = require('../../common/logger').log;
	

/*
 * get VM details
 */
var getVmDetails = function(req, res, callback) {	
	logger.info('Azure Vm Details : controller : received request : getVmDetails :');
	azureVmDao.getVmDetails(req, res ,callback);
};

var getVmUsage = function(req, res, callback) {	
	logger.info('Azure Vm Details : controller : received request : getVmUsage :');
	
	  var vms= [ 'demo-oilfield','DockerRunEPYIG6','DockerRunO69WS4',  'edtapiserver',  'edtappian',  'edtemee',  'edtemee01',  'edtftp',  'edthoopz',  'edtjavaserver',  'edtnodemongo',  'edtrabbitmq',  'edtradia',  'edtsalesforce', 'edtsiinstance6mtbj0',  'edtsiinstance85zps1',  'LastRun22RSZS',  'LastRunSZHUID',  'LogiPlus1OTTE0',  'LogiPlus4LWF9H',  'LogiPlus642TE5',  'LogiPlusDDIMUR',  'LogiPlusDVI0N3',  'LogiPlusEDTDG8',  'LogiPlusENGQ3P',  'LogiPlusGEBNYS', 'LogiPlusHG40IU',  'LogiPlusHQU17C',  'LogiPlusIEAEBZ',  'LogiPlusISSW01',  'LogiplusIXELCS',  'LogiPlusJ9ZXC5', 'LogiPlusLLJ4EW',  'LogiPlusLMJKEY',  'LogiPlusMPXUH9',  'LogiPlusMQPVEI',  'LogiPlusNYBHY5',  'LogiPlusOCVBVO', 'LogiPlusPDWHXO',  'LogiplusPUENUK',  'LogiPlusQ3E8SD',  'LogiPlusQDHH0U',  'LogiplusSRS1GJ',  'LogiPlusTC6OYG', 'LogiPlusURDVW6',  'LogiPlusWAO6FJ',  'LogiPlusWS1WGP',  'LogiPlusX91LY7',  'LogiPlusXC3XND',  'LogiPlusZPKAG4', 'RajeshTestITMZAI',  'semicolonapps',  'TechCUcheckapp',  'TestVm015XCKL4',  'TestVm01IJM8D5',  'twodegree01', 'twodegree02',  'vegaattivio',  'vegabuild',  'vegadb',  'vegaweb',  'vishalFYIRUX' ] ;
	  
	azureVmDao.getVmUsage(vms,req, res ,callback);
};

/*
 * On or Off VM
 */
var startOrStopVm = function(req, res, callback) {	
	logger.info('Azure Vm Details : controller : received request : startOrStopVm :');	 
	azureVmDao.startOrStopVm(req, res ,callback);
};
module.exports.getVmDetails=getVmDetails;
module.exports.getVmUsage= getVmUsage;
module.exports.startOrStopVm= startOrStopVm;


