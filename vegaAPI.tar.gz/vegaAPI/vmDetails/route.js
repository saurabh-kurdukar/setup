var express = require('express');
var logger = require('../common/logger').log;
var azureVmController = require('./controller/AzureVmDetailsController');
var ErrorResponse = require('../common/ErrorResponse').ErrorResponse;
var router = express.Router();
const MODULE_NAME = 'vmDetails';

/*
 * Get Azure VM Details 
 ?type={component/Experience}
 */
router.get('/', function (req, res) {	
	logger.info(MODULE_NAME + ' : router : received request : getAllVmDetails : status : '
	+ req.query.status);
	
    azureVmController.getVmDetails(req,res,function (err,data){
    if(err){
      	logger.error('Component : router : failed getAllComponents : error : '+err);   
        	var error = new ErrorResponse();
        	error.setErrorCode("VM001");
        	error.setErrorMessage(err.message);
        	error.setHttpResponseCode(500);
            res.status(500).end(JSON.stringify(error));
    }else{
    logger.info(MODULE_NAME+" : router : getVmDetails successful !");
        	res.status(200).end(JSON.stringify(data));
    }
    }); 
    
});


/*
 * Get Azure VM Usage 
 */
router.get('/usage', function (req, res) {	
	logger.info(MODULE_NAME + ' : router : received request : getVmUsage ');
	
    azureVmController.getVmUsage(req,res,function (err,data){
    if(err){
      	logger.error(MODULE_NAME + ': router : failed getVmUsage : error : '+err);   
        	var error = new ErrorResponse();
        	error.setErrorCode("VM002");
        	error.setErrorMessage(err.message);
        	error.setHttpResponseCode(500);
            res.status(500).end(JSON.stringify(error));
    }else{
    logger.info(MODULE_NAME+" : router : getVmUsage successful !");
        	res.status(200).end(JSON.stringify(data));
    }
    }); 
    
});

/*
* On or Off VM
*/
router.put('/:id', function(req, res){
	logger.info(MODULE_NAME + ' : router : received request : startOrStopVm : vmId: '+req.params.id);
	azureVmController.startOrStopVm(req, res, function(err, data) {
		if(err){
			logger.error(MODULE_NAME + ' : router : failed startOrStopVm : error : '+err);
			var error = new ErrorResponse();
			if(err.name == 'ValidationError'){
				error.setErrorMessage(err.errors[Object.keys(err.errors)[0]].message);
			} else {
				error.setErrorMessage(err.message);
			}
			error.setErrorCode("VM003");
			error.setHttpResponseCode(500);
			res.status(500).end(JSON.stringify(error));
		}else{
			logger.info(MODULE_NAME + " : router : startOrStopVm successful !");
			res.status(200).end(JSON.stringify(data));
		}
	});
});

/*
 * Options method
 */
router.options('/', function(req, res) {
	logger.info('Azure VM Details : router : received request : Options call Azure VM Details APIs');
	res.header('Allow-Access-Allow-Origin', '*');
	res.header('Access-Control-Allow-Headers', '*');
	res.header('Access-Control-Allow-Methods', 'GET,POST,DELETE,PUT,OPTIONS');
	res.header('Connection', 'keep-alive');
	res.header('Content-Type', 'application/json;charset=UTF-8');
	res.end();
	logger.info('Azure VM Details : router : Options call Azure VM Details APIs processed !');
});

router.all('/*', function (req, res) {		
	res.status(404).send(JSON.stringify({'error':'No matching resource for url: '+req.originalUrl}));	  	
});


module.exports = router;