'use strict';

var express = require('express'),
controller = require('./controller/data-pipeline'),
logger = require('../common/logger').log
.child({
  module: 'Data Pipeline',
  type: 'router'
}),
PlatformError = require('../common/platform-error'),
ErrorResponse = require('../common/ErrorResponse').ErrorResponse,
router = express.Router(),
ResourceBundle = require('./../common/resource-bundle.js'),
rsBundle = new ResourceBundle(['./../data-pipeline/resource/lang/', './../oozie-adapter/resource/lang/']);

function processResponse(res, failureLog, err, data) {
  if (err) {
    var error;
    if (err instanceof PlatformError) {
      logger.error(`${failureLog} Stack trace : \n ${JSON.stringify(err)}`);
      error = new ErrorResponse(err.code, rsBundle.getMessage(err.code, err.args), err.httpCode);
    } else {

      logger.error(`${failureLog} Root cause : \n ${JSON.stringify(err) }`);
      // any error that comes here will be mapped with internal server error as it's either programmatic error or server side issue and client shouldn't be aware about actual cause.
      error = new ErrorResponse("DTPL001", rsBundle.getMessage("DTPL001"), 500);
    }

    res.status(error.getHttpResponseCode()).json(error);
  } else {
    if (data) {

      if(!res.headers || res.headers['Content-Type'] !== 'image/png') {
        res.json(data);
      } else {
        res.writeHead(200, {'Content-Type': 'image/png' });
        res.end(data, 'binary');
      }
    } else {
      res.statusCode = 204;
      res.end();
    }
  }
}

router.put('/process', function (req, res) {

  logger.info(`Data pipeline processing request received. Request body : ${JSON.stringify(req.body) }`);

  controller.processPipeline(req.body, function (err, data) {
    processResponse(res, 'Data pipeline processing failed.', err, data);
  });
});

router.get('/instance/:id', function (req, res) {

  logger.info(`Get data pipeline execution details for instance id # ${req.params.id}`);

  controller.getWorkflowExecutionDetails(req.params.id, function (err, data) {
    processResponse(res, 'Get data pipeline execution details failed.', err, data);
  });
});

router.get('/instance/:id/graph', function (req, res) {

  logger.info(`Get data pipeline execution graph details for instance id # ${req.params.id}`);

  res.headers = {
    'Content-Type' : 'image/png'
  };
  controller.getWorkflowExecutionGraph(req.params.id, function (err, data) {
    processResponse(res, 'Get data pipeline execution graph details failed.', err, data);
  });
});

router.options('/', function (req, res) {
  logger.debug('Options call for data pipeline APIs');
  res.header('Allow-Access-Allow-Origin', '*');
  res.header('Access-Control-Allow-Headers', '*');
  res.header('Access-Control-Allow-Methods', 'GET,PUT,OPTIONS');
  res.header('Connection', 'keep-alive');
  res.header('Content-Type', 'application/json;charset=UTF-8');
  res.end();
  logger.info('experience : router : Options call experience APIs processed !');
});

router.all('/*', function (req, res) {
  logger.error('No matching resource for URL : ' + req.originalUrl);
  var error = new ErrorResponse();
  error.setErrorCode("E0002");
  error.setErrorMessage('No matching resource for URL: ' + req.originalUrl);
  error.setHttpResponseCode(404);
  res.status(404).send(JSON.stringify(error));
});

module.exports = router;
