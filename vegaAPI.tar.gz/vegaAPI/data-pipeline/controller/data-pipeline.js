'use strict';

var logger = require('../../common/logger').log
.child({
  module: 'Data Pipeline',
  type: 'controller'
}),
async = require('async'),
OozieHelper = require('./../../oozie-adapter/client'),
PlatformError = require('../../common/platform-error');

function getPipelineDetails(piplelineReq, cb) {

  // todo: replace with db call to get pipeline details
  var pipeline;
  if(piplelineReq.id == '1212-uuid') {
    pipeline = {
  		'id' : '1212-uuid',
  		'name' : 'palliative prognostic pipeline',
  		'description' : 'end to end palliative prognostic pipeline',
  		'created' : new Date(),
  		'update' : new Date(),
  		'version' : 0,
  		'createdBy' : 'vishal',
  		'configurations' : [
  			{'name' : 'user.name', 'value' : 'hdfs'},
  			{'name' : 'oozie.wf.application.path', 'value' : 'hdfs://vegahcaredtlake.persistent.co.in:8020/workflows/palliative-prognostic'},
  			{'name' : 'hdfsDirPath', 'value' : 'data/palliative-prognostic'},
  			{'name' : 'hdfsTempDirPath', 'value' : 'workflows/palliative-prognostic/temp'},
  			{'name' : 'inputFileNamePattern', 'value' : 'survey.json'},
  			{'name' : 'inputDirPath', 'value' : '/home/project/lake_input/palliative_survey'},
  			{'name' : 'mapReduceQueue', 'value' : 'default'},
  			{'name' : 'jobTracker', 'value' : 'vegahcaredtlake.persistent.co.in:8050'},
  			{'name' : 'nameNode', 'value' : 'hdfs://vegahcaredtlake.persistent.co.in:8020'}
  		]
  	};
  } else {
    pipeline = {
  		'id' : '1213-uuid',
  		'name' : 'HL7V2.x to FHIR',
  		'description' : 'Data pipeline to convert HL7V2 message entities to FHIR entities.',
  		'created' : new Date(),
  		'update' : new Date(),
  		'version' : 0,
  		'createdBy' : 'Gitanjali',
  		'configurations' : [
  			{'name' : 'user.name', 'value' : 'hdfs'},
  			{'name' : 'oozie.wf.application.path', 'value' : 'hdfs://vegahcaredtlake.persistent.co.in:8020/user/project/workflows/hl7v2-ingestion'},
  			{'name' : 'hdfsWorkflowDir', 'value' : 'user/project/workflows/hl7v2-ingestion'},
  			{'name' : 'hdfsTempDirPath', 'value' : 'user/project/workflows/hl7v2-ingestion/temp'},
  			{'name' : 'inputFileNamePattern', 'value' : 'messages_a01.txt'},
  			{'name' : 'inputDirPath', 'value' : '/home/project/lake_input/hl7v2-ingestion'},
  			{'name' : 'mapReduceQueue', 'value' : 'default'},
  			{'name' : 'jobTracker', 'value' : 'vegahcaredtlake.persistent.co.in:8050'},
  			{'name' : 'nameNode', 'value' : 'hdfs://vegahcaredtlake.persistent.co.in:8020'}
  		]
  	};
  }

  cb(null, pipeline);
}

function processOozieWorkflow(pipeline, cb) {
  OozieHelper.processWorkflow(pipeline, cb);
}

function processPipeline(piplelineReq, cb) {

  logger.info(`Start data pipeline processing for pipeline id ${piplelineReq.id}.`);

  async.waterfall([
    async.apply(getPipelineDetails, piplelineReq),
    processOozieWorkflow
  ], function(err, instanceObj) {
    if (err) {
      cb(err);
      return;
    }

    logger.info(`Successfully scheduled workflow in oozie. Scheduled instance Id : ${instanceObj.id}`);
    cb(null, instanceObj);
  });
}

function getWorkflowExecutionGraph(workflowInstanceId, cb) {
  logger.info(`Get workflow execution graph for instance id : ${workflowInstanceId}`);
  OozieHelper.getJobGraph(workflowInstanceId, cb);
}

function getWorkflowExecutionDetails(workflowInstanceId, cb) {
  logger.info(`Get workflow execution details for instance id : ${workflowInstanceId}`);
  OozieHelper.getJobStatus(workflowInstanceId, cb);
}

module.exports = {
  processPipeline: processPipeline,
  getWorkflowExecutionGraph: getWorkflowExecutionGraph,
  getWorkflowExecutionDetails: getWorkflowExecutionDetails,
};
