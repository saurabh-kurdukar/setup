Temporary directory to contain provisioning specific intermediates.
