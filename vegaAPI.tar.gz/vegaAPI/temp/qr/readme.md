Temporary directory to contain QR code intermediates. Currently, not using it
