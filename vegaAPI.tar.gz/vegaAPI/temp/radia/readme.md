Temporary directory to contain Radia specific JSON intermediates.
