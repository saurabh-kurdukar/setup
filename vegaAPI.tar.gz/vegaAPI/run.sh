#! /bin/bash

# Absolute path to this script, e.g. /home/user/bin/foo.sh
SCRIPT=$(readlink -f "$0")
# Absolute path this script is in, thus /home/user/bin
SCRIPTPATH=$(dirname "$SCRIPT")
echo ${SCRIPTPATH}
#kill running process
kill $(ps aux | grep '[n]ode platformserver.js 8080'|awk '{print $2}')
sudo mkdir -p ${SCRIPTPATH}/logs
CURRENT_TIME=`date +%s%N`
mv ${SCRIPTPATH}/edtplatform.log ${SCRIPTPATH}/logs/edtplatform.log_${CURRENT_TIME}
nohup node platformserver.js 8080 > ${SCRIPTPATH}/edtplatform.log &
