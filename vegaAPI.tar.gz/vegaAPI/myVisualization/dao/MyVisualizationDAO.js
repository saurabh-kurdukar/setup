var MyVisualization = require('../models/MyVisualization');
var logger = require('../../common/logger').log;
var config = require('../../common/Config');
var fs = require('fs');
var async = require('async');
var visualizationDao = require('../../visualization/dao/VisualizationDAO');

/*
 * logging format followed: logger.info(<module_name>: <component name> : <description> : [<long_description>] : <data/params/errors>);
 */


/*
 * Add new myVisualization details
 */
var addNewMyVisualization = function(req, res, callback) {
	logger.info('MyVisualization : DAO : received request : addNewMyVisualization : body : ' + JSON.stringify(req.body));
	if(req.body.createdBy) {
		req.body.updatedBy = req.body.createdBy;
	}
	var myVisualization = new MyVisualization(req.body);

	var query = {};
	var nameRegex = new RegExp(['^', req.body.name, '$'].join(''), 'i');
	var usernameRegex = new RegExp(['^', req.body.username, '$'].join(''), 'i');

	query.name = nameRegex;
	query.username = usernameRegex;

	MyVisualization.findOne(query, function(err, data) {
		if(err) {
			fs.unlinkSync(req.body.transformationScriptPath);
			logger.error('MyVisualization : DAO : failed addNewMyVisualization : get by id : error : ' + err);
			callback(err, null);
		}
		else if(data) {
			fs.unlinkSync(req.body.transformationScriptPath);
			var err = new Error('MyVisualization name/username combination already exists');
			err.status = 409;
			logger.error('MyVisualization : DAO : failed addNewMyVisualization : error : Username already exists');
			callback(err, null);
		}
		else {
			myVisualization.save(function(err, data) {
				if (err) {
					logger.error('MyVisualization : DAO : failed addNewMyVisualization : error : ' + err);
					callback(err, null);
				} else if(data != null){
					logger.info('MyVisualization : DAO : addNewMyVisualization successful !');
					callback(null, data);
				} else {
					var err = new Error('Failed to add new myVisualization details');
					logger.error('MyVisualization : DAO : failed addNewMyVisualization : error : '+ err);
					callback(err, null);
				}
			});
		}
	})
};

/*
 * Get all myVisualizations
 */
var getAllMyVisualizations = function(req, res, callback) {
	logger.info('MyVisualization : DAO : received request : getAllMyVisualizations');

	var query = {};
	var nameRegex, usernameRegex;
	if(req.query.name && req.query.username) {
		logger.info('MyVisualization : DAO : received request : getAllMyVisualizations : name : ' + req.query.name + ' :: username : ' + req.query.username);
		var myVisualizationName = decodeURIComponent(req.query.name);
		var myVisualizationUsername = decodeURIComponent(req.query.username)
		nameRegex = new RegExp(['^', myVisualizationName, '$'].join(''), 'i');
		usernameRegex = new RegExp(['^', myVisualizationUsername, '$'].join(''), 'i');
		query.name = nameRegex;
		query.username = usernameRegex;
	}
	else if(req.query.username) {
		logger.info('MyVisualization : DAO : received request : getAllMyVisualizations : username : ' + req.query.username);
		var myVisualizationUsername = decodeURIComponent(req.query.username)
		usernameRegex = new RegExp(['^', myVisualizationUsername, '$'].join(''), 'i');
		query.username = usernameRegex;
	}

	MyVisualization.find(query, function(err, data) {
		if(err) {
			logger.error('MyVisualization : DAO : failed getAllMyVisualizations : error : ' + err);
			callback(err, null);
		}
		else {
			if (data.length != 0) {
				var responseData = [];
				async.eachSeries(data, function(record, cb) {
					var mv = JSON.parse(JSON.stringify(record));
					req.params.id = mv.referenceId;
					visualizationDao.getVisualizationById(req, res, function(fail, success) {
						if(fail) {
							logger.error('MyVisualization : DAO : getAllMyVisualizations : failed to get visualization by id : error : ' + err);
							cb(fail, null);
						}
						else {
							mv.referenceId = success;
							responseData.push(mv);
							cb(null, success);
						}
					})
				}, function(err) {
					if(err) {
						callback(err, null);
					}
					else {
						logger.info('MyVisualization : DAO : getAllMyVisualizations successful !');
						callback(null, responseData);
					}
				})
			} else {
				var err = new Error('No records found');
				err.status = 404;
				logger.error('MyVisualization : DAO : failed getAllMyVisualizations : error : ' + err);
				callback(err, null);
			}
		}
	})
}

/*
 * Get myVisualization by id
 */
var getMyVisualizationById = function(req, res, callback) {
	logger.info('MyVisualization : DAO : received request : getMyVisualizationById : id : ' + req.params.id);

	MyVisualization.findOne({
		id: req.params.id
	}, function(err, data) {
		if(err) {
			logger.error('MyVisualization : DAO : failed getMyVisualizationById : error : ' + err);
			callback(err, null);
		}
		else {
			if(data) {
				logger.info('MyVisualization : DAO : getMyVisualizationById successful !');
				callback(null, data);
			} else {
				var err = new Error('Invalid myVisualization id');
				err.status = 404;
				logger.error('MyVisualization : DAO : failed getMyVisualizationById : error : ' + err);
				callback(err, null);
			}
		}
	})
}

/*
 * Update myVisualization by id
 */
var updateMyVisualizationById = function(req, res, callback) {
	logger.info('MyVisualization : DAO : received request : updateMyVisualizationById : id : ' + req.params.id);

	var json = {};
	if(req.body.username) {
		json.username = req.body.username;
	}
	if(req.body.name) {
		json.name = req.body.name;
	}
	if(req.body.description) {
		json.description = req.body.description;
	}
	if(req.body.version) {
		json.version = req.body.version;
	}
	if(req.body.tags && req.body.tags.length > 0) {
		json.tags = req.body.tags;
	}
	if(req.body.queryString) {
		json.queryString = req.body.queryString;
	}
	if(req.body.referenceId) {
		json.referenceId = req.body.referenceId;
	}
	if(req.body.updatedBy) {
		json.updatedBy = req.body.updatedBy;
	}
	if(req.body.transformationScriptLocation) {
		json.transformationScriptLocation = req.body.transformationScriptLocation;
	}
	json.updatedOn = new Date();

	MyVisualization.findOne({
		id: req.params.id
	}, function(error, myVisualization) {
		if(error) {
			logger.error('MyVisualization : DAO : failed updateMyVisualizationById : get by id : error : ' + error);
			callback(error, null);
		}
		else {
			if(myVisualization) {
				MyVisualization.findOneAndUpdate({
					id: req.params.id
				}, json, {
					new: true
				}, function(err, data) {
					if(err) {
						logger.error('MyVisualization : DAO : failed updateMyVisualizationById : error : ' + err);
						callback(err, null);
					}
					else {
						if(data) {
							if(req.body.transformationScriptLocation) {
								var filePath = config.BINARY_STORAGE.BASE_PATH + config.BINARY_STORAGE.MYVISUALIZATION + myVisualization.transformationScriptLocation.split('/').pop();
								deleteMyVisualizationFile(filePath, function(err, file) {
									if(err) {
										callback(err, null);
										return;
									}
									else {
										logger.info('MyVisualization : DAO : updateMyVisualizationById successful !');
										callback(null, data);
									}
								});
							}
							else {
								logger.info('MyVisualization : DAO : updateMyVisualizationById successful !');
								callback(null, data);
							}
						}
						else {
							var err = new Error('Invalid myVisualization id');
							err.status = 404;
							logger.error('MyVisualization : DAO : failed updateMyVisualizationById : error : ' + err);
							callback(err, null);
						}
					}
				})
			} else {
				var err = new Error('Invalid myVisualization id');
				err.status = 404;
				logger.error('MyVisualization : DAO : failed updateMyVisualizationById : error : ' + err);
				callback(err, null);
			}
		}
	})
}

/*
 * Delete myVisualization by id
 */
var deleteMyVisualizationById = function(req, res, callback) {
	logger.info('MyVisualization : DAO : received request : deleteMyVisualizationById : id : ' + req.params.id);

	MyVisualization.findOne({
		id: req.params.id
	}, function(err, data) {
		if(err) {
			logger.error('MyVisualization : DAO : failed deleteMyVisualizationById : get myVisualization by id : error : ' + err);
			callback(err, null);
		}
		else {
			if(data) {
				var filePath = config.BINARY_STORAGE.BASE_PATH + config.BINARY_STORAGE.MYVISUALIZATION + data.transformationScriptLocation.split('/').pop();
				MyVisualization.remove({
					id: req.params.id
				}, function(err, data) {
					if(err) {
						logger.error('MyVisualization : DAO : failed deleteMyVisualizationById : error : ' + err);
						callback(err, null);
					}
					else {
						deleteMyVisualizationFile(filePath, function(err, data) {
							if(err) {
								callback(err, null);
							}
							else {
								logger.info('MyVisualization : DAO : deleteMyVisualizationById successful !');
								callback(null, "MyVisualization deleted successfully");
							}
						});
					}
				})
			} else {
				var err = new Error('Invalid myVisualization id');
				err.status = 404;
				logger.error('MyVisualization : DAO : failed getMyVisualizationById : error : ' + err);
				callback(err, null);
			}
		}
	})
}

/*
 * Delete myVisualization file
 */
var deleteMyVisualizationFile = function(file, callback) {
	logger.error('MyVisualization : DAO : deleteMyVisualizationFile : file : ' + file);
	if(fs.existsSync(file)) {
		fs.unlink(file, function(err) {
			if(err) {
				logger.error('MyVisualization : DAO : deleteMyVisualizationFile : error : ' + err);
				callback(err, null);
			}
			else {
				logger.error('MyVisualization : DAO : deleteMyVisualizationFile successful! ');
				callback(null, file);
			}
		})
	}
	else {
		logger.error('MyVisualization : DAO : deleteMyVisualizationFile : No visualization found to delete !');
		callback(null, file);
	}
}

/*
 * Search myVisualizations
 */
var searchMyVisualizations = function(req, res, callback) {
	logger.info('MyVisualization : DAO : received request : searchMyVisualizations : text : ' + req.query.text);

	if(!req.query.text) {
		var err = new Error('No tags found');
		logger.error('MyVisualization : DAO : failed searchMyVisualizations : error : No text found');
		callback(err, null);
	}
	else {
		var queryString = decodeURIComponent(req.query.text);
		var split = queryString.split(",");
		var searchString = "";
		split.forEach(function(word) {
			searchString += "\"" + word + "\" ";
		})

		MyVisualization.find({
			$text: {
				$search: req.query.text
			}
		}, function(err, data) {
			if(err) {
				logger.error('MyVisualization : DAO : failed searchMyVisualizations : error : ' + err);
				callback(err, null);
			}
			else {
				if(data.length > 0) {
					logger.info('MyVisualization : DAO : searchMyVisualizations successful !');
					callback(null, data);
				} else {
					var err = new Error('No records found');
					err.status = 404;
					logger.error('MyVisualization : DAO : failed searchMyVisualizations : error : ' + err);
					callback(err, null);
				}
			}
		})
	}
}


module.exports.addNewMyVisualization = addNewMyVisualization;
module.exports.getAllMyVisualizations = getAllMyVisualizations;
module.exports.getMyVisualizationById = getMyVisualizationById;
module.exports.updateMyVisualizationById = updateMyVisualizationById;
module.exports.deleteMyVisualizationById = deleteMyVisualizationById;
module.exports.searchMyVisualizations = searchMyVisualizations;
