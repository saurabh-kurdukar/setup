var express = require('express');
var myVisualizationController = require('./controller/MyVisualizationController');
var logger = require('../common/logger').log;
var ErrorResponse = require('../common/ErrorResponse').ErrorResponse;
var router = express.Router();
var config = require('../common/Config');

/*
 * logging format followed: logger.info(<module_name>: <component name> : <description> : [<long_description>] : <data/params/errors>);
 */

/*
 * Add new myVisualization details
 */
router.post('/', function(req, res) {
	logger.info('MyVisualization : router : received request : addNewMyVisualization : body : ' + JSON.stringify(req.body));
	myVisualizationController.addNewMyVisualization(req, res, function(err, data) {
		if(err) {
			logger.error('MyVisualization : router : failed addNewMyVisualization : error : '+err);
			var error = new ErrorResponse();
			if(err.name == 'ValidationError'){
				error.setErrorMessage(err.errors[Object.keys(err.errors)[0]].message);
			} else {
				error.setErrorMessage(err.message);
			}
			error.setErrorCode("MV0001");
			var errorStatus = 500;
			if(err.status) {
				errorStatus = err.status;
			}
			error.setHttpResponseCode(errorStatus);
			res.status(errorStatus).end(JSON.stringify(error));
		}
		else {
			logger.info('MyVisualization : router : addNewMyVisualization successful !');
			res.status(200).end(JSON.stringify(data));
		}
	});
});

/*
 * Get all myVisualizations
 */
router.get('/', function(req, res) {
	logger.info('MyVisualization : router : received request : getAllMyVisualizations');
	myVisualizationController.getAllMyVisualizations(req, res, function(err, data) {
		if(err) {
			logger.error('MyVisualization : router : failed getAllMyVisualizations : error : ' + err);
			var error = new ErrorResponse();
			error.setErrorCode("MV0002");
			error.setErrorMessage(err.message);
			var errorStatus = 500;
			if(err.status) {
				errorStatus = err.status;
			}
			error.setHttpResponseCode(errorStatus);
			res.status(errorStatus).end(JSON.stringify(error));
		}
		else {
			logger.info('MyVisualization : router : getAllMyVisualizations successful!');
			res.status(200).end(JSON.stringify(data));
		}
	})
})

/*
 * Search myVisualizations
 */
router.get('/search', function(req, res) {
	logger.info('MyVisualization : router : received request : searchMyVisualizations : text : ' + req.query.text);
	myVisualizationController.searchMyVisualizations(req, res, function(err, data) {
		if(err) {
			logger.error('MyVisualization : router : failed searchMyVisualizations : error : ' + err);
			var error = new ErrorResponse();
			error.setErrorCode("MV0006");
			error.setErrorMessage(err.message);
			var errorStatus = 500;
			if(err.status) {
				errorStatus = err.status;
			}
			error.setHttpResponseCode(errorStatus);
			res.status(errorStatus).end(JSON.stringify(error));
		}
		else {
			logger.info('MyVisualization : router : searchMyVisualizations successful!');
			res.status(200).end(JSON.stringify(data));
		}
	})
})

/*
 * Get myVisualization by id
 */
router.get('/:id', function(req, res) {
	logger.info('MyVisualization : router : received request : getMyVisualizationById : id : ' + req.params.id);
	myVisualizationController.getMyVisualizationById(req, res, function(err, data) {
		if(err) {
			logger.error('MyVisualization : router : failed getMyVisualizationById : error : ' + err);
			var error = new ErrorResponse();
			error.setErrorCode("MV0003");
			error.setErrorMessage(err.message);
			var errorStatus = 500;
			if(err.status) {
				errorStatus = err.status;
			}
			error.setHttpResponseCode(errorStatus);
			res.status(errorStatus).end(JSON.stringify(error));
		}
		else {
			logger.info('MyVisualization : router : getMyVisualizationById successful!');
			res.status(200).end(JSON.stringify(data));
		}
	})
})

/*
 * Update myVisualization by id
 */
router.put('/:id', function(req, res) {
	logger.info('MyVisualization : router : received request : updateMyVisualizationById : id : ' + req.params.id);
	myVisualizationController.updateMyVisualizationById(req, res, function(err, data) {
		if(err) {
			logger.error('MyVisualization : router : failed updateMyVisualizationById : error : ' + err);
			var error = new ErrorResponse();
			error.setErrorCode("MV0004");
			error.setErrorMessage(err.message);
			var errorStatus = 500;
			if(err.status) {
				errorStatus = err.status;
			}
			error.setHttpResponseCode(errorStatus);
			res.status(errorStatus).end(JSON.stringify(error));
		}
		else {
			logger.info('MyVisualization : router : updateMyVisualizationById successful!');
			res.status(200).end(JSON.stringify(data));
		}
	})
})

/*
 * Delete myVisualization by id
 */
router.delete('/:id', function(req, res) {
	logger.info('MyVisualization : router : received request : deleteMyVisualizationById : id : ' + req.params.id);
	myVisualizationController.deleteMyVisualizationById(req, res, function(err, data) {
		if(err) {
			logger.error('MyVisualization : router : failed deleteMyVisualizationById : error : ' + err);
			var error = new ErrorResponse();
			error.setErrorCode("MV0005");
			error.setErrorMessage(err.message);
			var errorStatus = 500;
			if(err.status) {
				errorStatus = err.status;
			}
			error.setHttpResponseCode(errorStatus);
			res.status(errorStatus).end(JSON.stringify(error));
		}
		else {
			logger.info('MyVisualization : router : deleteMyVisualizationById successful!');
			res.status(200).end(JSON.stringify(data));
		}
	})
})


module.exports = router;
