var mongoose = require('../../common/MongoDbConnection').mongoose;
var autoIncrement = require('mongoose-auto-increment');
var logger = require('../../common/logger').log;
var connection = mongoose.connection;
autoIncrement.initialize(connection);
/*
 * logging format followed: logger.info(<module_name>: <component name> :
 * <description> : <long_description> : <data/params/errors>);
 */


/*
 * Define schema
 */
var myVisualizationSchema = mongoose.Schema({
  id: Number,
  username: { type : String , required : true },
	name: { type : String , required : true },
  description: String,
  version: String,
  tags: [ String ],
  transformationScriptLocation: String,
  queryString: String,
  referenceId: Number,
  createdBy: String,
  updatedBy: String,
  createdOn: { type: Date, default: Date.now },
  updatedOn: { type: Date, default: Date.now }
});


// logger.info('MyVisualization : model : created schema : MyVisualization :'+JSON.stringify(myVisualizationSchema.paths));

/*
 * Add Auto increment plugin for field myVisualization id
 */
myVisualizationSchema.plugin(autoIncrement.plugin, { model: 'MyVisualization', field: 'id', startAt: 1 });

// Create index for text search
myVisualizationSchema.index({name:"text", description: "text", tags: "text"});

/*
 * Create collection/model in mongo db using Schema
 */
var MyVisualization = mongoose.model('MyVisualization', myVisualizationSchema);
logger.info('MyVisualization : model : created model : MyVisualization : ' + MyVisualization);


module.exports = MyVisualization;
