var myVisualizationDao = require('../dao/MyVisualizationDAO');
var logger = require('../../common/logger').log;
var config = require('../../common/Config');
var fs = require('fs');

/*
 * logging format followed: logger.info(<module_name>: <component name> : <description> : [<long_description>] : <data/params/errors>);
 */


/*
 * Add new myVisualization details
 */
var addNewMyVisualization = function(req, res, callback) {
	logger.info('MyVisualization : controller : received request : addNewMyVisualization : body : ' + JSON.stringify(req.body));
	var fileContent = req.body.transformationScript;
	if(!fileContent) {
		logger.error('MyVisualization : controller : addNewMyVisualization : error : No transformation script found');
		var error = new Error('No transformation script found');
		callback(error, null);
	}
	else {
		var folderPath = config.BINARY_STORAGE.BASE_PATH + config.BINARY_STORAGE.MYVISUALIZATION;
		if(!fs.existsSync(folderPath)) {
			fs.mkdirSync(folderPath);
		}
		var fileName = 'file_' + new Date().getTime() + '.js';
		var savePath = config.BINARY_STORAGE.BASE_PATH + config.BINARY_STORAGE.MYVISUALIZATION + fileName;
		fs.writeFile(savePath, fileContent, 'utf-8', function(err) {
			if(err) {
				logger.error('MyVisualization : controller : addNewMyVisualization : error : ' + err);
				var error = new Error('Failed to write transformation script');
				callback(error, null);
			}
			else {
				req.body.transformationScriptPath = savePath;
				req.body.transformationScriptLocation = config.BINARY_STORAGE.BASE_URL + config.BINARY_STORAGE.MYVISUALIZATION + fileName;
				myVisualizationDao.addNewMyVisualization(req, res, callback);
			}
		})
	}
};

/*
 * Get all myVisualizations
 */
var getAllMyVisualizations = function(req, res, callback) {
	logger.info('MyVisualization : controller : received request : getAllMyVisualizations');
	myVisualizationDao.getAllMyVisualizations(req, res, callback);
}

/*
 * Get myVisualization by id
 */
var getMyVisualizationById = function(req, res, callback) {
	logger.info('MyVisualization : controller : received request : getMyVisualizationById : id : ' + req.params.id);
	myVisualizationDao.getMyVisualizationById(req, res, callback);
}

/*
 * Update myVisualization by id
 */
var updateMyVisualizationById = function(req, res, callback) {
	logger.info('MyVisualization : controller : received request : updateMyVisualizationById : id : ' + req.params.id);
	var fileContent = req.body.transformationScript;
	if(!fileContent) {
		myVisualizationDao.updateMyVisualizationById(req, res, callback);
	}
	else {
		var fileName = 'file_' + new Date().getTime() + '.js';
		var savePath = config.BINARY_STORAGE.BASE_PATH + config.BINARY_STORAGE.MYVISUALIZATION + fileName;
		fs.writeFile(savePath, fileContent, 'utf-8', function(err) {
			if(err) {
				logger.error('MyVisualization : controller : addNewMyVisualization : error : ' + err);
				var error = new Error('Failed to write transformation script');
				callback(error, null);
			}
			else {
				req.body.transformationScriptPath = savePath;
				req.body.transformationScriptLocation = config.BINARY_STORAGE.BASE_URL + config.BINARY_STORAGE.MYVISUALIZATION + fileName;
				myVisualizationDao.updateMyVisualizationById(req, res, callback);
			}
		})
	}
}

/*
 * Delete myVisualization by id
 */
var deleteMyVisualizationById = function(req, res, callback) {
	logger.info('MyVisualization : controller : received request : deleteMyVisualizationById : id : ' + req.params.id);
	myVisualizationDao.deleteMyVisualizationById(req, res, callback);
}

/*
 * Search myVisualizations
 */
var searchMyVisualizations = function(req, res, callback) {
	logger.info('MyVisualization : controller : received request : searchMyVisualizations : text : ' + req.query.text);
	myVisualizationDao.searchMyVisualizations(req, res, callback);
}


module.exports.addNewMyVisualization = addNewMyVisualization;
module.exports.getAllMyVisualizations = getAllMyVisualizations;
module.exports.getMyVisualizationById = getMyVisualizationById;
module.exports.updateMyVisualizationById = updateMyVisualizationById;
module.exports.deleteMyVisualizationById = deleteMyVisualizationById;
module.exports.searchMyVisualizations = searchMyVisualizations;
