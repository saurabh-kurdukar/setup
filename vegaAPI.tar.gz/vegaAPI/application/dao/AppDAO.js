var db = require('../../common/MongoDbConnection');
var App = require('../models/App');
var Experience = require('../../experience/models/Experience');
var logger = require('../../common/logger').log;
var audit = require('../../common/Audit').audit;
var request = require('request');
var fs = require('fs');
var async = require('async');
var config = require('../../common/Config');
const MODULE_NAME = 'application';

/*
 * Add new app
 */
var addNewApp = function(req, res, callback) {
	logger.info(MODULE_NAME + ' : DAO : received request : addNewApp : body : '+JSON.stringify(req.body));
	var reqBody = req.body;
	var app = new App();
	app.setName(reqBody.name);
	app.setDisplayName(reqBody.displayName);
	app.setAppSuffix(reqBody.appSuffix);
	app.setDescription(reqBody.description);
	app.setSummary(reqBody.summary);
	app.setLogo(reqBody.logo);	
	app.setType(reqBody.type);		
	app.setFileName(reqBody.fileName);	
	app.setDistribution(reqBody.distribution);	
	app.setURL(reqBody.url);	
	app.setSwaggerUrl(reqBody.swaggerUrl);	
	app.setBoundFromPort(reqBody.boundFromPort);	
	app.setBoundToPort(reqBody.boundToPort);	
	app.setExperienceId(reqBody.experienceId);		
	app.setVersion(reqBody.version);
	app.setStatus('ACTIVE');	
	app.setDirectDeploy(reqBody.directDeploy);
	app.setDeployOptionFlag(reqBody.deployOptionFlag);
	app.setHostLinkLocation(reqBody.hostLinkLocation);
	app.setSupportedDevices(reqBody.supportedDevices);		
	app.setScreenshots(reqBody.screenshots);	
	app.setMandatoryFlag(reqBody.mandatoryFlag);
	app.setCreatedOn(new Date());
	app.setUpdatedOn(new Date());
	app.setCreatedBy(req.header('username'));	
	app.setUpdatedBy(req.header('username'));
	
	app.save(function(err, data) {
		if (err) {
			logger.error(MODULE_NAME + ' : DAO : failed addNewApp : error : ' + err);
			callback(err, null);
		} else {
			logger.info(MODULE_NAME + ' : DAO : addNewApp successful !');
			callback(null, data);
		}
	});
};

/*
 * Get app by app id
 */
var getAppById = function(req, res, callback) {
	logger.info(MODULE_NAME + ' : DAO : received request : getAppById : (appId:'+req.params.id+')');
	App.findOne({
		'id' : req.params.id,
	}, function(err, data) {
		if (err) {
			logger.error(MODULE_NAME + ' : DAO : failed getAppById : error : ' + err);
			callback(err, null);
		} else {
			if (data != null) {
				logger.info(MODULE_NAME + ' : DAO : getAppById successful !');
				callback(null, data);
			} else {
				var err = new Error('No record exist for app id');
				err.status = 404;
				logger.error(MODULE_NAME + ' : DAO : failed getAppById : error : ' + err);
				callback(err, null);
			}
		}
	});
};

/*
 * Edit/Update app
 */
var updateAppById = function(req, res, callback) {
	logger.info(MODULE_NAME + ' : DAO : received request : updateAppById : (appId:'+req.params.id+', body:'+JSON.stringify(req.body)+')');

	/*
	 * Callback function after getting original record to update with new values.
	 */
	var callbackUpdate = function(err, data) {
		if(err) {
			logger.error(MODULE_NAME + ' : DAO : failed updateAppById : error : ' + err);
			callback(err, null);
		} else if (data != null) {

			var app = data;
			var updatableFields = [
			                       	"displayName", "appSuffix", "description", "summary", "logo", "type", "fileName", 
			                       	"distribution", "url", "swaggerUrl", "boundFromPort", "boundToPort", "version", "status", 
			                       	"directDeploy",	"deployOptionFlag", "hostLinkLocation","mandatoryFlag"
			                      ];
			var updatedData = [];
			var json = {};			
			var reqBodyKeys = Object.keys(req.body);
			for(var i = 0; i < reqBodyKeys.length; i++) {				
				if(updatableFields.indexOf(reqBodyKeys[i]) > -1 && app[reqBodyKeys[i]] != req.body[reqBodyKeys[i]]) {					
					json[reqBodyKeys[i]] = req.body[reqBodyKeys[i]];
					var obj = {};
					obj.column = reqBodyKeys[i];
					obj.oldValue = app[reqBodyKeys[i]];
					obj.newValue = req.body[reqBodyKeys[i]];
					obj.identifier = 'Platform_app_'+req.params.id;
					obj.modifiedBy = 'admin';
					obj.modifiedOn = new Date();
					updatedData.push(obj);
				}
			}
			if(req.body.screenshots && req.body.screenshots.length) {			
				json.screenshots = req.body.screenshots;							
			}
			if(req.body.supportedDevices && req.body.supportedDevices.length) {				
				json.supportedDevices = req.body.supportedDevices;				
			}
			var updateDoc = false;
			if(Object.keys(json).length != 0) {
				updateDoc = true;
			}
			
			if (updateDoc) {
				json.updatedOn = new Date();
				json.updatedBy = req.header('username');
				logger.info(MODULE_NAME + ' : DAO : updateAppById : updating data : ' + JSON.stringify(json));
				App.findOneAndUpdate({
					'id' : req.params.id
				}, json, {
					'new' : true				
				}, function(err, data) {
					if (err) {
						logger.error(MODULE_NAME + ' : DAO : failed updateAppById : error : ' + err);
						callback(err, null);
					} else {
						if (data != null) {
							logger.info(MODULE_NAME + ' : DAO : updateAppById successful !');
							/* Call audit function for changed data */
							audit(req, res, updatedData);
							/* Call function to send response to client */
							callback(null, data);
						} else {
							var err = new Error('No record exist for app id');
							logger.error(MODULE_NAME + ' : DAO : failed updateAppById : error : ' + err);
							callback(err, null);
						}
					}
				});
			} else {
				var err = new Error('No fields modified');
				logger.error(MODULE_NAME + ' : DAO : failed updateAppById : error : ' + err);
				callback(err, null)
			}
		} else {
			var err = new Error('No record exist for app id');
			logger.error(MODULE_NAME + ' : DAO : failed updateAppById : error : ' + err);
			callback(err, null);
		}
	}

	/*
	 * Get the original record from db before update.
	 */
	getAppById(req, res, callbackUpdate);
};

/*
 * Get all apps created under given experience id
 */
var getAllApps = function(req, res, callback) {
	logger.info(MODULE_NAME + ' : DAO : received request : getAllApps : (experienceId:'+req.params.id+')');
	App.find({
		'experienceId' : req.params.id
	}, function(err, data) {
		if (err) {
			logger.error(MODULE_NAME + ' : DAO : failed getAllApps : error : ' + err);
			callback(err, null);
		} else {
			if (data.length != 0) {
				logger.info(MODULE_NAME + ' : DAO : getAllApps successful !');
				callback(null, data);
			} else {
				var err = new Error('No apps exist for experience id');
				err.status = 404;
				logger.error(MODULE_NAME + ' : DAO : failed getAllApps : error : ' + err);
				callback(err, null);
			}
		}
	});
};

var existAppId = function(id, callback) {
	App.count({id: id}, function (err, count){ 
	    if(err){
	        return callback(err);
	    }
	    if(count > 0) {
	    	return callback();
	    }
	    var err = new Error('no record exist for app id');
	    err.status = 200;
	    callback(err);
	}); 
}

/*
 * Get all apps created under given App Type
 */
var getApplicationsByType = function(req, res, callback) {
	logger.info(MODULE_NAME + ' : DAO : received request : getApplicationsByType : (appType:'+req.query.type+')');
    var type = req.query.type;
    
    if( ( type == undefined ) || ( type == null )  )
    {
        /* var err = new Error('type parameter missing from query');
	    err.status = 422;
	    callback(err); */
		App.find(function(err, data) {
		if (err) {
			logger.error(MODULE_NAME + ' : DAO : failed getApps : error : ' + err);
			callback(err, null);
		} else {
			if (data.length != 0) {
				logger.info(MODULE_NAME + ' : DAO : getApps successful !');
				callback(null, data);
			} else {
				var err = new Error('No apps exist');
				err.status = 404;
				logger.error(MODULE_NAME + ' : DAO : failed getApps : error : ' + err);
				callback(err, null);
			}
		}
	});
		
    }
    else
    {
        type = type.trim();
        if( type.length == 0 )
        {
            var err = new Error('No data passed in given type query');
            err.status = 422;
            callback(err);             
         }

        App.find({
            'type' : type.toUpperCase()
        }, function(err, data) {
            if (err) {
                logger.error(MODULE_NAME + ' : DAO : failed getApplicationsByType : error : ' + err);
                callback(err, null);
            } else {
                if (data.length != 0) {
                    logger.info(MODULE_NAME + ' : DAO : getApplicationsByType successful !');
                    callback(null, data);
                } else {
                    var err = new Error('No apps exist under given application type');
                    err.status = 422;
                    logger.error(MODULE_NAME + ' : DAO : failed getApplicationsByType : error : ' + err);
                    callback(err, null);
                }
            }
        });
    }
};


module.exports.addNewApp = addNewApp;
module.exports.getAppById = getAppById;
module.exports.updateAppById = updateAppById;
module.exports.getAllApps = getAllApps;
module.exports.existAppId = existAppId;
module.exports.getApplicationsByType = getApplicationsByType;
