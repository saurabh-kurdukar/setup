var appDao = require('../dao/AppDAO');
var experienceDao = require('../../experience/dao/ExperienceDAO');
var documentDao = require('../../documents/dao/DocumentDAO');
var attributesDao = require('../../attributes/dao/AttributesDAO');
var logger = require('../../common/logger').log;
const MODULE_NAME = 'application';

/*
 * Add new app
 */
var addNewApp = function(req, res, callback) {
	logger.info(MODULE_NAME + ' : controller : received request : addNewApp : body : '+JSON.stringify(req.body));
	appDao.addNewApp(req, res, callback);
};

/*
 * Get app by app id & company id
 */
var getAppById = function(req, res, callback) {
	logger.info(MODULE_NAME + ' : controller : received request : getAppById : (appId:'+req.params.id+')');
	appDao.getAppById(req, res, callback);
};

/*
 * Edit/Update app
 */
var updateAppById = function(req, res, callback) {
	logger.info(MODULE_NAME + ' : controller : received request : updateAppById : (appId:'+req.params.id+', body:'+JSON.stringify(req.body)+')');
	appDao.updateAppById(req, res, callback);
};


/*
 * Get documents by app id
 */
var getDocumentsByAppId = function(req, callback) {
	logger.info(MODULE_NAME + ' : controller : received request : getDocumentsByAppId : (appId:'+req.params.id+')');
	documentDao.getDocumentsByAppId(req.params.id, callback);
};

/*
 * Get applications by app id
 */
var getApplicationsByType = function(req, res,callback) {
	logger.info(MODULE_NAME + ' : controller : received request : getApplicationsByType : (type:'+req.query.type+')');
	appDao.getApplicationsByType(req , res, callback);
};

/*
* Get all attributes by app id
*/
var getAllAttributes = function(req, callback) {
	logger.info(MODULE_NAME + ' : controller : received request : getAllAttributes : (appId:' + req.params.id + ')');
	req.params.appId = req.params.id; 
	attributesDao.getAllAttributes(req, callback);
};



module.exports.addNewApp = addNewApp;
module.exports.getAppById = getAppById;
module.exports.updateAppById = updateAppById;
module.exports.getDocumentsByAppId = getDocumentsByAppId;
module.exports.getApplicationsByType = getApplicationsByType;
module.exports.getAllAttributes = getAllAttributes;






