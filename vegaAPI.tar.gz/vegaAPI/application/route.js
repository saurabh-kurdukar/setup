var express = require('express');
var appController = require('./controller/AppController');
var logger = require('../common/logger').log;
var ErrorResponse = require('../common/ErrorResponse').ErrorResponse;
var router = express.Router();
const MODULE_NAME = 'application';





/*
* Get all applications by type
*/
router.get('/', function (req, res) {
	logger.info(MODULE_NAME + ' : router : received request : getApplicationsByType : type : '
	+ req.query.type);
	appController.getApplicationsByType(req, res, function(err, data) {
		if(err){
			logger.error(MODULE_NAME + ' : router : failed getApplicationsByType : error : '+err);
			var error = new ErrorResponse();
			error.setErrorCode("AP0001");
			error.setErrorMessage(err.message);
			error.setHttpResponseCode(err.status);
			res.status(err.status).end(JSON.stringify(error));
		}else{
			logger.info(MODULE_NAME + " : router : getApplicationsByType successful !");
			res.status(200).end(JSON.stringify(data));
		}
	});
});


/*
 * Add new app
 */
router.post('/', function(req, res) {
	logger.info(MODULE_NAME + ' : router : received request : addNewApp : body : '+JSON.stringify(req.body));
	if (req.body.experienceId != null) {
		appController.addNewApp(req, res, function(err, data) {
			if (err) {
				logger.error(MODULE_NAME + ' : router : failed addNewApp : error : '+err);   
				var error = new ErrorResponse();
				if (err.name == 'ValidationError') {
					error.setErrorMessage(err.errors[Object.keys(err.errors)[0]].message);
				} else {
					error.setErrorMessage(err.message);
				}
				error.setErrorCode("AP0002");
				error.setHttpResponseCode(500);
				res.status(500).end(JSON.stringify(error));
			} else {
				logger.info(MODULE_NAME + " : router : addNewApp successful !");
				res.status(200).end(JSON.stringify(data));
			}
		});
	} else {
		var error = new ErrorResponse();
		error.setErrorCode("AP0002");
		error.setErrorMessage('experience id not set');
		error.setHttpResponseCode(500);
		logger.error(MODULE_NAME + ' : router : failed addNewApp : error : '+JSON.stringify(error));
		res.status(500).end(JSON.stringify(error));
	}
});

/*
 * Get app by app id
 */
router.get('/:id', function(req, res) {
	logger.info(MODULE_NAME + ' : router : received request : getAppById : (appId:'+req.params.id+')');
	appController.getAppById(req, res, function(err, data) {
		if (err) {
			logger.error(MODULE_NAME + ' : router : failed getAppById : error : '+err);
			var error = new ErrorResponse();
			error.setErrorCode("AP0003");
			error.setErrorMessage(err.message);
			error.setHttpResponseCode(500);
			res.status(500).end(JSON.stringify(error));
		} else {
			logger.info(MODULE_NAME + " : router : getAppById successful !");
			res.status(200).end(JSON.stringify(data));
		}
	});	
});

/*
 * Edit/Update app
 */
router.put('/:id', function(req, res) {
	logger.info(MODULE_NAME + ' : router : received request : updateAppById : (appId:'+req.params.id+', companyId:'+req.header('companyId')+', body:'+JSON.stringify(req.body)+')');
	appController.updateAppById(req, res, function(err, data) {
		if (err) {
			logger.error(MODULE_NAME + ' : router : failed updateAppById : error : '+err);
			var error = new ErrorResponse();
			if (err.name == 'ValidationError') {
				error.setErrorMessage(err.errors[Object.keys(err.errors)[0]].message);
			} else {
				error.setErrorMessage(err.message);
			}
			error.setErrorCode("AP0004");			
			error.setHttpResponseCode(500);
			res.status(500).end(JSON.stringify(error));
		} else {
			logger.info(MODULE_NAME + " : router : updateAppById successful !");
			res.status(200).end(JSON.stringify(data));
		}
	});	
});


/*
 * Get documents by app id
 */
router.get('/:id/documents', function(req, res) {
	logger.info(MODULE_NAME + ' : router : received request : getDocumentsByAppId : (appId:' + req.params.id + ')');
	appController.getDocumentsByAppId(req, function(err, data) {
		if (err) {
			logger.error(MODULE_NAME + ' : router : failed getDocumentsByAppId : error : '+err);
			var error = new ErrorResponse();
			error.setErrorCode("AP0005");
			error.setErrorMessage(err.message);
			error.setHttpResponseCode(err.status);
			return res.status(err.status).end(JSON.stringify(error));
		} 
		logger.info(MODULE_NAME + " : router : getDocumentsByAppId successful !");
		res.status(200).end(JSON.stringify(data));		
	});	
});


/*
* Get all attributes by app id
*/
router.get('/:id(\\d+)/attributes', function(req, res) {
	logger.info(MODULE_NAME + ' : router : received request : getAllAttributes : (appId:' + req.params.id + ')');
	appController.getAllAttributes(req, function(err, data) {
		if (err) {
			logger.error(MODULE_NAME + ' : router : failed getAllAttributes : error : '+err);
			var error = new ErrorResponse();
			error.setErrorCode("AP0006");
			error.setErrorMessage(err.message);
			error.setHttpResponseCode(500);
			return res.status(500).end(JSON.stringify(error));
		} 
		logger.info(MODULE_NAME + " : router : getAllAttributes successful !");
		res.status(200).end(JSON.stringify(data));		
	});	
});



module.exports = router;



