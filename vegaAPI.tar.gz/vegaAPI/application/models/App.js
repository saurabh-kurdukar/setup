var mongoose = require('../../common/MongoDbConnection').mongoose;
var autoIncrement = require('mongoose-auto-increment');
var logger = require('../../common/logger').log;
var connection = mongoose.connection;
autoIncrement.initialize(connection);
const MODULE_NAME = 'application';

/*
 * Define schema
 */
var appSchema = mongoose.Schema({
	id : Number,
    name : { type: String, unique: true, required: 'App name is required' },
    displayName : {type: String},
    appSuffix : {type: String},
    description : {type: String, required: 'field description is required'}, 
    summary : String,
    logo : {type: String},
    type : {type:String, required: 'field type is required'},					// values - ANDROID, IOS, WEBAPP
    fileName: String,    
    distribution: String,
    url : String,
    swaggerUrl : String,
    boundFromPort : Number,
    boundToPort : Number,    
    screenshots : [],
    experienceId : { type: Number, required: 'field experienceId is required' },        
    version : { type: String, required: 'field version is required' },
    status : { type: String, default: 'PENDING'},
    directDeploy : { type: String, enum: ['true', 'false'] },
    deployOptionFlag : { type: String, enum: [ 'DIRECT_DEPLOY', 'HOSTED', 'OTHER' ], required: 'field deployOptionFlag is required' },
    hostLinkLocation : { type: String },
    supportedDevices: [], 					
    /*
    -	if iOS selected: supportedDevices values can be
    iPhone Only, iPad Only, Both iPhone and iPad

    -	if android selected: supportedDevices values can be
    Android Less that 7 Inches, Android Tablet 	more than 7 Inches, All Android Devices
    */
    mandatoryFlag: { type: Boolean, default:false },
    createdOn: { type: Date },
	createdBy: {type: String},
	updatedOn: { type: Date },
	updatedBy: {type: String}
});


logger.info(MODULE_NAME + ' : model : created schema : Apps :'+JSON.stringify(appSchema.paths));


appSchema.path('name').validate(function(value, fn) {	  
	  var App = mongoose.model('Apps');
	  App.find({'name': value}, function (err, data) {
	    fn(err || data.length === 0);
	  });
}, 'App name is already taken');


appSchema.pre('findOneAndUpdate', function(next) {
	  this.options.runValidators = true;
	  next();
});

appSchema.pre('update', function(next) {
	  this.options.runValidators = true;
	  next();
});

appSchema.path('name').validate(function (v) {
	  return (v.length > 0 && v.length <= 100);
}, 'data too long/short for field name'); 

appSchema.path('logo').validate(function (v) {
	  return v.length <= 255;
}, 'data too long for field logo'); 

/*
 *  Add autoincrement for app Id
 */
appSchema.plugin(autoIncrement.plugin, { model: 'Apps', field: 'id', startAt: 175 });

/*
 * Setters
 */
appSchema.methods.setId = function(id) {	
	this.id = id;
};

appSchema.methods.setName = function(name) {
	this.name = name;
};

appSchema.methods.setDisplayName = function(displayName) {
	this.displayName = displayName;
};

appSchema.methods.setAppSuffix = function(appSuffix) {
	this.appSuffix = appSuffix;
};

appSchema.methods.setDescription = function(description) {
	this.description = description;
};

appSchema.methods.setSummary = function(summary) {
	this.summary = summary;
};

appSchema.methods.setLogo = function(logo) {
	this.logo = logo;
};

appSchema.methods.setType = function(type) {
	this.type = type;
};

appSchema.methods.setFileName = function(fileName) {
	this.fileName = fileName;
};

appSchema.methods.setDistribution = function(distribution) {
	this.distribution = distribution;
};

appSchema.methods.setURL = function(url) {
	this.url = url;
};

appSchema.methods.setSwaggerUrl = function(swaggerUrl) {
	this.swaggerUrl = swaggerUrl;
};

appSchema.methods.setBoundFromPort = function(boundFromPort) {
	this.boundFromPort = boundFromPort;
};

appSchema.methods.setBoundToPort = function(boundToPort) {
	this.boundToPort = boundToPort;
};

appSchema.methods.addScreenshot = function(screenshot) {
	this.screenshots.push(screenshot);
};

appSchema.methods.setScreenshots = function(screenshots) {
	this.screenshots = screenshots;
};

appSchema.methods.setExperienceId = function(experienceId) {
	this.experienceId = experienceId;
};

appSchema.methods.setVersion = function(version) {
	this.version = version;
};

appSchema.methods.setStatus = function(status) {
	this.status = status;
};

appSchema.methods.setDirectDeploy = function(directDeploy) {
	this.directDeploy = directDeploy;
};

appSchema.methods.setDeployOptionFlag = function(deployOptionFlag) {
	this.deployOptionFlag = deployOptionFlag;
};

appSchema.methods.setHostLinkLocation = function(hostLinkLocation) {
	this.hostLinkLocation = hostLinkLocation;
};

appSchema.methods.setSupportedDevices = function(supportedDevices) {
	this.supportedDevices = supportedDevices;
};

appSchema.methods.setMandatoryFlag = function(mandatoryFlag) {
	this.mandatoryFlag = mandatoryFlag;
};

appSchema.methods.setCreatedOn = function(createdOn) {
	this.createdOn = createdOn;
};

appSchema.methods.setCreatedBy = function(createdBy) {
	this.createdBy = createdBy;
};

appSchema.methods.setUpdatedOn = function(updatedOn) {
	this.updatedOn = updatedOn;
};

appSchema.methods.setUpdatedBy = function(updatedBy) {
	this.updatedBy = updatedBy;
};

/*
 * Create collection/model in mongo db using Schema
 */
var App = mongoose.model('Apps', appSchema);
logger.info(MODULE_NAME + ' : model : created model : Apps : ' + App);


module.exports = App;
