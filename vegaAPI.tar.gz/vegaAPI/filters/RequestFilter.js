var async = require('async');
var url = require('url');
var companyDao = require('../company/dao/CompanyDAO');
var experienceDao = require('../experience/dao/ExperienceDAO');
var appDao = require('../application/dao/AppDAO');
var platformUserDAO = require('../platformUser/dao/PlatformUserDAO');
var userRegistrationDAO = require('../userManagement/dao/UserRegistrationDAO');
var userRoleDao = require('../userRoles/dao/UserRoleDAO');
var roleDao = require('../roles/dao/RoleDAO');
var ErrorResponse = require('../common/ErrorResponse').ErrorResponse;
var logger = require('../common/logger').log;
var config= require('../common/Config');
var utf8 = require('utf8');
var options_proxy = {
	proxy: {
		host: "hjproxy.persistent.co.in",
		port: 8080,
	}
};
var Client = require('node-rest-client').Client;
//var client = new Client(options_proxy);
var client = new Client();
var skipValidateTokenEndpoint = [{endPoint: "/v1.0/discover", methods: ["GET", "POST", "PUT", "DELETE"]},
                                 {endPoint: "/v1.0/auth/login", methods: ["GET", "POST", "PUT", "DELETE"]},
                                 {endPoint: "/v1.0/platformusers/export", methods: []},
                                 {endPoint: "/v1.0/platformusers", methods: ["GET", "POST", "PUT", "DELETE"]},
                                 {endPoint: "/v1.0/platformusers/activationLink/active", methods: ["GET", "POST", "PUT", "DELETE"]},
                                 {endPoint: "/v1.0/users", methods: ["GET", "POST", "PUT", "DELETE"]},
                                 {endPoint: "/v1.0/captcha", methods: ["GET", "POST", "PUT", "DELETE"]},
                                 {endPoint: "/v1.0/users/captcha/generate", methods: ["GET", "POST", "PUT", "DELETE"]},
                                 {endPoint: "/v1.0/trace", methods: ["GET", "POST", "PUT", "DELETE"]},
                                 {endPoint: "/v1.0/activation", methods: ["GET", "POST", "PUT", "DELETE"]},
                                 {endPoint: "/v1.0/forgotPassword", methods: ["GET", "POST", "PUT", "DELETE"]}
                                ];
const MODULE_NAME = "filters";
const baseUrlAuthorization = "http://edtapiserver.cloudapp.net:8080/VegaIDM";
var async = require('async');
var userRoleDao= require('../userRoles/dao/UserRoleDAO');


var filter = function(req, res, next) {
    logger.info(MODULE_NAME + ' : RequestFilter : received request : (requested path:' + req.originalUrl + ', method:' + req.method + ')');
    async.parallel([
			function(callback) {
				validateRequest(req, res, callback);
			},
            function(callback) {
            	validateRefreshToken(req, res, callback);
            },
            function(callback) {
                encodeQueryParams(req, res, callback);
            },
            function(callback) {
                encodeHeaderParams(req, res, callback);
            },
            function(callback) {
                encodeFormParams(req, res, callback);
            }
            /*
            function(callback) {
            	encodeJSON(req, res, callback);
            }*/
        ],
        function(err, results) {
            //console.log('req.body = '+JSON.stringify(req.body));
            if (err) {
            	var error = new ErrorResponse();
                error.setErrorMessage(err.message);
                error.setErrorCode("RF0001");
                error.setHttpResponseCode(err.status);
                res.status(err.status).end(JSON.stringify(error));
            } else if (results.length != 0) {
                /*
                 * 	Call filter function to filter request
                 */
                callbackFilterRequest(req, res, next);
            } else {
                var error = new ErrorResponse();
                error.setErrorMessage('Internal server error');
                error.setErrorCode("RF0001");
                error.setHttpResponseCode(500);
                res.status(500).end(JSON.stringify(error));
            }
        }
    );
}

/*
 * 	Encode query params
 */
function encodeQueryParams(req, res, callback) {
    //console.log(req.query);
    if (Object.keys(req.query).length != 0) {
        var queryParams = req.query;
        var keys = Object.keys(queryParams);
        for (var i = 0; i < keys.length; i++) {
            if (queryParams[keys[i]]) {
                queryParams[keys[i]] = utf8.encode(queryParams[keys[i]]);
            }
            if (i == keys.length - 1) {
                callback(null, 'encoded query params');
            }
        }
    } else {
        callback(null, 'no query params to encode');
    }
}

/*
 * 	Encode header params
 */
function encodeHeaderParams(req, res, callback) {
    //console.log(req.headers);
    if (Object.keys(req.query).length != 0) {
        var headers = req.headers;
        var keys = Object.keys(headers);
        for (var i = 0; i < keys.length; i++) {
            if (keys[i] === 'companyId' || keys[i] === 'id') {
                headers[keys[i]] = utf8.encode(headers[keys[i]]);
            }
            if (i == keys.length - 1) {
                callback(null, 'encoded header params');
            }
        }
    } else {
        callback(null, 'no header params to encode');
    }
}

/*
 * 	Encode form params
 */
function encodeFormParams(req, res, callback) {
    //console.log('form params:'+JSON.stringify(req.body));
    if (req.header('Content-Type') === 'application/x-www-form-urlencoded' && Object.keys(req.body).length != 0) {
        var formParams = req.body;
        var keys = Object.keys(formParams);
        for (var i = 0; i < keys.length; i++) {
            if (formParams[keys[i]]) {
                formParams[keys[i]] = utf8.encode(formParams[keys[i]]);
            }
            if (i == keys.length - 1) {
                callback(null, 'encoded form params');
            }
        }
    } else {
        callback(null, 'no form params to encode');
    }
}

var pathExist = function(path, method) {
	var pathExist = false;
	var BreakException= {};
	try {
		skipValidateTokenEndpoint.forEach(function(obj, index, array) {
			if(path.indexOf(obj.endPoint) > -1) {
				if(obj.methods.indexOf(method) > -1) {
					//console.log('in skipped list');
					pathExist = true;
				}
				throw BreakException;
			}
		});
	} catch(e) {}
	return pathExist;
}

/*
 * Check if user is allowed to access resource
 */
function validateRequest(req, res, callback) {
	logger.info(MODULE_NAME + ' : RequestFilter : validateRequest : (headers: '+JSON.stringify(req.headers)+
			', requested path:' + req.originalUrl + ', method:' + req.method + ')');
	var environment = config.ENVIRONMENT;
	var url_parts = url.parse(req.originalUrl, false);
	var endPoint = url_parts.pathname;
	if(!(pathExist(endPoint, req.method))) {
		logger.info(MODULE_NAME + ' : RequestFilter : validateRequest : info : path is not in skipped list : '+
				'(headers: '+JSON.stringify(req.headers)+', requested path:' + req.originalUrl + ', method:' + req.method + ')');
		if(environment != "dev") {
			logger.info(MODULE_NAME + ' : RequestFilter : validateRequest : info : allowed role & resource checking, '+
					'enviornment: "'+environment+'" : (headers: '+JSON.stringify(req.headers)+', requested path:' + req.originalUrl + ', method:' + req.method + ')');
			if(req.headers.username) {
				if(!req.headers.rolename) {
					req.headers.rolename = config.DEFAULT_USER_ROLE;
				}
				userRoleDao.getUserRoleByUsernameAndRoleName(req.headers.username, req.headers.rolename, function(err, userRole) {
					if(err) {
						err.status = 500;
						return callback(err);
					}
					req.params.id = userRole.roleId;
					roleDao.getRolesByRoleId(req, res, function(err, roles) {
						if(err) {
							err.status = 500;
							return callback(err);
						}

						var allowedAccess = false;
						roles.resources.some(function(resource, index, array) {
							if(endPoint.indexOf(resource.endPoint) > -1 && resource.allowedMethods.indexOf(req.method) > -1) {
								allowedAccess = true;
								return true;
							}
						});
						if(allowedAccess) {
							logger.info(MODULE_NAME + ' : RequestFilter : validateRequest : allowed access : (headers: '+JSON.stringify(req.headers)+
									', requested path:' + req.originalUrl + ', method:' + req.method + ')');
							callback(null, 'allowed access!');
						} else {
							logger.info(MODULE_NAME + ' : RequestFilter : validateRequest : rejected request, not allowed to access resource : '+
									'(headers: '+JSON.stringify(req.headers)+' ,requested path:' + req.originalUrl + ', method:' + req.method + ')');
							var error = new Error('not allowed to access resource.');
							error.status = 403;
							callback(error);
						}
					});
				});
			} else {
				var error = new Error('missing username in header');
				error.status = 400;
		        callback(error);
			}
		} else {
			logger.info(MODULE_NAME + ' : RequestFilter : validateRequest : info : skipped role & resource checking, '+
					'enviornment: "'+environment+'" : (headers: '+JSON.stringify(req.headers)+', requested path:' + req.originalUrl + ', method:' + req.method + ')');
			callback(null, 'skipped validation for dev enviornment');
		}
	} else {
		logger.info(MODULE_NAME + ' : RequestFilter : validateRequest : info : skipped role & resource checking, '+
				'url is in skipped list : (headers: '+JSON.stringify(req.headers)+', requested path:' + req.originalUrl + ', method:' + req.method + ')');
		callback(null, 'skipped validation, url is in skipped list');
	}
}

/** Validate and refresh token **/
function validateRefreshToken(req, res, callback) {
    //if (!((skipValidateTokenEndpoint.indexOf(req.originalUrl.split("?")[0])) >= 0)  ) {
	var url_parts = url.parse(req.originalUrl, false);
	var endPoint = url_parts.pathname;
    if (!(pathExist(endPoint, req.method))) {
    	if (req.header('access-token') != undefined && req.header('access-token') != "") {
			//auth API
			var args = {
                data: {
                    userId: config.FORGEROCK_USERID,
                    password: config.FORGEROCK_PASSWORD
                },
                headers: {
                    "Content-Type": "application/json",
                    "Accept": "application/json"
                }
            };
			client.post(config.FORGRROCK_URL + "/api/v1/users/authenticate", args, function(data, response) {
				logger.info("token="+data.tokenId);
                var tokenId = data.tokenId;
				//console.log("header****************"+req.header('access-token'));

				if(data.tokenId == undefined || data.tokenId=="" || data.tokenId== null){
					var error = new ErrorResponse();
		                    error.setErrorMessage('Internal Server Error');
		                    error.setErrorCode("RF0007");
		                    error.setHttpResponseCode(500);
		                    res.status(500).end(JSON.stringify(error));
				}

				else if(data.tokenId) {
					var args = {
		                data: {
							"action":"isActive",
							"refresh":true,
							"tokenId":req.header('access-token')
		                },
		                headers: {
		                    "Content-Type": "application/json",
		                    "Authorization": tokenId
		                }
					};
					client.post(config.FORGRROCK_URL + "/api/v1/session", args, function(data, response) {
		                //console.log("User Active > " + data.active);
		                 if (data.active) {
		                    callback(null, 'access token validated and refreshed');
		                } else {
		                    var error = new ErrorResponse();
		                    error.setErrorMessage('Invalid Token or Token expired');
		                    error.setErrorCode("RF0001");
		                    error.setHttpResponseCode(401);
		                    res.status(401).end(JSON.stringify(error));
		                }
		            });
				} else {
					//error no token
							var error = new ErrorResponse();
		                    error.setErrorMessage('Authentication failed');
		                    error.setErrorCode("RF0001");
		                    error.setHttpResponseCode(401);
		                    res.status(401).end(JSON.stringify(error));
				}
            });

			// Forgerock API is bypassed here

        } else {
            var error = new ErrorResponse();
            error.setErrorMessage('Unauthorized! No access-token in header');
            error.setErrorCode("RF0001");
            error.setHttpResponseCode(401);
            res.status(401).end(JSON.stringify(error));
        }
    } else {
        callback(null, 'New request ignore access token');
    }
}

/*
 * 	Function to encode JSON
 */
/*
function encodeJSON(req, res, callback) {
	if(req.header('Content-Type') === 'application/json') {
		var reqJSON = req.body;
		if(typeof reqJSON == 'object' && !Array.isArray(reqJSON) && Object.keys(reqJSON).length != 0) {
			encodeJSONObject(reqJSON, callback);
		}
		else if(Array.isArray(reqJSON)) {
			encodeJSONArray(reqJSON, callback);
		}
		else {
			callback(null, 'encoded json body');
		}
	} else {
		callback(null, 'encoded json body');
	}
}

function encodeJSONObject(json, parent, callback) {
	var attributes = Object.keys(json);
	for(var i = 0; i < attributes.length; i++)
	{
		if(typeof json[attributes[i]] == 'object' && typeof json[attributes[i]] != 'string' && !Array.isArray(json[attributes[i]])) {
			encodeJSONObject(json[attributes[i]], false, callback);
		}
		else if(Array.isArray(json[attributes[i]])) {
			encodeJSONArray(json[attributes[i]], callback);
		}
		else if(typeof json[attributes[i]] == 'string') {
			json[attributes[i]] = 'hiiii';	utf8.encode(json[attributes[i]]);
		}
		if(i == attributes.length-1 && parent) {
			callback(null, 'encoded json body');
		}
	}
}

function encodeJSONArray(json, callback) {
	for(var i = 0; i < json.length; i++) {
		if(typeof json[i] == 'string') {
			json[i] = 'hii';	//utf8.encode(json[i]);
		} else if(Array.isArray(json[i])){
			encodeJSONArray(json[i], callback);
		} else if(typeof json[i] == 'object' && typeof json[i] != 'string' && !Array.isArray(json[i])) {
			encodeJSONObject(json[i], false, callback);
		}
	}
}
*/

var callbackFilterRequest = function(req, res, next) {
    /*
     *	Filter /companies request: GET, POST, PUT, DELETE
     */
    if (req.originalUrl.match('\/v[^/]*\/companies')) {
        logger.info(MODULE_NAME + ' : RequestFilter : companies : (requested path:' + req.originalUrl + ', method:' + req.method + ')');
        var pathValues = req.originalUrl.split("/");
        var companyId = Number(pathValues[3]);
        req.params.id = companyId;
        if (req.method == 'POST') {
            logger.info(MODULE_NAME + ' : RequestFilter : companies : proceed to add new company !');
            next();
        } else if (companyId) {
            logger.info(MODULE_NAME + ' : RequestFilter : companies : call getCompanyById');
            companyDao.getCompanyById(req, res, function(err, data) {
                if (err) {
                    var error = new ErrorResponse();
                    error.setErrorMessage(err.message);
                    error.setErrorCode("RF0002");
                    error.setHttpResponseCode(500);
                    logger.error(MODULE_NAME + ' : RequestFilter : companies : failed getCompanyById : error :' + JSON.stringify(error));
                    res.status(500).end(JSON.stringify(error));
                } else {
                    logger.info(MODULE_NAME + ' : RequestFilter : companies : getCompanyById successful !');
                    next();
                }
            });
        } else {
            next();
        }
    }

    /*
     *	Filter /experiencesenrolled request: GET, POST, PUT, DELETE
     */
    else if (req.originalUrl.match('\/v[^/]*\/experiencesenrolled')) {
        logger.info(MODULE_NAME + ' : RequestFilter : experiencesenrolled : requested path:' + req.originalUrl + ', method:' + req.method);
        var pathValues = req.originalUrl.split("/");

        if (req.method == "POST") {
            next();
        } else if (req.method == "GET" || req.method == "PUT" || req.method == "DELETE") {
            next();
        } else {
            var error = new ErrorResponse();
            error.setErrorMessage('INVALID Method Operations');
            error.setErrorCode("RF0003");
            error.setHttpResponseCode(500);
            logger.error(MODULE_NAME + ' : RequestFilter : experiencesenrolled : error :' + JSON.stringify(error));
            res.status(500).end(JSON.stringify(error));
        }
    }

    /*
     *	Filter /experiences request: GET, POST, PUT, DELETE
     */
    else if (req.originalUrl.match('\/v[^/]*\/experiences')) {
        logger.info(MODULE_NAME + ' : RequestFilter : experiences : (requested path:' + req.originalUrl + ', method:' + req.method + ')');
        var pathValues = req.originalUrl.split("/");
        var id = Number(pathValues[3]);
        if (req.method == "POST" || (req.method == "GET" && !id)) {
            next();
        } else if (id) {
            logger.info(MODULE_NAME + ' : RequestFilter : experiences : call getExperienceById');
            req.params.id = id;
            experienceDao.getExperienceById(req, res, function(err, data) {
                if (err) {
                    var error = new ErrorResponse();
                    error.setErrorMessage(err.message);
                    error.setErrorCode("RF0004");
                    error.setHttpResponseCode(500);
                    logger.error(MODULE_NAME + ' : RequestFilter : experiences : failed getExperienceById : error :' + JSON.stringify(error));
                    res.status(500).end(JSON.stringify(error));
                } else {
                    logger.info(MODULE_NAME + ' : RequestFilter : experiences : getExperienceById successful !');
                    next();
                }
            });
        } else {
            var error = new ErrorResponse();
            error.setErrorMessage('experience id not set');
            error.setErrorCode("RF0004");
            error.setHttpResponseCode(500);
            logger.error(MODULE_NAME + ' : RequestFilter : experiences : error :' + JSON.stringify(error));
            res.status(500).end(JSON.stringify(error));
        }
    }

    /*
     *	Filter /apps request: GET, POST, PUT, DELETE
     */
    else if (req.originalUrl.split('?')[0].match('\/v[^/]*\/apps')) {
        logger.info(MODULE_NAME + ' : RequestFilter : apps : (requested path:' + req.originalUrl + ', method:' + req.method + ')');
        var pathValues = req.originalUrl.split("/");
        var id = Number(pathValues[3]); //app id
        var experienceId = Number(req.body.experienceId);
        if (experienceId && req.method == "POST") {
            logger.info(MODULE_NAME + ' : RequestFilter : apps : call getExperienceById');
            req.params.id = experienceId;
            experienceDao.getExperienceById(req, res, function(err, data) {
                if (err) {
                    var error = new ErrorResponse();
                    error.setErrorMessage(err.message);
                    error.setErrorCode("RF0005");
                    error.setHttpResponseCode(500);
                    logger.error(MODULE_NAME + ' : RequestFilter : apps : failed getExperienceById : error :' + JSON.stringify(error));
                    res.status(500).end(JSON.stringify(error));
                } else {
                    logger.info(MODULE_NAME + ' : RequestFilter : apps : getExperienceById successful !');
                    next();
                }
            });
        } else if (id) {
            logger.info(MODULE_NAME + ' : RequestFilter : apps : call getAppById');
            req.params.id = id;
            appDao.getAppById(req, res, function(err, data) {
                if (err) {
                    var error = new ErrorResponse();
                    error.setErrorMessage(err.message);
                    error.setErrorCode("RF0005");
                    error.setHttpResponseCode(500);
                    logger.error(MODULE_NAME + ' : RequestFilter : apps : failed getAppById : error :' + JSON.stringify(error));
                    res.status(500).end(JSON.stringify(error));
                } else {
                    logger.info(MODULE_NAME + ' : RequestFilter : apps : getAppById successful !');
                    next();
                }
            });
        } else {
            var error = new ErrorResponse();
            error.setErrorMessage('App id or experience id not set');
            error.setErrorCode("RF0001");
            error.setHttpResponseCode(500);
            logger.error(MODULE_NAME + ' : RequestFilter : apps : error :' + JSON.stringify(error));
            next();
            //res.status(500).end(JSON.stringify(error));
        }
    }

    /*
     *	Filter /authenticate request: POST
     */
    else if (req.originalUrl.match('\/v[^/]*\/auth/login')) {

        if (req.method == "POST") { //Change method name once you need to do final coding
            var args = {
                data: {
                    userId: req.body.username.toLowerCase(),
                    password: req.body.password
                },
                headers: {
                    "Content-Type": "application/json",
                    "Accept": "application/json"
                }
            };

// Calling forgerock authenticate API, once forgerock API is in place implement platform and non platform user logic in success of forgerock autenticate API.
				client.post(config.FORGRROCK_URL+"/api/v1/users/authenticate", args, function (data, response) {

					//console.log("access-token: "+data.tokenId);
					var headerTokenId = data.tokenId;
					if(response.statusCode==200)
					{


            		//res.status(200).end("");
// TODO - Further platform specific token will be generated here

			req.params.username = req.body.username.toLowerCase();
// Logic for persistent users
            if (req.params.username.split("@")[1] === "persistent.co.in" || req.params.username.split("@")[1] === "persistent.com" || req.params.username.split("@")[1] === "persistentsys.com") {

                platformUserDAO.getUserByUsername(req, res, function(err, data) {
                    if (err) {
// Logic for Invalid persistent users
						if(err.status== 404)
						{
							nonPslAuth(headerTokenId,req,res,function(err,data){
								if(err){
									var error = new ErrorResponse();
									error.setErrorMessage(err.message);
									error.setErrorCode(err.statusCode);
									res.end(JSON.stringify(err));
								}
								else{
									res.status(200).end(JSON.stringify(data));
								}
							})
				}
						else
						{
						var error = new ErrorResponse();
						error.setErrorMessage("Unauthorized user");
						error.setErrorCode("AU0002");
						error.setHttpResponseCode(401);
						res.status(401).end(JSON.stringify(error));
						}
                    } else if (data[0] != undefined && data[0].verified) {
// Logic for activated persistent users

							var response= JSON.stringify(data[0]);
							var authResponse={};

							//get Role Details
							userRoleDao.getUserRolesByUsername(req,res,function(err,userroles){
								if(err)
								{
									logger.error(' RequestFilter : users : error :' + JSON.stringify(err));
									var error = new ErrorResponse();
									error.setErrorMessage(err.message);
									error.setHttpResponseCode(500);
									res.status(500).end(JSON.stringify(error));
								}
								else
								{
									//combine user response with user role response
									authResponse.verified= data[0].verified;
									authResponse.attributes= data[0].attributes;
									authResponse.referenceCompanyId= data[0].referenceCompanyId;
									authResponse.experienceCount= data[0].experienceCount;
									authResponse.vmCount= data[0].vmCount;
									authResponse.lastLoginDatetime= data[0].lastLoginDatetime;
									authResponse.accountStatus= data[0].accountStatus;
									authResponse.username= data[0].username;
									authResponse.userpassword= data[0].userpassword;
									authResponse.telephoneNumber= data[0].telephoneNumber;
									authResponse.mail= data[0].mail;
									authResponse.givenName= data[0].givenName;
									authResponse.sn= data[0].sn;
									authResponse.companyId= data[0].companyId;
									authResponse.createdOn= data[0].createdOn;
									authResponse.id= data[0].id;
									authResponse.userroles= userroles;

										//update last login date
								async.parallel(
									[
										function(callback) {
											res.setHeader("Access-Control-Expose-Headers", "access-token");
											res.setHeader("access-token",headerTokenId);
											res.status(200).end(JSON.stringify(authResponse));
											},
										function(callback) {
											platformUserDAO.updateLastLoginDatetime(req,res);
											},
										function(callback) {
											req.body.username= req.params.username;
											req.body.usertype= 'PU';
											platformUserDAO.addNewLoginActivity(req,res,function(err,data){
												if(err)
													logger.error(' : RequestFilter : users : error :' + JSON.stringify(err));
												})
											}
									], function(err, results) {
										if(err){
											var error = new ErrorResponse();
											error.setErrorMessage(err.message);
											error.setErrorCode("AU0003");
											error.setHttpResponseCode(500);
											res.status(500).end(JSON.stringify(error));

										}
										}
									);
								}
							})
                    } else {
// Logic for non activated non-persistent users
						var error = new ErrorResponse();
            error.setErrorMessage('User not activated');
            error.setErrorCode("AU0001");
            error.setHttpResponseCode(500);
			 res.status(500).end(JSON.stringify(error));
                    }
                });
            } else {
// Logic for non-persistent users
                //res.status(200).end("");
              nonPslAuth(headerTokenId,req,res,function(err,data){
								if(err){
									var error = new ErrorResponse();
									error.setErrorMessage(err.message);
									error.setErrorCode(err.statusCode);
									res.end(JSON.stringify(err));
								}
								else{
									res.status(200).end(JSON.stringify(data));
								}
							})
            }


					}
					else{
						var error = new ErrorResponse();
									error.setErrorMessage('Unauthorized user');
									error.setErrorCode("AU0002");
									error.setHttpResponseCode(401);
									res.status(500).end(JSON.stringify(error));
					}

            });


        } else {
            //do nothing redirect request further
            var error = new ErrorResponse();
            error.setErrorMessage('Incorrect method');
            error.setErrorCode("RF0006"); //Change error code once you need to do final coding  (talk with Pavan Agine)
            error.setHttpResponseCode(500);
            logger.error(MODULE_NAME + ' : RequestFilter : apps : error :' + JSON.stringify(error));
            res.status(500).end(JSON.stringify(error));
        }
    }

    /*
     *	Filter all the other requests: GET, POST, PUT, DELETE
     */
    else {
        logger.info(MODULE_NAME + ' : RequestFilter : No filtering available, Submit to next route : (requested path:' + req.originalUrl + ', method:' + req.method + ')');
        next();
    }
}



var nonPslAuth= function(headerTokenId,req,res,callback)
{
	userRegistrationDAO.getUserByUsername(req, res, function(err, data) {
                    if (err) {
// Logic for Invalid non-persistent users
                        var error = new ErrorResponse();
						error.setErrorMessage("Unauthorized user");
						error.setErrorCode("AU0002");
						error.setHttpResponseCode(401);
						res.status(401).end(JSON.stringify(error));
                    } else if (data[0] != undefined && data[0].verified) {
// Logic for activated non-persistent users


						var response= JSON.stringify(data[0]);
						var authResponse={};

							//get Role Details
							userRoleDao.getUserRolesByUsername(req,res,function(err,userroles){
								if(err)
								{
									logger.error(' RequestFilter : users : error :' + JSON.stringify(err));
									var error = new ErrorResponse();
									error.setErrorMessage(err.message);
									error.setHttpResponseCode(500);
									res.status(500).end(JSON.stringify(error));
								}
								else
								{

									//combine user response with user role response
									authResponse.verified= data[0].verified;
									authResponse.username= data[0].username;
									authResponse.password= data[0].password;
									authResponse.companyId= data[0].companyId;
									authResponse.userId= data[0].userId;
									authResponse.userroles= userroles;
									authResponse.givenName= data[0].givenName;
									authResponse.sn= data[0].lastname;
									authResponse.mail= data[0].username;

								async.parallel(
									[
										function(callback) {
											res.setHeader("Access-Control-Expose-Headers", "access-token");
											res.setHeader("access-token",headerTokenId);
											res.status(200).end(JSON.stringify(authResponse));
											},
										function(callback) {
											userRegistrationDAO.updateLastLoginDatetime(req,res);
											},
										function(callback) {
											req.body.username= req.params.username;
											req.body.usertype= 'U';
											platformUserDAO.addNewLoginActivity(req,res,function(err,data){
												if(err)
													logger.error(' : RequestFilter : users : error :' + JSON.stringify(err));
												})
											}
									], function(err, results) {
										if(err){
											var error = new ErrorResponse();
											error.setErrorMessage(err.message);
											error.setErrorCode("AU0003");
											error.setHttpResponseCode(500);
											res.status(500).end(JSON.stringify(error));

										}
										}
									);
								}
							})

                    } else {
							// Logic for non activated non-persistent users
									var error = new ErrorResponse();
									error.setErrorMessage('User not activated');
									error.setErrorCode("AU0001");
									error.setHttpResponseCode(500);
									res.status(500).end(JSON.stringify(error));
                    }
                });
}
module.exports.filter = filter;
