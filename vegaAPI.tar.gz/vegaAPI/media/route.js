var express = require('express');
var mediaController = require('./controller/MediaController');
var logger = require('../common/logger').log;
var ErrorResponse = require('../common/ErrorResponse').ErrorResponse;
var router = express.Router();
var upload = require('./helpers/uploadFile');
var config = require('../common/Config');
var client = require('scp2');
var fs = require('fs');

/*
 * logging format followed: logger.info(<module_name>: <component name> : <description> : [<long_description>] : <data/params/errors>);
 */

/*
 * Add new media details
 */
router.post('/', upload.any(), function(req, res) {

	var addMediaToDb = function(filePath) {
		logger.info('media : router : received request : addNewMedia : body : ' + JSON.stringify(req.body));
		mediaController.addNewMedia(req, res, function(err, data) {
			if(err) {
				logger.error('media : router : failed addNewMedia : error : '+err);
				var error = new ErrorResponse();
				if(err.name == 'ValidationError'){
					error.setErrorMessage(err.errors[Object.keys(err.errors)[0]].message);
				} else {
					error.setErrorMessage(err.message);
				}
				error.setErrorCode("M0001");
				error.setHttpResponseCode(500);
				res.status(500).end(JSON.stringify(error));
			}
			else {
				logger.info("media : router : addNewMedia successful !");
				// if(fs.existsSync(filePath) && config.DISTRIBUTION_LOCATION_TYPE.toLowerCase() === "remote") {
				// 	fs.unlinkSync(filePath);
				// }
				res.status(200).end(JSON.stringify(data));
			}
		});
	}

	if(req.fileValidationError) {
		logger.info('media : router : received request : addNewMedia : error : ' + req.fileValidationError);
		var error = new ErrorResponse();
		error.setErrorMessage(req.fileValidationError);
		error.setErrorCode("M0001");
		error.setHttpResponseCode(500);
		res.status(500).end(JSON.stringify(error));
	}
	else if(req.files.length == 0) {
		logger.info('media : router : received request : addNewMedia : error : No file found');
		var error = new ErrorResponse();
		error.setErrorMessage("No file found");
		error.setErrorCode("M0001");
		error.setHttpResponseCode(500);
		res.status(500).end(JSON.stringify(error));
	}
	else {
		var mediaFile = req.files[0];
		var mediaFileLocation = "";
		mediaFileLocation = "";
		if(config.DISTRIBUTION_LOCATION_TYPE.toLowerCase() === "remote") {
			logger.info("media : router : received request : addNewMedia remote");
			if(req.body.mediaType.toLowerCase() === "distribution") {
				var hostServer = config.EXPERIENCE_DISTRIBUTION.USERNAME + ":" + config.EXPERIENCE_DISTRIBUTION.PASSWORD + "@" +
												 config.EXPERIENCE_DISTRIBUTION.HOSTNAME + ":" + config.EXPERIENCE_DISTRIBUTION.PATH;

				client.scp(mediaFile.path, hostServer + mediaFile.filename, function(err) {
					if(err) {
						logger.info('media : router : received request : addNewMedia : error : ' + err);
						var error = new ErrorResponse();
						error.setErrorMessage(err.message);
						error.setErrorCode("M0001");
						error.setHttpResponseCode(500);
						res.status(500).end(JSON.stringify(error));
				  }
					else {
						logger.info("media : router : received request : addNewMedia scp success");
						mediaFileLocation = config.EXPERIENCE_DISTRIBUTION.PATH + mediaFile.filename;
						req.body.mediaFileLocation = mediaFileLocation;
						addMediaToDb(mediaFile.path);
					}
				})
			}
			else if(req.body.mediaType.toLowerCase() === "hosting") {
				mediaFileLocation = config.MEDIA_SITE_BASEURL + mediaFile.filename;
				req.body.mediaFileLocation = mediaFileLocation;
				addMediaToDb(mediaFile.path);
			}
		}
		else if(config.DISTRIBUTION_LOCATION_TYPE.toLowerCase() === "local") {
			logger.info("media : router : received request : addNewMedia local");
			if(req.body.mediaType.toLowerCase() === "distribution") {
				mediaFileLocation = config.MEDIA_DISTRIBUTION_LOCATION + mediaFile.filename;
				req.body.mediaFileLocation = mediaFileLocation;
				addMediaToDb(mediaFile.path);
			}
			else if(req.body.mediaType.toLowerCase() === "hosting") {
				mediaFileLocation = config.MEDIA_SITE_BASEURL + mediaFile.filename;
				req.body.mediaFileLocation = mediaFileLocation;
				addMediaToDb(mediaFile.path);
			}
		}
		else {
			logger.info('media : router : received request : addNewMedia : error : No distribution location type defined');
			var error = new ErrorResponse();
			error.setErrorMessage("No distribution location type defined");
			error.setErrorCode("M0001");
			error.setHttpResponseCode(500);
			res.status(500).end(JSON.stringify(error));
		}
	}
});


module.exports = router;
