var mediaDao = require('../dao/MediaDAO');
var logger = require('../../common/logger').log;


/*
 * logging format followed: logger.info(<module_name>: <component name> : <description> : [<long_description>] : <data/params/errors>);
 */


/*
 * Add new media details
 */
var addNewMedia = function(req, res, callback) {
	logger.info('media : controller : received request : addNewMedia : body : '+JSON.stringify(req.body));
	mediaDao.addNewMedia(req, res, callback);
};


module.exports.addNewMedia = addNewMedia;
