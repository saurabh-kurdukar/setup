var mongoose = require('../../common/MongoDbConnection').mongoose;
var autoIncrement = require('mongoose-auto-increment');
var logger = require('../../common/logger').log;
var connection = mongoose.connection;
autoIncrement.initialize(connection);
/*
 * logging format followed: logger.info(<module_name>: <component name> :
 * <description> : <long_description> : <data/params/errors>);
 */


/*
 * Define schema
 */
var mediaSchema = mongoose.Schema({
  mediaId: Number,
	mediaType: { type: String, required: true },
  mediaFileLocation: { type: String, required: true }
});


logger.info('media : model : created schema : Media :'+JSON.stringify(mediaSchema.paths));

/*
 * Add Auto increment plugin for field mediaId
 */
mediaSchema.plugin(autoIncrement.plugin, { model: 'Media', field: 'mediaId', startAt: 1 });


/*
 * Setters
 */
mediaSchema.methods.setMediaId = function(mediaId) {
	this.mediaId = mediaId;
};

mediaSchema.methods.setMediaType = function(mediaType) {
	this.mediaType = mediaType;
};

mediaSchema.methods.setMediaFileLocation = function(mediaFileLocation) {
	this.mediaFileLocation = mediaFileLocation;
};


/*
 * Getters
 */
mediaSchema.methods.getMediaId = function() {
	return this.mediaId;
};

mediaSchema.methods.getMediaType = function() {
	return this.mediaType;
};

mediaSchema.methods.getMediaFileLocation = function() {
	return this.mediaFileLocation;
};

/*
 * Create collection/model in mongo db using Schema
 */
var Media = mongoose.model('Media', mediaSchema);
logger.info('media : model : created model : Media : ' + Media);



module.exports = Media;
