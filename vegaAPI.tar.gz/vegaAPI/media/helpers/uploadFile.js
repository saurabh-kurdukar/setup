var multer  = require('multer');
var fs = require('fs');
var config = require('../../common/Config');

var filePath = config.MEDIA_DISTRIBUTION_LOCATION;
var supported_media_types = config.SUPPORTED_MEDIA_TYPES;
var mediaTypes = config.MEDIA_TYPES;

if(!fs.existsSync(filePath)) {
  fs.mkdirSync(filePath);
}

var storage = multer.diskStorage({
  destination: function (req, file, cb) {
    cb(null, filePath);
  },
  filename: function (req, file, cb) {
  	var ext = file.originalname.split('.').pop();
  	var timestamp = new Date().getTime();
  	var fileName = "file_"+timestamp+"."+ext;
  	cb(null, fileName);
  }
});

function fileFilter(req, file, cb) {
	var ext = file.originalname.split('.').pop();
	if(!file.fieldname) {
    req.fileValidationError = 'No fieldname provided for the file';
	  cb(null, false);
	}
  else if(supported_media_types.indexOf(ext.toLowerCase()) == -1) {
    req.fileValidationError = 'Unsupported Media file';
	  cb(null, false);
	}
  else if(mediaTypes.indexOf(req.body.mediaType.toLowerCase()) == -1) {
    req.fileValidationError = 'Invalid Media type';
	  cb(null, false);
  }
  else {
    cb(null, true);
  }
}

var upload = multer({ storage: storage,  fileFilter: fileFilter });

module.exports = upload;
