var Media = require('../models/Media');
var logger = require('../../common/logger').log;

/*
 * logging format followed: logger.info(<module_name>: <component name> : <description> : [<long_description>] : <data/params/errors>);
 */


/*
 * Add new media details
 */
var addNewMedia = function(req, res, callback) {
	logger.info('media : DAO : received request : addNewMedia : body : '
			+ JSON.stringify(req.body));
	var reqBody = req.body;
	var media = new Media();
	media.setMediaType(reqBody.mediaType.toLowerCase());
	media.setMediaFileLocation(reqBody.mediaFileLocation);

	media.save(function(err, data) {
		if (err) {
			logger.error('media : DAO : failed addNewMedia : error : ' + err);
			callback(err, null);
		} else if(data != null){
			logger.info('media : DAO : addNewMedia successful !');
			callback(null, data);
		} else {
			var err = new Error('Failed to add new media details');
			logger.error('media : DAO : failed addNewMedia : error : '+ err);
			callback(err, null);
		}
	});
};


module.exports.addNewMedia = addNewMedia;
