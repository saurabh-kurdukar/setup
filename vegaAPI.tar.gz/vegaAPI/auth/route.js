var express = require('express'),
captchapng = require('captchapng'),
logger = require('./../common/logger').log
.child({
  module: 'Auth',
  type: 'Captcha'
}),
router = express.Router();

router.get('/',function(request, response) {

  logger.debug('Captcha request received.');

  var imgBuffer,
  value = parseInt(Math.random() * 9000 + 1000),
  p = new captchapng(80, 30, value),
  captchaResponse = {
    captchaImage: '',
    captchaCode: value
  };

  p.color(0, 0, 0, 0); // First color: background (red, green, blue, alpha)
  p.color(80, 80, 80, 255); // Second color: paint (red, green, blue, alpha)

  imgBuffer = new Buffer(p.getBase64(), 'base64');
  captchaResponse.captchaImage = imgBuffer;

  logger.debug(`Successfully generated Captcha with value : ${value}`);
  response.json(captchaResponse);
});

module.exports = router;
