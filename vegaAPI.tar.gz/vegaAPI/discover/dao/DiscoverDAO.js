var ProvisionedVM = require('../../provision/models/provisioned-vm').ProvisionedVM;
var VmDetail = require('../../provision/models/vmdetails').VMDetails;
var ProvisionedExperience = require('../../provision/models/provisioned-experience').ProvisionedExperience;
var Experience = require('../../experience/models/Experience');
var Service = require('../../service/models/Service');
var logger = require('../../common/logger').log;

/*
 * logging format followed: logger.info(<module_name>: <component name> : <description> : [<long_description>] : <data/params/errors>);
 */

/*
 * Discover by provision id
 */
var getDiscoverById = function(req, res, callback) {

	var ResponseObj = {};

	logger.info('discover : DAO : received request : getDiscoverById : provision id : ' + req.params.id);

	ProvisionedExperience.findOne({
		'_id': req.params.id,
		'deleted': false
	}, function(err, data) {
		if (err) {
			logger.error('discover : DAO : failed getDiscoverById : error : ' + err);
			callback(err, null);
		} else {
			if (data) {
				ResponseObj.provisionId = data._id;
				ResponseObj.experienceId = data.experienceId;
				ResponseObj.companyId = data.orgId;
				getProvisionedVM(ResponseObj, callback);								
			}
			else {
				var err = new Error('No provision found for given provision id');
				err.status = 404;
				logger.error('discover : DAO : failed getDiscoverById : error : '+ err);
				callback(err, null);
			}
		}
	});
};


/*
 * Discover by experience id and company id
 */
var getDiscoverByQuery = function(req, res, callback) {

	var ResponseObj = {};

	logger.info('discover : DAO : received request : getDiscoverByQuery : ' + JSON.stringify(req.query));

	ProvisionedExperience.findOne({
		'experienceId': req.query.expid,
		'orgId': req.query.companyid,
		'deleted': false
	}, function(err, data) {
		if (err) {
			logger.error('discover : DAO : failed getDiscoverByQuery : error : ' + err);
			callback(err, null);
		} else {
			if (data) {
				ResponseObj.provisionId = data._id;
				ResponseObj.experienceId = data.experienceId;
				ResponseObj.companyId = data.orgId;
				getProvisionedVM(ResponseObj, callback);
			}
			else {
				var err = new Error('No provision found for given experience and company');
				err.status = 404;
				logger.error('company : DAO : failed getDiscoverByQuery : error : '+ err);
				callback(err, null);
			}
		}
	});
};


var getProvisionedVM = function(ResponseObj, callback) {
	ProvisionedVM.findOne({
		'provisionId': ResponseObj.provisionId
	}, function(err, data) {
		if (err) {
			logger.error('discover : DAO : failed getProvisionedVM : error : ' + err);
			callback(err, null);
		} else {
			if (data) {
				getVmDetails(ResponseObj, data.vmId, callback);
			}
			else if (!data) {
				ResponseObj.vmDetails = null;
				getComponents(ResponseObj, callback);
			} else {
				var err = new Error('Invalid provision id for provisioned vm');
				err.status = 404;
				logger.error('discover : DAO : failed getProvisionedVM : error : '+ err);
				callback(err, null);
			}
		}
	});
}

var getVmDetails = function(ResponseObj, vmId, callback) {
	VmDetail.findOne({
		'_id': vmId
	}, function(err, data) {
		if (err) {
			logger.error('discover : DAO : failed getVmDetails : error : ' + err);
			callback(err, null);
		} else {
			ResponseObj.vmDetails = data;
			getComponents(ResponseObj, callback);
		}
	});
}

var getComponents = function(ResponseObj, callback) {
	Experience.findOne({
		'id': ResponseObj.experienceId
	}, function(err, data) {
		if (err) {
			logger.error('discover : DAO : failed getComponents : error : ' + err);
			callback(err, null);
		} else {
			ResponseObj.components = data.components;
			getServices(ResponseObj, callback);
		}
	});
}

var getServices = function(ResponseObj, callback) {
	Service.find({
		'experienceId': ResponseObj.experienceId
	}, function(err, data) {					
		if (err) {
			logger.error('discover : DAO : failed getServices : error : ' + err);
			callback(err, null);
		} else {
			ResponseObj.services = data;
			callback(null, ResponseObj);			
		}
	});
}


module.exports.getDiscoverById = getDiscoverById;
module.exports.getDiscoverByQuery = getDiscoverByQuery;
