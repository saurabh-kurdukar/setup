var express = require('express');
var discoverDAO = require('./dao/DiscoverDAO');
var logger = require('../common/logger').log;
var ErrorResponse = require('../common/ErrorResponse').ErrorResponse;
var router = express.Router();

/*
 * logging format followed: logger.info(<module_name>: <component name> : <description> : [<long_description>] : <data/params/errors>);
 */

/*
 * Discover by provision id
 */
router.get('/:id', function (req, res) {
	discoverDAO.getDiscoverById(req, res, function(err, data) {
        if(err){
        	logger.error('discover : router : failed getDiscoverById : error : '+err);
        	var error = new ErrorResponse();
        	error.setErrorCode("DC0001");
        	error.setErrorMessage(err.message);
        	error.setHttpResponseCode(500);
          res.status(500).end(JSON.stringify(error));
        }else{
					logger.info("discover : router : getDiscoverById successful !");
        	res.status(200).end(JSON.stringify(data));
        }
    });
});


router.get('/', function (req, res) {
	discoverDAO.getDiscoverByQuery(req, res, function(err, data) {
        if(err){
        	logger.error('company : router : failed getDiscoverByQuery : error : '+err);
        	var error = new ErrorResponse();
        	error.setErrorCode("DC0002");
        	error.setErrorMessage(err.message);
        	error.setHttpResponseCode(500);
          res.status(500).end(JSON.stringify(error));
        }else{
					logger.info("discover : router : getDiscoverByQuery successful !");
        	res.status(200).end(JSON.stringify(data));
        }
    });
});


module.exports = router;
