var express = require('express');
var roleController = require('./controller/RoleController');
var logger = require('../common/logger').log;
var ErrorResponse = require('../common/ErrorResponse').ErrorResponse;
var router = express.Router();

/*
 * logging format followed: logger.info(<module_name>: <component name> : <description> : [<long_description>] : <data/params/errors>);
 */

/*
 * Add new Role
 */
router.post('/', function(req, res) {
  logger.info('Roles : router : received request : addNewRole : body : ' + JSON.stringify(req.body));
  roleController.addNewRole(req, res, function(err, data) {
    if (err) {
      logger.error('Roles : router : failed addNewRole : error : ' + err);
      var error = new ErrorResponse();
      if (err.name == 'ValidationError') {
        error.setErrorMessage(err.errors[Object.keys(err.errors)[0]].message);
      } else {
        error.setErrorMessage(err.message);
      }
      error.setErrorCode("R0001");
      error.setHttpResponseCode(500);
      res.status(500).end(JSON.stringify(error));
    } else {
      logger.info("Roles : router : addNewRole successful !");
      res.status(200).end(JSON.stringify(data));
    }
  });
});

/*
 * Get Roles specified by the experienceId parameter
 */
router.get('/', function(req, res) {
  logger.info('Roles : router : received request : getRolesByExpId : id : ' + req.query.expId);
  roleController.getRolesByExpId(req, res, function(err, data) {
    if (err) {
      logger.error('Roles : router : failed getRolesByExpId : error : ' + err);
      var error = new ErrorResponse();
      error.setErrorCode("R0002");
      error.setErrorMessage(err.message);
      error.setHttpResponseCode(500);
      res.status(500).end(JSON.stringify(error));
    } else {
      logger.info("Roles : router : getRolesByExpId successful !");
      res.status(200).end(JSON.stringify(data));
    }
  });
});

/*
 * Deletes Roles by rolename
 */
router.delete('/:rolename', function(req, res) {
  logger.info('Roles : router : received request : deleteRoleByRoleName : rolename : ' + req.params.rolename);
  roleController.deleteRoleByRoleName(req, res, function(err, data) {
    if (err) {
      logger.error('Roles : router : failed deleteRoleByRoleName : error : ' + err);
      var error = new ErrorResponse();
      error.setErrorCode("R0004");
      error.setErrorMessage(err.message);
      error.setHttpResponseCode(500);
      res.status(500).end(JSON.stringify(error));
    } else {
      logger.info("Roles : router : deleteRoleByRoleName successful !");
      res.status(200).end(JSON.stringify(data));
    }
  });
});

/*
 * Get Roles specified by the roleid parameter
 */
router.get('/:id', function(req, res) {
  logger.info('Roles : router : received request : getRolesByRoleId : id : ' + req.params.id);
  roleController.getRolesByRoleId(req, res, function(err, data) {
    if (err) {
      logger.error('Roles : router : failed getRolesByRoleId : error : ' + err);
      var error = new ErrorResponse();
      error.setErrorCode("R0005");
      error.setErrorMessage(err.message);
      error.setHttpResponseCode(500);
      res.status(500).end(JSON.stringify(error));
    } else {
      logger.info("Roles : router : getRolesByRoleId successful !");
      res.status(200).end(JSON.stringify(data));
    }
  });
});

/*
 * Add new Resource
 */
router.post('/:id/resources', function(req, res) {
	logger.info('Roles : router : received request : addNewResource : roleId : ' + req.params.id);
	roleController.addNewResource(req, res, function(err, data) {
			if(err) {
				logger.error('Roles : router : failed addNewResource : error : '+err);
				var error = new ErrorResponse();
				if(err.name == 'ValidationError'){
					error.setErrorMessage(err.errors[Object.keys(err.errors)[0]].message);
				} else {
					error.setErrorMessage(err.message);
				}
				error.setErrorCode("R0006");
				error.setHttpResponseCode(500);
				res.status(500).end(JSON.stringify(error));
			} else {
				logger.info("Roles : router : addNewResource successful !");
				res.status(200).end(JSON.stringify(data));
			}
	});
});

/*
 * Delete Resource by resourcename
 */
router.delete('/:id/resources/:resourcename', function(req, res) {
  logger.info('Roles : router : received request : deleteResourceByResourceName : roleid : ' + req.params.id + 'resourcename : ' + req.params.resourcename);
  roleController.deleteResourceByResourceName(req, res, function(err, data) {
    if (err) {
      logger.error('Roles : router : failed deleteResourceByResourceName : error : ' + err);
      var error = new ErrorResponse();
      error.setErrorCode("R0007");
      error.setErrorMessage(err.message);
      error.setHttpResponseCode(500);
      res.status(500).end(JSON.stringify(error));
    } else {
      logger.info("Roles : router : deleteResourceByResourceName successful !");
      res.status(200).end(JSON.stringify(data));
    }
  });
});

/*
 * Update/Replace the Resource
 */
router.put('/:id/resources', function(req, res) {
	logger.info('Roles : router : received request : replaceResource : roleId : ' + req.params.id);
	roleController.replaceResource(req, res, function(err, data) {
			if(err) {
				logger.error('Roles : router : failed replaceResource : error : '+err);
				var error = new ErrorResponse();
				if(err.name == 'ValidationError'){
					error.setErrorMessage(err.errors[Object.keys(err.errors)[0]].message);
				} else {
					error.setErrorMessage(err.message);
				}
				error.setErrorCode("R0008");
				error.setHttpResponseCode(500);
				res.status(500).end(JSON.stringify(error));
			} else {
				logger.info("Roles : router : replaceResource successful !");
				res.status(200).end(JSON.stringify(data));
			}
	});
});

module.exports = router;
