var db = require('../../common/MongoDbConnection');
var Role = require('../models/Role');
var logger = require('../../common/logger').log;
var audit = require('../../common/Audit').audit;
var UserRole = require('../../userRoles/models/UserRole');
var Experience = require('../../experience/models/Experience');
var mongoose = db.mongoose;

/*
 * Add new Role
 */
var addNewRole = function(req, res, callback) {
  logger.info('Roles : DAO : received request : addNewRole : body : ' + JSON.stringify(req.body));
  var reqBody = req.body;
  var role = new Role();

  if (reqBody.experienceId != undefined || reqBody.experienceId != null) {
    role.setexperienceId(reqBody.experienceId);
    role.setroleName(reqBody.roleName);
    if (reqBody.defaultflag != undefined || reqBody.defaultflag != null) {
      role.setDefaultflag(reqBody.defaultflag);
    }

    if (reqBody.defaultCustomerFlag != undefined || reqBody.defaultflag != null) {
      role.setDefaultCustomerFlag(reqBody.defaultCustomerFlag);
    }

    role.setHierarchy(reqBody.hierarchy);
    role.setCreatedBy(req.headers['username']);

    Experience.find({
      'id': reqBody.experienceId
    }, function(err, data) {
      if (err) {
        logger.error('Roles : DAO : failed addNewRole : error : ' + err);
        callback(err, data);
      } else {
        if (data.length != 0) {
          role.save(function(err, data) {
            if (err) {
              logger.error('Roles : DAO : failed addNewRole : error : ' + err);
              callback(err, null);
            } else if (data != null) {
              logger.info('Roles : DAO : addNewRole successful !');
              callback(null, data);
            } else {
              var err = new Error('Failed to addNewRole details');
              logger.error('Roles : DAO : failed addNewRole : error : ' + err);
              callback(err, null);
            }
          });
        } else {
          var err = new Error('Invalid Experience id');
          err.status = 404;
          callback(err, data);
        }
      }
    });
  } else {
    role.setroleName(reqBody.roleName);
    role.setHierarchy(reqBody.hierarchy);
    role.setCreatedBy(req.headers['username']);

    if (reqBody.defaultflag != undefined || reqBody.defaultflag != null) {
      role.setDefaultflag(reqBody.defaultflag);
    }
    if (reqBody.defaultCustomerFlag != undefined || reqBody.defaultflag != null) {
      role.setDefaultCustomerFlag(reqBody.defaultCustomerFlag);
    }

    role.save(function(err, data) {
      if (err) {
        logger.error('Roles : DAO : failed addNewRole : error : ' + err);
        callback(err, null);
      } else if (data != null) {
        logger.info('Roles : DAO : addNewRole successful !');
        callback(null, data);
      } else {
        var err = new Error('Failed to addNewRole details');
        logger.error('Roles : DAO : failed addNewRole : error : ' + err);
        callback(err, null);
      }
    });
  }
};


/*
 *  Get Roles specified by the experienceId parameter
 */
var getRolesByExpId = function(req, res, callback) {

  logger.info('Roles : DAO : received request : getRolesByExpId : id : ' + req.params.id);
  Role.find({
    'experienceId': req.query.expId
  }, function(err, data) {
    if (err) {
      logger.error('Roles : DAO : failed getRolesByExpId : error : ' + err);
      callback(err, null);
    } else {
      if (data.length != 0) {
        logger.info('Roles : DAO : getRolesByExpId successful !');
        callback(null, data);
      } else {
        var err = new Error('No Roles found for given ExperienceId');
        err.status = 404;
        logger.error('Roles : DAO : failed getRolesByExpId : error : ' + err);
        callback(err, null);
      }
    }
  });
};

/*
 *  Get Roles specified by the experienceId(from header) parameter and RoleId
 */
var getRolesByRoleNameAndRoleId = function(req, res, callback) {

  var roleName = req.headers['rolename'];

  logger.info('Roles : DAO : received request : getRolesByRoleNameAndRoleId : roleId : ' + req.params.roleId);
  Role.find({
    //'experienceId' : ExpId,
    'roleId': req.params.roleId,
    'roleName': roleName
  }, function(err, data) {
    if (err) {
      logger.error('Roles : DAO : failed getRolesByRoleNameAndRoleId : error : ' + err);
      callback(err, null);
    } else {
      if (data.length != 0) {
        logger.info('Roles : DAO : getRolesByRoleNameAndRoleId successful !');
        callback(null, data);
      } else {
        var err = new Error('No Roles found for given RoleId and RoleName');
        err.status = 404;
        logger.error('Roles : DAO : failed getRolesByRoleNameAndRoleId : error : ' + err);
        callback(err, null);
      }
    }
  });
};

/*
 **get Role by Rolename
 */
var getRolesByRolename = function(req, res, callback) {

  logger.info('Roles : DAO : received request : getRolesByRolename : id : ' + req.params.rolename);
  Role.find({
    'roleName': req.params.rolename
  }, function(err, data) {
    if (err) {
      logger.error('Roles : DAO : failed getRolesByRolename : error : ' + err);
      callback(err, null);
    } else {
      if (data.length != 0) {
        logger.info('Roles : DAO : getRolesByRolename successful !');
        callback(null, data);
      } else {
        var err = new Error('No Roles found for given rolename');
        err.status = 404;
        logger.error('Roles : DAO : failed getRolesByRolename : error : ' + err);
        callback(err, null);
      }
    }
  });
};

/*
 *   Deletes Role by rolename
 */
var deleteRoleByRoleName = function(req, res, callback) {
  logger.info('Roles : DAO : received request : deleteRoleByRoleName : (id: ' + req.params.rolename);

  UserRole.find({
    'roleName': req.params.rolename
  }, function(err, data) {
    if (err) {
      logger.error('Roles : DAO : failed getUsersByRoleName : error : ' + err);
      callback(err, null);
    } else {
      if (data[0].username.length != 0) {
        var err = new Error('Users are associated to ' + req.params.rolename + ' role. Role can not be deleted');
        err.status = 500;
        logger.info('Roles : DAO : getUsersByRoleName successful !');
        callback(err, data);
      } else {
        var err = new Error('Not Found');
        err.status = 404;
        logger.error('Roles : DAO : failed getUsersByRoleName : error : ' + err);

        //delete code
        var callbackDelete = function(err, data) {
          if (err) {
            logger.error('Roles : DAO : failed deleteRoleByRoleName : error :' + err);
            callback(err, data);
          } else {

            Role.remove({
                'roleName': req.params.rolename
              },
              function(err, data) {
                if (err) {
                  logger.error('Roles : DAO : failed deleteRoleByRoleName : error :' + err);
                  callback(err, data);
                } else {
                  logger.info('Roles : DAO : deleteRoleByRoleName successful !');
                  callback(err, 'Role Deleted');
                }
              });
          }
        };
        getRolesByRolename(req, res, callbackDelete);
      }
    }
  });
};

/*
 * Get Role by role id
 */
var getRolesByRoleId = function(req, res, callback) {

  logger.info('Roles : DAO : received request : getRolesByRoleId : id : ' + req.params.id);
  Role.findOne({
    'roleId': req.params.id
  }, function(err, data) {
    if (err) {
      logger.error('Roles : DAO : failed getRolesByRoleId : error : ' + err);
      callback(err, null);
    } else {
      if (data) {
        logger.info('Roles : DAO : getRolesByRoleId successful !');
        callback(null, data);
      } else {
        var err = new Error('No Roles found for given roleid');
        err.status = 404;
        logger.error('Roles : DAO : failed getRolesByRoleId : error : ' + err);
        callback(err, null);
      }
    }
  });
};

/*
 *  Get Roles by default flag
 */
var getRolesByFlag = function(req, res, callback) {

  logger.info('Roles : DAO : received request : getRolesByFlag ');
  Role.find({
    'defaultflag': true
  }, function(err, data) {
    if (err) {
      logger.error('Roles : DAO : failed getRolesByFlag : error : ' + err);
      callback(err, null);
    } else {
      logger.info('Roles : DAO : getRolesByFlag successful !');
      callback(null, data);
    }
  });
};

/*
 *  Get Roles by DefaultCustomerFlag
 */
var getRolesByDefaultCustomerFlag = function(req, res, callback) {
  logger.info('Roles : DAO : received request : getRolesByDefaultCustomerFlag : ');
  Role.find({
    'defaultCustomerFlag': true
  }, function(err, data) {
    if (err) {
      logger.error('Roles : DAO : failed getRolesByDefaultCustomerFlag : error : ' + err);
      callback(err, null);
    } else {
      logger.info('Roles : DAO : getRolesByDefaultCustomerFlag successful !');
      callback(null, data);
    }
  });
};

/*
 * Add new Resource
 */
var addNewResource = function(req, res, callback) {
  logger.info('Roles : DAO : received request : addNewResource : body : ' + JSON.stringify(req.body));
  var reqBody = req.body;

  Role.findOneAndUpdate({
    'roleId': req.params.id
  }, {
    $addToSet: {
      resources: reqBody
    }
  }, {
    'new': true
  }, function(err, data) {
    if (err) {
      logger.error('Roles : DAO : failed addNewResource : add resource : error : ' + err);
      callback(err, null);
    } else {
      if (data) {
        logger.info('Roles : DAO : addNewResource successful !');
        callback(null, data);
      } else {
        var err = new Error('No Record found for given roleId');
        err.status = 404;
        logger.error('Roles : DAO : failed addNewResource : error : ' + err);
        callback(err, null);
      }
    }
  })
};

/*
 *   Delete Resource by resourcename
 */
var deleteResourceByResourceName = function(req, res, callback) {
  logger.info('Roles : DAO : received request : deleteResourceByResourceName : roleid : ' + req.params.id + 'resourcename : ' + req.params.resourcename);

  Role.findOneAndUpdate({
    'roleId': req.params.id
  }, {
    $pull: {
      resources: {
        accessGrp: req.params.resourcename
      }
    }
  }, {
    'new': true
  }, function(err, data) {
    if (err) {
      logger.error('Roles : DAO : failed deleteResourceByResourceName : add resource : error : ' + err);
      callback(err, null);
    } else {
      if (data) {
        logger.info('Roles : DAO : deleteResourceByResourceName successful !');
        callback(null, data);
      } else {
        var err = new Error('No Record found for given roleId');
        err.status = 404;
        logger.error('Roles : DAO : failed deleteResourceByResourceName : error : ' + err);
        callback(err, null);
      }
    }
  })
};

/*
 * Update/Replace the Resource
 */
var replaceResource = function(req, res, callback) {
  logger.info('Roles : controller : received request : replaceResource : body : ' + JSON.stringify(req.body));
  var reqBody = req.body;

  Role.findOneAndUpdate({
    'roleId': req.params.id,
    'resources.id': reqBody.id
  }, {
    $set: {
      'resources.$': reqBody
    }
  }, {
    'new': true
  }, function(err, data) {
    if (err) {
      logger.error('Roles : DAO : failed replaceResource : error : ' + err);
      callback(err, null);
    } else {
      if (data) {
        logger.info('Roles : DAO : replaceResource successful !');
        callback(null, data);
      } else {
        var err = new Error('No Record found for given roleId and resourceId');
        err.status = 404;
        logger.error('Roles : DAO : failed replaceResource : error : ' + err);
        callback(err, null);
      }
    }
  })
};

module.exports.addNewRole = addNewRole;
module.exports.getRolesByExpId = getRolesByExpId;
module.exports.getRolesByRoleNameAndRoleId = getRolesByRoleNameAndRoleId;
module.exports.deleteRoleByRoleName = deleteRoleByRoleName;
module.exports.getRolesByRoleId = getRolesByRoleId;
module.exports.addNewResource = addNewResource;
module.exports.deleteResourceByResourceName = deleteResourceByResourceName;
module.exports.replaceResource = replaceResource;
module.exports.getRolesByFlag = getRolesByFlag;
module.exports.getRolesByDefaultCustomerFlag = getRolesByDefaultCustomerFlag;
