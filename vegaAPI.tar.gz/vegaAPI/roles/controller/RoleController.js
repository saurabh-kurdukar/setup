var roleDao = require('../dao/RoleDAO');
var logger = require('../../common/logger').log;
var userRoleDelegate = require('../../userRoles/delegate/UserRoleDelegate');
var userRoleDAO = require('../../userRoles/dao/UserRoleDAO');

/*
 * Add new Role
 */
var addNewRole = function(req, res, callback) {
  logger.info('Roles : controller : received request : addNewRole : body : ' + JSON.stringify(req.body));
  roleDao.addNewRole(req, res, function(err, data) {
    if (err) {
      logger.error('Roles : controller : failed addNewRole : error : ' + err);
      callback(err, null);
    } else {
      req.body.roleId = data.roleId;
      req.body.roleName = data.roleName;
      req.body.username = [];
      userRoleDelegate.addNewUserRole(req, res, function(err, userRoleResponse) {
        if (err) {
          logger.error('Roles : controller : failed addNewRole : error : ' + err);
          callback(err, null);
        } else {
          logger.info('Roles : controller : addNewRole successful !');
          userRoleDAO.addNewUserRole('', '', req, res, callback);
        }
      })
    }
  });
};

/*
 * Get Roles specified by the experienceId parameter
 */
var getRolesByExpId = function(req, res, callback) {
  logger.info('Roles : controller : received request : getRolesByExpId : Expid : ' + req.query.expId);
  roleDao.getRolesByExpId(req, res, callback);
};

/*
 *  Delete Role by rolename
 */
var deleteRoleByRoleName = function(req, res, callback) {
  logger.info('Roles : controller : received request : deleteRoleByRoleName : id : ' + req.params.rolename);
  roleDao.deleteRoleByRoleName(req, res, function(err, data) {
    if (err) {
      logger.error('Roles : controller : failed deleteRoleByRoleName : error : ' + err);
      callback(err, null);
    } else {
      userRoleDelegate.deleteUserRolesByRoleName(req, res, function(err, deleteRoleResponse) {
        if (err) {
          logger.error('Roles : controller : failed deleteRoleByRoleName : error : ' + err);
          callback(err, null);
        } else {

          userRoleDAO.deleteUserRolesByRoleName(req, res, function(err, response) {
            if (err) {
              logger.error('Roles : controller : failed deleteRoleByRoleName : error : ' + err);
              callback(err, null);
            } else {
              logger.info('Roles : controller : deleteRoleByRoleName successful !');
              callback(null, data);
            }
          });
        }
      })
    }
  });
};

/*
 *  Get Role by roleId
 */
var getRolesByRoleId = function(req, res, callback) {
  logger.info('Roles : controller : received request : getRolesByRoleId : id : ' + req.params.id);
  roleDao.getRolesByRoleId(req, res, callback);
};

/*
 * Add new Resource
 */
var addNewResource = function(req, res, callback) {
  logger.info('Roles : controller : received request : addNewResource : roleId : ' + req.params.id);
  roleDao.addNewResource(req, res, callback);
};

/*
 *  Delete Resource by resourcename
 */
var deleteResourceByResourceName = function(req, res, callback) {
  logger.info('Roles : controller : received request : deleteResourceByResourceName : roleid : ' + req.params.id + 'resourcename : ' + req.params.resourcename);
  roleDao.deleteResourceByResourceName(req, res, callback);
};

/*
 * Update/Replace the Resource
 */
var replaceResource = function(req, res, callback) {
  logger.info('Roles : controller : received request : replaceResource : roleId : ' + req.params.id);
  roleDao.replaceResource(req, res, callback);
};

module.exports.addNewRole = addNewRole;
module.exports.getRolesByExpId = getRolesByExpId;
module.exports.deleteRoleByRoleName = deleteRoleByRoleName;
module.exports.getRolesByRoleId = getRolesByRoleId;
module.exports.addNewResource = addNewResource;
module.exports.deleteResourceByResourceName = deleteResourceByResourceName;
module.exports.replaceResource = replaceResource;
