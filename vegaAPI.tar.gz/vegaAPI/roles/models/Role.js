var mongoose = require('../../common/MongoDbConnection').mongoose;
var autoIncrement = require('mongoose-auto-increment');
var logger = require('../../common/logger').log;
var connection = mongoose.connection;
autoIncrement.initialize(connection);
/*
 * logging format followed: logger.info(<module_name>: <component name> :
 * <description> : <long_description> : <data/params/errors>);
 */


/*
 * Define schema for resaccgrps
 */
var resAccGrpSchema = mongoose.Schema({
  id: Number,
  endPoint: {
    type: String
  },
  allowedMethods: [],
  accessGrp: {
    type: String
  },
  status: {
    type: String
  },
  createdOn: {
    type: Date
  },
  createdBy: {
    type: String
  },
  updatedOn: {
    type: Date
  },
  updatedBy: {
    type: String
  }
});

/*
 * Define schema for roles
 */
var roleSchema = mongoose.Schema({
  roleId: {
    type: Number
  },
  experienceId: {
    type: Number
  },
  roleName: {
    type: String,
    unique: true
  },
  defaultflag: {
    type: Boolean,
    default: false
  },
  hierarchy: Number,
  defaultCustomerFlag: {
    type: Boolean,
    default: false
  },
  createdOn: {
    type: Date,
    default: Date.now
  },
  createdBy: {
    type: String
  },
  resources: [resAccGrpSchema]
});


logger.info('Roles : model : created schema : Roles :' + JSON.stringify(roleSchema.paths));

roleSchema.path('roleName').validate(function(value, fn) {
  var Role = mongoose.model('Roles');
  Role.find({
    'roleName': value
  }, function(err, data) {
    fn(err || data.length === 0);
  });
}, 'Role name is already taken');

/*
 * Add Auto increment plugin for field roleId
 */
roleSchema.plugin(autoIncrement.plugin, {
  model: 'Roles',
  field: 'roleId',
  startAt: 1
});

/*
 * Setters
 */
roleSchema.methods.setroleId = function(roleId) {
  this.roleId = roleId;
};

roleSchema.methods.setexperienceId = function(experienceId) {
  this.experienceId = experienceId;
};

roleSchema.methods.setroleName = function(roleName) {
  this.roleName = roleName;
};

roleSchema.methods.setDefaultflag = function(defaultflag) {
  this.defaultflag = defaultflag;
};

roleSchema.methods.setHierarchy = function(hierarchy) {
  this.hierarchy = hierarchy;
};

roleSchema.methods.setDefaultCustomerFlag = function(defaultCustomerFlag) {
  this.defaultCustomerFlag = defaultCustomerFlag;
};

roleSchema.methods.setCreatedBy = function(createdBy) {
  this.createdBy = createdBy;
};

/*
 * Getters
 */
roleSchema.methods.getroleId = function() {
  return this.roleId;
};

roleSchema.methods.getexperienceId = function() {
  return this.experienceId;
};

roleSchema.methods.getroleName = function() {
  return this.roleName;
};

roleSchema.methods.getDefaultflag = function() {
  return this.defaultflag;
};

roleSchema.methods.getHierarchy = function() {
  return this.hierarchy;
};

roleSchema.methods.getDefaultCustomerFlag = function() {
  return this.defaultCustomerFlag;
};

roleSchema.methods.getCreatedBy = function() {
  return this.createdBy;
};

/*
 * Create collection/model in mongo db using Schema
 */
var Role = mongoose.model('Roles', roleSchema);
logger.info('Roles : model : created model : Roles : ' + Role);

module.exports = Role;
