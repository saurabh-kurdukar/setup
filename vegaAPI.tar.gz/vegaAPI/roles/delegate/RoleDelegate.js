var logger = require('../../common/logger').log;
var roleDAO = require('../dao/RoleDAO');
var request = require('request');
var config = require('../../common/Config');

/*
 * call forgeRock
 */

/*var addNewRole = function(req, res, callback) {
	 
	 logger.info('Roles : delegate : received request : addNewRole : body : '
			+ JSON.stringify(req.body));

	 var reqBody = req.body;
	 var json1={};
	 
	 json1.groupname=reqBody.roleName;
	 json1.groupusers="{\n" +
                        "\"groupname\": \"emeeadmins\",\n" +
                        "\"groupusers\": [\n" +
                        "  {\"name\":\"joe\"}]\n" +
                        "}";
	 
	 console.log("Rolename"+reqBody.roleName);
	 
	 //generate tokenId using forgeRock API
	var proxyurl=config.NETWORK_PROXY+":"+config.NETWORK_PROXY_PORT;
    request({
		//'proxy':proxyurl ,
      url: config.FORGRROCK_URL + '/api/v1/users/authenticate',
      method: 'POST',
      headers: {
        'Content-Type': 'application/json'
      },
      json: {
        "userId": "amadmin",
        "password": "zaq1@WSX"
      }

    }, function(error, response, body) {
      if (error) {
        console.log(error);
        callback(error, null);
      } else {
        console.log("***********************" + body.tokenId);
        tokenId = body.tokenId

        //createGroup forgeRock call
        request({
			//'proxy':proxyurl ,
         url: config.FORGRROCK_URL + '/api/v1/groups',
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            'Authorization': tokenId			
          },
          json: json1
        }, function(error, response, body) {
          if (error) {
            console.log(error);
            callback(error, null);
          } else {			  
            //console.log("Body"+body);
			if(body.code == 405)
				callback(body,null);
			else if(body.code==400)
				callback(body,null);
			else
			roleDAO.addNewRole(req, res, callback);
          }
        });
      }
    });
	 
	 
	 
 }
 
 module.exports.addNewRole = addNewRole;*/
