var Script = require('../models/Script');
var logger = require('../../common/logger').log;
var config = require('../../common/Config');
var upload = require('../helpers/uploadFile');
var fs = require('fs');

/*
 * logging format followed: logger.info(<module_name>: <component name> : <description> : [<long_description>] : <data/params/errors>);
 */


/*
 * Add new script details
 */
var addNewScript = function(req, res, callback) {
	logger.info('Script : DAO : received request : addNewScript : body : ' + JSON.stringify(req.body));
	if(req.body.createdBy) {
		req.body.updatedBy = req.body.createdBy;
	}
	var script = new Script(req.body);

	var regex = new RegExp(['^', req.body.name, '$'].join(''), 'i');

	Script.findOne({
		name: regex
	}, function(err, data) {
		if(err) {
			logger.error('Script : DAO : failed addNewScript : get by id : error : ' + err);
			callback(err, null);
		}
		else if(data) {
			var err = new Error('Script name already exists');
			err.status = 409;
			logger.error('Script : DAO : failed addNewScript : error : Name already exists');
			callback(err, null);
		}
		else {
			script.save(function(err, data) {
				if (err) {
					logger.error('Script : DAO : failed addNewScript : error : ' + err);
					callback(err, null);
				} else if(data != null){
					logger.info('Script : DAO : addNewScript successful !');
					callback(null, data);
				} else {
					var err = new Error('Failed to add new script details');
					logger.error('Script : DAO : failed addNewScript : error : '+ err);
					callback(err, null);
				}
			});
		}
	})
};

/*
 * Get all scripts
 */
var getAllScripts = function(req, res, callback) {
	logger.info('Script : DAO : received request : getAllScripts');

	var query = {};
	var regex;
	if(req.query.name) {
		logger.info('Script : DAO : received request : getAllScripts : name : ' + req.query.name);
		var scriptName = decodeURIComponent(req.query.name);
		regex = new RegExp(['^', scriptName, '$'].join(''), 'i');
		query.name = regex;
	}

	Script.find(query, function(err, data) {
		if(err) {
			logger.error('Script : DAO : failed getAllScripts : error : ' + err);
			callback(err, null);
		}
		else {
			if (data.length != 0) {
				logger.info('Script : DAO : getAllScripts successful !');
				callback(null, data);
			} else {
				var err = new Error('No records found');
				err.status = 404;
				logger.error('Script : DAO : failed getAllScripts : error : ' + err);
				callback(err, null);
			}
		}
	})
}

/*
 * Get script by id
 */
var getScriptById = function(req, res, callback) {
	logger.info('Script : DAO : received request : getScriptById : id : ' + req.params.id);

	Script.findOne({
		id: req.params.id
	}, function(err, data) {
		if(err) {
			logger.error('Script : DAO : failed getScriptById : error : ' + err);
			callback(err, null);
		}
		else {
			if(data) {
				logger.info('Script : DAO : getScriptById successful !');
				callback(null, data);
			} else {
				var err = new Error('Invalid script id');
				err.status = 404;
				logger.error('Script : DAO : failed getScriptById : error : ' + err);
				callback(err, null);
			}
		}
	})
}

/*
 * Update script by id
 */
var updateScriptById = function(req, res, callback) {
	logger.info('Script : DAO : received request : updateScriptById : id : ' + req.params.id);

	var json = {};
	if(req.body.name) {
		json.name = req.body.name;
	}
	if(req.body.description) {
		json.description = req.body.description;
	}
	if(req.body.version) {
		json.version = req.body.version;
	}
	if(req.body.tags && req.body.tags.length > 0) {
		json.tags = req.body.tags;
	}
	if(req.body.updatedBy) {
		json.updatedBy = req.body.updatedBy;
	}
	if(req.files.length != 0) {
		var scriptFile = req.files[0];
		json.scriptFileLocation = config.BINARY_STORAGE.BASE_URL + config.BINARY_STORAGE.SCRIPT + scriptFile.filename;
	}
	json.updatedOn = new Date();

	Script.findOne({
		id: req.params.id
	}, function(error, script) {
		if(error) {
			logger.error('Script : DAO : failed updateScriptById : get by id : error : ' + error);
			callback(error, null);
		}
		else {
			if(script) {
				Script.findOneAndUpdate({
					id: req.params.id
				}, json, {
					new: true
				}, function(err, data) {
					if(err) {
						logger.error('Script : DAO : failed updateScriptById : error : ' + err);
						callback(err, null);
					}
					else {
						if(data) {
							if(req.files.length != 0) {
								var filePath = config.BINARY_STORAGE.BASE_PATH + config.BINARY_STORAGE.SCRIPT + script.scriptFileLocation.split('/').pop();
								deleteScriptFile(filePath, function(err, file) {
									if(err) {
										callback(err, null);
										return;
									}
									else {
										logger.info('Script : DAO : updateScriptById successful !');
										callback(null, data);
									}
								});
							}
							else {
								logger.info('Script : DAO : updateScriptById successful !');
								callback(null, data);
							}
						}
						else {
							var err = new Error('Invalid script id');
							err.status = 404;
							logger.error('Script : DAO : failed updateScriptById : error : ' + err);
							callback(err, null);
						}
					}
				})
			} else {
				var err = new Error('Invalid script id');
				err.status = 404;
				logger.error('Script : DAO : failed updateScriptById : error : ' + err);
				callback(err, null);
			}
		}
	})
}

/*
 * Delete script by id
 */
var deleteScriptById = function(req, res, callback) {
	logger.info('Script : DAO : received request : deleteScriptById : id : ' + req.params.id);

	Script.findOne({
		id: req.params.id
	}, function(err, data) {
		if(err) {
			logger.error('Script : DAO : failed deleteScriptById : get script by id : error : ' + err);
			callback(err, null);
		}
		else {
			if(data) {
				var filePath = config.BINARY_STORAGE.BASE_PATH + config.BINARY_STORAGE.SCRIPT + data.scriptFileLocation.split('/').pop();
				Script.remove({
					id: req.params.id
				}, function(err, data) {
					if(err) {
						logger.error('Script : DAO : failed deleteScriptById : error : ' + err);
						callback(err, null);
					}
					else {
						deleteScriptFile(filePath, function(err, data) {
							if(err) {
								callback(err, null);
							}
							else {
								logger.info('Script : DAO : deleteScriptById successful !');
								callback(null, "Script deleted successfully");
							}
						});
					}
				})
			} else {
				var err = new Error('Invalid script id');
				err.status = 404;
				logger.error('Script : DAO : failed getScriptById : error : ' + err);
				callback(err, null);
			}
		}
	})
}

/*
 * Delete script file
 */
var deleteScriptFile = function(file, callback) {
	logger.error('Script : DAO : deleteScriptFile : file : ' + file);
	if(fs.existsSync(file)) {
		fs.unlink(file, function(err) {
			if(err) {
				logger.error('Script : DAO : deleteScriptFile : error : ' + err);
				callback(err, null);
			}
			else {
				logger.error('Script : DAO : deleteScriptFile successful! ');
				callback(null, file);
			}
		})
	}
	else {
		logger.error('Script : DAO : deleteScriptFile : No script found to delete !');
		callback(null, file);
	}
}

/*
 * Search scripts
 */
var searchScripts = function(req, res, callback) {
	logger.info('Script : DAO : received request : searchScripts : text : ' + req.query.text);

	if(!req.query.text) {
		var err = new Error('No tags found');
		logger.error('Script : DAO : failed searchScripts : error : No text found');
		callback(err, null);
	}
	else {
		var queryString = decodeURIComponent(req.query.text);
		var split = queryString.split(",");
		var searchString = "";
		split.forEach(function(word) {
			searchString += "\"" + word + "\" ";
		})

		Script.find({
			$text: {
				$search: req.query.text
			}
		}, function(err, data) {
			if(err) {
				logger.error('Script : DAO : failed searchScripts : error : ' + err);
				callback(err, null);
			}
			else {
				if(data.length > 0) {
					logger.info('Script : DAO : searchScripts successful !');
					callback(null, data);
				} else {
					var err = new Error('No records found');
					err.status = 404;
					logger.error('Script : DAO : failed searchScripts : error : ' + err);
					callback(err, null);
				}
			}
		})
	}
}


module.exports.addNewScript = addNewScript;
module.exports.getAllScripts = getAllScripts;
module.exports.getScriptById = getScriptById;
module.exports.updateScriptById = updateScriptById;
module.exports.deleteScriptById = deleteScriptById;
module.exports.searchScripts = searchScripts;
