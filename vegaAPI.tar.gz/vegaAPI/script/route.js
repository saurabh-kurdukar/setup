var express = require('express');
var scriptController = require('./controller/ScriptController');
var logger = require('../common/logger').log;
var ErrorResponse = require('../common/ErrorResponse').ErrorResponse;
var router = express.Router();
var upload = require('./helpers/uploadFile');
var config = require('../common/Config');

/*
 * logging format followed: logger.info(<module_name>: <component name> : <description> : [<long_description>] : <data/params/errors>);
 */

/*
 * Add new script details
 */
router.post('/', upload.any(), function(req, res) {

	if(req.fileValidationError) {
		logger.info('Script : router : received request : addNewScript : error : ' + req.fileValidationError);
		var error = new ErrorResponse();
		error.setErrorMessage(req.fileValidationError);
		error.setErrorCode("SC0001");
		error.setHttpResponseCode(500);
		res.status(500).end(JSON.stringify(error));
	}
	else if(req.files.length == 0) {
		logger.info('Script : router : received request : addNewScript : error : No file found');
		var error = new ErrorResponse();
		error.setErrorMessage("No file found");
		error.setErrorCode("SC0001");
		error.setHttpResponseCode(500);
		res.status(500).end(JSON.stringify(error));
	}
	else {
		var scriptFile = req.files[0];
		var scriptFileLocation = "";
		scriptFileLocation = config.BINARY_STORAGE.BASE_URL + config.BINARY_STORAGE.SCRIPT + scriptFile.filename;
		req.body.scriptFileLocation = scriptFileLocation;

		logger.info('Script : router : received request : addNewScript : body : ' + JSON.stringify(req.body));
		scriptController.addNewScript(req, res, function(err, data) {
			if(err) {
				logger.error('Script : router : failed addNewScript : error : '+err);
				var error = new ErrorResponse();
				if(err.name == 'ValidationError'){
					error.setErrorMessage(err.errors[Object.keys(err.errors)[0]].message);
				} else {
					error.setErrorMessage(err.message);
				}
				error.setErrorCode("SC0001");
				var errorStatus = 500;
				if(err.status) {
					errorStatus = err.status;
				}
				error.setHttpResponseCode(errorStatus);
				res.status(errorStatus).end(JSON.stringify(error));
			}
			else {
				logger.info('Script : router : addNewScript successful !');
				res.status(200).end(JSON.stringify(data));
			}
		});
	}
});

/*
 * Get all scripts
 */
router.get('/', function(req, res) {
	logger.info('Script : router : received request : getAllScripts');
	scriptController.getAllScripts(req, res, function(err, data) {
		if(err) {
			logger.error('Script : router : failed getAllScripts : error : ' + err);
			var error = new ErrorResponse();
			error.setErrorCode("SC0002");
			error.setErrorMessage(err.message);
			var errorStatus = 500;
			if(err.status) {
				errorStatus = err.status;
			}
			error.setHttpResponseCode(errorStatus);
			res.status(errorStatus).end(JSON.stringify(error));
		}
		else {
			logger.info('Script : router : getAllScripts successful!');
			res.status(200).end(JSON.stringify(data));
		}
	})
})

/*
 * Search scripts
 */
router.get('/search', function(req, res) {
	logger.info('Script : router : received request : searchScripts : text : ' + req.query.text);
	scriptController.searchScripts(req, res, function(err, data) {
		if(err) {
			logger.error('Script : router : failed searchScripts : error : ' + err);
			var error = new ErrorResponse();
			error.setErrorCode("SC0006");
			error.setErrorMessage(err.message);
			var errorStatus = 500;
			if(err.status) {
				errorStatus = err.status;
			}
			error.setHttpResponseCode(errorStatus);
			res.status(errorStatus).end(JSON.stringify(error));
		}
		else {
			logger.info('Script : router : searchScripts successful!');
			res.status(200).end(JSON.stringify(data));
		}
	})
})

/*
 * Get script by id
 */
router.get('/:id', function(req, res) {
	logger.info('Script : router : received request : getScriptById : id : ' + req.params.id);
	scriptController.getScriptById(req, res, function(err, data) {
		if(err) {
			logger.error('Script : router : failed getScriptById : error : ' + err);
			var error = new ErrorResponse();
			error.setErrorCode("SC0003");
			error.setErrorMessage(err.message);
			var errorStatus = 500;
			if(err.status) {
				errorStatus = err.status;
			}
			error.setHttpResponseCode(errorStatus);
			res.status(errorStatus).end(JSON.stringify(error));
		}
		else {
			logger.info('Script : router : getScriptById successful!');
			res.status(200).end(JSON.stringify(data));
		}
	})
})

/*
 * Update script by id
 */
router.put('/:id', upload.any(), function(req, res) {
	logger.info('Script : router : received request : updateScriptById : id : ' + req.params.id);
	scriptController.updateScriptById(req, res, function(err, data) {
		if(err) {
			logger.error('Script : router : failed updateScriptById : error : ' + err);
			var error = new ErrorResponse();
			error.setErrorCode("SC0004");
			error.setErrorMessage(err.message);
			var errorStatus = 500;
			if(err.status) {
				errorStatus = err.status;
			}
			error.setHttpResponseCode(errorStatus);
			res.status(errorStatus).end(JSON.stringify(error));
		}
		else {
			logger.info('Script : router : updateScriptById successful!');
			res.status(200).end(JSON.stringify(data));
		}
	})
})

/*
 * Delete script by id
 */
router.delete('/:id', function(req, res) {
	logger.info('Script : router : received request : deleteScriptById : id : ' + req.params.id);
	scriptController.deleteScriptById(req, res, function(err, data) {
		if(err) {
			logger.error('Script : router : failed deleteScriptById : error : ' + err);
			var error = new ErrorResponse();
			error.setErrorCode("SC0005");
			error.setErrorMessage(err.message);
			var errorStatus = 500;
			if(err.status) {
				errorStatus = err.status;
			}
			error.setHttpResponseCode(errorStatus);
			res.status(errorStatus).end(JSON.stringify(error));
		}
		else {
			logger.info('Script : router : deleteScriptById successful!');
			res.status(200).end(JSON.stringify(data));
		}
	})
})


module.exports = router;
