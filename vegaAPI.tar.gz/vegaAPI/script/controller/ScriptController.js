var scriptDao = require('../dao/ScriptDAO');
var logger = require('../../common/logger').log;

/*
 * logging format followed: logger.info(<module_name>: <component name> : <description> : [<long_description>] : <data/params/errors>);
 */


/*
 * Add new script details
 */
var addNewScript = function(req, res, callback) {
	logger.info('Script : controller : received request : addNewScript : body : ' + JSON.stringify(req.body));
	scriptDao.addNewScript(req, res, callback);
};

/*
 * Get all scripts
 */
var getAllScripts = function(req, res, callback) {
	logger.info('Script : controller : received request : getAllScripts');
	scriptDao.getAllScripts(req, res, callback);
}

/*
 * Get script by id
 */
var getScriptById = function(req, res, callback) {
	logger.info('Script : controller : received request : getScriptById : id : ' + req.params.id);
	scriptDao.getScriptById(req, res, callback);
}

/*
 * Update script by id
 */
var updateScriptById = function(req, res, callback) {
	logger.info('Script : controller : received request : updateScriptById : id : ' + req.params.id);
	scriptDao.updateScriptById(req, res, callback);
}

/*
 * Delete script by id
 */
var deleteScriptById = function(req, res, callback) {
	logger.info('Script : controller : received request : deleteScriptById : id : ' + req.params.id);
	scriptDao.deleteScriptById(req, res, callback);
}

/*
 * Search scripts
 */
var searchScripts = function(req, res, callback) {
	logger.info('Script : controller : received request : searchScripts : text : ' + req.query.text);
	scriptDao.searchScripts(req, res, callback);
}


module.exports.addNewScript = addNewScript;
module.exports.getAllScripts = getAllScripts;
module.exports.getScriptById = getScriptById;
module.exports.updateScriptById = updateScriptById;
module.exports.deleteScriptById = deleteScriptById;
module.exports.searchScripts = searchScripts;
