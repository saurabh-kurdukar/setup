var express = require('express');
var appgroupController = require('./controller/AppGroupController');
var logger = require('../common/logger').log;
var ErrorResponse = require('../common/ErrorResponse').ErrorResponse;
var router = express.Router();


/*
 * Add new app group
 */
router.post('/', function(req, res) {
	logger.info('appgroup : router : received request : addNewAppGroup : body : '+JSON.stringify(req.body));	
	if (req.header('companyId') != null) {
		appgroupController.addNewAppGroup(req, res, function(err, data) {
			if (err) {
				logger.error('appgroup : router : failed addNewAppGroup : error : '+err);   
				var error = new ErrorResponse();
				if(err.name == 'ValidationError'){
	        		error.setErrorMessage(err.errors[Object.keys(err.errors)[0]].message);
	        	} else {
	        		error.setErrorMessage(err.message);
	        	}
	        	error.setErrorCode("A0002");        	
	        	error.setHttpResponseCode(500);
				res.status(500).end(JSON.stringify(error));
			} else {
				logger.info("appgroup : router : addNewAppGroup successful !");
				res.status(200).end(JSON.stringify(data));
			}
		});
	} else {
		var error = new ErrorResponse();
		error.setErrorCode("A0002");
		error.setErrorMessage('company id not set');
		error.setHttpResponseCode(500);
		logger.error('appgroup : router : failed addNewAppGroup : error : '+JSON.stringify(error));    
		res.status(500).end(JSON.stringify(error));
	}
});

/*
 * Get app group by app group id & company id
 */
router.get('/:id', function(req, res) {
	logger.info('appgroup : router : received request : getAppGroupById : (appGroupId:'+req.params.id+', companyId:'+req.header('companyId')+')');
	if (req.header('companyId') != null) {
		appgroupController.getAppGroupById(req, res, function(err, data) {
			if (err) {
				logger.error('appgroup : router : failed getAppGroupById : error : '+err); 
				var error = new ErrorResponse();
				error.setErrorCode("A0002");
				error.setErrorMessage(err.message);
				error.setHttpResponseCode(500);
				res.status(500).end(JSON.stringify(error));
			} else {
				logger.info("appgroup : router : getAppGroupById successful !");
				res.status(200).end(JSON.stringify(data));
			}
		});
	} else {
		var error = new ErrorResponse();
		error.setErrorCode("A0002");
		error.setErrorMessage('company id not set');
		error.setHttpResponseCode(500);
		logger.error('appgroup : router : failed getAppGroupById : error : '+JSON.stringify(error));    
		res.status(500).end(JSON.stringify(error));
	}
});

/*
 * Edit/Update app group
 */
router.put('/:id', function(req, res) {
	logger.info('appgroup : router : received request : updateAppGroupById : (appGroupId:'+req.params.id+', companyId:'+req.header('companyId')+', body:'+JSON.stringify(req.body)+')');
	if (req.header('companyId') != null) {
		if(req.body.hasOwnProperty('description') || req.body.hasOwnProperty('image')) {
			appgroupController.updateAppGroupById(req, res, function(err, data) {
				if (err) {
					logger.error('appgroup : router : failed updateAppGroupById : error : '+err); 
					var error = new ErrorResponse();
					if(err.name == 'ValidationError'){
		        		error.setErrorMessage(err.errors[Object.keys(err.errors)[0]].message);
		        	} else {
		        		error.setErrorMessage(err.message);
		        	}
					error.setErrorCode("A0002");				
					error.setHttpResponseCode(500);
					res.status(500).end(JSON.stringify(error));
				} else {
					logger.info("appgroup : router : updateAppGroupById successful !");
					res.status(200).end(JSON.stringify(data));
				}
			});
		} else {
			var error = new ErrorResponse();
			error.setErrorCode("A0002");
			error.setErrorMessage('Cannot update data');
			error.setHttpResponseCode(500);
			logger.error('appgroup : router : failed updateAppGroupById : error : '+JSON.stringify(error));    
			res.status(500).end(JSON.stringify(error));
		}
	} else {
		var error = new ErrorResponse();
		error.setErrorCode("A0002");
		error.setErrorMessage('company id not set');
		error.setHttpResponseCode(500);
		logger.error('appgroup : router : failed updateAppGroupById : error : '+JSON.stringify(error));    
		res.status(500).end(JSON.stringify(error));
	}
});

/*
 * Options for App Groups APIs
 */
router.options('/', function(req, res) {
	logger.info('appgroup : router : received request : Options call appgroups APIs');
	res.header('Allow-Access-Allow-Origin', '*');
	res.header('Access-Control-Allow-Headers', '*');
	res.header('Access-Control-Allow-Methods', 'GET,POST,DELETE,PUT,OPTIONS');
	res.header('Connection', 'keep-alive');
	res.header('Content-Type', 'application/json;charset=UTF-8');
	res.end();
	logger.info('appgroup : router : Options call appgroups APIs processed !');
});

/*
 * Get all apps created under given app group id & company id
 */
router.get('/:id/apps', function(req, res) {
	logger.info('appgroup : router : received request : getAllApps : (appGroupId:'+req.params.id+', companyId:'+req.header('companyId')+')');
	if (req.header('companyId') != null) {
		appgroupController.getAllApps(req, res, function(err, data) {
			if (err) {
				logger.error('appgroup : router : failed getAllApps : error : '+err); 
				var error = new ErrorResponse();
				error.setErrorCode("A0002");
				error.setErrorMessage(err.message);
				error.setHttpResponseCode(500);
				res.status(500).end(JSON.stringify(error));
			} else {
				logger.info("appgroup : router : getAllApps successful !");
				res.status(200).end(JSON.stringify(data));
			}
		});
	} else {
		var error = new ErrorResponse();
		error.setErrorCode("A0002");
		error.setErrorMessage('company id not set');
		error.setHttpResponseCode(500);
		logger.error('appgroup : router : failed getAllApps : error : '+JSON.stringify(error));  
		res.status(500).end(JSON.stringify(error));
	}
});

router.all('/*', function(req, res) {
	logger.info('appgroup : router : received request : with URL : ' + req.originalUrl);
	logger.error('appgroup : router : No matching resource for URL : ' + req.originalUrl);
	var error = new ErrorResponse();
	error.setErrorCode("A0002");
	error.setErrorMessage('No matching resource for URL: ' + req.originalUrl);
	error.setHttpResponseCode(404);
	res.status(404).send(JSON.stringify(error));
});

module.exports = router;