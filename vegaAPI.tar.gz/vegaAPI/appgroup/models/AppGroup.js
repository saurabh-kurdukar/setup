var mongoose = require('../../common/MongoDbConnection').mongoose;
var autoIncrement = require('mongoose-auto-increment');
var logger = require('../../common/logger').log;
var connection = mongoose.connection;
autoIncrement.initialize(connection);

/*
 * Define schema
 */
var appgroupSchema = mongoose.Schema({
	appGroupId : Number,
	appGroupName : { type: String, unique: true, required: true }, // unique
	description : { type: String },
	companyId : Number,				 // foreign key
	image : {type: String},
	createdBy : {type: String},
	createdOn : { type: Date, default: Date.now },
	updatedBy : {type: String},
	updatedOn : { type: Date, default: Date.now }
});


logger.info('appgroup : model : created schema : AppGroups :'+JSON.stringify(appgroupSchema.paths));


appgroupSchema.path('appGroupName').validate(function(value, fn) {	  
	  var AppGroup = mongoose.model('AppGroups');
	  AppGroup.find({'appGroupName': value}, function (err, data) {
	    fn(err || data.length === 0);
	  });
}, 'App Group name is already taken');


appgroupSchema.pre('findOneAndUpdate', function(next) {
	  this.options.runValidators = true;
	  next();
});

appgroupSchema.path('appGroupName').validate(function (v) {
	  return (v.length > 0 && v.length <= 100);
}, 'data too long/short for field appGroupName'); 

appgroupSchema.path('image').validate(function (v) {
	  return v.length <= 255;
}, 'data too long for field image'); 

appgroupSchema.path('createdBy').validate(function (v) {
	  return v.length <= 50;
}, 'data too long for field createdBy'); 

appgroupSchema.path('updatedBy').validate(function (v) {
	  return v.length <= 50;
}, 'data too long for field updatedBy'); 


appgroupSchema.plugin(autoIncrement.plugin, { model: 'AppGroups', field: 'appGroupId' });

/*
 * Setters
 */
appgroupSchema.methods.setAppgroupid = function(appGroupId) {	
	this.appGroupId = appGroupId;
};

appgroupSchema.methods.setAppgroupname = function(appGroupName) {
	this.appGroupName = appGroupName;
};

appgroupSchema.methods.setDescription = function(description) {
	this.description = description;
};

appgroupSchema.methods.setCompanyId = function(companyId) {
	this.companyId = companyId;
};

appgroupSchema.methods.setImage = function(image) {
	this.image = image;
};

appgroupSchema.methods.setCreatedBy = function(createdBy) {
	this.createdBy = createdBy;
};

appgroupSchema.methods.setCreatedOn = function(createdOn) {
	this.createdOn = createdOn;
};

appgroupSchema.methods.setUpdatedBy = function(updatedBy) {
	this.updatedBy = updatedBy;
};

appgroupSchema.methods.setUpdatedOn = function(updatedOn) {
	this.updatedOn = updatedOn;
};


/*
 * Getters
 */
appgroupSchema.methods.getAppgroupid = function() {	
	return this.appGroupId;
};

appgroupSchema.methods.getAppgroupname = function() {
	return this.appGroupName;
};

appgroupSchema.methods.getDescription = function() {
	return this.description;
};

appgroupSchema.methods.getCompanyId = function() {
	return this.companyId;
};

appgroupSchema.methods.getImage = function() {
	return this.image;
};

appgroupSchema.methods.getCreatedOn = function() {
	return this.createdOn;
};

appgroupSchema.methods.getCreatedBy = function() {
	return this.createdBy;
};

appgroupSchema.methods.getUpdatedOn = function() {
	return this.updatedOn;
};

appgroupSchema.methods.getUpdatedBy = function() {
	return this.updatedBy;
};


/*
 * Create collection/model in mongo db using Schema
 */
var AppGroup = mongoose.model('AppGroups', appgroupSchema);
logger.info('appgroups : model : created model : AppGroups : ' + AppGroup);


module.exports = AppGroup;