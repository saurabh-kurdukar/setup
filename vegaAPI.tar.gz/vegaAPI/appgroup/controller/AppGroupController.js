var appgroupDao = require('../dao/AppGroupDAO');
var companyDao = require('../../company/dao/CompanyDAO');
var appDao = require('../../application/dao/AppDAO');
var logger = require('../../common/logger').log;

/*
 * Add new app group
 */
var addNewAppGroup = function(req, res, callback) {
	logger.info('appgroup : controller : received request : addNewAppGroup : body : '+JSON.stringify(req.body));	
	appgroupDao.addNewAppGroup(req, res, callback);
};

/*
 * Get app group by app group id & company id
 */
var getAppGroupById = function(req, res, callback) {
	logger.info('appgroup : controller : received request : getAppGroupById : (appGroupId:'+req.params.id+', companyId:'+req.header('companyId')+')');	
	appgroupDao.getAppGroupById(req, res, callback);
};

/*
 * Edit/Update app group details
 */
var updateAppGroupById = function(req, res, callback) {
	logger.info('appgroup : controller : received request : updateAppGroupById : (appGroupId:'+req.params.id+', companyId:'+req.header('companyId')+', body:'+JSON.stringify(req.body)+')');
	appgroupDao.updateAppGroupById(req, res, callback);
};

/*
 * Get all apps created under given app group id & company id
 */
var getAllApps = function(req, res, callback) {
	logger.info('appgroup : controller : received request : getAllApps : (appGroupId:'+req.params.id+', companyId:'+req.header('companyId')+')');
	appDao.getAllApps(req, res, callback);
};

module.exports.addNewAppGroup = addNewAppGroup;
module.exports.getAppGroupById = getAppGroupById;
module.exports.updateAppGroupById = updateAppGroupById;
module.exports.getAllApps = getAllApps;