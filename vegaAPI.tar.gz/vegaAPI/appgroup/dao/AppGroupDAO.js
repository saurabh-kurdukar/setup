var AppGroup = require('../models/AppGroup');
var Company = require('../../company/models/Company');
var logger = require('../../common/logger').log;
var audit = require('../../common/Audit').audit;

/*
 * Add new app group
 */
var addNewAppGroup = function(req, res, callback) {
	logger.info('appgroup : DAO : received request : addNewAppGroup : body : '+JSON.stringify(req.body));	
	/*
	 *	Find if companyId exist or not 
	 */
	Company.find({
		'companyId' : req.header('companyId')
	}, function(err, data) {
		if (err) {		
			logger.error('appgroup : DAO : failed addNewAppGroup : error : ' + err);
			callback(err, null);
		} else {
			if (data.length != 0) {
				/*
				 * 	companyId exist, add new app group
				 */
				var reqBody = req.body;	
				var appgroup = new AppGroup();
				appgroup.setAppgroupid(reqBody.appGroupId);
				appgroup.setAppgroupname(reqBody.appGroupName);
				appgroup.setDescription(reqBody.description);
				appgroup.setCompanyId(req.header('companyId'));
				appgroup.setImage(reqBody.image);
				appgroup.setCreatedOn(new Date());
				appgroup.setCreatedBy("admin");
				appgroup.setUpdatedOn(new Date());
				appgroup.setUpdatedBy("admin");	
				appgroup.save(function(err, data) {
					if (err) {
						logger.error('appgroup : DAO : failed addNewAppGroup : error : ' + err);
						callback(err, null);
					} else {
						logger.info('appgroup : DAO : addNewAppGroup successful !');						
						callback(null, data);
					}
				});
			} else {
				var err = new Error('Invalid company id');
				err.status = 404;	
				logger.error('appgroup : DAO : failed addNewAppGroup : error : ' + err);
				callback(err, null);
			}
		}
	});	
};

/*
 * Get app group by app group id & company id
 */
var getAppGroupById = function(req, res, callback) {
	logger.info('appgroup : DAO : received request : getAppGroupById : (appGroupId:'+req.params.id+', companyId:'+req.header('companyId')+')');
	AppGroup.find({
		'appGroupId' : req.params.id,
		'companyId' : req.header('companyId')
	}, function(err, data) {
		if (err) {
			logger.error('appgroup : DAO : failed getAppGroupById : error : ' + err);
			callback(err, null);
		} else {
			if (data.length != 0) {
				logger.info('appgroup : DAO : getAppGroupById successful !');
				callback(null, data[0]);
			} else {
				var err = new Error('Invalid App Group Id or company id');
				err.status = 404;
				logger.error('appgroup : DAO : failed getAppGroupById : error : ' + err);
				callback(err, null);
			}
		}
	});
};

/*
 * Edit/Update app group details
 */
var updateAppGroupById = function(req, res, callback) {
	logger.info('appgroup : DAO : received request : updateAppGroupById : (appGroupId:'+req.params.id+', companyId:'+req.header('companyId')+', body:'+JSON.stringify(req.body)+')');
	
	var callbackUpdate = function(err, data) {	
		if(err) {
			logger.error('appgroup : DAO : failed updateAppGroupById : error : ' + err);
			callback(err, null);
		} else if(data != null) {
			var appgroup = data;			
			var updatedData = [];
			var json = {};
			if (req.body.description && appgroup['description'] != req.body.description) {
				json.description = req.body.description;
				var obj = {};
				obj.column = 'description';
				obj.oldValue = appgroup['description'];
				obj.newValue = req.body.description;
				obj.identifier = 'Platform_AppGroup_'+req.params.id;
				obj.modifiedBy = 'admin';
				obj.modifiedOn = new Date();
				updatedData.push(obj);
			}
			if (req.body.image && appgroup['image'] != req.body.image) {
				json.image = req.body.image;
				var obj = {};
				obj.column = 'image';
				obj.oldValue = appgroup['image'];
				obj.newValue = req.body.image;
				obj.identifier = 'Platform_AppGroup_'+req.params.id;
				obj.modifiedBy = 'admin';
				obj.modifiedOn = new Date();
				updatedData.push(obj);
			}
			if (Object.keys(json).length != 0) {
				json.updatedBy = 'admin';
				json.updatedOn = new Date();
				logger.info('appgroup : DAO : updateAppGroupById : updating data : ' + JSON.stringify(json));
				AppGroup.findOneAndUpdate({
					'appGroupId' : req.params.id,
					'companyId' : req.header('companyId')
				}, json, {
					'new' : true
				// returns updated entity if update successful
				}, function(err, data) {
					if (err) {
						logger.error('appgroup : DAO : failed updateAppGroupById : error : ' + err);
						callback(err, null);
					} else {
						if(data != null) {
							logger.info('appgroup : DAO : updateAppGroupById successful !');
							/*
							 *	Call audit function for changed data 
							 */
							audit(req, res, updatedData);
							/*
							 *	Call function to send response to client 
							 */
							callback(null, data);
						} else {
							var err = new Error('Invalid App group id or company id');
							logger.error('appgroup : DAO : failed updateAppGroupById : error : ' + err);
							callback(err, null);
						}
					}
				});
			} else {
				var err = new Error('Cannot update data');
				logger.error('appgroup : DAO : failed updateAppGroupById : error : ' + err);
				callback(err, null);
			}
		} else {
			var err = new Error('Failed to get app group details');
			logger.error('appgroup : DAO : failed updateAppGroupById : error : ' + err);
			callback(err, null);
		}			
	}
	
	getAppGroupById(req, res, callbackUpdate);
	
	
};

/*
 * Get all app groups created under the given companyid
 */
var getAppGroupsByCompanyId = function(req, res, callback) {
	logger.info('appgroup : DAO : received request : getAppGroupsByCompanyId : companyId:'+req.header('companyId'));	
	AppGroup.find({
		'companyId' : req.header('companyId')
	}, function(err, data) {
		if (err) {
			logger.error('appgroup : DAO : failed getAppGroupsByCompanyId : error : ' + err);
			callback(err, data);
		} else {
			if (data.length != 0) {
				logger.info('appgroup : DAO : getAppGroupsByCompanyId successful !');
				callback(null, data);
			} else {
				var err = new Error('No appgroup exist for company id');
				err.status = 404;
				logger.error('appgroup : DAO : failed getAppGroupsByCompanyId : error : ' + err);
				callback(err, null);
			}
		}
	});	
};

module.exports.addNewAppGroup = addNewAppGroup;
module.exports.getAppGroupById = getAppGroupById;
module.exports.updateAppGroupById = updateAppGroupById;
module.exports.getAppGroupsByCompanyId = getAppGroupsByCompanyId;