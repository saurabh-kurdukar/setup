var express = require('express');
var logger = require('../common/logger').log;
var ComponentController=require('./controller/ComponentController');
var ErrorResponse = require('../common/ErrorResponse').ErrorResponse;
var router = express.Router();


/*
 * Add new Component details
 */
router.post('/', function(req, res){
	logger.info('Component : router : received request : addNewComponent : body : '+JSON.stringify(req.body));
	ComponentController.addNewComponent(req, res, function(err, data) {
        if(err){
        	logger.error('Component : router : failed addNewComponent : error : '+err);             	     
        	var error = new ErrorResponse();
        	if(err.name == 'ValidationError'){
        		error.setErrorMessage(err.errors[Object.keys(err.errors)[0]].message);
        	} else {
        		error.setErrorMessage(err.message);
        	}
        	error.setErrorCode("U0001");        	
        	error.setHttpResponseCode(500);        	
        	res.status(500).end(JSON.stringify(error));        
        
        } else {        	
        	logger.info("Component : router : addNewComponent successful !");
        	res.status(200).end(JSON.stringify(data));
        }
    });
});

/*
 * Get Component by id
 */
router.get('/:id', function (req, res) {
	logger.info('Component : router : received request : getComponentById : id : '+req.params.id);
	ComponentController.getComponentById(req, res, function(err, data) {
        if(err){
        	logger.error('Component : router : failed getComponentById : error : '+err);  
        	var error = new ErrorResponse();
        	error.setErrorCode("U0002");
        	error.setErrorMessage(err.message);
        	error.setHttpResponseCode(500);
            res.status(500).end(JSON.stringify(error));
        }else{        	
        	logger.info("Component : router : getComponentById successful !") ;
        	res.status(200).end(JSON.stringify(data));
        }
    });
	});
	
	/*
	* Update Component details
	*/
 
router.put('/:id', function(req, res){	 
	logger.info('Component : router : received request : updateComponentById : (id: '+req.params.id+', body: '+JSON.stringify(req.body)+')');
	ComponentController.updateComponentById(req, res, function(err, data) {
        if(err){
        	logger.error('Component : router : failed updateComponentById : error : '+err);   
        	var error = new ErrorResponse();
        	if(err.name == 'ValidationError'){
        		error.setErrorMessage(err.errors[Object.keys(err.errors)[0]].message);
        	} else {
        		error.setErrorMessage(err.message);
        	}
        	error.setErrorCode("U0003");        	
        	error.setHttpResponseCode(500);
            res.status(500).end(JSON.stringify(error));
        }else{        	
        	logger.info("Component : router : updateComponentById successful !");
        	res.status(200).end(JSON.stringify(data));
        }
    });
});


/*
 * Get all Components
 */
 
router.get('/', function (req, res) {	
	logger.info('Component : router : received request : getAllComponents : status : '
			+ req.query.status);
	ComponentController.getAllComponents(req, res, function(err, data) {
        if(err){
        	logger.error('Component : router : failed getAllComponents : error : '+err);   
        	var error = new ErrorResponse();
        	error.setErrorCode("U0004");
        	error.setErrorMessage(err.message);
        	error.setHttpResponseCode(500);
            res.status(500).end(JSON.stringify(error));
        }else{        	
        	logger.info("Component : router : getAllComponents successful !");
        	res.status(200).end(JSON.stringify(data));
        }
    });
});

/*
 * Delete Component details
 */
router.delete('/:id', function(req, res){
	logger.info('Component : router : received request : deleteComponentById : id : '+req.params.id);
	ComponentController.deleteComponentById(req, res, function(err, data) {
        if(err){
        	logger.error('Component : router : failed deleteComponentById : error : '+err); 
        	var error = new ErrorResponse();
        	error.setErrorCode("U0005");
        	error.setErrorMessage(err.message);
        	error.setHttpResponseCode(500);
            res.status(500).end(JSON.stringify(error));
        }else{        	
        	logger.info("Component : router : deleteComponentById successful !");
        	res.status(200).end(JSON.stringify(data));
        }
    });
});

/*
 * Options method
 */
router.options('/', function(req, res) {
	logger.info('Component : router : received request : Options call Component APIs');
	res.header('Allow-Access-Allow-Origin', '*');
	res.header('Access-Control-Allow-Headers', '*');
	res.header('Access-Control-Allow-Methods', 'GET,POST,DELETE,PUT,OPTIONS');
	res.header('Connection', 'keep-alive');
	res.header('Content-Type', 'application/json;charset=UTF-8');
	res.end();
	logger.info('Component : router : Options call Component APIs processed !');
});

router.all('/*', function (req, res) {		
	res.status(404).send(JSON.stringify({'error':'No matching resource for url: '+req.originalUrl}));	  	
});


module.exports = router;