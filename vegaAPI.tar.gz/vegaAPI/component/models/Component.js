var mongoose = require('../../common/MongoDbConnection').mongoose;
var autoIncrement = require('mongoose-auto-increment');
var logger = require('../../common/logger').log;
var connection = mongoose.connection;
autoIncrement.initialize(connection);

/*
 * Define schema
 */
var componentSchema = mongoose.Schema({
	
	id: Number ,
	componentname: String ,
	name: String,
	baseUrl:  String ,
	logo: String,
	summary: String,
	description: String,
	versionNo: String,
	swaggerUrl: String,
	screenShots:[{type:String}],
    createdOn: { type: Date, default: Date.now },
	createdBy: {type: String},
	updatedOn: { type: Date, default: Date.now },
	updatedBy: {type: String}
		            
});

logger.info('Component : model : created schema : Component :'+JSON.stringify(componentSchema.paths));

/*
* Add Auto increment plugin for field component Id
*/
componentSchema.plugin(autoIncrement.plugin, { model: 'Component', field: 'id', startAt: 1 });



/*
 * Setters
 */
componentSchema.methods.setId=function(id){
	this.id=id;
}

componentSchema.methods.setName=function(name){
	this.name=name;
}

componentSchema.methods.setComponentname=function(componentname){
	this.componentname=componentname;
}

componentSchema.methods.setBaseUrl=function(baseUrl){
	this.baseUrl=baseUrl;
}

componentSchema.methods.setLogo=function(logo){
	this.logo=logo;
}

componentSchema.methods.setSummary=function(summary){
	this.summary=summary;
}

componentSchema.methods.setDescription=function(description){
	this.description=description;
}

componentSchema.methods.setVersionNo=function(versionNo){
	this.versionNo=versionNo;
}

componentSchema.methods.setSwaggerUrl=function(swaggerUrl){
	this.swaggerUrl=swaggerUrl;
}

componentSchema.methods.setScreenShots=function(screenShots){
	this.screenShots=screenShots;
}

componentSchema.methods.setCreatedOn = function(createdOn) {
	this.createdOn = createdOn;
};
componentSchema.methods.setCreatedBy = function(createdBy) {
	this.createdBy = createdBy;
};
componentSchema.methods.setUpdatedOn = function(updatedOn) {
	this.updatedOn = updatedOn;
};
componentSchema.methods.setUpdatedBy = function(updatedBy) {
	this.updatedBy = updatedBy;
};




/*
 * Getters
 */
componentSchema.methods.getId=function(){
	return this.id;
}

componentSchema.methods.getComponentname=function(){
	return this.componentname;
}

componentSchema.methods.getBaseUrl=function(){
	return this.baseUrl;
}

componentSchema.methods.getLogo=function(){
	return this.logo;
}

componentSchema.methods.getSummary=function(){
	return this.summary;
}

componentSchema.methods.getDescription=function(){
	return this.description;
}	
	
componentSchema.methods.getVersionNo=function(){
	return this.versionNo;
}	

componentSchema.methods.getSwaggerUrl=function(){
	return this.swaggerUrl;
}	
	

componentSchema.methods.getScreenShots=function(){
	return this.screenShots;
}

componentSchema.methods.getCreatedOn=function(){
	return this.createdOn;
}
componentSchema.methods.getCreatedBy=function(){
	return this.createdBy;
}
componentSchema.methods.getUpdatedOn=function(){
	return this.updatedOn;
}
componentSchema.methods.getUpdatedBy=function(){
	return this.updatedBy;
}	
/*
 * Create collection/model in mongo db using Schema
 */
var Component = mongoose.model('Component', componentSchema);

module.exports = Component;