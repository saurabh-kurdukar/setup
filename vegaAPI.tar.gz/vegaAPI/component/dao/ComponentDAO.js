var db = require('../../common/MongoDbConnection');
var Component = require('../models/Component');
var logger = require('../../common/logger').log;
var audit = require('../../common/Audit').audit;
var encryptdecrypt= require('../../common/EncryptDecrypt');
const MODULE_NAME = 'Component';

/*
 * Add new Domain details
 */
var addNewComponent = function(req, res, callback) {	
	logger.info('Component : DAO : received request : addNewComponent : body : '
			+ JSON.stringify(req.body));
	
	var reqBody = req.body;
	var component = new Component();
	component.setName(reqBody.name);	
	component.setBaseUrl(reqBody.baseUrl);
	component.setLogo(reqBody.logo);
	component.setSummary(reqBody.summary);
	component.setDescription(reqBody.description);	
	component.setVersionNo(reqBody.versionNo);
	component.setSwaggerUrl(reqBody.swaggerUrl);
	component.setScreenShots(reqBody.screenShots);
	component.setCreatedBy(req.headers.username);
	component.setUpdatedBy(req.headers.username);
	
	component.save(function(err, data) {
		if (err) {
			logger.error('Component : DAO : failed addNewComponent : error : ' + err);
			callback(err, null);
		} else if(data != null){
			logger.info('Component : DAO : addNewComponent successful !');
			callback(null, data);
		} else {
			var err = new Error('Failed to add new Component details');			
			logger.error('Component : DAO : failed addNewComponent : error : '+ err);
			callback(err, null);
		}
	});		
};

/*
* Get Compnent by id
*/
var getComponentById = function(req, res, callback) {
	logger.info('Component : DAO : received request : getComponentById : id : '+req.params.id);
	Component.findOne({
		'id' : req.params.id
	}, function(err, data) {
		if (err) {
			callback(err, data);
		} else {
			if (data && data.length != 0) {            
				callback(err, data);
			} else {
				var err = new Error('Invalid Component id');
				err.status = 404;
				callback(err, data);
			}
		}
	});
};

/*
* Update Compnent details
*/
 
var updateComponentById = function(req, res, callback) {
	logger.info('Component : DAO : received request : updateComponentById : (id: '+req.params.id+', body: '+JSON.stringify(req.body)+')');
	
	/*
	 * Callback function after getting original record to update with new values.
	 */
	  
	var callbackUpdate = function(err, data) {	
		if(err) {
			logger.error('Component : DAO : failed updateComponentById : error :' + err);
			callback(err, null);
		} else if(data != null) {
			/*
			 *	Compare updatable fields values in db with request data
			 *	Add those fields in temproary object which are having new values
			 */
			var component = data;
			var json = {};
			var updatedData = [];
			if (req.body.name && component['name'] != req.body.name) {
				json.name = req.body.name;
				var obj = {};				
				obj.column = 'name';
				obj.oldValue = component['name'];
				obj.newValue = req.body.name;
				obj.identifier = 'Platform_user_'+req.params.id;
				obj.modifiedBy = 'admin';
				obj.modifiedOn = new Date();
				updatedData.push(obj);
			}
			if (req.body.baseUrl && component['baseUrl'] != req.body.baseUrl) {
				
				json.baseUrl = req.body.baseUrl;			
                var obj = {};
				obj.column = 'baseUrl';
				obj.oldValue = component['baseUrl'];
				obj.newValue = req.body.baseUrl;
				obj.identifier = 'Platform_user_'+req.params.id;
				obj.modifiedBy = 'admin';
				obj.modifiedOn = new Date();
				updatedData.push(obj);
			}
			if (req.body.logo && component['logo'] != req.body.logo) {
				json.logo = req.body.logo;
				var obj = {};
				obj.column = 'logo';
				obj.oldValue = component['logo'];
				obj.newValue = req.body.logo;
				obj.identifier = 'Platform_user_'+req.params.id;
				obj.modifiedBy = 'admin';
				obj.modifiedOn = new Date();
				updatedData.push(obj);
			}
			if (req.body.summary && component['summary'] != req.body.summary) {
				json.summary = req.body.summary;
				var obj = {};
				obj.column = 'summary';
				obj.oldValue = component['summary'];
				obj.newValue = req.body.summary;
				obj.identifier = 'Platform_user_'+req.params.id;
				obj.modifiedBy = 'admin';
				obj.modifiedOn = new Date();
				updatedData.push(obj);
			}
			if (req.body.description && component['description'] != req.body.description) {
				json.description = req.body.description;
				var obj = {};
				obj.column = 'description';
				obj.oldValue = component['description'];
				obj.newValue = req.body.description;
				obj.identifier = 'Platform_user_'+req.params.id;
				obj.modifiedBy = 'admin';
				obj.modifiedOn = new Date();
				updatedData.push(obj);
			}
			if (req.body.versionNo && component['versionNo'] != req.body.versionNo) {
				json.versionNo = req.body.versionNo;
				var obj = {};
				obj.column = 'versionNo';
				obj.oldValue = component['versionNo'];
				obj.newValue = req.body.versionNo;
				obj.identifier = 'Platform_user_'+req.params.id;
				obj.modifiedBy = 'admin';
				obj.modifiedOn = new Date();
				updatedData.push(obj);
			}
			if (req.body.swaggerUrl && component['swaggerUrl'] != req.body.swaggerUrl) {
				json.swaggerUrl = req.body.swaggerUrl;
				var obj = {};
				obj.column = 'swaggerUrl';
				obj.oldValue = component['swaggerUrl'];
				obj.newValue = req.body.swaggerUrl;
				obj.identifier = 'Platform_user_'+req.params.id;
				obj.modifiedBy = 'admin';
				obj.modifiedOn = new Date();
				updatedData.push(obj);
			}			
			if (req.body.screenShots && component['screenShots'] != req.body.screenShots) {
				json.screenShots = req.body.screenShots;
				var obj = {};
				obj.column = 'screenShots';
				obj.oldValue = component['screenShots'];
				obj.newValue = req.body.screenShots;
				obj.identifier = 'Platform_user_'+req.params.id;
				obj.modifiedBy = 'admin';
				obj.modifiedOn = new Date();
				updatedData.push(obj);
			}
			
			
			/*
			 *	Update the data to database 
			 */
			 var updateDoc = false;
			if(Object.keys(json).length != 0) {
				updateDoc = true;
			 }
             
            if(updateDoc){
            
			if (Object.keys(json).length != 0) {
				json.updatedOn = new Date();
				json.updatedBy = req.headers.username;
				logger.info('Component : DAO : updateComponentById : updating data : ' + JSON.stringify(json));
				Component.findOneAndUpdate({
					'id' : req.params.id
				}, json, {
					'new' : true
				// returns updated entity if update successful, if false then old entry
				}, function(err, data) {
					if (err) {
						logger.error('Component : DAO : failed updateComponentById : error :' + err);
						callback(err, null);
					} else {
						if(data != null) {
							logger.info('Component : DAO : updateComponentById successful !');		
							
							/*
							 *	Call audit function for changed data 
							 */
							audit(req, res, updatedData);
							/*
							 *	Call function to send response to client 
							 */
							callback(null, data);
						} else {
							var err = new Error('Bad request data');
							logger.error('Component : DAO : failed updateComponentById : error :' + err);
							callback(err, null);
						}
					}
				});
			} else {
				var err = new Error('Cannot update data');
				logger.error('Component : DAO : failed updateComponentById : error :' + err);
				callback(err, null);
			}
            }else{
                var err = new Error('Already up to date');
				logger.error(MODULE_NAME + ' : DAO : failed updateComponentById : error : ' + err);
				callback(err, null)
            }
            
		} else {
			var err = new Error('Failed to get Component details');
			logger.error('Component : DAO : failed updateComponentById : error :' + err);
			callback(err, null);
		}
	}
	
	/*
	 * Get the original record from db before update.
	 */
	  
	getComponentById(req, res, callbackUpdate);
	
};


/*
 * Get all components
 */
var getAllComponents = function(req, res, callback) {
	logger.info('Components : DAO : received request : getAllComponents :');
						
if (typeof req.query.email !== 'undefined' && req.query.name !== null){

Component.find({
		'name' : req.query.name
	}, function(err, data) {
		if (err) {
			callback(err, data);
		} else {
			if (data.length != 0) {
				callback(err, data);
			} else {
				var err = new Error('Invalid component name');
				err.status = 404;
				callback(err, data);
			}
		}
	});	
}
else
{
	Component.find(function(err, data) {
		if (err) {
			logger.error('Components : DAO : failed getAllComponents : error : ' + err);
			callback(err, null);
		} else {
			if (data.length != 0) {
				logger.info('Components : DAO : getAllComponents successful !');
				callback(null, data);
			} else {
				var err = new Error('No records found');
				err.status = 404;
				logger.error('Components : DAO : failed getAllComponents : error : ' + err);
				callback(err, null);
			}
		}
	});
}
};


/*
 * Delete component by id
 */
var deleteComponentById =function (req,res,callback){
		
	var callbackDelete = function(err, data) {
		if (err) {
			callback(err, data);
		} else {			
			Component.remove({'id': req.params.id }, 
			function(err, data) {
				if (err) {
					callback(err, data);
				} else {
					callback(err, data);
				}
			});
		}
	};
	getComponentById(req, res, callbackDelete);
};	

module.exports.addNewComponent = addNewComponent;
module.exports.getComponentById= getComponentById;
module.exports.updateComponentById= updateComponentById;
module.exports.getAllComponents= getAllComponents;
module.exports.deleteComponentById= deleteComponentById;
