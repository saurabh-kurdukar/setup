var ComponentDao = require('../dao/ComponentDAO');
var logger = require('../../common/logger').log;
/*
 * Add new Component details
 */
var addNewComponent = function(req, res, callback) {
	logger.info('Component : controller : received request : addNewComponent : body : '+JSON.stringify(req.body));			
	ComponentDao.addNewComponent(req, res, callback);
}; 	

/*
* Get Component by id
*/
var getComponentById = function(req, res, callback) {	
	logger.info('Component : controller : received request : getComponentById : id : '+req.params.id);
	ComponentDao.getComponentById(req, res ,callback);
};

/*
 * Update Component details
 */
var updateComponentById = function(req, res, callback) {
	logger.info('Component : controller : received request : updateComponentById : (id: '+req.params.id+', body: '+JSON.stringify(req.body)+')');
	ComponentDao.updateComponentById(req, res, callback);
};


/*
 * Get all Components
 */
var getAllComponents = function(req, res, callback) {	
	logger.info('Component : controller : received request : getAllComponents : ');
	ComponentDao.getAllComponents(req, res ,callback);
};

/*
 * delete Component by id
 */
var deleteComponentById = function(req, res, callback) {	
	logger.info('Component : controller : received request : deleteComponentById : ');
	ComponentDao.deleteComponentById(req, res ,callback);
};


module.exports.addNewComponent = addNewComponent;
module.exports.getComponentById= getComponentById;
module.exports.updateComponentById= updateComponentById;
module.exports.getAllComponents= getAllComponents;
module.exports.deleteComponentById= deleteComponentById;
