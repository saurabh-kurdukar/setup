var async = require('async');
var request = require('request');
var otplib = require('otplib/lib/totp');
var sendMessageController = require('../../sendMessage/controller/SendMessageController');
var otpRegisterDao = require('../../otpRegistration/dao/OTPRegisterDAO');
var otpRecordDao = require('../dao/OTPRecordDAO');
var templateDao = require('../../template/dao/TemplateDAO');
var logger = require('../../common/logger').log;
var config = require('../../common/Config');
var RabbitMQ= require('../../common/RabbitMQ');
var queueName='otpqueue';
const MODULE_NAME = 'otp';

/*
 * 
* logging format followed: logger.info(<module_name>: <component name> : <description> : [<long_description>] : <data/params/errors>);
*/


/*
* Send otp
*/
var sendOTP = function(req, callback) {
	logger.info(MODULE_NAME + ' : controller : received request : sendOTP : '
			+'(body:'+JSON.stringify(req.body)+', username:'+req.header('username')+')');
	otpRegisterDao.getOtpDetailsById(req.body.otpRegisterId, function(err, otpRegisterDetails){
		if(err) {
			err.status = 500;
			return callback(err);
		}		
		var secret = otplib.utils.generateSecret();
		var otp = otplib.generate(secret);
		req.body.jsonData = {
			"otp" :  otp	
		};
		req.body.version = otpRegisterDetails.templateVersion;
		req.params.id = otpRegisterDetails.templateId;
		req.headers.companyid = config.PLATFORMUSER_COMPANYID;
		req.body.otp = otp;
		templateDao.getFilledTemplateById(req, null, function(err, filledTemplate) {
			if(err) {
				err.status = 500;
				return callback(err);
			}
			sendMessageController.createSMSRequest(config.SMS_GATEWAY_ID_FOR_OTP, req.body.mobileNo, filledTemplate, req, function(err, req) {
				if(err) {
					err.status = 500;
					return callback(err);
				}				
				req.requestObj.reqBody = req.body;
				req.requestObj.reqBody.otp = otp;
				req.requestObj.headers = req.headers;
				// call to send SMS
				sendSMS(req.requestObj, function(smsErr, smsResponse) {					 
					 if(smsErr) {
						 return callback(err);
					 }
					 callback(null, {"message" : smsResponse});
				});
			});			
		});
	});
}	

/*
 * Add sms to queue
 */
var sendSMS = function(requestObj, callback) {
	logger.info(MODULE_NAME + ' : controller : sendSMS : requestObj: ' + JSON.stringify(requestObj));	
	RabbitMQ.getConnection(function(connection){
		connection.createChannel(function(err, ch) {
		    ch.assertQueue(queueName, {durable: false});
		    ch.sendToQueue(queueName, new Buffer(JSON.stringify(requestObj)));
		    console.log(" [x] Message sent to sms queue.");
			callback(err, 'OTP Sent');
			setTimeout(function() { connection.close();  }, 500);
		});
	});
}

/*
* Verify otp
*/
var verifyOTP = function(req, callback) {
	logger.info(MODULE_NAME + ' : controller : received request : verifyOTP : (body:'+JSON.stringify(req.body)+", otpRegisterId:"
			+req.params.otpRegisterId+", username:"+req.headers.username+")");
	otpRecordDao.getOTPRecordByRegIdAndMobileNo(req.params.otpRegisterId, req.body.mobileNo, function(err, otpRecords) {
		//console.log('otpRecords='+JSON.stringify(otpRecords));
		var status = '';
		var url = '';	
		if(err) {
			logger.error(MODULE_NAME + ' : controller : verifyOTP : error : no otp record exist.');
			var err = new Error('invalid otp or expired, please re-generate.');
			err.status = 401;
			callback(err);
		} else {		
			var otpRecord = otpRecords[0];
			if(otpRecords && otpRecords.length > 1) {
				logger.info(MODULE_NAME + ' : controller : verifyOTP : info : multiple active otp records exist.');				
				var updateMultiplestatus = 'INVALID_STATE';
				var ids = [];
				for(var i=1; i<otpRecords.length; i++) {					  
					ids.push(otpRecords[i].id);
				}
				var json = {
					status : updateMultiplestatus
				};
				otpRecordDao.updateMultipleOTPRecords(ids, json, function(err, data) {
					if(err) {
						logger.error(MODULE_NAME + ' : controller : verifyOTP : update multiple OTP records : error : '+JSON.stringify(err));
						err.status = 500;
						return callback(err);
					}					
				});
			}
			if(req.body.otp === otpRecord.otp) {
				logger.info(MODULE_NAME + ' : controller : verifyOTP : info : otp matched!');
				status = 'VERIFIED';
			} else {
				logger.error(MODULE_NAME + ' : controller : verifyOTP : error : otp does not match!');
				status = 'FAILED';
			}
			otpRegisterDao.getOtpDetailsById(req.params.otpRegisterId, function(err, otpRegister) {				
				if(err) {
					logger.error(MODULE_NAME + ' : controller : verifyOTP : get OTP details by id : error : '+JSON.stringify(err));
					err.status = 500;
					return callback(err);											
				} else if(status === 'VERIFIED') {
					var currentTime = new Date().getTime();
					var otpCreatedTime = new Date(otpRecord.createdOn).getTime();
					var diffMins = Math.round((currentTime - otpCreatedTime)/60000);									
					url = otpRegister.onSuccessURL;
					if(diffMins > otpRegister.expiresIn) {
						status = 'EXPIRED';
						url = otpRegister.onFailureURL;
					}						
				} else if(status === 'FAILED') {
					url = otpRegister.onFailureURL;
				}
				var json = {
					status : status,
					updatedOn: new Date(),
					updatedBy: req.headers.username
				};
				logger.info(MODULE_NAME + ' : controller : verifyOTP : info : updating otp record : '+JSON.stringify(json));
				otpRecordDao.updateOTPRecord(otpRecord.id, json, function(err, data) {
					if(err) {
						logger.error(MODULE_NAME + ' : controller : verifyOTP : update OTP record : error : '+JSON.stringify(err));
						err.status = 500;
						return callback(err);
					}
					if(status != 'VERIFIED') {
						var err = new Error('invalid otp or expired, please re-generate.');
						err.status = 401;
						callback(err);
					} else {							
						var response = {};				
						response.redirectURL = url;
						callback(null, response);
					}
				});
			});			
		}
	});
};



module.exports.sendOTP = sendOTP;
module.exports.verifyOTP = verifyOTP;









