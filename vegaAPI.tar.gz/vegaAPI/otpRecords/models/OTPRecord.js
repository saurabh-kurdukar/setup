var mongoose = require('../../common/MongoDbConnection').mongoose;
var autoIncrement = require('mongoose-auto-increment');
const MODULE_NAME = 'otp_record';
var connection = mongoose.connection;
autoIncrement.initialize(connection);

/*
 * Define schema
 */
var otpRecordsSchema = mongoose.Schema({
    id: Number,
    otpRegisterId: { type: Number, required: 'field otpRegisterId is required' },
	otp: { type: String, required: true },
	mobileNo: { type: String, required: 'field mobileNo is required' },	
	status: {type: String, enum: [], default: 'ACTIVE'},
	createdOn: { type: Date, default: Date.now },
	createdBy: {type: String},
	updatedOn: { type: Date, default: Date.now },
	updatedBy: {type: String}
});


otpRecordsSchema.pre('findOneAndUpdate', function(next) {
	  this.options.runValidators = true;
	  next();
});

otpRecordsSchema.pre('update', function(next) {
	  this.options.runValidators = true;
	  next();
});


/*
 * Add Auto increment for field id
 */
otpRecordsSchema.plugin(autoIncrement.plugin, { model: 'otp_records', field: 'id', startAt: 1 });



/*
 * Create collection/model in mongo db using Schema
 */
var OTPRecords = mongoose.model('otp_records', otpRecordsSchema);


module.exports = OTPRecords;