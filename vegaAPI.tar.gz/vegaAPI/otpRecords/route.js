var express = require('express');
var otpRecordController = require('./controller/OTPRecordController');
var logger = require('../common/logger').log;
var ErrorResponse = require('../common/ErrorResponse').ErrorResponse;
var router = express.Router();
const MODULE_NAME = 'otp';

/*
* logging format followed: logger.info(<module_name>: <component name> : <description> : [<long_description>] : <data/params/errors>);
*/

/*
* Send otp
*/
router.post('/', function (req, res) {
	logger.info(MODULE_NAME + ' : router : received request : sendOTP : '
			+'(body:'+JSON.stringify(req.body)+', username:'+req.header('username')+')');
	if(req.body.mobileNo && req.body.otpRegisterId && req.headers.username) {		
		otpRecordController.sendOTP(req, function(err, data) {
			if(err) {
				logger.error(MODULE_NAME + ' : router : failed sendOTP : error : '+err);
				var error = new ErrorResponse();	
				if(err.name == 'ValidationError'){
					error.setErrorMessage(err.errors[Object.keys(err.errors)[0]].message);
				} else {
					error.setErrorMessage(err.message);
				}
				error.setErrorCode("OTP0001");
				error.setHttpResponseCode(err.status);
				res.status(err.status).end(JSON.stringify(error));
			} else {
				logger.info(MODULE_NAME + " : router : sendOTP successful !") ;
				res.status(200).end(JSON.stringify(data));
			}
		});		
	} else {
		var error = new ErrorResponse('OTP0001', 'fields mobileNo, otpRegisterId and header username is required', 200);	
		logger.error(MODULE_NAME + ' : router : failed sendOTP : error : '+JSON.stringify(error));
		res.status(200).end(JSON.stringify(error));
	}
});

/*
* Verify otp
*/
router.put('/:otpRegisterId/verify', function (req, res) {
	logger.info(MODULE_NAME + ' : router : received request : verifyOTP : (body:'+JSON.stringify(req.body)+", otpRegisterId:"
			+req.params.otpRegisterId+", username:"+req.headers.username+")");
	if(req.body.mobileNo && req.body.otp && req.headers.username) {		
		otpRecordController.verifyOTP(req, function(err, data) {
			if(err) {
				logger.error(MODULE_NAME + ' : router : failed verifyOTP : error : '+err);
				var error = new ErrorResponse("OTP0003", err.message, err.status);				
				res.status(err.status).end(JSON.stringify(error));
			} else {
				logger.info(MODULE_NAME + " : router : verifyOTP successful !");
				res.status(200).end(JSON.stringify(data));
			}
		});		
	} else {
		var error = new ErrorResponse('OTP0003', 'fields mobileNo, otpRegisterId, otp and header username is required', 200);	
		logger.error(MODULE_NAME + ' : router : failed verifyOTP : error : '+JSON.stringify(error));
		res.status(200).end(JSON.stringify(error));
	}
});




module.exports = router;
