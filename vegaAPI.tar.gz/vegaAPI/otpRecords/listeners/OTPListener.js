/**
 * New node file
 */
var request=require('request');
var RabbitMQ= require('../../common/RabbitMQ');
var logger = require('../../common/logger').log;
var otpRecordDao = require('../dao/OTPRecordDAO');
var q = 'otpqueue';

/*
 * Receive Message
 */
RabbitMQ.getConnection(function(connection){	
	connection.createChannel(function(err, ch) {
		ch.prefetch(1);
	    ch.assertQueue(q, {durable: false});	
		console.log(" [*] Waiting for messages in " + q);		
		ch.consume(q, function(msg) {
				console.log(" [x] Received %s", msg.content.toString());
				var requestObj = JSON.parse(msg.content);				
				//send sms
				sendSMS(msg, -1, requestObj.SMSMessageRetries, function(smsErr, smsResponse) {					
					saveOTPRecord(requestObj, smsErr, smsResponse);
					ch.ack(msg);
				});				
			}, {
				noAck: false
			}
		);
	});	
});

function sendSMS(msg, retryCount, MAX_RETRY_COUNT, cb) {
	var smsSent = false;
	retryCount++;	
	var requestObj = JSON.parse(msg.content);
	logger.info('otpRecords : listeners : sendSMS : requestObj: ' + JSON.stringify(requestObj));
	request(requestObj.requestOptions, function (error, response, body) {		
		//console.log('error='+JSON.stringify(error));
		//console.log('response='+JSON.stringify(response));
		console.log('body='+JSON.stringify(body));
		if(error) {
			logger.error('otpRecords : listeners : sendSMS : failed sendSMS : attempt:'+ retryCount +' : error : '+ JSON.stringify(error));
			console.log('otpRecords : listeners : sendSMS : attempt:'+ retryCount +' : error : '+ JSON.stringify(error));
		} else if(response.statusCode === 200 || response.statusCode === 201) {
			logger.info('otpRecords : listeners : sendSMS : SMS sent. : body : '+ body+', response:'+JSON.stringify(response));									
			console.log('otpRecords : listeners : sendSMS : attempt:'+ retryCount +' : SMS sent.');
			smsSent = true;
			retryCount = MAX_RETRY_COUNT;			
		} else {
			logger.error('otpRecords : listeners : sendSMS : failed sendSMS : attempt:'+retryCount+' : error : '+JSON.stringify(body));									
			console.log('otpRecords : listeners : sendSMS : attempt:'+retryCount+' : error : '+JSON.stringify(body));
		}
		if(retryCount === MAX_RETRY_COUNT) {
			if(smsSent) {
				cb(null, body);
			} else {
				cb(body, null);
			}
		} else {
			sendSMS(msg, retryCount, MAX_RETRY_COUNT, cb)
		}
	});
}

function saveOTPRecord(requestObj, smsErr, smsResponse) {
	 var status = 'SENT';
	 if(smsErr) {
		 status = 'FAILED';
	 }
	 var req = {};
	 req.body = requestObj.reqBody;
	 req.body.status = status;
	 req.headers = requestObj.headers;
	 otpRecordDao.saveOTPRecord(req, function(errOnSave, otpRecord) {
		if(errOnSave) {
			logger.error('otpRecords : listeners : failed saveOTPRecord : error : '+ JSON.stringify(error));
		}		
	 });
}


