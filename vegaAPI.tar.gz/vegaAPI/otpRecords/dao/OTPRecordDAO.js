var OTPRegister = require('../../otpRegistration/models/OTPRegister');
var OTPRecord = require('../models/OTPRecord');
var logger = require('../../common/logger').log;
var audit = require('../../common/Audit').audit;
const MODULE_NAME = 'otp';

/*
 * logging format followed: logger.info(<module_name>: <component name> : <description> : [<long_description>] : <data/params/errors>);
 */

/*
 * Save otp record
 */
var saveOTPRecord = function(req, callback) {
	logger.info(MODULE_NAME + ' : DAO : received request : saveOTPRecord : body : '+JSON.stringify(req.body));	
	var otp_record = new OTPRecord(req.body);	
	otp_record.createdBy = req.headers.username;
	otp_record.updatedBy = req.headers.username;
	
	otp_record.save(function(err, data) {
		if (err) {
			err.status = 500;
			logger.error(MODULE_NAME + ' : DAO : failed saveOTPRecord : error : ' + err);
			callback(err);
		} else if(data){
			logger.info(MODULE_NAME + ' : DAO : saveOTPRecord successful !');
			callback(err, data);
		} else {
			var err = new Error('Failed to save otp record');
			err.status = 500;
			logger.error(MODULE_NAME + ' : DAO : failed saveOTPRecord : error : '+ err);
			callback(err);
		}
	});
};



/*
 * Get otp record
*/
var getOTPRecord = function(otpRegisterId, mobileNo, otp, callback) {
	logger.info(MODULE_NAME + ' : DAO : received request : verifyOTP : (mobileNo : '+mobileNo+", otp:" +otp+")" );
	OTPRecord.findOne({
		'otpRegisterId' : otpRegisterId,
		'mobileNo' : mobileNo,
		'otp': otp,
		'status': 'SENT'
	}, function(err, data) {
		if (err) {
			err.status = 500;
			logger.error(MODULE_NAME + ' : DAO : failed verifyOTP : error : ' + JSON.stringify(err));
			callback(err);
		} else {
			if (data) {				
				logger.info(MODULE_NAME + ' : DAO : verifyOTP successful !');
                callback(null, data);
			} else {
				var err = new Error('no otp record exist');
				err.status = 404;
				logger.error(MODULE_NAME + ' : DAO : failed verifyOTP : error : '+ err);
				callback(err);
			}
		}
	});
};


var getOTPRecordByRegIdAndMobileNo = function(otpRegisterId, mobileNo, callback) {
	OTPRecord.find({
		'otpRegisterId' : otpRegisterId,
		'mobileNo' : mobileNo,
		'status': 'SENT'
	}, function(err, data) {
		if (err) {
			err.status = 500;
			logger.error(MODULE_NAME + ' : DAO : failed verifyOTP : error : ' + JSON.stringify(err));
			callback(err);
		} else {
			if (data.length) {				
				logger.info(MODULE_NAME + ' : DAO : verifyOTP successful !');
                callback(null, data);
			} else {
				var err = new Error('no otp records exist');
				err.status = 404;
				logger.error(MODULE_NAME + ' : DAO : failed verifyOTP : error : '+ err);
				callback(err);
			}
		}
	}).sort({'createdOn': 'desc'});
}


var updateOTPRecord = function(id, json, callback) {
	OTPRecord.update({
		'id' : id
	}, json, function(err, data) {
		if (err) {
			err.status = 500;
			logger.error(MODULE_NAME + ' : DAO : failed updateOTPRecord : error : ' + JSON.stringify(err));
			callback(err);
		} else {
			if (data) {				
				logger.info(MODULE_NAME + ' : DAO : updateOTPRecord successful !');
                callback(null, data);
			} else {
				var err = new Error('invalid otp');
				err.status = 404;
				logger.error(MODULE_NAME + ' : DAO : failed updateOTPRecord : error : '+ err);
				callback(err);
			}
		}
	});
}

var updateMultipleOTPRecords = function(ids, json, callback) {
	OTPRecord.update({
		'id' : { $in: ids }
	}, json, { multi: true }, function(err, data) {
		if (err) {
			err.status = 500;
			logger.error(MODULE_NAME + ' : DAO : failed updateOTPRecord : error : ' + JSON.stringify(err));
			callback(err);
		} else {
			if (data) {				
				logger.info(MODULE_NAME + ' : DAO : updateOTPRecord successful !');
                callback(null, data);
			} else {
				var err = new Error('invalid otp');
				err.status = 404;
				logger.error(MODULE_NAME + ' : DAO : failed updateOTPRecord : error : '+ err);
				callback(err);
			}
		}
	});
}




module.exports.saveOTPRecord = saveOTPRecord;
module.exports.getOTPRecord = getOTPRecord;
module.exports.updateOTPRecord = updateOTPRecord;
module.exports.getOTPRecordByRegIdAndMobileNo = getOTPRecordByRegIdAndMobileNo;
module.exports.updateMultipleOTPRecords= updateMultipleOTPRecords;

