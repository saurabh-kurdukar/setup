var Widget = require('../models/Widget');
var logger = require('../../common/logger').log;
var config = require('../../common/Config');
var fs = require('fs');
var rimraf = require('rimraf');
var async = require('async');

/*
 * logging format followed: logger.info(<module_name>: <component name> : <description> : [<long_description>] : <data/params/errors>);
 */


/*
 * Add new widget details
 */
var addNewWidget = function(req, res, callback) {
	logger.info('Widget : DAO : received request : addNewWidget : body : ' + JSON.stringify(req.body));
	if(req.body.createdBy) {
		req.body.updatedBy = req.body.createdBy;
	}
	var widget = new Widget(req.body);

	var regex = new RegExp(['^', req.body.name, '$'].join(''), 'i');

	Widget.findOne({
		name: regex
	}, function(err, data) {
		if(err) {
			logger.error('Widget : DAO : failed addNewWidget : get by id : error : ' + err);
			callback(err, null);
		}
		else if(data) {
			var err = new Error('Widget name already exists');
			err.status = 409;
			logger.error('Widget : DAO : failed addNewWidget : error : Name already exists');
			callback(err, null);
		}
		else {
			widget.save(function(err, data) {
				if (err) {
					logger.error('Widget : DAO : failed addNewWidget : error : ' + err);
					callback(err, null);
				} else if(data != null){
					logger.info('Widget : DAO : addNewWidget successful !');
					callback(null, data);
				} else {
					var err = new Error('Failed to add new widget details');
					logger.error('Widget : DAO : failed addNewWidget : error : '+ err);
					callback(err, null);
				}
			});
		}
	})
};

/*
 * Get all widgets
 */
var getAllWidgets = function(req, res, callback) {
	logger.info('Widget : DAO : received request : getAllWidgets');

	var query = {};
	var regex;
	if(req.query.name) {
		logger.info('Widget : DAO : received request : getAllWidgets : name : ' + req.query.name);
		var widgetName = decodeURIComponent(req.query.name);
		regex = new RegExp(['^', widgetName, '$'].join(''), 'i');
		query.name = regex;
	}

	Widget.find(query, function(err, data) {
		if(err) {
			logger.error('Widget : DAO : failed getAllWidgets : error : ' + err);
			callback(err, null);
		}
		else {
			if (data.length != 0) {
				logger.info('Widget : DAO : getAllWidgets successful !');
				callback(null, data);
			} else {
				var err = new Error('No records found');
				err.status = 404;
				logger.error('Widget : DAO : failed getAllWidgets : error : ' + err);
				callback(err, null);
			}
		}
	})
}

/*
 * Get widget by id
 */
var getWidgetById = function(req, res, callback) {
	logger.info('Widget : DAO : received request : getWidgetById : id : ' + req.params.id);

	Widget.findOne({
		id: req.params.id
	}, function(err, data) {
		if(err) {
			logger.error('Widget : DAO : failed getWidgetById : error : ' + err);
			callback(err, null);
		}
		else {
			if(data) {
				logger.info('Widget : DAO : getWidgetById successful !');
				callback(null, data);
			} else {
				var err = new Error('Invalid widget id');
				err.status = 404;
				logger.error('Widget : DAO : failed getWidgetById : error : ' + err);
				callback(err, null);
			}
		}
	})
}

/*
 * Update widget by id
 */
var updateWidgetById = function(req, res, callback) {
	logger.info('Widget : DAO : received request : updateWidgetById : id : ' + req.params.id);

	var json = {};
	if(req.body.name) {
		json.name = req.body.name;
	}
	if(req.body.description) {
		json.description = req.body.description;
	}
	if(req.body.version) {
		json.version = req.body.version;
	}
	if(req.body.type) {
		json.type = req.body.type;
	}
	if(req.body.inputData) {
		json.inputData = req.body.inputData;
	}
	if(req.body.tags && req.body.tags.length > 0) {
		json.tags = req.body.tags;
	}
	if(req.body.updatedBy) {
		json.updatedBy = req.body.updatedBy;
	}
	json.updatedOn = new Date();

	Widget.findOne({
		id: req.params.id
	}, function(err, data) {
		if(err) {
			logger.error('Widget : DAO : failed updateWidgetById : get by id : error : ' + err);
			callback(err, null);
		}
		else {
			if(data) {
			  async.series([
			    function(cb) {
			      var deleteFiles = req.body.deleteFiles;
			      if(deleteFiles && deleteFiles.length > 0) {
			        async.eachSeries(deleteFiles, function(file, call) {
			          var filePath = data.widgetLocationBasePath + '/' + file.split('/').pop();
			          deleteWidgetFolder(filePath, function(fail, success) {
			            if(fail) {
			              call(fail, null);
			            }
			            else {
			              logger.info('Widget : DAO : updateWidgetById : File deleted : ' + success);
			              var deletePos = data.dependentFiles.indexOf(file);
			              data.dependentFiles.splice(deletePos, 1);
			              call(null, success);
			            }
			          });
			        }, function(err) {
			          if(err) {
			            logger.error('Widget : DAO : updateWidgetById : Failed to delete file : error : ' + err);
			            cb(err, null);
			          }
			          else {
			            json.dependentFiles = data.dependentFiles;
			            cb(null, "One");
			          }
			        });
			      }
			      else {
			        cb(null, "One");
			      }
			    },
			    function(cb) {
			      if(req.files.length != 0) {
			        var widgetFiles = req.files;
			        async.eachSeries(widgetFiles, function(file, call) {
			          var saveFile = config.BINARY_STORAGE.BASE_URL + config.BINARY_STORAGE.WIDGET + data.name + '/' + file.filename;
			          if((file.filename.split('.').pop().toLowerCase() === 'png'
			                || file.filename.split('.').pop().toLowerCase() === 'jpg'
			                || file.filename.split('.').pop().toLowerCase() === 'jpeg')
			              && file.fieldname.toLowerCase() === 'thumbnail') {
			            var deleteFile = data.widgetLocationBasePath + '/' + data.thumbnail.split('/').pop();
									if(deleteFile.split('/').pop() === file.filename) {
										call(null, deleteFile);
									}
									else {
										deleteWidgetFolder(deleteFile, function(fail, success) {
				              if(fail) {
				                logger.error('Widget : DAO : updateWidgetById : delete thumbnail : error : ' + fail);
				                call(fail, null);
				              }
				              else {
				                logger.info('Widget : DAO : updateWidgetById : thumbnail deleted successfully!');
				                json.thumbnail = saveFile;
				                call(null, success);
				              }
				            })
									}
			          }
			          else if(file.fieldname.toLowerCase() === 'html' && file.filename.split('.').pop().toLowerCase() === 'html') {
			            var deleteFile = data.widgetLocationBasePath + '/' + data.htmlFile.split('/').pop();
									if(deleteFile.split('/').pop() === file.filename) {
										call(null, deleteFile);
									}
									else {
										deleteWidgetFolder(deleteFile, function(fail, success) {
				              if(fail) {
				                logger.error('Widget : DAO : updateWidgetById : delete htmlFile : error : ' + fail);
				                call(fail, null);
				              }
				              else {
				                logger.info('Widget : DAO : updateWidgetById : htmlFile deleted successfully!');
				                json.htmlFile = saveFile;
				                call(null, success);
				              }
				            })
									}
			          }
								else if(file.fieldname.toLowerCase() === 'controller' && file.filename.split('.').pop().toLowerCase() === 'js') {
			            var deleteFile = data.widgetLocationBasePath + '/' + data.controllerFile.split('/').pop();
									if(deleteFile.split('/').pop() === file.filename) {
										call(null, deleteFile);
									}
									else {
										deleteWidgetFolder(deleteFile, function(fail, success) {
				              if(fail) {
				                logger.error('Widget : DAO : updateWidgetById : delete controllerFile : error : ' + fail);
				                call(fail, null);
				              }
				              else {
				                logger.info('Widget : DAO : updateWidgetById : controllerFile deleted successfully!');
				                json.controllerFile = saveFile;
				                call(null, success);
				              }
				            })
									}
			          }
								else if(file.fieldname.toLowerCase() === 'css' && file.filename.split('.').pop().toLowerCase() === 'css') {
			            var deleteFile = data.widgetLocationBasePath + '/' + data.cssFile.split('/').pop();
									if(deleteFile.split('/').pop() === file.filename) {
										call(null, deleteFile);
									}
									else {
										deleteWidgetFolder(deleteFile, function(fail, success) {
				              if(fail) {
				                logger.error('Widget : DAO : updateWidgetById : delete cssFile : error : ' + fail);
				                call(fail, null);
				              }
				              else {
				                logger.info('Widget : DAO : updateWidgetById : cssFile deleted successfully!');
				                json.cssFile = saveFile;
				                call(null, success);
				              }
				            })
									}
			          }
			          else {
			            if(data.dependentFiles.indexOf(saveFile) == -1) {
			              data.dependentFiles.push(saveFile);
			            }
			            call(null, saveFile);
			          }
			        }, function(err) {
			          if(err) {
			            logger.error('Widget : DAO : updateWidgetById : Failed to delete file : error : ' + err);
			            cb(err, null);
			          }
			          else {
			            json.dependentFiles = data.dependentFiles;
			            cb(null, "Two");
			          }
			        })
			      }
			      else {
			        cb(null, "Two");
			      }
			    }
			  ], function(err, data) {
			    if(err) {
			      logger.error('Widget : DAO : updateWidgetById : Failed to update record : error : ' + err);
			      callback(err, null);
			    }
			    else {
			      Widget.findOneAndUpdate({
			        id: req.params.id
			      }, json, {
			        new: true
			      }, function(err, data) {
			        if(err) {
			          logger.error('Widget : DAO : failed updateWidgetById : error : ' + err);
			          callback(err, null);
			        }
			        else {
			          if(data) {
			            logger.info('Widget : DAO : updateWidgetById successful !');
			            callback(null, data);
			          }
			          else {
			            var err = new Error('Invalid widget id');
			            err.status = 404;
			            logger.error('Widget : DAO : failed updateWidgetById : error : ' + err);
			            callback(err, null);
			          }
			        }
			      })
			    }
			  });
			} else {
				var err = new Error('Invalid widget id');
				err.status = 404;
				logger.error('Widget : DAO : failed updateWidgetById : error : ' + err);
				callback(err, null);
			}
		}
	})
}

/*
 * Delete widget by id
 */
var deleteWidgetById = function(req, res, callback) {
	logger.info('Widget : DAO : received request : deleteWidgetById : id : ' + req.params.id);

	Widget.findOne({
		id: req.params.id
	}, function(err, data) {
		if(err) {
			logger.error('Widget : DAO : failed deleteWidgetById : get widget by id : error : ' + err);
			callback(err, null);
		}
		else {
			if(data) {
				var folderPath = data.widgetLocationBasePath;
				Widget.remove({
					id: req.params.id
				}, function(err, data) {
					if(err) {
						logger.error('Widget : DAO : failed deleteWidgetById : error : ' + err);
						callback(err, null);
					}
					else {
						deleteWidgetFolder(folderPath, function(err, data) {
							if(err) {
								callback(err, null);
							}
							else {
								logger.info('Widget : DAO : deleteWidgetById successful !');
								callback(null, "Widget deleted successfully");
							}
						});
					}
				})
			} else {
				var err = new Error('Invalid widget id');
				err.status = 404;
				logger.error('Widget : DAO : failed getWidgetById : error : ' + err);
				callback(err, null);
			}
		}
	})
}

/*
 * Delete widget file/folder
 */
var deleteWidgetFolder = function(folder, callback) {
	logger.error('Widget : DAO : deleteWidgetFolder : folder : ' + folder);
	if(fs.existsSync(folder)) {
		rimraf(folder, function(err) {
			if(err) {
				logger.error('Widget : DAO : deleteWidgetFolder : error : ' + err);
				callback(err, null);
			}
			else {
				logger.error('Widget : DAO : deleteWidgetFolder successful !');
				callback(null, folder);
			}
		})
	}
	else {
		logger.error('Widget : DAO : deleteWidgetFolder : No widgets found to delete !');
		callback(null, folder);
	}
}

/*
 * Search widgets
 */
var searchWidgets = function(req, res, callback) {
	logger.info('Widget : DAO : received request : searchWidgets : text : ' + req.query.text);

	if(!req.query.text) {
		var err = new Error('No tags found');
		logger.error('Widget : DAO : failed searchWidgets : error : No text found');
		callback(err, null);
	}
	else {
		var queryString = decodeURIComponent(req.query.text);
		var split = queryString.split(",");
		var searchString = "";
		split.forEach(function(word) {
			searchString += "\"" + word + "\" ";
		})

		Widget.find({
			$text: {
				$search: req.query.text
			}
		}, function(err, data) {
			if(err) {
				logger.error('Widget : DAO : failed searchWidgets : error : ' + err);
				callback(err, null);
			}
			else {
				if(data.length > 0) {
					logger.info('Widget : DAO : searchWidgets successful !');
					callback(null, data);
				} else {
					var err = new Error('No records found');
					err.status = 404;
					logger.error('Widget : DAO : failed searchWidgets : error : ' + err);
					callback(err, null);
				}
			}
		})
	}
}


module.exports.addNewWidget = addNewWidget;
module.exports.getAllWidgets = getAllWidgets;
module.exports.getWidgetById = getWidgetById;
module.exports.updateWidgetById = updateWidgetById;
module.exports.deleteWidgetById = deleteWidgetById;
module.exports.searchWidgets = searchWidgets;
