var widgetDao = require('../dao/WidgetDAO');
var logger = require('../../common/logger').log;

/*
 * logging format followed: logger.info(<module_name>: <component name> : <description> : [<long_description>] : <data/params/errors>);
 */


/*
 * Add new widget details
 */
var addNewWidget = function(req, res, callback) {
	logger.info('Widget : controller : received request : addNewWidget : body : ' + JSON.stringify(req.body));
	widgetDao.addNewWidget(req, res, callback);
};

/*
 * Get all widgets
 */
var getAllWidgets = function(req, res, callback) {
	logger.info('Widget : controller : received request : getAllWidgets');
	widgetDao.getAllWidgets(req, res, callback);
}

/*
 * Get widget by id
 */
var getWidgetById = function(req, res, callback) {
	logger.info('Widget : controller : received request : getWidgetById : id : ' + req.params.id);
	widgetDao.getWidgetById(req, res, callback);
}

/*
 * Update widget by id
 */
var updateWidgetById = function(req, res, callback) {
	logger.info('Widget : controller : received request : updateWidgetById : id : ' + req.params.id);
	widgetDao.updateWidgetById(req, res, callback);
}

/*
 * Delete widget by id
 */
var deleteWidgetById = function(req, res, callback) {
	logger.info('Widget : controller : received request : deleteWidgetById : id : ' + req.params.id);
	widgetDao.deleteWidgetById(req, res, callback);
}

/*
 * Search widgets
 */
var searchWidgets = function(req, res, callback) {
	logger.info('Widget : controller : received request : searchWidgets : text : ' + req.query.text);
	widgetDao.searchWidgets(req, res, callback);
}


module.exports.addNewWidget = addNewWidget;
module.exports.getAllWidgets = getAllWidgets;
module.exports.getWidgetById = getWidgetById;
module.exports.updateWidgetById = updateWidgetById;
module.exports.deleteWidgetById = deleteWidgetById;
module.exports.searchWidgets = searchWidgets;
