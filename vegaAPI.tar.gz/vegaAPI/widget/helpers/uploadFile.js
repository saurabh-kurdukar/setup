var multer  = require('multer');
var fs = require('fs');
var config = require('../../common/Config');
var Widget = require('../models/Widget');

var filePath = config.BINARY_STORAGE.BASE_PATH;

if(!fs.existsSync(filePath)) {
  fs.mkdirSync(filePath);
}
if(!fs.existsSync(filePath + config.BINARY_STORAGE.WIDGET)) {
  fs.mkdirSync(filePath + config.BINARY_STORAGE.WIDGET);
}

var storage = multer.diskStorage({
  destination: function (req, file, cb) {
    // console.log("File", req);
    var folderName = req.body.name;
    if(req.body.name) {
      if(!fs.existsSync(filePath + config.BINARY_STORAGE.WIDGET + folderName)) {
        fs.mkdirSync(filePath + config.BINARY_STORAGE.WIDGET + folderName);
      }
      req.body.widgetLocationBasePath = filePath + config.BINARY_STORAGE.WIDGET + folderName;
      cb(null, filePath + config.BINARY_STORAGE.WIDGET + folderName);
    }
    else if(!req.body.name && req.params.id) {
      Widget.findOne({
        id: req.params.id
      }, function(err, data) {
        if(err) {
          var error = new Error("Cannot save widget file", file);
          cb(error, null);
        }
        else {
          folderName = data.name;
          if(!fs.existsSync(filePath + config.BINARY_STORAGE.WIDGET + folderName)) {
            fs.mkdirSync(filePath + config.BINARY_STORAGE.WIDGET + folderName);
          }
          req.body.widgetLocationBasePath = filePath + config.BINARY_STORAGE.WIDGET + folderName;
          cb(null, filePath + config.BINARY_STORAGE.WIDGET + folderName);
        }
      })
    }
    else {
      var error = new Error("Widget name or id not found");
      cb(error, null);
    }
  },
  filename: function (req, file, cb) {
  	var fileName = file.originalname;
  	cb(null, fileName);
  }
});
var l = 0;
function fileFilter(req, file, cb) {
	var ext = file.originalname.split('.').pop();
	if(!file.fieldname) {
    req.fileValidationError = 'No fieldname provided for the file';
	  cb(null, false);
	}
  else {
    cb(null, true);
  }
}

var upload = multer({ storage: storage,  fileFilter: fileFilter });

module.exports = upload;
