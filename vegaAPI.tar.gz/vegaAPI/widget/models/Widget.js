var mongoose = require('../../common/MongoDbConnection').mongoose;
var autoIncrement = require('mongoose-auto-increment');
var logger = require('../../common/logger').log;
var connection = mongoose.connection;
autoIncrement.initialize(connection);
/*
 * logging format followed: logger.info(<module_name>: <component name> :
 * <description> : <long_description> : <data/params/errors>);
 */


/*
 * Define schema
 */
var widgetSchema = mongoose.Schema({
  id: Number,
	name: { type: String, unique : true, required : true },
  description: String,
  version: String,
  type: String,
  tags: [ String ],
  inputData: String,
  widgetLocationBasePath: String,
  thumbnail: String,
  htmlFile: String,
  controllerFile: String,
  cssFile: String,
  dependentFiles: [ String ],
  createdBy: String,
  updatedBy: String,
  createdOn: { type: Date, default: Date.now },
  updatedOn: { type: Date, default: Date.now }
});


// logger.info('Widget : model : created schema : Widget :'+JSON.stringify(widgetSchema.paths));

/*
 * Add Auto increment plugin for field widget id
 */
widgetSchema.plugin(autoIncrement.plugin, { model: 'Widget', field: 'id', startAt: 1 });

// Create index for text search
widgetSchema.index({name:"text", description: "text", tags: "text"});

/*
 * Create collection/model in mongo db using Schema
 */
var Widget = mongoose.model('Widget', widgetSchema);
logger.info('Widget : model : created model : Widget : ' + Widget);


module.exports = Widget;
