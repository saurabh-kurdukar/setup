var express = require('express');
var widgetController = require('./controller/WidgetController');
var logger = require('../common/logger').log;
var ErrorResponse = require('../common/ErrorResponse').ErrorResponse;
var router = express.Router();
var upload = require('./helpers/uploadFile');
var config = require('../common/Config');

/*
 * logging format followed: logger.info(<module_name>: <component name> : <description> : [<long_description>] : <data/params/errors>);
 */

/*
 * Add new widget details
 */
router.post('/', upload.any(), function(req, res) {

	if(req.fileValidationError) {
		logger.info('Widget : router : received request : addNewWidget : error : ' + req.fileValidationError);
		var error = new ErrorResponse();
		error.setErrorMessage(req.fileValidationError);
		error.setErrorCode("W0001");
		error.setHttpResponseCode(500);
		res.status(500).end(JSON.stringify(error));
	}
	else if(req.files.length == 0) {
		logger.info('Widget : router : received request : addNewWidget : error : No file found');
		var error = new ErrorResponse();
		error.setErrorMessage("No file found");
		error.setErrorCode("W0001");
		error.setHttpResponseCode(500);
		res.status(500).end(JSON.stringify(error));
	}
	else {
		var widgetFiles = req.files;
		var dependentFiles = [];
		widgetFiles.forEach(function(file) {
			var saveFile = config.BINARY_STORAGE.BASE_URL + config.BINARY_STORAGE.WIDGET + req.body.name + '/' + file.filename;
			if((file.filename.split('.').pop().toLowerCase() === 'png'
						|| file.filename.split('.').pop().toLowerCase() === 'jpg'
						|| file.filename.split('.').pop().toLowerCase() === 'jpeg')
					&& file.fieldname.toLowerCase() === 'thumbnail') {
				req.body.thumbnail = saveFile;
			}
			else if(file.filename.split('.').pop().toLowerCase() === 'html' && file.fieldname.toLowerCase() === 'html') {
				req.body.htmlFile = saveFile;
			}
			else if(file.filename.split('.').pop().toLowerCase() === 'js' && file.fieldname.toLowerCase() === 'controller') {
				req.body.controllerFile = saveFile;
			}
			else if(file.filename.split('.').pop().toLowerCase() === 'css' && file.fieldname.toLowerCase() === 'css') {
				req.body.cssFile = saveFile;
			}
			else {
				dependentFiles.push(saveFile);
			}
		})
		req.body.dependentFiles = dependentFiles;

		logger.info('Widget : router : received request : addNewWidget : body : ' + JSON.stringify(req.body));
		widgetController.addNewWidget(req, res, function(err, data) {
			if(err) {
				logger.error('Widget : router : failed addNewWidget : error : '+err);
				var error = new ErrorResponse();
				if(err.name == 'ValidationError'){
					error.setErrorMessage(err.errors[Object.keys(err.errors)[0]].message);
				} else {
					error.setErrorMessage(err.message);
				}
				error.setErrorCode("W0001");
				var errorStatus = 500;
				if(err.status) {
					errorStatus = err.status;
				}
				error.setHttpResponseCode(errorStatus);
				res.status(errorStatus).end(JSON.stringify(error));
			}
			else {
				logger.info('Widget : router : addNewWidget successful !');
				res.status(200).end(JSON.stringify(data));
			}
		});
	}
});

/*
 * Get all widgets
 */
router.get('/', function(req, res) {
	logger.info('Widget : router : received request : getAllWidgets');
	widgetController.getAllWidgets(req, res, function(err, data) {
		if(err) {
			logger.error('Widget : router : failed getAllWidgets : error : ' + err);
			var error = new ErrorResponse();
			error.setErrorCode("W0002");
			error.setErrorMessage(err.message);
			var errorStatus = 500;
			if(err.status) {
				errorStatus = err.status;
			}
			error.setHttpResponseCode(errorStatus);
			res.status(errorStatus).end(JSON.stringify(error));
		}
		else {
			logger.info('Widget : router : getAllWidgets successful!');
			res.status(200).end(JSON.stringify(data));
		}
	})
})

/*
 * Search widgets
 */
router.get('/search', function(req, res) {
	logger.info('Widget : router : received request : searchWidgets : text : ' + req.query.text);
	widgetController.searchWidgets(req, res, function(err, data) {
		if(err) {
			logger.error('Widget : router : failed searchWidgets : error : ' + err);
			var error = new ErrorResponse();
			error.setErrorCode("W0006");
			error.setErrorMessage(err.message);
			var errorStatus = 500;
			if(err.status) {
				errorStatus = err.status;
			}
			error.setHttpResponseCode(errorStatus);
			res.status(errorStatus).end(JSON.stringify(error));
		}
		else {
			logger.info('Widget : router : searchWidgets successful!');
			res.status(200).end(JSON.stringify(data));
		}
	})
})

/*
 * Get widget by id
 */
router.get('/:id', function(req, res) {
	logger.info('Widget : router : received request : getWidgetById : id : ' + req.params.id);
	widgetController.getWidgetById(req, res, function(err, data) {
		if(err) {
			logger.error('Widget : router : failed getWidgetById : error : ' + err);
			var error = new ErrorResponse();
			error.setErrorCode("W0003");
			error.setErrorMessage(err.message);
			var errorStatus = 500;
			if(err.status) {
				errorStatus = err.status;
			}
			error.setHttpResponseCode(errorStatus);
			res.status(errorStatus).end(JSON.stringify(error));
		}
		else {
			logger.info('Widget : router : getWidgetById successful!');
			res.status(200).end(JSON.stringify(data));
		}
	})
})

/*
 * Update widget by id
 */
router.put('/:id', upload.any(), function(req, res) {
	logger.info('Widget : router : received request : updateWidgetById : id : ' + req.params.id);
	widgetController.updateWidgetById(req, res, function(err, data) {
		if(err) {
			logger.error('Widget : router : failed updateWidgetById : error : ' + err);
			var error = new ErrorResponse();
			error.setErrorCode("W0004");
			error.setErrorMessage(err.message);
			var errorStatus = 500;
			if(err.status) {
				errorStatus = err.status;
			}
			error.setHttpResponseCode(errorStatus);
			res.status(errorStatus).end(JSON.stringify(error));
		}
		else {
			logger.info('Widget : router : updateWidgetById successful!');
			res.status(200).end(JSON.stringify(data));
		}
	})
})

/*
 * Delete widget by id
 */
router.delete('/:id', function(req, res) {
	logger.info('Widget : router : received request : deleteWidgetById : id : ' + req.params.id);
	widgetController.deleteWidgetById(req, res, function(err, data) {
		if(err) {
			logger.error('Widget : router : failed deleteWidgetById : error : ' + err);
			var error = new ErrorResponse();
			error.setErrorCode("W0005");
			error.setErrorMessage(err.message);
			var errorStatus = 500;
			if(err.status) {
				errorStatus = err.status;
			}
			error.setHttpResponseCode(errorStatus);
			res.status(errorStatus).end(JSON.stringify(error));
		}
		else {
			logger.info('Widget : router : deleteWidgetById successful!');
			res.status(200).end(JSON.stringify(data));
		}
	})
})


module.exports = router;
