var mongoose = require('../../common/MongoDbConnection').mongoose;
var autoIncrement = require('mongoose-auto-increment');
var logger = require('../../common/logger').log;
const MODULE_NAME = 'company';
var connection = mongoose.connection;
autoIncrement.initialize(connection);

/*
 * logging format followed: logger.info(<module_name>: <component name> :
 * <description> : <long_description> : <data/params/errors>);
 */


/*
 * Define schema
 */
var companySchema = mongoose.Schema({
    companyId: Number,
	companyName: { type: String, unique: true, required: true },
	companyAddress: {type: String},
	city: {type: String},
	state: {type: String},
	country: {type: String},
	zipCode: {type: String},
	companyURL: {type: String},
	companyImageURL: {type: String},
	phone: {type: String},
	fax: {type: String},
	email: {type: String},
	adminFullName: {type: String},
	adminMobile: {type: String},
	adminEmail: {type: String},
	gamificationSharing: {type: String, default: 'DISABLED'},
	status: {type: String, default: 'PENDING'},
	createdOn: { type: Date, default: Date.now },
	createdBy: {type: String},
	updatedOn: { type: Date, default: Date.now },
	updatedBy: {type: String},
	adminMobileVerified: {type: String, default: 'N'},
	adminEmailVerified: {type: String, default: 'N'},
	parentCompanyId: {type: String , default: ''},
	lookupenabled:{type:Boolean , default:true} ,
	userCount: {type:Number, default: 0} ,
	provisionCount: {type: Number , default: 0} ,
	vmCount: {type: Number , default: 0}
});


logger.info(MODULE_NAME + ' : model : created schema : Companies :'+JSON.stringify(companySchema.paths));


companySchema.path('companyName').validate(function(value, fn) {	  
	  var Company = mongoose.model('Companies');
	  Company.find({'companyName': value}, function (err, data) {
	    fn(err || data.length === 0);
	  });
}, 'Company name is already taken');

companySchema.pre('findOneAndUpdate', function(next) {
	  this.options.runValidators = true;
	  next();
});

companySchema.pre('update', function(next) {
	  this.options.runValidators = true;
	  next();
});

companySchema.path('companyName').validate(function (v) {
	  return (v.length > 0 && v.length <= 100);
}, 'data too long/short for field companyName'); 

companySchema.path('companyAddress').validate(function (v) {
	  return (v.length > 0 && v.length <= 100);
}, 'data too long/short for field companyAddress');

companySchema.path('city').validate(function (v) {
	  return (v.length > 0 && v.length <= 100);
}, 'data too long/short for field city');

companySchema.path('state').validate(function (v) {
	  return (v.length > 0 && v.length <= 100);
}, 'data too long/short for field state');

companySchema.path('country').validate(function (v) {
	  return (v.length > 0 && v.length <= 100);
}, 'data too long/short for field country');

companySchema.path('zipCode').validate(function (v) {
	  return (v.length > 0 && v.length <= 11);
}, 'data too long/short for field zipCode');

companySchema.path('companyURL').validate(function (v) {
	  return (v.length > 0 && v.length <= 100);
}, 'data too long/short for field companyURL');

companySchema.path('companyImageURL').validate(function (v) {
	  return (v.length > 0 && v.length <= 150);
}, 'data too long/short for field companyImageURL');

companySchema.path('phone').validate(function (v) {
	  return (v.length > 0 && v.length <= 20);
}, 'data too long/short for field phone');

companySchema.path('fax').validate(function (v) {
	  return (v.length > 0 && v.length <= 20);
}, 'data too long/short for field fax');

companySchema.path('email').validate(function (v) {
	  return (v.length > 0 && v.length <= 100);
}, 'data too long/short for field email');

companySchema.path('adminFullName').validate(function (v) {
	  return (v.length > 0 && v.length <= 100);
}, 'data too long/short for field adminFullName');

companySchema.path('adminMobile').validate(function (v) {
	  return v.length <= 20;
}, 'data too long/short for field adminMobile');

companySchema.path('adminEmail').validate(function (v) {
	  return (v.length > 0 && v.length <= 100);
}, 'data too long/short for field adminEmail');

companySchema.path('status').validate(function (v) {
	  return (v.length > 0 && v.length <= 20);
}, 'data too long/short for field status');

companySchema.path('createdBy').validate(function (v) {
	  return (v.length > 0 && v.length <= 100);
}, 'data too long/short for field createdBy');

companySchema.path('updatedBy').validate(function (v) {
	  return (v.length > 0 && v.length <= 50);
}, 'data too long/short for field updatedBy');

companySchema.path('adminMobileVerified').validate(function (v) {
	  return (v.length > 0 && v.length <= 1);
}, 'data too long/short for field adminMobileVerified');

companySchema.path('adminEmailVerified').validate(function (v) {
	  return (v.length > 0 && v.length <= 1);
}, 'data too long/short for field adminEmailVerified');

/*
 * Add Auto increment plugin for field companyId
 */
companySchema.plugin(autoIncrement.plugin, { model: 'Companies', field: 'companyId', startAt: 1 });


/*
 * Setters
 */
companySchema.methods.setCompanyId = function(companyId) {	
	this.companyId = companyId;
};

companySchema.methods.setCompanyName = function(companyName) {
	this.companyName = companyName;
};

companySchema.methods.setCompanyAddress = function(companyAddress) {
	this.companyAddress = companyAddress;
};

companySchema.methods.setCity = function(city) {
	this.city = city;
};

companySchema.methods.setState = function(state) {
	this.state = state;
};

companySchema.methods.setCountry = function(country) {
	this.country = country;
};

companySchema.methods.setZipCode = function(zipCode) {
	this.zipCode = zipCode;
};

companySchema.methods.setCompanyURL = function(companyURL) {
	this.companyURL = companyURL;
};

companySchema.methods.setCompanyImageURL = function(companyImageURL) {
	this.companyImageURL = companyImageURL;
};

companySchema.methods.setPhone = function(phone) {
	this.phone = phone;
};

companySchema.methods.setFax = function(fax) {
	this.fax = fax;
};

companySchema.methods.setEmail = function(email) {
	this.email = email;
};

companySchema.methods.setAdminFullName = function(adminFullName) {
	this.adminFullName = adminFullName;
};

companySchema.methods.setAdminMobile = function(adminMobile) {
	this.adminMobile = adminMobile;
};

companySchema.methods.setAdminEmail = function(adminEmail) {
	this.adminEmail = adminEmail;
};

companySchema.methods.setGamificationSharing = function(gamificationSharing) {
	this.gamificationSharing = gamificationSharing;
};

companySchema.methods.setStatus = function(status) {
	this.status = status;
};

companySchema.methods.setCreatedOn = function(createdOn) {
	this.createdOn = createdOn;
};

companySchema.methods.setCreatedBy = function(createdBy) {
	this.createdBy = createdBy;
};

companySchema.methods.setUpdatedOn = function(updatedOn) {
	this.updatedOn = updatedOn;
};

companySchema.methods.setUpdatedBy = function(updatedBy) {
	this.updatedBy = updatedBy;
};

companySchema.methods.setAdminMobileVerified = function(adminMobileVerified) {
	this.adminMobileVerified = adminMobileVerified;
};

companySchema.methods.setAdminEmailVerified = function(adminEmailVerified) {
	this.adminEmailVerified = adminEmailVerified;
};

companySchema.methods.setParentCompanyId = function(parentCompanyId) {
	this.parentCompanyId = parentCompanyId;
};

companySchema.methods.setLookupenabled = function(lookupenabled) {
	this.lookupenabled = lookupenabled;
};

	companySchema.methods.setUserCount = function(userCount) {
	this.userCount = userCount;
};

companySchema.methods.setProvisionCount = function(provisionCount) {
	this.provisionCount = provisionCount;
};

companySchema.methods.setVmCount = function(vmCount) {
	this.vmCount = vmCount;
};

/*
 * Getters
 */
companySchema.methods.getCompanyId = function() {
	return this.companyId;
};

companySchema.methods.getCompanyName = function() {
	return this.companyName;
};

companySchema.methods.getCompanyAddress = function() {
	return this.companyAddress;
};

companySchema.methods.getCity = function() {
	return this.city;
};

companySchema.methods.getState = function() {
	return this.state;
};

companySchema.methods.getCountry = function() {
	return this.country;
};

companySchema.methods.getZipCode = function() {
	return this.zipCode;
};

companySchema.methods.getCompanyURL = function() {
	return this.companyURL;
};

companySchema.methods.getCompanyImageURL = function() {
	return this.companyImageURL;
};

companySchema.methods.getPhone = function() {
	return this.phone;
};

companySchema.methods.getFax = function() {
	return this.fax;
};

companySchema.methods.getEmail = function() {
	return this.email;
};

companySchema.methods.getAdminFullName = function() {
	return this.adminFullName;
};

companySchema.methods.getAdminMobile = function() {
	return this.adminMobile;
};

companySchema.methods.getAdminEmail = function() {
	return this.adminEmail;
};

companySchema.methods.getGamificationSharing = function() {
	return this.gamificationSharing;
};

companySchema.methods.getStatus = function() {
	return this.status;
};

companySchema.methods.getCreatedOn = function() {
	return this.createdOn;
};

companySchema.methods.getCreatedBy = function() {
	return this.createdBy;
};

companySchema.methods.getUpdatedOn = function() {
	return this.updatedOn;
};

companySchema.methods.getUpdatedBy = function() {
	return this.updatedBy;
};

companySchema.methods.getAdminMobileVerified = function() {
	return this.adminMobileVerified;
};

companySchema.methods.getAdminEmailVerified = function() {
	return this.adminEmailVerified;
};

companySchema.methods.getParentCompanyId = function() {
	return this.parentCompanyId;
};

companySchema.methods.getLookupenabled = function() {
	return this.lookupenabled;
};

companySchema.methods.getUserCount = function() {
	return this.userCount;
};

companySchema.methods.getProvisionCount = function() {
	return this.provisionCount;
};

companySchema.methods.getVmCount = function() {
	return this.vmCount;
};
	

/*
 * Create collection/model in mongo db using Schema
 */
var Company = mongoose.model('Companies', companySchema);
logger.info(MODULE_NAME + ' : model : created model : Companies : ' + Company);



module.exports = Company;