var companyDao = require('../dao/CompanyDAO');
var experienceDao = require('../../experience/dao/ExperienceDAO');
var apimanagerDao = require('../../apiMgrConfig/dao/ApiManagerDAO');
var smsgatewayDao=require('../../smsGateway/dao/SMSGatewayDAO');
var SMTPServerDao= require('../../smtpServer/dao/SMTPServerDAO');
var UserRegistrationDAO= require('../../userManagement/dao/UserRegistrationDAO');
var logger = require('../../common/logger').log;
var provisionGroup = require('./../../provision/controller/provision-group');
var vmdetailsdao= require('../../vmDetails/dao/AzureVmdetailsDao');
const MODULE_NAME = 'company';
var config = require('../../common/Config');
var radiaHelper = require('../../radia-adapter/client');
var mandatoryApps = config.MANDATORY_APPS;

/*
* logging format followed: logger.info(<module_name>: <component name> : <description> : [<long_description>] : <data/params/errors>);
*/


/*
* Add new company details
*/
var addNewCompany = function(req, res, callback) {
	logger.info(MODULE_NAME + ' : controller : received request : addNewCompany : body : '+JSON.stringify(req.body));
	provisionGroup.provisionGroup(req.body, function(err) {
		if(err) {
			callback(err);
		} else {
			companyDao.addNewCompany(req, res, function(error, company) {
				if(error) {
					logger.error("Error while company :  ", JSON.stringify(error));
					callback(error);
				}else {
					//EDR:1787 : Mandatory Apps assignment to the group
					req.body.mandatoryApps = mandatoryApps;
					console.log("Mandatory req : ", req);
					//mandatory App Association method call
					radiaHelper.associateMandatoryApplicationsInRadia(req.body ,function(err, data){
						if(err) {
							logger.error("Error in assigning mandatory appps", JSON.stringify(err));
							callback(error);
						}else {
							callback(null,company);
						}
					});
				}
			});
		}
	});
};

/*
* Get company by company id
*/
var getCompanyById = function(req, res, callback) {
	logger.info(MODULE_NAME + ' : controller : received request : getCompanyById : id : '+req.params.id);
	companyDao.getCompanyById(req, res, callback);
};

/*
* Get all companies
*/
var getAllCompanies = function(req, res, callback) {
	logger.info(MODULE_NAME + ' : controller : received request : getAllCompanies : status : '
	+ req.query.status);
	companyDao.getAllCompanies(req, res, callback);
};

/*
* Update company details
*/
var updateCompanyById = function(req, res, callback) {
	logger.info(MODULE_NAME + ' : controller : received request : updateCompanyById : (companyId: '+req.params.id+', body: '+JSON.stringify(req.body)+')');
	companyDao.updateCompanyById(req, res, callback);
};

/*
* Delete company details
*/
var deleteCompanyById = function(req, res, callback) {
	logger.info(MODULE_NAME + ' : controller : received request : deleteCompanyById : id : '+req.params.id);
	companyDao.deleteCompanyById(req, res, callback);
};

/*
* Get all experiences created under the given companyid
*/
var getExperiencesByCompanyId = function(req, res, callback) {
	logger.info(MODULE_NAME + ' : controller : received request : getExperiencesByCompanyId : id : '+req.params.id);
	experienceDao.getExperiencesByCompanyId(req, res, callback);
}

/*
* Get API Manager Config  by company id
*/
var getAPIManagerConfig = function(req, res, callback) {

	logger.info(MODULE_NAME + ' : controller : received request : getAPIManagerConfig : id : '+req.params.id);
	apimanagerDao.getAPIManagerConfig(req, res, callback);
};


/*
* 	Get  SMS Gateway   by company id
*/
var getSMSGateway = function(req, res, callback) {

	logger.info(MODULE_NAME + ' : controller : received request : getSMSGateway : id : '+req.params.id);
	smsgatewayDao.getSMSGateway(req, res, callback);
};

/*
* 	Get  SMTP Server by company id
*/
var getSmtpServers = function(req, res, callback) {

	logger.info(MODULE_NAME + ' : controller : received request : getSmtpServers : id : '+req.params.id);
	SMTPServerDao.getSMTPServersByCompanyId(req, res, callback);
};
/*
* 	Get  users by company id
*/
var getUsersByCompanyId = function(req, res, callback) {

	logger.info(MODULE_NAME + ' : controller : received request : getUsersByCompanyId : id : '+req.params.id);
	UserRegistrationDAO.getUsersByCompanyId(req, res, callback);
};

/*
**get vm details associated with companyId
*/
var getVMsByCompanyId = function(req, res, callback) {

	logger.info(MODULE_NAME + ' : controller : received request : getVMsByCompanyId : id : '+req.params.id);
	vmdetailsdao.getVMsByCompanyId(req, res, callback);
};

module.exports.addNewCompany = addNewCompany;
module.exports.getCompanyById = getCompanyById;
module.exports.getAllCompanies = getAllCompanies;
module.exports.updateCompanyById = updateCompanyById;
module.exports.deleteCompanyById = deleteCompanyById;
module.exports.getExperiencesByCompanyId = getExperiencesByCompanyId;
module.exports.getAPIManagerConfig = getAPIManagerConfig;
module.exports.getSMSGateway = getSMSGateway;
module.exports.getSmtpServers= getSmtpServers;
module.exports.getUsersByCompanyId= getUsersByCompanyId;
module.exports.getVMsByCompanyId= getVMsByCompanyId;
