var express = require('express');
var companyController = require('./controller/CompanyController');
var experiencesEnrolledController = require('../experiencesenrolled/controller/ExperiencesEnrolledController');
var logger = require('../common/logger').log;
var ErrorResponse = require('../common/ErrorResponse').ErrorResponse;
var router = express.Router();
var ResourceBundle = require('./../common/resource-bundle.js'),
PlatformError = require('../common/platform-error'),
rsBundle = new ResourceBundle(['./../radia-adapter/resource/lang/']);
const MODULE_NAME = 'company';

/*
* logging format followed: logger.info(<module_name>: <component name> : <description> : [<long_description>] : <data/params/errors>);
*/

/*
* Add new company details
*/
router.post('/', function(req, res) {
	logger.info(MODULE_NAME + ' : router : received request : addNewCompany : body : '+JSON.stringify(req.body));
	companyController.addNewCompany(req, res, function(err, data) {
		if(err) {

			if (err instanceof PlatformError) {
				logger.error(`An error occurred while creating company. Stack trace : \n ${JSON.stringify(err)}`);
				var error = new ErrorResponse(err.code, rsBundle.getMessage(err.code, err.args), err.httpCode);
				res.status(error.getHttpResponseCode()).json(error);
			} else {
				logger.error(MODULE_NAME + ' : router : failed addNewCompany : error : '+err);
				var error = new ErrorResponse();
				if(err.name == 'ValidationError'){
					error.setErrorMessage(err.errors[Object.keys(err.errors)[0]].message);
				} else {
					error.setErrorMessage(err.message);
				}
				error.setErrorCode("C0001");
				error.setHttpResponseCode(500);
				res.status(500).end(JSON.stringify(error));
			}
		} else {
			logger.info(MODULE_NAME + " : router : addNewCompany successful !");
			res.status(200).end(JSON.stringify(data));
		}
	});
});

/*
* Get company by company id
*/
router.get('/:id', function (req, res) {
	logger.info(MODULE_NAME + ' : router : received request : getCompanyById : id : '+req.params.id);
	companyController.getCompanyById(req, res, function(err, data) {
		if(err){
			logger.error(MODULE_NAME + ' : router : failed getCompanyById : error : '+err);
			var error = new ErrorResponse();
			error.setErrorCode("C0002");
			error.setErrorMessage(err.message);
			error.setHttpResponseCode(500);
			res.status(500).end(JSON.stringify(error));
		}else{
			logger.info(MODULE_NAME + " : router : getCompanyById successful !") ;
			res.status(200).end(JSON.stringify(data));
		}
	});
});

/*
* Get all companies
*/
router.get('/', function (req, res) {
	logger.info(MODULE_NAME + ' : router : received request : getAllCompanies : status : '
	+ req.query.status);
	companyController.getAllCompanies(req, res, function(err, data) {
		if(err){
			logger.error(MODULE_NAME + ' : router : failed getAllCompanies : error : '+err);
			var error = new ErrorResponse();
			error.setErrorCode("C0003");
			error.setErrorMessage(err.message);
			error.setHttpResponseCode(500);
			res.status(500).end(JSON.stringify(error));
		}else{
			logger.info(MODULE_NAME + " : router : getAllCompanies successful !");
			res.status(200).end(JSON.stringify(data));
		}
	});
});

/*
* Update company details
*/
router.put('/:id', function(req, res){
	logger.info(MODULE_NAME + ' : router : received request : updateCompanyById : (companyId: '+req.params.id+', body: '+JSON.stringify(req.body)+')');
	companyController.updateCompanyById(req, res, function(err, data) {
		if(err){
			logger.error(MODULE_NAME + ' : router : failed updateCompanyById : error : '+err);
			var error = new ErrorResponse();
			if(err.name == 'ValidationError'){
				error.setErrorMessage(err.errors[Object.keys(err.errors)[0]].message);
			} else {
				error.setErrorMessage(err.message);
			}
			error.setErrorCode("C0004");
			error.setHttpResponseCode(500);
			res.status(500).end(JSON.stringify(error));
		}else{
			logger.info(MODULE_NAME + " : router : updateCompanyById successful !");
			res.status(200).end(JSON.stringify(data));
		}
	});
});

/*
* Delete company details
*/
router.delete('/:id', function(req, res){
	logger.info(MODULE_NAME + ' : router : received request : deleteCompanyById : id : '+req.params.id);
	companyController.deleteCompanyById(req, res, function(err, data) {
		if(err){
			logger.error(MODULE_NAME + ' : router : failed deleteCompanyById : error : '+err);
			var error = new ErrorResponse();
			error.setErrorCode("C0005");
			error.setErrorMessage(err.message);
			error.setHttpResponseCode(500);
			res.status(500).end(JSON.stringify(error));
		}else{
			logger.info(MODULE_NAME + " : router : deleteCompanyById successful !");
			res.status(200).end(JSON.stringify(data));
		}
	});
});

/*
* Get ExperiencesEnrolled for given CompanyId
*/
router.get('/:id/experiencesenrolled', function (req, res) {
	logger.info(MODULE_NAME + ' : router : received request : getExperiencesEnrolledByComapnyId : Company Id : '+req.params.id);
	if(req.header('companyId') == null || req.params.id != req.header('companyId')){
		var error = new ErrorResponse();
		error.setErrorCode("C0006");
		error.setErrorMessage('Company Id not set');
		error.setHttpResponseCode(500);
		logger.error(MODULE_NAME + ' : router : failed getExperiencesEnrolledByComapnyId : error :'+JSON.stringify(error));
		res.status(500).end(JSON.stringify(error));
	} else {
		experiencesEnrolledController.getExperiencesEnrolledByComapnyId(req, res, function(err, data) {
			if(err){
				logger.error(MODULE_NAME + ' : router : failed getExperiencesEnrolledByComapnyId : error : '+err);
				var error = new ErrorResponse();
				error.setErrorCode("C0006");
				error.setErrorMessage(err.message);
				error.setHttpResponseCode(500);
				res.status(500).end(JSON.stringify(error));
			}else{
				logger.info(MODULE_NAME + " : router : getExperiencesEnrolledByComapnyId successful !");
				res.status(200).end(JSON.stringify(data));
			}
		});
	}
});

/*
* Get all experiences created under the given companyid
*/
router.get('/:id/experiences', function (req, res) {
	logger.info(MODULE_NAME + ' : router : received request : getExperiencesByCompanyId : id : '+req.params.id);
	if(req.header('companyId') == null || req.params.id != req.header('companyId')){
		var error = new ErrorResponse();
		error.setErrorCode("C0007");
		error.setErrorMessage('company id not set');
		error.setHttpResponseCode(500);
		logger.error(MODULE_NAME + ' : router : failed getExperiencesByCompanyId : error :'+JSON.stringify(error));
		res.status(500).end(JSON.stringify(error));
	} else {
		companyController.getExperiencesByCompanyId(req, res, function(err, data) {
			if(err){
				logger.error(MODULE_NAME + ' : router : failed getExperiencesByCompanyId : error : '+err);
				var error = new ErrorResponse();
				error.setErrorCode("C0007");
				error.setErrorMessage(err.message);
				error.setHttpResponseCode(500);
				res.status(500).end(JSON.stringify(error));
			}else{
				logger.info(MODULE_NAME + " : router : getExperiencesByCompanyId successful !");
				res.status(200).end(JSON.stringify(data));
			}
		});
	}
});


/*
* 	Get API Manager Config  by company id
*/
router.get('/:id/apimanager', function (req, res) {

	logger.info(MODULE_NAME + ' : router : received request : getAPIManagerConfig : id : '+req.params.id);
	companyController.getAPIManagerConfig(req, res, function(err, data) {
		if(err) {
			logger.error(MODULE_NAME + ' : router : failed getAPIManagerConfig : error : '+err);
			var error = new ErrorResponse();
			error.setErrorCode("C0008");
			error.setErrorMessage(err.message);
			error.setHttpResponseCode(500);
			res.status(500).end(JSON.stringify(error));
		} else {
			logger.info(MODULE_NAME + " : router :  getAPIManagerConfig successful !");
			res.status(200).end(JSON.stringify(data));
		}
	});
});

/*
* 	Get  SMS Gateway   by company id
*/
router.get('/:id(\\d+)/smsgateway', function (req, res) {
	logger.info(MODULE_NAME + ' : router : received request : getSMSGateway : id : '+req.params.id);
	companyController.getSMSGateway(req, res, function(err, data) {
		if(err){
			logger.error(MODULE_NAME + ' : router : failed getSMSGateway : error : '+err);
			var error = new ErrorResponse();
			error.setErrorCode("C0009");
			error.setErrorMessage(err.message);
			error.setHttpResponseCode(500);
			res.status(500).end(JSON.stringify(error));
		}else{

			logger.info(MODULE_NAME + " : router : getSMSGateway successful !");
			res.status(200).end(JSON.stringify(data));
		}
	});
});


/*
* 	Get  SMTP Server by company id
*/
router.get('/:id(\\d+)/smtpservers', function (req, res) {
	logger.info(MODULE_NAME + ' : router : received request : getSmtpServers : id : '+req.params.id);
	companyController.getSmtpServers(req, res, function(err, data) {
		if(err){
			logger.error(MODULE_NAME + ' : router : failed getSmtpServers : error : '+err);
			var error = new ErrorResponse();
			error.setErrorCode("C0010");
			error.setErrorMessage(err.message);
			error.setHttpResponseCode(500);
			res.status(500).end(JSON.stringify(error));
		}else{

			logger.info(MODULE_NAME + " : router : getSmtpServers successful !");
			res.status(200).end(JSON.stringify(data));
		}
	});
});

/*
* 	Get  users by company id
*/
router.get('/:id(\\d+)/users', function (req, res) {
	logger.info(MODULE_NAME + ' : router : received request : getUsersByCompanyId : id : '+req.params.id);
	companyController.getUsersByCompanyId(req, res, function(err, data) {
		if(err){
			logger.error(MODULE_NAME + ' : router : failed getUsersByCompanyId : error : '+err);
			var error = new ErrorResponse();
			error.setErrorCode("C0011");
			error.setErrorMessage(err.message);
			error.setHttpResponseCode(500);
			res.status(500).end(JSON.stringify(error));
		}else{

			logger.info(MODULE_NAME + " : router : getUsersByCompanyId successful !");
			res.status(200).end(JSON.stringify(data));
		}
	});
});

/*
* get vm details by companyId
*/
router.get('/:id/vms', function (req, res) {
	logger.info(MODULE_NAME + ' : router : received request : getVMsByCompanyId : id : '+req.params.id);
	companyController.getVMsByCompanyId(req, res, function(err, data) {
		if(err){
			logger.error(MODULE_NAME + ' : router : failed getVMsByCompanyId : error : '+err);
			var error = new ErrorResponse();
			error.setErrorCode("C0012");
			error.setErrorMessage(err.message);
			error.setHttpResponseCode(500);
			res.status(500).end(JSON.stringify(error));
		}else{
			logger.info(MODULE_NAME + " : router : getVMsByCompanyId successful !") ;
			res.status(200).end(JSON.stringify(data));
		}
	});
});

module.exports = router;
