var Company = require('../models/Company');
var AppGroup = require('../../appgroup/models/AppGroup');
var logger = require('../../common/logger').log;
var audit = require('../../common/Audit').audit;
var config = require('../../common/Config');
const MODULE_NAME = 'company';

/*
 * logging format followed: logger.info(<module_name>: <component name> : <description> : [<long_description>] : <data/params/errors>);
 */


/*
 * Add new company details
 */
var addNewCompany = function(req, res, callback) {
	logger.info(MODULE_NAME + ' : DAO : received request : addNewCompany : body : '
			+ JSON.stringify(req.body));
	var reqBody = req.body;
	var company = new Company();
	company.setCompanyName(reqBody.companyName);
	company.setCompanyAddress(reqBody.companyAddress);
	company.setCity(reqBody.city);
	company.setState(reqBody.state);
	company.setCountry(reqBody.country);
	company.setZipCode(reqBody.zipCode);
	company.setCompanyURL(reqBody.companyURL);
	company.setCompanyImageURL(reqBody.companyImageURL);
	company.setPhone(reqBody.phone);
	company.setFax(reqBody.fax);
	company.setEmail(reqBody.email);
	company.setAdminFullName(reqBody.adminFullName);
	company.setAdminMobile(reqBody.adminMobile);
	company.setAdminEmail(reqBody.adminEmail);
	company.setGamificationSharing(reqBody.gamificationSharing);
	company.setCreatedOn(new Date());
	company.setCreatedBy(reqBody.adminFullName);
	company.setUpdatedOn(new Date());
	company.setUpdatedBy(reqBody.adminFullName);

	company.save(function(err, data) {
		if (err) {
			logger.error(MODULE_NAME + ' : DAO : failed addNewCompany : error : ' + err);
			callback(err, null);
		} else if(data != null){
			logger.info(MODULE_NAME + ' : DAO : addNewCompany successful !');
			callback(null, data);
		} else {
			var err = new Error('Failed to add new company details');
			logger.error(MODULE_NAME + ' : DAO : failed addNewCompany : error : '+ err);
			callback(err, null);
		}
	});
};

/*
 * Get company details by CompanyId
*/
var getCompanyByOrgId = function(companyId, callback) {
	logger.info(`company : DAO : received request : getCompanyByOrgId : id : # ${companyId}`);
	Company.findOne({
		'companyId' : companyId
	}, function(err, data) {
		if (err) {
			logger.error(`company : DAO : failed getCompanyByOrgId : error : # ${err}`);
			callback(err, null);
		} else {
			if (data && data.length != 0) {				
				logger.info(`company : DAO : getCompanyByOrgId Successful ! `);
                callback(null,data);
			} else {
				var err = new Error('company id not exist');
				err.status = 404;
				logger.error(`company : DAO : failed getCompanyByOrgId : error : # ${err}`);
				callback(err, null);
			}
		}
	});
};



/*
 * Get company by company id
 */
var getCompanyById = function(req, res, callback) {
	logger.info(MODULE_NAME + ' : DAO : received request : getCompanyById : id : '+req.params.id);
	Company.find({
		'companyId' : req.params.id ,
		'lookupenabled': true
	}, function(err, data) {
		if (err) {
			logger.error(MODULE_NAME + ' : DAO : failed getCompanyById : error : ' + err);
			callback(err, null);
		} else {
			if (data.length != 0) {
				logger.info(MODULE_NAME + ' : DAO : getCompanyById successful !');
				callback(null, data[0]);
			} else {
				var err = new Error('company id not exist');
				err.status = 404;
				logger.error(MODULE_NAME + ' : DAO : failed getCompanyById : error : '+ err);
				callback(err, null);
			}
		}
	});
};

/*
 * Get all companies
 */
var getAllCompanies = function(req, res, callback) {
	logger.info(MODULE_NAME + ' : DAO : received request : getAllCompanies : status : '
			+ req.query.status);
	var obj = {
		$or: [
		      {parentCompanyId: {$exists: false }},
		      {parentCompanyId: {$in: ["", null]}}		      
		]
	};
	obj.lookupenabled= true ;
	if (Object.keys(req.query).length != 0) {
		var keys = Object.keys(req.query);
		for(var i=0; i < keys.length; i++) {
			if((keys[i] == 'status' || keys[i] == 'name') && req.query[keys[i]]) {
				var key = keys[i];
				if(keys[i] == 'name') {
					key = 'companyName';
				}
				obj[key] = new RegExp('^' + req.query[keys[i]].toLowerCase(), 'i');
			}
		}
		/*if (req.query.status) {
			obj.status = new RegExp('^' + req.query.status.toLowerCase() + '$',	'i');
			logger.info(MODULE_NAME + ' : DAO : getAllCompanies by status');
		}
		if (req.query.name) {
			obj.companyName = new RegExp('^' + req.query.name.toLowerCase(), 'i');
			logger.info(MODULE_NAME + ' : DAO : getAllCompanies by name');
		}*/
	}

	Company.find(obj, function(err, data) {
		if (err) {
			logger.error(MODULE_NAME + ' : DAO : failed getAllCompanies : error : ' + err);
			callback(err, null);
		} else {
			if (data.length != 0) {
				logger.info(MODULE_NAME + ' : DAO : getAllCompanies successful !');
				callback(null, data);
			} else {
				var err = new Error('No records found');
				err.status = 404;
				logger.error(MODULE_NAME + ' : DAO : failed getAllCompanies : error : ' + err);
				callback(err, null);
			}
		}
	});
};

/*
 * Update company details
 */
var updateCompanyById = function(req, res, callback) {
	logger.info(MODULE_NAME + ' : DAO : received request : updateCompanyById : (companyId: '+req.params.id+', body: '+JSON.stringify(req.body)+')');

	/*
	 * Callback function after getting original record to update with new values.
	 */
	var callbackUpdate = function(err, data) {
		if(err) {
			logger.error(MODULE_NAME + ' : DAO : failed updateCompanyById : error :' + err);
			callback(err);
		} else {
			/*
			 *	Compare updatable fields values in db with values in request body
			 *	Update only new values
			 */
			var company = data;
			var updatableFields = [
			                       "companyAddress", "companyURL", "companyImageURL", "phone", "fax",  "email", 
			                       "adminFullName",  "adminMobile", "adminEmail", "status", "adminMobileVerified", 
			                       "adminEmailVerified", "gamificationSharing"
			                      ];
			var json = {};
			var updatedData = [];
			var reqBodyKeys = Object.keys(req.body);
			for(var i = 0; i < reqBodyKeys.length; i++) {				
				if(updatableFields.indexOf(reqBodyKeys[i]) > -1 && company[reqBodyKeys[i]] != req.body[reqBodyKeys[i]]) {
					json[reqBodyKeys[i]] = req.body[reqBodyKeys[i]];
					var obj = {};
					obj.column = reqBodyKeys[i];
					obj.oldValue = company[reqBodyKeys[i]];
					obj.newValue = req.body[reqBodyKeys[i]];
					obj.identifier = 'Platform_company_'+req.params.id;
					obj.modifiedBy = 'admin';
					obj.modifiedOn = new Date();
					updatedData.push(obj);
				}
			}
			var updateDoc = false;
			if(Object.keys(json).length != 0) {
				updateDoc = true;
			}			
			if (updateDoc) {
				json.updatedOn = new Date();
				json.updatedBy = 'admin';
				logger.info('company : DAO : updateCompanyById : updating data : ' + JSON.stringify(json));
				Company.findOneAndUpdate({
					'companyId' : req.params.id
				}, json, {
					'new' : true				
				}, function(err, data) {
					if (err) {
						logger.error('company : DAO : failed updateCompanyById : error :' + err);
						callback(err, null);
					} else {
						if(data != null) {
							logger.info('company : DAO : updateCompanyById successful !');
							/*	audit updated values  */
							audit(req, res, updatedData);
							/*	Callback to send response to client  */
							callback(null, data);
						} else {
							var err = new Error('Failed to update');
							logger.error('company : DAO : failed updateCompanyById : error :' + err);
							callback(err, null);
						}
					}
				});
			} else {
				var err = new Error('no fields modified');
				logger.error('company : DAO : failed updateCompanyById : error :' + err);
				callback(err);
			}			
		}
	}

	/*
	 * Get the original record from db before update.
	 */
	getCompanyById(req, res, callbackUpdate);
};

/*
 * Delete company details
 */
var deleteCompanyById = function(req, res, callback) {
	logger.info(MODULE_NAME + ' : DAO : received request : deleteCompanyById : id : ' + req.params.id);
	var callbackDelete = function(err, data) {
		if(err) {
			logger.error(MODULE_NAME + ' : DAO : failed deleteCompanyById : error :' + err);
			callback(err, null);
		} else if(data != null) {
			var company = data;
			var updatedData = [];
			if(company.status != 'DELETED') {
					var json = {
						'status' : 'DELETED'
					};
					Company.findOneAndUpdate({
						'companyId' : req.params.id
					}, json, {
						'new' : true
					}, function(err, data) {
						if (err) {
							logger.error(MODULE_NAME + ' : DAO : failed deleteCompanyById : error :' + err);
							callback(err, null);
						} else if(data != null){
							logger.info(MODULE_NAME + ' : DAO : deleteCompanyById successful !');
							var obj = {};
							obj.column = 'status';
							obj.oldValue = company['status'];
							obj.newValue = data.status;
							obj.identifier = 'Platform_company_'+req.params.id;
							obj.modifiedBy = 'admin';
							obj.modifiedOn = new Date();
							updatedData.push(obj);
							/*
							 *	Call audit function for changed data
							 */
							audit(req, res, updatedData);
							/*
							 *	Call function to send response to client
							 */
							callback(null, data);
						} else {
							var err = new Error('Invalid compnay id');
							logger.error(MODULE_NAME + ' : DAO : failed deleteCompanyById : error :' + err);
							callback(err, null);
						}
					});
			} else {
				var err = new Error('Already deleted');
				logger.error(MODULE_NAME + ' : DAO : failed deleteCompanyById : error :' + err);
				callback(err, null);
			}
		} else {
			var err = new Error('Failed to get company details');
			logger.error(MODULE_NAME + ' : DAO : failed deleteCompanyById : error :' + err);
			callback(err, null)
		}
	}

	/*
	 * Get the original record from db before update.
	 */
	getCompanyById(req, res, callbackDelete);

};


/*
 * Add new company details for PlatformUser
 */
var addNewCompanyForPlatformUser = function(req, res, callback) {
	logger.info(MODULE_NAME + ' : DAO : received request : addNewCompanyForPlatformUser : body : '
			+ JSON.stringify(req.body));
	var reqBody = req.body;
	var company = new Company();
	
	company.setCompanyName(reqBody.companyName);
	company.setCompanyAddress("Hinjawadi");
	company.setCity("Pune");
	company.setState("Maharashtra");
	company.setCountry("India");
	company.setZipCode("411057");
	company.setCompanyURL("http://www.persistent.com");
	company.setCompanyImageURL("persistent.jpg");
	company.setPhone("123");
	company.setFax("123");
	company.setEmail("admin@persistent.co.in");
	company.setAdminFullName("admin");
	company.setAdminMobile("123");
	company.setAdminEmail("admin@persistent.co.in");
	//company.setGamificationSharing("");
	company.setCreatedOn(new Date());
	company.setCreatedBy(reqBody.username);
	company.setUpdatedOn(new Date());
	company.setUpdatedBy(reqBody.username);
	company.setParentCompanyId(config.COMPANY_ID);
	company.setLookupenabled(true);
	

	company.save(function(err, data) {
		if (err) {
			logger.error(MODULE_NAME + ' : DAO : failed addNewCompanyForPlatformUser : error : ' + err);
			callback(err, null);
		} else if(data != null){
			logger.info(MODULE_NAME + ' : DAO : addNewCompanyForPlatformUser successful !');
			callback(null, data);
		} else {
			var err = new Error('Failed to add new company details');
			logger.error(MODULE_NAME + ' : DAO : failed addNewCompanyForPlatformUser : error : '+ err);
			callback(err, null);
		}
	});
};


/*
 * Increment user count
 */
var incrementUserCounter = function(id) {
	Company.update({ 'companyId' : id }, { $inc: { userCount: +1 } }, function(err, data) {
		if (err) {
			logger.error(MODULE_NAME + ' : DAO : failed incrementUserCounter : error : ' + err);			
		} else if(data){
			logger.info(MODULE_NAME + ' : DAO : incrementUserCounter successful !');			
		} else {
			var err = new Error('failed to update');
			logger.error(MODULE_NAME + ' : DAO : failed incrementUserCounter : error : ' + err);			
		}				
	});
}

/*
 * decrement user count
 */
var decrementUserCounter = function(id) {
	Company.update({ 'companyId' : id }, { $inc: { userCount: -1 } }, function(err, data) {
		if (err) {
			logger.error(MODULE_NAME + ' : DAO : failed decrementUserCounter : error : ' + err);			
		} else if(data){
			logger.info(MODULE_NAME + ' : DAO : decrementUserCounter successful !');			
		} else {
			var err = new Error('failed to update');
			logger.error(MODULE_NAME + ' : DAO : failed decrementUserCounter : error : ' + err);			
		}				
	});
}

/*
 * Increment provision count
 */
var incrementProvisionCounter = function(id) {
	Company.update({ 'companyId' : id }, { $inc: { provisionCount: +1 } }, function(err, data) {
		if (err) {
			logger.error(MODULE_NAME + ' : DAO : failed incrementprovisionCounter : error : ' + err);			
		} else if(data){
			logger.info(MODULE_NAME + ' : DAO : incrementprovisionCounter successful !');			
		} else {
			var err = new Error('failed to update');
			logger.error(MODULE_NAME + ' : DAO : failed incrementprovisionCounter : error : ' + err);			
		}				
	});
}

/*
 * Decrement provision count
 */
var decrementProvisionCounter = function(id) {
	Company.update({ 'companyId' : id }, { $inc: { provisionCount: -1 } }, function(err, data) {
		if (err) {
			logger.error(MODULE_NAME + ' : DAO : failed decrementProvisionCounter : error : ' + err);			
		} else if(data){
			logger.info(MODULE_NAME + ' : DAO : decrementProvisionCounter successful !');			
		} else {
			var err = new Error('failed to update');
			logger.error(MODULE_NAME + ' : DAO : failed decrementProvisionCounter : error : ' + err);			
		}				
	});
}

/*
 * Increment vm count
 */
var incrementVmCounter = function(id) {	
	Company.update({ 'companyId' : id }, { $inc: { vmCount: +1 } }, function(err, data) {
		if (err) {
			logger.error(MODULE_NAME + ' : DAO : failed incrementVmCounter : error : ' + err);			
		} else if(data){
			logger.info(MODULE_NAME + ' : DAO : incrementVmCounter successful !');			
		} else {
			var err = new Error('failed to update');
			logger.error(MODULE_NAME + ' : DAO : failed incrementVmCounter : error : ' + err);			
		}				
	});
}

/*
 * Decrement vm count
 */
var decrementVmCounter = function(id) {
	Company.update({ 'companyId' : id }, { $inc: { vmCount: -1 } }, function(err, data) {
		if (err) {
			logger.error(MODULE_NAME + ' : DAO : failed decrementVmCounter : error : ' + err);			
		} else if(data){
			logger.info(MODULE_NAME + ' : DAO : decrementVmCounter successful !');			
		} else {
			var err = new Error('failed to update');
			logger.error(MODULE_NAME + ' : DAO : failed decrementVmCounter : error : ' + err);			
		}				
	});
}
module.exports.addNewCompany = addNewCompany;
module.exports.getCompanyById = getCompanyById;
module.exports.getAllCompanies = getAllCompanies;
module.exports.updateCompanyById = updateCompanyById;
module.exports.deleteCompanyById = deleteCompanyById;
module.exports.getCompanyByOrgId=getCompanyByOrgId;
module.exports.addNewCompanyForPlatformUser= addNewCompanyForPlatformUser;
module.exports.incrementUserCounter= incrementUserCounter;
module.exports.decrementUserCounter= decrementUserCounter;
module.exports.incrementProvisionCounter= incrementProvisionCounter;
module.exports.decrementProvisionCounter= decrementProvisionCounter;
module.exports.incrementVmCounter= incrementVmCounter;
module.exports.decrementVmCounter= decrementVmCounter;
