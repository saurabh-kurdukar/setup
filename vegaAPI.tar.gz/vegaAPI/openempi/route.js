var express = require('express');
var openEmpiController = require('./controller/OpenEmpiController');
var logger = require('../common/logger').log;
var ErrorResponse = require('../common/ErrorResponse').ErrorResponse;
var router = express.Router();

/*
 * logging format followed: logger.info(<module_name>: <component name> : <description> : [<long_description>] : <data/params/errors>);
 */

/*
 * Authenticate
 */
router.put('/', function(req, res) {
	logger.info('OpenEmpi : router : received request : authenticate : query : ' + JSON.stringify(req.query));
	openEmpiController.authenticate(req, res, function(err, data) {
		if(err) {
			logger.error('OpenEmpi : router : failed authenticate : error : '+err);
			var error = new ErrorResponse();
			if(err.name == 'ValidationError'){
				error.setErrorMessage(err.errors[Object.keys(err.errors)[0]].message);
			} else {
				error.setErrorMessage(err.message);
			}
			error.setErrorCode("OE0001");
			var errorStatus = 500;
			if(err.status) {
				errorStatus = err.status;
			}
			error.setHttpResponseCode(errorStatus);
			res.status(errorStatus).end(JSON.stringify(error));
		}
		else {
			logger.info('OpenEmpi : router : authenticate successful !');
			res.status(200).end(JSON.stringify(data));
		}
	});
});

/*
 * Get persons by attributes
 */
router.post('/', function(req, res) {
	logger.info('OpenEmpi : router : received request : getPersonsByAttributes');
	openEmpiController.getPersonsByAttributes(req, res, function(err, data) {
		if(err) {
			logger.error('OpenEmpi : router : failed getPersonsByAttributes : error : ' + err);
			var error = new ErrorResponse();
			error.setErrorCode("OE0002");
			error.setErrorMessage(err.message);
			var errorStatus = 500;
			if(err.status) {
				errorStatus = err.status;
			}
			error.setHttpResponseCode(errorStatus);
			res.status(errorStatus).end(JSON.stringify(error));
		}
		else {
			logger.info('OpenEmpi : router : getPersonsByAttributes successful!');
			res.status(200).end(JSON.stringify(data));
		}
	})
})

module.exports = router;
