var logger = require('../../common/logger').log;
var fs = require('fs');
var request = require('request');

/*
 * logging format followed: logger.info(<module_name>: <component name> : <description> : [<long_description>] : <data/params/errors>);
 */


/*
 * Authenticate
 */
var authenticate = function(req, res, callback) {
	logger.info('OpenEmpi : controller : received request : authenticate : query : ' + JSON.stringify(req.query));
	if(req.query.username && req.query.password) {
		var requestBody = "<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?><authenticationRequest><password>"
												+ req.query.password + "</password><username>"
												+ req.query.username + "</username></authenticationRequest>";
		var requestObj = {
			method: 'PUT',
			url: 'http://vegahcare.cloudapp.net:8080/openempi-entity-webapp-web-3.1.0/openempi-ws-rest/security-resource/authenticate',
			body: requestBody,
			headers: {
				'content-type': 'application/xml',
				'cache-control': 'no-cache'
			}
		}

		request(requestObj, function(error, response, body) {
			if(error) {
				logger.error('OpenEmpi : controller : failed to authenticate : error : ' + error);
				callback(error, null);
			}
			else {
				logger.error('OpenEmpi : controller : authenticate successful!');
				callback(null, body);
			}
		})
	}
	else {
		logger.error('OpenEmpi : controller : failed to authenticate : error : Required query params not found');
		var error = new Error('Required query params not found');
		callback(error, null);
	}
};

/*
 * Get persons by attributes
 */
var getPersonsByAttributes = function(req, res, callback) {
	logger.info('OpenEmpi : controller : received request : getPersonsByAttributes : query : ' + JSON.stringify(req.query));
	if(req.query.firstname && req.query.lastname) {
		var requestBody = "<person><familyName>" + req.query.lastname + "</familyName><givenName>" + req.query.firstname + "</givenName></person>";
		var requestObj = {
			method: 'POST',
			url: 'http://vegahcare.cloudapp.net:8080/openempi-entity-webapp-web-3.1.0/openempi-ws-rest/person-query-resource/findPersonsByAttributes',
			body: requestBody,
			headers: {
				'openempi_session_key': req.headers['openempi_session_key'],
				'content-type': 'application/xml',
				'cache-control': 'no-cache'
			}
		}

		request(requestObj, function(error, response, body) {
			if(error) {
				logger.error('OpenEmpi : controller : failed getPersonsByAttributes : error : ' + error);
				callback(error, null);
			}
			else {
				logger.error('OpenEmpi : controller : getPersonsByAttributes successful!');
				console.log(typeof body);
				callback(null, body);
			}
		})
	}
	else {
		logger.error('OpenEmpi : controller : failed getPersonsByAttributes : error : Required query params not found');
		var error = new Error('Required query params not found');
		callback(error, null);
	}
}


module.exports.authenticate = authenticate;
module.exports.getPersonsByAttributes = getPersonsByAttributes;
