var amqp = require('amqplib/callback_api');
var RabbitMQ = require('../../common/RabbitMQ');
var auditsDao = require('../dao/AuditsDao');
var AuditMessage = require('../listeners/AuditsMessaging').AuditMessage;
var logger = require('../../common/logger').log;
var appConfig = require('../../common/Config');


var prepareAuditMessage = function(reqBodyDel){	
	var auditMessage = new AuditMessage();
	auditMessage.setIdentifier(reqBodyDel.identifier);
	auditMessage.setColumn(reqBodyDel.column);
	if (!(typeof reqBodyDel.oldValue !== "undefined" && reqBodyDel.oldValue !== null)){
		auditMessage.setOldValue('new record');
	}
	auditMessage.setOldValue(reqBodyDel.oldValue);
	auditMessage.setNewValue(reqBodyDel.newValue);
	auditMessage.setModifiedBy(reqBodyDel.modifiedBy);
	
	return auditMessage;
};


var validateAuditMessage = function(reqBodyDel){
	// Update Validation Check START
	var validationError = null;
	
	if(reqBodyDel.column.length <= 0 || reqBodyDel.column.length > 100) {
		logger.error('AUDIT-COLUMN validation error!!!');
		validationError = new Error('AUDIT-COLUMN Data not valid');
	}
	if (typeof reqBodyDel.oldValue !== "undefined" && reqBodyDel.oldValue !== null){
		if(reqBodyDel.oldValue.length <= 0 || reqBodyDel.oldValue.length > 255) {
			logger.error('AUDIT-OLDVALUE validation error!!!');
			validationError = new Error('AUDIT-OLDVALUE Data not valid');
		}
	}else{
		reqBodyDel.oldValue = 'new record';
	}
	
	if(reqBodyDel.newValue.length <= 0 || reqBodyDel.newValue.length > 255) {
		logger.error('AUDIT-NEWVALUE validation error!!!');
		validationError = new Error('AUDIT-NEWVALUE Data not valid');
	}
	if(reqBodyDel.modifiedBy.length <= 0 || reqBodyDel.modifiedBy.length > 100) {
		logger.error('AUDIT-MODIFIEDBY validation error!!!');
		validationError = new Error('AUDIT-MODIFIEDBY Data not valid');
	}
	// Update Validation Check END
	return validationError;
};

var sendMessage = function(req, res, callback) {	
	var validationErr = validateAuditMessage(req.body);
	
	if (validationErr){
		logger.error('AUDIT_Delegate - POST Audit record Validation failed, error: ' + validationErr);
		callback(validationErr, null);
	}else{
		var auditPostDbDirect = appConfig.audit_post_db_direct;
		
		if(auditPostDbDirect){
			// Save Audit message into DB directly
			auditsDao.postAudits( prepareAuditMessage(req.body), callback);
		}
		else{
			// Put Audit message in Queue
			sendMessageToQueue(req, res, callback);
		}
	}
};

var saveAuditMessageDirect = function(auditMessageDel, callback) {	
	auditsDao.postAudits(prepareAuditMessage(auditMessageDel), callback);
};

/*
 * send Audit Message To Queue
 */

var sendMessageToQueue = function(req, res, callback) {
	logger.info('AUDIT Message DELEGATE : received request : Body : '+ JSON.stringify(req.body));

	RabbitMQ.getConnection(function(connection) {
		
		var requestBodyDel = req.body;
		
		if(connection == null){
			// Directly save Audit Message to Database
			saveAuditMessageDirect(requestBodyDel, callback);
		}else{
			connection.createChannel(function(err, channel) {			
				if (err != null){
					logger.error("Error occurred while creating Channel :"+err);
					// Directly save Audit Message to Database
					saveAuditMessageDirect(requestBodyDel, callback);
				}
				else{		
					var exchangeName = appConfig.AUDITS_MESSAGE_EXCHANGE_PRIMARY;
					var queueName = appConfig.AUDITS_MESSAGE_QUEUE_PRIMARY;
					var routingKey = appConfig.AUDITS_MESSAGE_ROUTING_KEY;
					var exchangeType = appConfig.AUDITS_MESSAGE_EXCHANGE_TYPE;
					
					var messageOptions = {
						arguments: {
							'x-retry-count' : 0
						}
					};

					
					channel.assertExchange(exchangeName, exchangeType, {durable: true}, function(err, ok){
						if (err != null){
							logger.error("Error occurred while Asserting Exchange :"+err);
							// Directly save Audit Message to Database
							saveAuditMessageDirect(requestBodyDel, callback);
						}
						else{
							channel.assertQueue(queueName, { durable : true }, function(err, ok) {
								if (err != null){
									logger.error("Error occurred while Asserting Queue :"+err);
									// Directly save Audit Message to Database
									saveAuditMessageDirect(requestBodyDel, callback);
								}
								else{
									channel.bindQueue(queueName, exchangeName, routingKey);
									channel.sendToQueue(queueName, new Buffer(JSON.stringify(requestBodyDel)), messageOptions);
									logger.info("Audit Message Queued Successfully :"+ JSON.stringify(requestBodyDel));
									callback(err, JSON.parse('{"result": "success"}'));
									setTimeout(function() {
										connection.close();
									}, 500);
								}
							});
						}

					});
				}
				
			});
		}
				
	});
	
};

module.exports.sendMessage = sendMessage;