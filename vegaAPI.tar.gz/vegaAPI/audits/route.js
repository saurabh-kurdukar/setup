var express = require('express');
var auditsController = require('./controller/AuditsController');
var logger = require('../common/logger').log;
var ErrorResponse = require('../common/ErrorResponse').ErrorResponse;


var router = express.Router();

/*
* 	Define POST route for INSERT / UPDATE records
*/
router.post('/', function(req, res) {

	if(JSON.stringify(req.body) != "{}"){
		auditsController.postAudits(req, res, function(err, data) {
	        if(err){
	        	logger.error("AUDIT POST Request fails to update/insert AUDIT Data: "+err);
	        	var error = new ErrorResponse();
	        	if(err.name == 'ValidationError'){
	        		error.setErrorMessage(err.errors[Object.keys(err.errors)[0]].message);
	        		error.setErrorCode("AL0001");
					error.setHttpResponseCode(400);
					res.status(400).end(JSON.stringify(error));
	        	} else {
	        		error.setErrorMessage(err.message);
	        		error.setErrorCode("AL0003");
					error.setHttpResponseCode(500);
					res.status(500).end(JSON.stringify(error));
	        	}
	        }else{
	        	logger.info("AUDIT POST returns successfully!!!");
	        	res.status(200).end(JSON.stringify(data));
	        }
	    });
	}else{
		var error = new ErrorResponse();
		error.setErrorMessage("Empty Request Body Found!!!");
		error.setErrorCode("AL0001");
		error.setHttpResponseCode(400);      	
		res.status(400).end(JSON.stringify(error));
	}

});


/*
*	Define GET route for SEARCH with Identifier
*/
router.get('/:identifier', function(req, res) {
	auditsController.getAuditsByIdentifier(req, res, function(err, data) {
        if(err){
        	logger.error("AUDIT GET fails to retrieve AUDIT Data: "+err);
        	var error = new ErrorResponse();
        	error.setErrorMessage(err.message);
			error.setErrorCode("AL0003");
			error.setHttpResponseCode(500);
			res.status(500).end(JSON.stringify(error));
        }else{
        	logger.info("AUDIT GET By Identifier returns successfully!!!");
        	res.status(200).end(JSON.stringify(data));
        }
    });
});

/*
 * Options for AUDIT APIs
 */
router.options('/', function(req, res) {
	logger.info('AUDIT_Router : received request : Options call appgroups APIs');
	res.header('Allow-Access-Allow-Origin', '*');
	res.header('Access-Control-Allow-Headers', '*');
	res.header('Access-Control-Allow-Methods', 'GET, POST, OPTIONS');
	res.header('Connection', 'keep-alive');
	res.header('Content-Type', 'application/json;charset=UTF-8');
	res.end();
	logger.info('appgroup : router : Options call appgroups APIs processed !');
});

/*
 * All for AUDIT APIs
 */
router.all('/*', function(req, res) {
	logger.error('AUDIT_Router: No matching resource for URL : ' + req.originalUrl);
	var error = new ErrorResponse();
	error.setErrorCode("AL0002");
	error.setErrorMessage('No matching resource for URL: ' + req.originalUrl);
	error.setHttpResponseCode(404);
	res.status(404).send(JSON.stringify(error));
});


module.exports = router;