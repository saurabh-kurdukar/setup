var mongoose = require('../../common/MongoDbConnection').mongoose;

var logger = require('../../common/logger').log;

// Define Schema

var Schema = mongoose.Schema;

var Audits = new Schema({
    column    		: { type: String },
    oldValue  		: { type: String },
    newValue  		: { type: String },
	modifiedBy  	: { type: String },
    modifiedOn  	: { type: Date, default: Date.now }
});

var Audit_Records = new Schema({
   identifier 	: { type: String },
   createdOn	: { type: Date, default: Date.now },
   audits  		: [Audits]
});


logger.info('AUDIT_Model created schema : '+JSON.stringify(Audit_Records.paths));

Audit_Records.pre('update', function(next) {
	  this.options.runValidators = true;
	  next();
});

Audits.path('column').validate(function (v) {
	  return (v.length > 0 && v.length <= 100);
}, 'data length not suitable for field column'); 

Audits.path('oldValue').validate(function (v) {
	  return (v.length > 0 && v.length <= 255);
}, 'data length not suitable for field oldValue');

Audits.path('newValue').validate(function (v) {
	  return (v.length > 0 && v.length <= 255);
}, 'data length not suitable for field newValue'); 

Audits.path('modifiedBy').validate(function (v) {
	  return (v.length > 0 && v.length <= 100);
}, 'data length not suitable for field modifiedBy');

Audit_Records.path('identifier').validate(function (v) {
		logger.info("V length"+v.length);
	  return (v.length > 0 && v.length <= 120);
}, 'data length not suitable for field identifier');


// Setter and Getter

Audits.methods.setColumn = function(column) {
	this.column = column;
};

Audits.methods.getColumn = function() {
	return this.column;
};

Audits.methods.setOldValue = function(oldValue) {
	this.oldValue = oldValue;
};

Audits.methods.getOldValue = function() {
	return this.oldValue;
};

Audits.methods.setNewValue = function(newValue) {
	this.newValue = newValue;
};

Audits.methods.getNewValue = function() {
	return this.newValue;
};

Audits.methods.setModifiedBy = function(modifiedBy) {
	this.modifiedBy = modifiedBy;
};

Audits.methods.getModifiedBy = function() {
	return this.modifiedBy;
};

Audits.methods.setModifiedOn = function(modifiedOn) {
	this.modifiedOn = modifiedOn;
};

Audits.methods.getModifiedOn = function() {
	return this.modifiedOn;
};

Audit_Records.methods.setIdentifier = function(identifier) {
	this.identifier = identifier;
};

Audit_Records.methods.getIdentifier = function() {
	return this.identifier;
};

Audit_Records.methods.setCreatedOn = function(createdOn) {
	this.createdOn = createdOn;
};

Audit_Records.methods.getCreatedOn = function() {
	return this.createdOn;
};

var Audit_Record = mongoose.model('Audit_Records', Audit_Records);

module.exports = Audit_Record;