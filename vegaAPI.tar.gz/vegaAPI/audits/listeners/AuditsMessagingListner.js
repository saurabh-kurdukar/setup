var amqp = require('amqplib/callback_api');
var RabbitMQ = require('../../common/RabbitMQ');
var auditsDao = require('../dao/AuditsDao');
var logger = require('../../common/logger').log;
var AuditMessage = require('../listeners/AuditsMessaging').AuditMessage;
var appConfig = require('../../common/Config');

var reqAuditMessage = function(auditMessageJsonContent) {

	var auditMessageJSObject = JSON.parse(auditMessageJsonContent);

	var auditMessage = new AuditMessage();
	auditMessage.setIdentifier(auditMessageJSObject.identifier);
	auditMessage.setColumn(auditMessageJSObject.column);
	auditMessage.setOldValue(auditMessageJSObject.oldValue);
	auditMessage.setNewValue(auditMessageJSObject.newValue);
	auditMessage.setModifiedBy(auditMessageJSObject.modifiedBy);

	return auditMessage;
};

/*
 * Receive Audit Message From Queue and store into MongoDB
 */

RabbitMQ.getConnection(function(connection) {

	if (connection == null) {
		// Connection to RabbitMQ fails
		logger.error("Audit Listner Connection fails!!!");
	} else {
		connection.createChannel(function(err, channel) {
			if (err != null) {
				logger.error("Error occurred while creating Channel :"+ err);
			} else {
				var exchangeName = appConfig.AUDITS_MESSAGE_EXCHANGE_PRIMARY;
				var queueName = appConfig.AUDITS_MESSAGE_QUEUE_PRIMARY;
				var routingKey = appConfig.AUDITS_MESSAGE_ROUTING_KEY;
				var exchangeType = appConfig.AUDITS_MESSAGE_EXCHANGE_TYPE;
				var dlxExchangeName = appConfig.AUDITS_MESSAGE_EXCHANGE_DLX;
				var dlxQueueName = appConfig.AUDITS_MESSAGE_QUEUE_DLX;
				var dlxRoutingKey = appConfig.AUDITS_MESSAGE_ROUTING_KEY_DLX;
				var maxRetryCount = appConfig.AUDITS_MESSAGE_MAX_RETRY_COUNT; 
			
				/*channel.assertExchange(dlxExchangeName, exchangeType, {durable : true}, function(waitExchange) {
					var waitQueueOptions = { arguments : {"x-dead-letter-exchange" : exchangeName} };

					channel.assertQueue(dlxQueueName, waitQueueOptions, function(waitQueue) {
						channel.bindQueue(dlxQueueName, dlxExchangeName, routingKey);
					});
				}); // wait exchange
*/				
				channel.assertExchange(exchangeName, exchangeType, {durable: true}, function(err, ok){
					if (err != null){
						logger.error("Error occurred while Asserting Exchange in Audit Lister :"+err);
					}
					else{
						channel.assertQueue(queueName, { durable : true }, function(err, ok) {
							if (err != null){
								logger.error("Error occurred while Asserting Queue in Audit Listner :"+err);
							}
							else{
								channel.bindQueue(queueName, exchangeName, routingKey);
								
							//	var consumerOptions = {ack : true};
								channel.consume(queueName, function(auditMessageJson){
									
									logger.info(" Consumming Audit Message to save into database : "+ auditMessageJson.content.toString());
									console.log("Consume msg :" + JSON.stringify(auditMessageJson));
									if (auditMessageJson.content.toString() != "{}") {
										logger.info(" Received for saving %s",auditMessageJson.content.toString());
										
										// Save AuditMessage into Database
										auditsDao.postAudits( reqAuditMessage(auditMessageJson.content), function(err, data) {
											if (err) {
												logger.error('Audit Message LISTENER : failed, error : '+ err);
												
												// Retry 3 times for failure and if still fails, move the message to Dead-letter-exchange
												var retryCount = auditMessageJson.properties.headers["x-retry-count"] || 0;
												console.log("Retry count :"+retryCount);
												
												var delTagCount = auditMessageJson.fields.deliveryTag;
												
												if(delTagCount++ <= maxRetryCount){
													// Update Retry count : not working, need to verify
													auditMessageJson.properties.headers = {"x-retry-count": ++retryCount};
													// Requeue message
													channel.nack(auditMessageJson);
												}
												else{
													logger.error("Exhausted max retries on the message:", auditMessageJson.content.toString());
													
													// Queue the message in Dead-Letter-Exchange													
													var headers = auditMessageJson.properties.headers;
											/*
													var expiration;
													if (headers["x-death"]) {
														expiration = (headers["x-death"][0]["original-expiration"] * 3);
													} else {
														expiration = 10000;
													}
													
													var retryMsgOptions = {
															'headers' : {"x-retry-count": retryCount},
															'expiration' : expiration
													};
											*/
													
													//channel.nack(auditMessageJson, false, false);
													
													// Acknowledge message on Primary Queue to remove it from queue
													channel.ack(auditMessageJson);
													
													channel.assertExchange(dlxExchangeName, exchangeType, {durable: true});
													channel.assertQueue(dlxQueueName, { durable : true });
													channel.bindQueue(dlxQueueName, dlxExchangeName, dlxRoutingKey);
													channel.sendToQueue(dlxQueueName, new Buffer(auditMessageJson.content.toString()));
												}
											} else {
												logger.info('AUDIT_Messaging Listner, Message saved into Database : Successful !');
												channel.ack(auditMessageJson);
											}
										});
									} else {
										console.log("No Valid Message in queue to process!!!");
									}
								});
								
							}
						});
					}

				});

			}
			
		});
	}

});