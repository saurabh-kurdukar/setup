var AuditMessage = function() {
	
	var identifier;
	var column;
	var oldValue;
	var newValue;
	var modifiedBy;

	// Setter and Getter

	this.setIdentifier = function(identifier) {
		this.identifier = identifier;
	};

	this.getIdentifier = function() {
		return this.identifier;
	};

	this.setColumn = function(column) {
		this.column = column;
	};

	this.getColumn = function() {
		return this.column;
	};

	this.setOldValue = function(oldValue) {
		this.oldValue = oldValue;
	};

	this.getOldValue = function() {
		return this.oldValue;
	};

	this.setNewValue = function(newValue) {
		this.newValue = newValue;
	};

	this.getNewValue = function() {
		return this.newValue;
	};

	this.setModifiedBy = function(modifiedBy) {
		this.modifiedBy = modifiedBy;
	};

	this.getModifiedBy = function() {
		return this.modifiedBy;
	};

};

module.exports.AuditMessage = AuditMessage;