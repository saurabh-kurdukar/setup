var db = require('../../common/MongoDbConnection');
var Audit_Record = require('../model/audits');
var logger = require('../../common/logger').log;
/*
 *	INSERT / UPDATE AUDIT DATA
 */
var postAudits = function(reqAuditMessage, callback) {
	
	var auditMessage = reqAuditMessage;
	logger.info(auditMessage.toString());
		
	var audit_identifier = auditMessage.getIdentifier();
	
	var audit_record_append = {
		column    		: auditMessage.getColumn(),
		oldValue  		: auditMessage.getOldValue(),
		newValue  		: auditMessage.getNewValue(),
		modifiedBy  	: auditMessage.getModifiedBy()
	};
	
	// Check whether "Identifier" exists using findOne() which will return Object including "projection" if exists else null
	Audit_Record.findOne({identifier: audit_identifier}, {identifier: audit_identifier}, function(err, objectWithProjection) {
		if (err) {
			logger.error('AUDIT_DAO - POST search for Identifier failed, error: ' + err);
			callback(err, objectWithProjection);
		}else{
			logger.info("AUDIT_DAO - POST search for Identifier Successful!!!");
			if(null != objectWithProjection && objectWithProjection.identifier == audit_identifier){				
				var conditions = {identifier: audit_identifier};
				var update = {$push: { audits: audit_record_append }};
				
				var options = { multi: false, upsert : false };
				var callbackUpdate = function (err, num) {
					//handle errors
					if (err){
						logger.error('AUDIT_DAO - POST Audit record update failed, error: ' + err);
						callback(err, num);
					}else{
						logger.info("AUDIT_DAO - POST Audit record update Successful!!!");
						callback(null, JSON.parse('{"result": "success"}'));
					}
				};

				Audit_Record.update(conditions, update, options, callbackUpdate);
			}
			else{				
				var newAuditRecordInstance = new Object();
				newAuditRecordInstance.identifier = audit_identifier;
				newAuditRecordInstance.createdOn = new Date();
				newAuditRecordInstance.audits = [audit_record_append];
				Audit_Record.create(newAuditRecordInstance, function(err, data){
					if (err) {
						logger.error('AUDIT_DAO - POST New Audit record Insert, error: ' + err);
						callback(err, data);
					} else{
						logger.info("AUDIT_DAO - POST New Insert Successful!!!");
						callback(null, JSON.parse('{"result": "success"}'));
					}
				});
			}
	
		}
	});	

};

/*
 *	 GET AUDIT DATA by Identifier
 */
var getAuditsByIdentifier = function(req, res, callback) {
	// get Audit Records for IDENTIFIER
	Audit_Record.find({identifier: req.params.identifier}, function(err, auditRecords) {
		if (err){
			logger.error('AUDIT_DAO : failed, error: ' + err);
			callback(err, auditRecords);
		}else{
			logger.info("AUDIT_DAO Get request Successful!!!");
			callback(null, auditRecords);
		}
	});
	
};

module.exports.postAudits = postAudits;
module.exports.getAuditsByIdentifier = getAuditsByIdentifier;