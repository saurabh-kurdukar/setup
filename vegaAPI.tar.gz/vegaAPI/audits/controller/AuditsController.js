var auditsMessagingDelegate = require('../delegate/AuditsMessagingDelegate');
var auditsDao = require('../dao/AuditsDao');
var logger = require('../../common/logger').log;
/*

/*
 *	INSERT / UPDATE AUDIT DATA
 */
var postAudits = function(req, res, callback) {
	
	logger.info('message : controller : received request : sendAuditMessage : body : '+JSON.stringify(req.body));
	auditsMessagingDelegate.sendMessage(req, res, callback);
};

/*
 *	 GET AUDIT DATA by Identifier
 */
var getAuditsByIdentifier = function(req, res, callback) {
	auditsDao.getAuditsByIdentifier(req, res, callback);
};


module.exports.postAudits = postAudits;
module.exports.getAuditsByIdentifier = getAuditsByIdentifier;