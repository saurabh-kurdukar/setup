'use strict';

var logger = require('./../common/logger').log
.child({module : 'Radia', type : 'Adapter'}),
async = require('async'),
config = require('./../common/Config'),
PlatformError = require('./../common/platform-error'),
UserCredential = require('./dto/user-credential'),
UserGroup = require('./dto/user-group'),
User = require('./dto/user'),
UserGroupAssociation = require('./dto/user-group-assoc'),
Application = require('./dto/application'),
GroupApplicationAssociation = require('./dto/group-application-assoc'),
request = require('request'),
dao = require('../provision/dao/provision-experience-dao'),
experienceDao = require('../experience/dao/ExperienceDAO'),
util = require('util'),
fs = require('fs');
var MandatoryGroupApplicationAssociation = require('./dto/mandatory-user-group-assoc');

const FORM_DATA = 'form',
MULTIPART_FORM = 'multipart',
APPLICATION_JSON = 'json';

function sendRequestToRadia(httpMethod, relativeUrl, cookie, dataType, content, cb) {

	var requestOptions = {
//			proxy:config.NETWORK_PROXY+":"+config.NETWORK_PROXY_PORT ,
			method: httpMethod,
			url: `${config.RADIA_BASE_URL}${relativeUrl}`,
			jar: cookie
	};

	if(dataType === FORM_DATA) {
		requestOptions.form = content;
	} else if(dataType === APPLICATION_JSON) {
		requestOptions.json = true;
		requestOptions.body = content;
	} else if(dataType === MULTIPART_FORM) {
		requestOptions.formData = content;
	}

	request(requestOptions, function (err, res, body) {
		cb(err, res, body);
	});
}

function login(requestObject, cb) {
	var cookie = request.jar();

	var processResponse = function (err, res, body) {

		if (err) {
			console.log('login err: '+err);
			logger.debug(`Failed to login Radia`, err);
			cb(new PlatformError('RDIA001', [], 500, err));
		} else if(res.statusCode === 200 && body) {
			cb(new PlatformError('RDIA002', [], 500, body));
		} else if (res.statusCode === 200 || res.statusCode === 302 || res.statusCode === 405) {

			requestObject.cookie = cookie;
			cb(null, requestObject);
		} else {
			cb(new PlatformError('RDIA001', [], 500, body));
		}
	};

	sendRequestToRadia(
			'post',
			'/tenant/j_security_check',
			cookie,
			FORM_DATA,
			new UserCredential(config.RADIA.ADMIN_USERNAME, config.RADIA.ADMIN_PASSWORD),
			processResponse
	);
}

// Comment below function to allow ipa provisioning flow
function provisionApplication(provisionRequest, application, cb) {

	logger.debug(`Request # ${provisionRequest.id} : Provision application : ${application.name} to radia.`);

	// to ensure each upload is delayed by around 30 seconds
	setTimeout(function() {
		var processResponse = function (err, res, body) {
			if (err) {
				cb(new PlatformError('RDIA001', [], 500, err));
			} else if(res.statusCode === 202 && body) {
				logger.debug(`Request # ${provisionRequest.id} : Application : ${application.name} successfully uploaded to radia.`);
				cb(null, provisionRequest);
			} else {
				cb(new PlatformError('RDIA003', [application.name], 500, body));
			}
		};

		sendRequestToRadia(
				'post',
				'/ws/radiaCustomer/job/publish',
				provisionRequest.cookie,
				MULTIPART_FORM,
				new Application(provisionRequest, application),
				processResponse
		);

	}, config.RADIA.SUGGESTED_DELAY_MILLIS, provisionRequest, application, cb);
}

// Uncomment below function to allow ipa provisioning flow
/*
function provisionApplication(provisionRequest, application, cb) {
	if(application.type === 'IOS') {
		cb(null, provisionRequest, application);
		return;
	}
	else if(application.type === 'ANDROID') {
		logger.debug(`Request # ${provisionRequest.id} : Provision application : ${application.name} to radia.`);

		// to ensure each upload is delayed by around 30 seconds
		setTimeout(function() {
			var processResponse = function (err, res, body) {
				if (err) {
					cb(new PlatformError('RDIA001', [], 500, err));
				} else if(res.statusCode === 202 && body) {
					logger.debug(`Request # ${provisionRequest.id} : Application : ${application.name} successfully uploaded to radia.`);
					cb(null, provisionRequest);
				} else {
					cb(new PlatformError('RDIA003', [application.name], 500, body));
				}
			};

			sendRequestToRadia(
					'post',
					'/ws/radiaCustomer/job/publish',
					provisionRequest.cookie,
					MULTIPART_FORM,
					new Application(provisionRequest, application),
					processResponse
			);

		}, config.RADIA.SUGGESTED_DELAY_MILLIS, provisionRequest, application, cb);
	}
	else {
		cb(new Error("Invalid application type"));
		return;
	}
}
*/

function provisionApplications(provisionRequest, cb) {
	//console.log('in provisionApplications fn');
	async.eachSeries(
			provisionRequest.experience.applications,
			async.apply(provisionApplication, provisionRequest),
			function(err) {
				if (err) {
					cb(err);
					return;
				}

				logger.info(`Request # ${provisionRequest.id} : Successfully uploaded mobile applications associated with experience : ${provisionRequest.experience.name}`);

				// time to digest upload on radia before we call association api
				setTimeout(cb, config.RADIA.SUGGESTED_DELAY_MILLIS, null, provisionRequest);
			}
	);
}

function associateApplicationsWithGroup(provisionRequest, cb) {
	logger.debug(`Request # ${provisionRequest.id} : Associate group : ${provisionRequest.organization.name} with mobile applications from experience : ${provisionRequest.experience.name}`);
	async.waterfall([
	                 async.apply(getProvisionedExperiencesByOrgId, provisionRequest),
									 checkIfFirstGroupAssociation,
									 associateApplicationsWithGroupIndirect,
	                 updateFlag
	                 ],
	                 function(err, result){
		if(err) {
			return cb(err);
		}
		cb(null, provisionRequest)
	});
}

function associateApplicationsWithGroupIndirect(provisionRequest, cb) {

  logger.debug(`Request # ${provisionRequest.id} : Associate group : ${provisionRequest.organization.name} with mobile applications from experience : ${provisionRequest.experience.name}`);

  var processResponse = function (err, res, body) {
    if (err) {
      cb(new PlatformError('RDIA001', [], 500, err));
    } else if(res.statusCode === 200 && body) {
			provisionRequest.associateApplicationsWithGroupIndirectSuccess = true;
      logger.debug(`Request # ${provisionRequest.id} : Successfully associated group : ${provisionRequest.organization.name} with mobile applications from experience : ${provisionRequest.experience.name}`);
      cb(null, provisionRequest);
    } else {
      logger.error(`Request # ${provisionRequest.id} : Could not associate group : ${provisionRequest.organization.name} with mobile applications from experience : ${provisionRequest.experience.name}`);
      cb(new PlatformError('RDIA004', [provisionRequest.organization.name], 500, body));
    }
  };


  var groupAssoc = new GroupApplicationAssociation(provisionRequest.organization, provisionRequest.experience);

  if(groupAssoc.apps && groupAssoc.apps.length) {
    sendRequestToRadia(
			'put', // provisionRequest.radiaAPIRequestType,
      '/ws/radiaCustomer/policy?operation=add',
      provisionRequest.cookie,
			APPLICATION_JSON,
      groupAssoc,
      processResponse
    );
  } else {
    cb(null, provisionRequest);
  }
}


function associateApplicationsWithGroupDirect(provisionRequest, cb) {
	logger.debug(`Request # ${provisionRequest.id} : Associate group : ${provisionRequest.organization.name} with mobile applications from experience : ${provisionRequest.experience.name}`);
	async.waterfall([
	                 async.apply(getProvisionedExperiencesByOrgId, provisionRequest),
	                 checkIfFirstGroupAssociation,
	                 getAllRadiaApps,
	                 associateApps,
	                 updateFlag
	                 ],
	                 function(err, result){
		if(err) {
			return cb(err);
		}
		cb(null, provisionRequest)
	});
};

//This method will get all the existing provisioned experiences based on orgId i.e. companyid
var getProvisionedExperiencesByOrgId = function(provisionRequest, cb) {
	dao.getAllExperiences(provisionRequest.orgId, function(err, data){
		if(err) {
			return cb(err);
		}
		//console.log('all provisioned experiences for orgid='+JSON.stringify(data));
		logger.info(`Request # ${provisionRequest.id} : Get All Provisioned Experiences for orgId = ${provisionRequest.orgId}: response length : ${data.length}`);
		provisionRequest.provisionedExperiences = data;
		cb(null, provisionRequest);
	});
}

/*
 * check if any app association is done before on radia for group
 * to decide to make put call or post call to avoid failure.
 */
var checkIfFirstGroupAssociation = function(provisionRequest, cb) {
	logger.debug(`Request # ${provisionRequest.id} : Check if it is first association to radia for : ${provisionRequest.organization.name} with mobile applications from experience : ${provisionRequest.experience.name}`);
	provisionRequest.radiaAPIRequestType = 'post';
	provisionRequest.provisionedExperiences.forEach(function(provExperience){
		if(provExperience.hasInternalAppStoreApps) {
			provisionRequest.radiaAPIRequestType = 'put';
		}
	});
	cb(null, provisionRequest);
}

var getAllRadiaApps = function(provisionRequest, cb) {
	var radiaApps = [];
	getAllAppsFromRadia(provisionRequest, function(err, provisionRequest, body){
		if(err) {
			return cb(new PlatformError('RDIA0011', 'Failed to get all apps from radia.', 500, body));
		}
		radiaApps = (JSON.parse(body)).apps;
		//console.log('all radia apps='+JSON.stringify(radiaApps));
		logger.info(`Request # ${provisionRequest.id} : Get all apps on radia : response length : ${radiaApps.length}`);
		provisionRequest.radiaApps = radiaApps;
		cb(null, provisionRequest);
	});
};

/*
 * Associate apps in experience with group on radia, apps which exist on radia
 */

var associateApps = function(provisionRequest, cb) {
	var processResponse = function (err, res, body) {
		if (err) {
			cb(new PlatformError('RDIA001', [], 500, err));
		} else if(res.statusCode === 200 && body) {
			logger.debug(`Request # ${provisionRequest.id} : Successfully associated group : ${provisionRequest.organization.name} with mobile applications from experience : ${provisionRequest.experience.name}`);
			cb(null, provisionRequest);
		} else {
			logger.error(`Request # ${provisionRequest.id} : Could not associate group : ${provisionRequest.organization.name} with mobile applications from experience : ${provisionRequest.experience.name}`);
			cb(new PlatformError('RDIA004', [provisionRequest.organization.name], 500, body));
		}
	};
	var methodType = 'put'; //provisionRequest.radiaAPIRequestType;
	//console.log('methodType='+methodType);
	logger.info(`Request # ${provisionRequest.id} : HTTP methodType for radia : ${methodType}`);
	var appExist = false;
	var assignApps = [];
	var BreakException= {};
	var provisionedCount = 0;
	var provisionState = null, provisionStatus = null;
	var allAppsCountToProvision = provisionRequest.experience.applications.length;
	provisionRequest.experience.applications.forEach(function(application, index, array) {
		if(application.type == 'WEBAPP') {
			/*	If application if webapp, then assume it is provisioned	 */
			provisionedCount++;
		} else if(application.type == 'ANDROID' || application.type == 'IOS') {
			provisionRequest.mobileAppExist = true;
			if(application.deployOptionFlag == 'DIRECT_DEPLOY' || application.deployOptionFlag == 'OTHER') {
				provisionRequest.deployFlagExist = true;
			}
			try {
				appExist = false;
				provisionRequest.radiaApps.forEach(function(radiaApp){
					application.name = application.name.replace(/ /g, '_');
					if('AA_AA_'+application.name.toUpperCase() == radiaApp.instanceName || 'IA_IA_'+application.name.toUpperCase() == radiaApp.instanceName) {
						//console.log('app exist: my app='+application.name+'radia app name='+radiaApp.instanceName);
						logger.info(`Request # ${provisionRequest.id} : app exist on radia : ${radiaApp.instanceName} for app in experience : ${application.name}`);
						assignApps.push(application);
						throw BreakException;
					}
				});
			} catch(ex) {
				// to break for each loop
			}
		}
		if(index == array.length-1) {
			//console.log('apps to send to radia: '+JSON.stringify(assignApps));
			logger.info(`Request # ${provisionRequest.id} : apps to associate on radia length : ${assignApps.length}`);
			provisionRequest.experience.applications = assignApps;
			var groupAssoc = new GroupApplicationAssociation(provisionRequest.organization, provisionRequest.experience);
			var calls = [];
			var singlyGroupAppAssoc = {
					dn: groupAssoc.dn,
					apps: []
			}
			if(groupAssoc.apps && groupAssoc.apps.length) {
				groupAssoc.apps.forEach(function(app, index1, array1) {
					calls.push(function(cb1){
						singlyGroupAppAssoc.apps = [];
						singlyGroupAppAssoc.apps.push(app);
						var requestBody = {
//								proxy:config.NETWORK_PROXY+":"+config.NETWORK_PROXY_PORT ,
								method: methodType,
								url: config.RADIA_BASE_URL + '/ws/radiaCustomer/policy?operation=add',
								jar: provisionRequest.cookie,
								json: true,
								body: singlyGroupAppAssoc
						};
						//console.log('calling '+methodType+' on: '+JSON.stringify(singlyGroupAppAssoc));
						logger.debug(`Request # ${provisionRequest.id} : calling ${methodType} for app : ${app.name}`);
						request(requestBody, function (err, res, body) {
							if(!err && res.statusCode === 200) {
								logger.debug(`Response Received from Radia # ${provisionRequest.id}, method type ${methodType}, response ${JSON.stringify(res)}`);
								provisionRequest.radiaAssociationSuccess = true;
								provisionedCount++;
							}
							if(err || res.statusCode === 200) {
								logger.debug(`Error Response From Radia # ${provisionRequest.id} ${JSON.stringify(res)}`);
								var response = {};
								response.err = err;
								response.res = res;
								response.body = body;
								cb1(null, response);
							}
						});
						if(methodType = 'post') {
							methodType = 'put';
						}
					});
				});
				async.series(calls, function(err, responses) {
//					console.log('radia responses: ' + JSON.stringify(responses));
					logger.debug(`Request # ${provisionRequest.id} : Number of Radia responses for association calls : ${responses.length}`);
					if(provisionedCount == allAppsCountToProvision) {
						provisionState = 'PROVISIONED';
						provisionStatus = 'PROVISIONED';
					} else if(provisionedCount > 0 && provisionedCount < allAppsCountToProvision) {
						provisionState = 'PARTIAL';
						provisionStatus = 'PARTIAL';
					} else if(provisionedCount === 0) {
						provisionState = 'FAILED';
						provisionStatus = 'FAILED';
					}
					provisionRequest.state = provisionState;
					provisionRequest.status = provisionStatus;
					var response = responses[responses.length-1];
					processResponse(response.err, response.res, response.body);
				});
			} else {
				if(provisionedCount == allAppsCountToProvision) {
					provisionState = 'PROVISIONED';
					provisionStatus = 'PROVISIONED';
				} else if(provisionedCount > 0 && provisionedCount < allAppsCountToProvision) {
					provisionState = 'PARTIAL';
					provisionStatus = 'PARTIAL';
				} else if(provisionedCount === 0) {
					provisionState = 'FAILED';
					provisionStatus = 'FAILED';
				}
				provisionRequest.state = provisionState;
				provisionRequest.status = provisionStatus;
				cb(null, provisionRequest);
			}
		}
	});
}

function updateFlag(provisionRequest, cb) {
	console.log("\n\nprovisionRequest Flags\n" + provisionRequest.mobileAppExist + "\n" + provisionRequest.deployFlagExist + "\n" + provisionRequest.radiaAssociationSuccess);
	if((provisionRequest.mobileAppExist
			&& provisionRequest.deployFlagExist
			&& provisionRequest.radiaAssociationSuccess)
			|| provisionRequest.associateApplicationsWithGroupIndirectSuccess) {
		var json = {};
		json.hasInternalAppStoreApps = true;
		dao.updateFields(provisionRequest, json, cb);
	} else {
		cb(null, provisionRequest);
	}
}

function updateFlagToFalse(provisionRequest, cb) {
	var json = {};
	json.hasInternalAppStoreApps = false;
	dao.updateFields(provisionRequest, json, cb);
}

function createUser(userRequest, cb) {

	logger.debug(`Create user in radia with email : ${userRequest.username}`);

	var user = new User(userRequest),
	processResponse = function (err, res, body) {
		if (err) {
			cb(new PlatformError('RDIA001', [], 500, err));
		} else if(res.statusCode === 201 && body) {
			cb(null, userRequest);
		} else if (res.statusCode === 409) {
			cb(new PlatformError('RDIA005', [userRequest.username], res.statusCode));
		} else {
			cb(new PlatformError('RDIA006', [userRequest.username], 500, body));
		}
	};

	sendRequestToRadia(
			'post',
			'/ws/radiaCustomer/users',
			userRequest.cookie,
			APPLICATION_JSON,
			user,
			processResponse
	);
}

function associateUserWithGroup(userRequest, cb) {

	logger.debug(`Associate user : ${userRequest.username} with group : ${userRequest.company.companyName} in radia.`);

	var processResponse = function (err, res, body) {
		if (err) {
			cb(new PlatformError('RDIA001', [], 500, err));
		} else if(res.statusCode === 200 && body) {
			cb(null, userRequest);
		} else {
			cb(new PlatformError('RDIA007', [userRequest.username, userRequest.company.companyName], 500, body));
		}
	};


	sendRequestToRadia(
			'put',
			'/ws/radiaCustomer/users/changeusermembership/addUsersToGroups',
			userRequest.cookie,
			APPLICATION_JSON,
			new UserGroupAssociation(userRequest),
			processResponse
	);
}

function createGroup(company, cb) {

	logger.debug(`Create group in radia with name : ${company.companyName}`);

	var userGroup = new UserGroup(company.companyName),
	processResponse = function (err, res, body) {
		if (err) {
			cb(new PlatformError('RDIA001', [], 500, err));
		} else if(res.statusCode === 201 && body) {
			logger.debug(`Group successfully created in radia with name : ${company.companyName}`);
			cb(null, company);
		} else if (res.statusCode === 409) {
			logger.debug(`Group already exists in radia with name : ${company.companyName}`);
			cb(new PlatformError('RDIA008', [company.companyName], res.statusCode));
		} else {
			cb(new PlatformError('RDIA009', [company.companyName], 500, body));
		}
	};

	sendRequestToRadia(
			'post',
			'/ws/radiaCustomer/groups',
			company.cookie,
			APPLICATION_JSON,
			userGroup,
			processResponse
	);
}

function getAllAppsFromRadia(provisionRequest, cb) {
	var processResponse = function (err, res, body) {
		if (err) {
			cb(new PlatformError('RDIA001', [], 500, err));
		} else if(res.statusCode === 200 && body) {
			logger.debug(`Request # ${provisionRequest.id} : Successfully fetched mobile applications from radia`);
			cb(null, provisionRequest, body);
		} else {
			logger.error(`Request # ${provisionRequest.id} : Could not fetch mobile applications from radia`);
			cb(new PlatformError('RDIA010', [], 500, body));
		}
	};
	sendRequestToRadia(
			'get',
			'/ws/radiaCustomer/services/MOBILE/apps',
			provisionRequest.cookie,
			null,
			null,
			processResponse
	);
}

//This Function will do deprovisioning in radia, First it will get Provisioned Experiences by Org ID then check,
//then get all radia apps and as per fdci delete that provisioning
function deassociateApplicationsWithGroup(provisionRequest, cb) {
	logger.debug(`Request # ${provisionRequest.id} : Associate group : ${provisionRequest.organization.name} with mobile applications from experience : ${provisionRequest.experience.name}`);

	provisionRequest.radiaAPIRequestType = 'put';

	async.waterfall([
	                 async.apply(getProvisionedExperiencesByOrgId, provisionRequest),
	                 login,
	                 getAllRadiaApps,
	                 deAssociateApps,
									 updateFlagToFalse
	                 ],
	                 function(err, result){
		if(err) {
			return cb(err);
		}
		cb(null, provisionRequest)
	});
};


/*
 * De Associate apps in experience with group on radia, apps which exist on radia
 */
var deAssociateApps = function(provisionRequest, cb) {
	var processResponse = function (err, res, body) {
		if (err && res.statusCode != 304 && res.statusCode != 500) {
			var json = {};
			json.hasInternalAppStoreApps = false;
			json.state = "FAILED";
			json.status = "FAILED";
			dao.updateFields(provisionRequest, json, cb);
			cb(new PlatformError('RDIA001', [], 500, err));
		} else if(res.statusCode === 200 && body) {
			logger.debug(`Request # ${provisionRequest.id} : Successfully de associated group : ${provisionRequest.organization.name} with mobile applications from experience : ${provisionRequest.experience.name}`);
			cb(null, provisionRequest);
		} else if(res.statusCode === 304) {
			logger.debug(`Request # ${provisionRequest.id} : Failed to de-associate group : ${provisionRequest.organization.name} with mobile applications from experience : ${provisionRequest.experience.name}`);
			var json = {};
			json.hasInternalAppStoreApps = false;
			json.state = "FAILED";
			json.status = "FAILED";
			dao.updateFields(provisionRequest, json, cb);
			cb(new PlatformError('RDIA010', [provisionRequest.organization.name], 304, err));
		} else {
			logger.error(`Request # ${provisionRequest.id} : Could not de-associate group : ${provisionRequest.organization.name} with mobile applications from experience : ${provisionRequest.experience.name}`);
			var json = {};
			json.hasInternalAppStoreApps = false;
			json.state = "DEPROVISIONED";
			json.status = "DEPROVISIONED";
			json.deleted = true;
			json.updated = new Date();
			dao.updateFields(provisionRequest, json, cb);
			cb(new PlatformError('RDIA011', [provisionRequest.organization.name], 500, body));
		}
	};
	var methodType = provisionRequest.radiaAPIRequestType;
	//console.log('methodType='+methodType);
	logger.info(`Request # ${provisionRequest.id} : HTTP methodType for radia : ${methodType}`);
	var appExist = false;
	var assignApps = [];
	var BreakException= {};
	var existAppsCount = 0;
	var provisionedCount = 0;
	var provisionState = null, provisionStatus = null;
	var allAppsCountToProvision = provisionRequest.experience.applications.length;
	provisionRequest.experience.applications.forEach(function(application, index, array) {
		if(application.type == 'WEBAPP') {
			/*	If application if webapp, then assume it is provisioned	 */
			provisionedCount++;
		} else if(application.type == 'ANDROID' || application.type == 'IOS') {
			var applicationName = "";
			if(application.deployOptionFlag == 'DIRECT_DEPLOY') {
				provisionRequest.organization.abbreviation = "";
				applicationName = application.name.replace(/ /g, '_');
			}
			else {
				applicationName = provisionRequest.organization.abbreviation + "_" + application.name.replace(/ /g, '_');
			}
			try {
				appExist = false;
				provisionRequest.radiaApps.forEach(function(radiaApp){
					// application.name = application.name.replace(/ /g, '_');
					if('AA_AA_'+applicationName.toUpperCase() == radiaApp.instanceName || 'IA_IA_'+applicationName.toUpperCase() == radiaApp.instanceName) {
						//console.log('app exist: my app='+application.name+'radia app name='+radiaApp.instanceName);
						logger.info(`Request # ${provisionRequest.id} : app exist on radia : ${radiaApp.instanceName} for app in experience : ${application.name}`);
						assignApps.push(application);
						existAppsCount++;
						throw BreakException;
					}
				});
			} catch(ex) {
				// to break for each loop
			}
		}

		if(index == array.length-1) {
			//console.log('apps to send to radia: '+JSON.stringify(assignApps));
			logger.info(`Request # ${provisionRequest.id} : apps to associate on radia length : ${assignApps.length}`);
			provisionRequest.experience.applications = assignApps;
			//console.log("abbreviation : "+provisionRequest.organization.abbreviation);
			logger.info(`Request # ${provisionRequest.id} : abbreviation : ${provisionRequest.organization.abbreviation}`);
			// provisionRequest.organization.abbreviation = "";
			var groupAssoc = new GroupApplicationAssociation(provisionRequest.organization, provisionRequest.experience);
			//methodType = 'post';
			var calls = [];
			var singlyGroupAppAssoc = {
					dn: groupAssoc.dn,
					apps: []
			}
			if(groupAssoc.apps && groupAssoc.apps.length) {
				groupAssoc.apps.forEach(function(app, index1, array1) {

					calls.push(function(cb1){
						singlyGroupAppAssoc.apps = [];
						singlyGroupAppAssoc.apps.push(app);
						var requestBody = {
//								proxy:config.NETWORK_PROXY+":"+config.NETWORK_PROXY_PORT ,
								method: methodType,
								url: config.RADIA_BASE_URL + '/ws/radiaCustomer/policy?operation=delete',
								jar: provisionRequest.cookie,
								json: true,
								body: singlyGroupAppAssoc
						};
						//console.log('requestBody '+JSON.stringify(requestBody));
						logger.debug(`Request # ${provisionRequest.id} : request time : ${new Date()}`);
						logger.debug(`Request # ${provisionRequest.id} : requestBody for radia de-associate call : ${JSON.stringify(requestBody)}`);
						request(requestBody, function (err, res, body) {
							if(!err && res.statusCode === 200) {
								provisionedCount++;
							}
							if(err || res.statusCode === 200) {
								var response = {};
								response.err = err;
								response.res = res;
								response.body = body;
								cb1(null, response);
							} else if(res.statusCode === 304) {
								var response = {};
								response.err = "Group does not exists in radia with name : "+groupAssoc.dn;
								response.res = res;
								response.body = body;
								cb1(null, response);
							} else {
								console.log("\nRadia error response code: ", res.statusCode);
								logger.debug(`Request # ${provisionRequest.id} : Radia error response code : ${JSON.stringify(res.statusCode)}`);
								console.log("\nRadia error body: ", body);
								logger.debug(`Request # ${provisionRequest.id} : Radia error body : ${JSON.stringify(body)}`);
								var response = {};
								response.err = "Unknown error while de-associating from radia";
								response.res = res;
								response.body = body;
								cb1(null, response);
							}
						});
					});

				});
				async.series(calls, function(err, responses) {
					logger.debug(`Request # ${provisionRequest.id} : Number of Radia responses for de-association calls : ${responses.length}`);
					if(provisionedCount == allAppsCountToProvision) {
						provisionState = 'RADIA_DEPROVISIONED';
						provisionStatus = 'RADIA_DEPROVISIONED';
					} else if(provisionedCount > 0 && provisionedCount < allAppsCountToProvision) {
						provisionState = 'PARTIAL';
						provisionStatus = 'PARTIAL';
					} else if(provisionedCount == 0) {
						provisionState = 'FAILED';
						provisionStatus = 'FAILED';
					}

					provisionRequest.state = provisionState;
					provisionRequest.status = provisionStatus;
					var response = responses[responses.length-1];
					processResponse(response.err, response.res, response.body);
				});
			} else {
				provisionRequest.state = 'RADIA_DEPROVISIONED';
				provisionRequest.status = 'RADIA_DEPROVISIONED';
				cb(null, provisionRequest);
			}
		}
	});
}

function getAppAssignments(provisionRequest, cb) {
	logger.debug(`Request # ${provisionRequest.oldApp.name} : Get group associations for the mobile application from radia`);

	var processResponse = function (err, res, body) {
		if (err) {
			cb(new PlatformError('RDIA001', [], 500, err));
		} else if(res.statusCode === 200 && body) {
			// console.log("Assignment", body);
			var bodyJson = JSON.parse(body);
			if(!bodyJson.userMessage) {
				provisionRequest.noAssignedGroups = false;
			}
			else {
				provisionRequest.noAssignedGroups = true;
			}
			logger.debug(`Request # ${provisionRequest.oldApp.name} : Successfully fetched mobile application assignments from radia`);
			cb(null, provisionRequest, bodyJson);
		} else {
			logger.error(`Request # ${provisionRequest.oldApp.name} : Could not fetch mobile application assignments from radia`);
			cb(new Error("Error fetching assignment of the app"), null);
		}
	};

	if(provisionRequest.oldApp.type == "ANDROID") {
		provisionRequest.radiaAppName = "AA_AA_" + provisionRequest.oldApp.name.replace(' ', '_').toUpperCase();
	}
	else if(provisionRequest.oldApp.type == "IOS") {
		provisionRequest.radiaAppName = "IA_IA_" + provisionRequest.oldApp.name.replace(' ', '_').toUpperCase();
	}
	else {
		cb(new Error("Invalid application type"), null);
	}

	sendRequestToRadia(
			'get',
			'/ws/radiaCustomer/services/PRIMARY.MOBILE.ZSERVICE.' + provisionRequest.radiaAppName + '?entities=1',
			provisionRequest.cookie,
			null,
			null,
			processResponse
	);
}

function deleteApp(provisionRequest, cb) {

	logger.debug(`Request # ${provisionRequest.oldApp.name} : Delete mobile application from radia`);
	var processResponse = function (err, res, body) {
		if (err) {
			cb(new PlatformError('RDIA001', [], 500, err));
		} else if(res.statusCode === 200 && body) {
			logger.debug(`Request # ${provisionRequest.oldApp.name} : Successfully deleted mobile application from radia`);
			cb(null, provisionRequest);
		} else {
			logger.error(`Request # ${provisionRequest.oldApp.name} : Could not delete mobile application from radia`);
			cb(new Error("Failed to delete mobile app from radia"), null);
		}
	};

	sendRequestToRadia(
			'delete',
			'/ws/radiaCustomer/services/PRIMARY.MOBILE.ZSERVICE.' + provisionRequest.radiaAppName,
			provisionRequest.cookie,
			null,
			null,
			processResponse
	);
}

function uploadApplication(provisionRequest, cb) {

	logger.debug(`Request # ${provisionRequest.oldApp.name} : Upload mobile application to radia.`);

	// to ensure each upload is delayed by around 30 seconds
	setTimeout(function() {
		var processResponse = function (err, res, body) {
			if (err) {
				cb(new PlatformError('RDIA001', [], 500, err));
			} else if(res.statusCode === 202 && body) {
				logger.debug(`Request # ${provisionRequest.oldApp.name} : Application successfully uploaded to radia.`);
				cb(null, provisionRequest);
			} else {
				cb(new PlatformError('RDIA003', [provisionRequest.oldApp.name], 500, body));
			}
		};

		var CHECKSUM = '{"%s":"48899286E171D16A15D13909048F63BA","icon.jpg":"48899286E171D16A15D13909048F63BA"}';

		var radiaMobileApp = {
				applicationName : provisionRequest.oldApp.name.replace(' ', '_'),
				applicationType : "Enterprise",
				vendor : "PSL",
				description : provisionRequest.newApp.description,
				category : "Enterprise",
				assignmentToUser : "Optional",
				appUpdate : "Automatic",
				publishType : "application",
				osList : provisionRequest.oldApp.type.substring(0, 3),
				checksum : provisionRequest.oldApp.type === config.APPLICATION_TYPE.ANDROID ? util.format(CHECKSUM, "app.apk") : util.format(CHECKSUM, "app.ipa"),
						binary : fs.createReadStream(provisionRequest.newApp.distribution),
						icon : fs.createReadStream(provisionRequest.newApp.logo),
						// radia swagger apis accept only single screenshot
						screenshot : fs.createReadStream(provisionRequest.newApp.screenshots[0])
		};

		sendRequestToRadia(
				'post',
				'/ws/radiaCustomer/job/publish',
				provisionRequest.cookie,
				MULTIPART_FORM,
				radiaMobileApp,
				processResponse
		);

	}, config.RADIA.SUGGESTED_DELAY_MILLIS, provisionRequest, cb);
}

//Associate Mandatory Applications In Radia, while company get created
function associateMandatoryApplicationsInRadia(req, cb) {

	logger.info(`associate Mandatory Applications In Radia: ${req}`);

	async.waterfall([
	                 async.apply(login, req),
	                 getAllRadiaApps,
	                 associateMandatoryApps,
	                 ], function(err, req) {
		if (err) {
			cb(err);
			return;
		}

		logger.info(`Successfully associated Mandatory Applications In Radia.`);
		cb(null, req);
	});
}

var associateMandatoryApps = function(req, cb) {
	logger.info('Client.js : associateMandatoryApps : received request : getUser : body : ' + JSON.stringify(req));
	var processResponse = function (err, res, body) {
		if (err) {
			cb(new PlatformError('RDIA001', [], 500, err));
		} else if(res.statusCode === 200 && body) {
			logger.debug(`Successfully associated group : ${req.companyName} with mobile applications from experience : ${req.mandatoryApps}`);
			cb(null, body);
		} else {
			logger.error(`Could not associate group : ${req.companyName} with mobile applications from experience : ${req.mandatoryApps}`);
			cb(new PlatformError('RDIA004', [req.companyName], 500, body));
		}
	};

	//First time Post, others are put call
	var methodType = 'post';
	var assignApps = [];
	var BreakException= {};
	logger.info(`HTTP methodType for radia : ${methodType}`);
	req.mandatoryApps.forEach(function(applicationName, index, array) {
		try {
			req.radiaApps.forEach(function(radiaApp){
				if('AA_AA_'+applicationName.toUpperCase() == radiaApp.instanceName || 'IA_IA_'+applicationName.toUpperCase() == radiaApp.instanceName) {
					//console.log('app exist: my app='+application.name+'radia app name='+radiaApp.instanceName);
					logger.info(`app exist on radia : ${radiaApp.instanceName} for app in experience : ${applicationName}`);
					applicationName = radiaApp.instanceName;
					assignApps.push(applicationName);
					throw BreakException;
				}
			});
		} catch(ex) {
			console.log("ex : " +JSON.stringify(ex));
			// to break for each loop
		}
		// create  GroupAssociation Obj for request
		if(index == array.length-1) {
			console.log('apps to send to radia: '+JSON.stringify(assignApps));
			console.log('apps to send to radia req: '+JSON.stringify(req));
			logger.info(`Request # apps to associate on radia length : ${assignApps.length}`);
			req.applications = assignApps;
			var groupAssoc = new MandatoryGroupApplicationAssociation(assignApps, req.companyName);
			var calls = [];
			var singlyGroupAppAssoc = {
					dn: groupAssoc.dn,
					apps: []
			}

			if(groupAssoc.apps && groupAssoc.apps.length) {
				groupAssoc.apps.forEach(function(app, index1, array1) {
					calls.push(function(cb1){
						singlyGroupAppAssoc.apps = [];
						singlyGroupAppAssoc.apps.push(app);
						var requestBody = {
//								proxy:config.NETWORK_PROXY+":"+config.NETWORK_PROXY_PORT ,
								method: methodType,
								url: config.RADIA_BASE_URL + '/ws/radiaCustomer/policy?operation=add',
								jar: req.cookie,
								json: true,
								body: singlyGroupAppAssoc
						};
						console.log('calling '+methodType+' on: '+JSON.stringify(singlyGroupAppAssoc));
						request(requestBody, function (err, res, body) {
							if(!err && res.statusCode === 200) {
								logger.debug(`Response Received from Radia # method type ${methodType}, response ${JSON.stringify(res)}`);
							}
							if(err || res.statusCode === 200) {
								logger.debug(`Error Response From Radia # ${JSON.stringify(res)}`);
								var response = {};
								response.err = err;
								response.res = res;
								response.body = body;
								cb1(null, response);
							}
						});
						if(methodType = 'post') {
							methodType = 'put';
						}
					});
				});
				async.series(calls, function(err, responses) {
					console.log('radia responses: ' + JSON.stringify(responses));
					logger.debug(`Request # Number of Radia responses for association calls : ${responses.length}`);

					var response = responses[responses.length-1];
					processResponse(response.err, response.res, response.body);
				});
			} else {
				cb(null, req);
			}
		}

	});

}


module.exports = {
		login : login,
		provisionApplications : provisionApplications,
		associateApplicationsWithGroup : associateApplicationsWithGroup,
		createUser : createUser,
		associateUserWithGroup : associateUserWithGroup,
		associateApplicationsWithGroupDirect: associateApplicationsWithGroupDirect,
		createGroup : createGroup,
		getAllAppsFromRadia: getAllAppsFromRadia,
		getAppAssignments: getAppAssignments,
		deleteApp: deleteApp,
		uploadApplication: uploadApplication,
		deassociateApplicationsWithGroup: deassociateApplicationsWithGroup,
		associateMandatoryApplicationsInRadia: associateMandatoryApplicationsInRadia
};
