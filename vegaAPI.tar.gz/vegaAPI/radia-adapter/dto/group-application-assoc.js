'use strict';

var UserGroup = require('./user-group'),
config = require('./../../common/Config');

const DOMAIN_NAME = 'MOBILE';
const ANDROID_PREFIX = 'AA_AA_';
const IOS_PREFIX = 'IA_IA_';

function GroupApplicationAssociation(organization, experience) {

  let groupApplicationAssociation = {
    dn: '',
    apps: []
  },
  prepareApplicationInstanceName = function(abbreviation, name) {
    let appName = name.toUpperCase();
    appName = appName.replace(/ /g, '_');

    if(abbreviation) {
      return abbreviation.toUpperCase() + '_' + appName;
    } else {
      return appName;
    }
  };

  groupApplicationAssociation.initialize = function() {

    let group = new UserGroup(organization.name);
    groupApplicationAssociation.dn = group.getDN();

    experience.applications.forEach(function(application) {

      if(application.type ===  config.APPLICATION_TYPE.WEBAPP
        || application.deployOptionFlag ===  'HOSTED') {
        return;
      }

      let appInstance = {
        instanceName:`${application.type === config.APPLICATION_TYPE.ANDROID ? ANDROID_PREFIX : IOS_PREFIX}${prepareApplicationInstanceName(organization.abbreviation, application.name)}`,
        domainname : DOMAIN_NAME
      };
      groupApplicationAssociation.apps.push(appInstance);
    });
  };


  groupApplicationAssociation.initialize();

  return groupApplicationAssociation;
}

module.exports = GroupApplicationAssociation;
