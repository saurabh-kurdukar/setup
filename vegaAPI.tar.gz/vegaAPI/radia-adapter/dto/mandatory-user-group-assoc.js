'use strict';

var UserGroup = require('./user-group');
const DOMAIN_NAME = 'MOBILE';


function MandatoryGroupApplicationAssociation(assignApps, companyName) {
	console.log("MandatoryGroupApplicationAssociation :: ", assignApps, companyName );
	let groupApplicationAssociation = {
			dn: '',
			apps: []
	};

	groupApplicationAssociation.initialize = function() {

		let group = new UserGroup(companyName);
		groupApplicationAssociation.dn = group.getDN();

		assignApps.forEach(function(applicationName) {

			let appInstance = {
					instanceName: applicationName,
					domainname : DOMAIN_NAME
			};
			groupApplicationAssociation.apps.push(appInstance);
		});
	};


	groupApplicationAssociation.initialize();
	console.log("MandatoryGroupApplicationAssociation :: ", JSON.stringify(groupApplicationAssociation) );
	return groupApplicationAssociation;
}
module.exports = MandatoryGroupApplicationAssociation;
