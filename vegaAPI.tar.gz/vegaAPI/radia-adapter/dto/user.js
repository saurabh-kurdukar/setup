'use strict';

var util = require('util');

const DESIGNATION = 'developer',
DN_FORMAT = 'uid=%s,cn=radiaCustomer,cn=user,cn=hp,cn=radia';

function User(userObj) {

  let user = {
    fullName: userObj.givenName,
    sn: userObj.sn,
    userCorporateEmailID: userObj.username,
    uid: userObj.username,
    userPersonalEmailID: userObj.username,
    generateAutoPassword: false,
    userPassword: userObj.userpassword,
    designation: DESIGNATION,
    getDN : function() {
      return util.format(DN_FORMAT, this.userCorporateEmailID);
    }
  };

  return user;
}

module.exports = User;
