'use strict';

var fs = require('fs'),
path = require('path'),
util = require('util'),
config = require('./../../common/Config');

const APPLICATION_TYPE = 'Enterprise',
ASSIGN_MANDATORY = 'Mandatory',
ASSIGN_OPTIONAL = 'Optional',
UPDATE = 'Automatic',
PUBLISH_TYPE = 'application',
OS_ANDROID = 'AND',
OS_IOS = 'IOS',
CHECKSUM = '{"%s":"48899286E171D16A15D13909048F63BA","icon.jpg":"48899286E171D16A15D13909048F63BA"}';

function Application(provisionRequest, app) {
  var application = {
    applicationName : provisionRequest.organization.abbreviation + '_' + app.name,
    applicationType : APPLICATION_TYPE,
    vendor : provisionRequest.experience.owner,
    description : app.description,
    category : APPLICATION_TYPE,
    assignmentToUser : app.mandatoryFlag ? ASSIGN_MANDATORY : ASSIGN_OPTIONAL,
    appUpdate : UPDATE,
    publishType : PUBLISH_TYPE,
    osList : app.type === config.APPLICATION_TYPE.ANDROID ? OS_ANDROID : OS_IOS,
    checksum : util.format(CHECKSUM, path.basename(app.artifactPath)),
    binary : fs.createReadStream(app.basePath + path.sep + app.artifactPath),
    icon : fs.createReadStream(app.logoPath),
    // radia swagger apis accept only single screenshot
    screenshot : fs.createReadStream(app.screenshotsPath[0])
  };


  return application;
}

module.exports = Application;
