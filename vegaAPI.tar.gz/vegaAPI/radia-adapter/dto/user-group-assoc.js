'use strict';

var UserGroup = require('./user-group'),
User = require('./user');

function UserGroupAssociation(userObj) {

  let userGroupAssociation = {
    userDN: [],
    listOfGroups: []
  };

  userGroupAssociation.initialize = function() {

    let group = new UserGroup(userObj.company.companyName);
    userGroupAssociation.listOfGroups.push(group.getDN());

    let user = new User(userObj);
    userGroupAssociation.userDN.push(user.getDN());
  };

  userGroupAssociation.initialize();

  return userGroupAssociation;
}

module.exports = UserGroupAssociation;
