var amqp = require('amqplib/callback_api');

/*
 * get RabbitMQ Connection
 */

var getConnection = function getConnection(callback) {
	amqp.connect('amqp://vegauser:vegauser123@10.0.2.8:5672/healthcare', function(err, conn) {
		if (err) {
			console.log('RabbitMQ connection error', err);					
		} else {						
			return callback(conn);
		}
	});
}

module.exports.getConnection = getConnection;
