'use strict';

var util = require('util');

function ResourceBundle(messageBundlePathArray) {

  let resourceBundle = {
    languages: {
      'en' : []
    }
  };

  resourceBundle.initialize = function() {

    messageBundlePathArray.forEach(function(messageBundlePath) {
      resourceBundle.languages.en.push(require(messageBundlePath + 'messages.json'));
    });
  };

  resourceBundle.initialize();

  resourceBundle.getMessage = function (key, args, language) {
    let lang = language,
    message;
    if(!lang) {
      lang = 'en';
    }

    for(let bIndex=0; bIndex<resourceBundle.languages[lang].length; bIndex++ ) {
      let bundle = resourceBundle.languages[lang][bIndex];
      message = bundle[key];
      if(message) {
        break;
      }
    }

    if(args && args.length) {
      return util.format(message, args.toString());
    } else {
      return message;
    }
  }
  return resourceBundle;
}

module.exports = ResourceBundle;
