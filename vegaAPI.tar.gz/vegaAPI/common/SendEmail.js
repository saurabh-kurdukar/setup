var config = require('./Config');
var messageDao = require('../sendMessage/dao/MessageDAO');
var sendgrid = require("sendgrid")(config.SENDGRID_API_KEY);
var logger = require('./logger').log;
var fs = require('fs');

var sendMail = function(msg) {
	logger.info('SendEmail :  received request : sendMail');
	var sendgrid = require("sendgrid")(config.SENDGRID_API_KEY);
	var email_data = msg.content.toString();
  var email_data_json = JSON.parse(email_data);
  // qr_image = fs.readFileSync(email_data_json.qr_file_path);

  var email = new sendgrid.Email({
    to: email_data_json.toMail,
    from: config.EMAIL_TEMPLATE_FROM,
    subject: config.EMAIL_TEMPLATE_SUBJECT,
    html: email_data_json.template
  });
  sendgrid.send(email, function(err, json) {
    if (err) {
      logger.info('SendEmail :  sendMail error !' + err);
      //update message status as Failed
      var status = 'Failed';
      messageDao.updateMessageStatus(status, email_data_json.messageId, function(err, data) {
        if (err) {
          logger.error('SendEmail : failed updateMessageStatus : error : ' + err);
        } else {
          logger.info('SendEmail :  updateMessageStatus successful !');
        }
      })
    } else {
      logger.info('SendEmail : sendMail successfull !' + json);
      //update message status as Sent
      var status = 'Sent';
      messageDao.updateMessageStatus(status, email_data_json.messageId, function(err, data) {
        if (err) {
          logger.error('SendEmail : failed updateMessageStatus : error : ' + err);
        } else {
          logger.info('SendEmail :  updateMessageStatus successful !');
        }
      })
    }
  });
}

module.exports.sendMail= sendMail;
