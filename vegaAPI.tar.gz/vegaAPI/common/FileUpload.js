var config = require('./Config');
var multer  = require('multer');
var storage = multer.diskStorage({
  destination: function (req, file, cb) {
	var ext = file.originalname.split('.').pop();
	if(ext === "apk") {
		cb(null, config.FILE_SERVER_APK_PATH);
	}
	if(ext === "ipa") {
		cb(null, config.FILE_SERVER_IPA_PATH);
	}
	if(file.mimetype.split('/')[0] === "image") {
		cb(null, config.FILE_SERVER_IMAGES_PATH);
	}
  },
  filename: function (req, file, cb) {
	var ext = file.originalname.split('.').pop();
	var timestamp = new Date().getTime();
	var fileName = "file_"+timestamp+"."+ext;	
	cb(null, fileName);		
  }
});

function fileFilter(req, file, cb) {
	var ext = file.originalname.split('.').pop();	
	if(file.fieldname && (ext === "apk" || ext === "ipa" || file.mimetype.split('/')[0] === "image")) {		
	  cb(null, true);
	} else {	
	  cb(null, false);
	}	 
}

var upload = multer({ storage: storage,  fileFilter: fileFilter});

module.exports = upload;