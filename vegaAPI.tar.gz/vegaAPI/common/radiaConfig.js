module.exports= {

	CREATE_USER : 'createUser',
	CREATE_GROUP : 'createGroup',
	ASSIGN_APP_TO_GROUP : 'assignAppToGroup',
	ADD_APP :'addApp',
	DELETE_APP :'deleteApp',
	DELETE_GROUP :'deleteGroup',
	UNASSIGN_APP_FROM_GROUP :'unassignAppFromGroup',
	DELETE_USER :'deleteUser',
	USER_LIST : 'userList',
	GROUP_LIST : 'groupList',
	APP_LIST : 'appList'
}
