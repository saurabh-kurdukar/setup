var config = require('./Config');
var request = require('request');
var getToken= function(callback){
//generate tokenId using forgeRock API
  var proxyurl = config.NETWORK_PROXY + ":" + config.NETWORK_PROXY_PORT;
  request({
    //'proxy':proxyurl ,
    url: config.FORGRROCK_URL + '/api/v1/users/authenticate',
    method: 'POST',
    headers: {
      'Content-Type': 'application/json'
    },
    json: {
      "userId": config.FORGEROCK_USERID,
      "password": config.FORGEROCK_PASSWORD
    }
  }, function(error, response, body) {
    if (error) {
      callback(error,null);
    } else {
      console.log("***********************" + body.tokenId);
      tokenId = body.tokenId      
	  callback(null,body);
    }
  });
}

module.exports.getToken= getToken;