var bunyan = require("bunyan");
var log = bunyan.createLogger({
	name:"EDTPlatformAPIs",
	streams:[{
			path : "edtplatform.log",
			level: "debug",
    	    period: '1d',          // daily rotation 
            rotateExisting: true,  // Give ourselves a clean file when we start up, based on period 
            threshold: '10m',      // Rotate log files larger than 10 megabytes 
            totalSize: '20m',      // Don't keep more than 20mb of archived log files 
            gzip: true             // Compress the archive log files to save space
	}]
});

var auditEventLog = bunyan.createLogger({
    name: 'AuditEvent',
    streams: [{
        type: 'rotating-file',
        path: 'auditEvent.log',
        period: '1d',   // daily rotation 
        count: 30       // keep 30 back copies 
    }]
});

module.exports.log = log;
module.exports.auditEventLog = auditEventLog;
