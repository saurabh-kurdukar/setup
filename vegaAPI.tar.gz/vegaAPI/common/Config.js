const SERVER = {
  PORT : 8080,
  PROTOCOL : 'http://',
  DOMAIN: 'cloudapp.net'
};
const PLATFORM_API_TARGET = 'vega1nodeweb.centralindia.cloudapp.azure.com';  // Current hostname
const NETWORK_PROXY= 'http://hjproxy.persistent.co.in';
const NETWORK_PROXY_PORT= 8080;
const NETWORK_PROXY_USERNAME='';
const NETWORK_PROXY_PASSWORD='';
const SMTP_HOST='hj-relay.persistent.co.in';
const SMTP_PORT= 25;
const EMAIL_TOTAL_ATTACHMENT_SIZE= 5000;
const EMAIL_INDIVIDUAL_FILE_SIZE= 3000;
const EMAIL_NUMBER_OF_ATTACHMENTS= 5;
const EMAIL_FILE_TYPES_ALLOWED=['text/plain','application/zip'];
const EMAIL_FILE_TYPES_NOT_ALLOWED=[];
const OTP_TIME_LIMIT='60' ;
const OTP_VERSION='1.0';
const OTP_TEMPLATE_ID= 1;

const REQUEST_TIMEOUT = 300000;

const QRCODE_TEMP_DIRECTORY= 'temp/qr';
const USER_EMAIL_TEMPLATE_PATH = 'resource/template/sandbox-email.htm';
const SENDGRID_API_KEY = "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";
const RADIA_BASE_URL = 'http://radia-core-api.cloudapp.net:3466/radiagw-server';		// Radia base url
const RADIA_JAR_PATH = 'resource/radia/RadiaApi1.0.0.jar';
const RADIA_CONFIG_PATH = '/common/radiaServerConfig.json';
const RADIA_GROUP_TYPE = 'Department';
const RADIA = {
  PORT : 443,
  HOSTNAME : 'radia-core-api.cloudapp.net',							// Radia hostname
  AGENT_URL : 'https://demo2.radiacloud.com/radia/ucdownload.jsp',
  ADMIN_USERNAME : 'radiaCustomer',
  ADMIN_PASSWORD: 'secret',
  SUGGESTED_DELAY_MILLIS : 30000
};

const DOCKER = {
  ADMIN_USERNAME : 'psledtdocker',
  ADMIN_PASSWORD : 'psledt123!@#',
  ADMIN_EMAIL : 'racbsl@yahoo.com',
  INTERMEDIATE_FILENAME : 'docker-service.js'
}

const JAVA_COMMAND_LINE = 'java -jar ';

const COMPONENT_SERVER_HOST = 'vega01pythonweb.southeastasia.cloudapp.azure.com';  // VM provisioning component
const COMPONENT_SERVER_PORT = 8080;							//Port
const DOCKER_VM_USER = 'edtuser';							// username
const DOCKER_VM_PASSWORD = 'Edt!@#123';							// password
const DOCKER_IMAGE_CONNECTIVITY_CHECK_ATTEMPTS = 60;
const DOCKER_IMAGE_CONNECTIVITY_CHECK_INTERVAL = 1000;
const VM_PROVISION_CHECK_ATTEMPTS = 120;
const VM_PROVISION_CHECK_INTERVAL = 10000;

const EXPERIENCE_PROVISION_LIMIT_PER_ORG = 500;						// no. of provisions for org
const EXPERIENCE_EXPIRY_DAYS = 5;

const EXPERIENCE_DISTRIBUTION = {			// Remote location for media api to save cordova project zips/images
  HOSTNAME: "devendra007.cloudapp.net",
  USERNAME : "dev",
  PASSWORD: "Pass123!",
  PORT: "22",
  LOGO_PATH : "logo",
  SCREENSHOTS_PATH : "screenshots",
  PATH: "/home/dev/blob/"
};

const APP_BLOB_LOCATION = {				// Location to host apps for provision download link
  PROTOCOL: "http://",
  HOSTNAME: "vega1nodeweb.centralindia.cloudapp.azure.com",
  USERNAME : "edtuser",
  PASSWORD: "Pass!@#123",
  DIRECTDEPLOY: "/provisions/directdeploy/",
  OTHER: "/provisions/org/",
  BASEDIR: "/var/www/html/provisions/org/"
};

const CORDOVA_PROJECT = {
    ENDPOINT_FILE : 'endpoint_config.js',
    ENDPOINT_LOCATION: 'www',
    IOS : {
      BUILD_URL: 'http://10.44.69.56:9090/v1.0/ipaprovision',
      SDK_HOME : '/opt/ios-sdk-linux',
      ARTIFACT_LOCATION : 'platforms/ios/www',
      ARTIFACT_TYPE : 'ipa',
      BUILD_CMD : 'ios'
    },
    ANDROID : {
      SDK_HOME : '/opt/android-sdk-linux',
      ARTIFACT_LOCATION : 'platforms/android/build/outputs/apk',
      ARTIFACT_TYPE : 'apk',
      BUILD_CMD : 'android'
    }
};

const APPLICATION_TYPE = {
  ANDROID : "ANDROID",
  IOS : "IOS",
  WEBAPP : "WEBAPP"
};

const FILE_SERVER_APPLICATION_APK_PATH = './application/files/apks/';
const FILE_SERVER_APPLICATION_IPA_PATH = './application/files/ipas/';
const FILE_SERVER_APPLICATION_IMAGES_PATH = './application/files/images/';
const FILE_SERVER_EXPERIENCE_IMAGES_PATH = './experience/files/images/';

const MEDIA_SITE_LOCATION = '/';
const MEDIA_SITE_BASEURL = 'http://' + PLATFORM_API_TARGET +'/files/';			// Remove port 8888 and give current hostname
const MEDIA_DISTRIBUTION_LOCATION = '/var/www/html/files/';				// Location to save images uploaded by media api
const MEDIA_TYPES = ['hosting', 'distribution'];
const SUPPORTED_MEDIA_TYPES = ['jpg', 'jpeg', 'gif', 'png', 'mpeg', 'mp4', 'wmv', 'apk', 'ipa', 'war', 'jar',
                              'zip', 'ear', 'doc', 'docx', 'pdf', 'xls', 'xlsx', 'txt', 'ppt', 'pptx'];
const MAX_MEDIA_SIZE = 100;

const DISTRIBUTION_LOCATION_TYPE = "remote";

const REMOTE_DISTRIBUTION = {
  HOSTNAME: "edt-experience.cloudapp.net",
  USERNAME : "edtteam",
  PASSWORD: "edtteam1!",
  PORTNUMBER: "8080",
  PATH: "/home/edtteam/blob/",
  URL: "http://edt-experience.cloudapp.net:7000/blob/",
  TYPE: "scp"
}

const CRONJOBS_DIR_PATH= './jobs';

const RESET_PASSWORD_TEMPLATE_ID= 40;
const RESET_PASSWORD_VERSION='1.0';

const SERVER_HOST = "http://" + PLATFORM_API_TARGET  + "/#/activation";  // Add current hostname
const FORGOT_PASS_URL= 'http://" + PLATFORM_API_TARGET  + ":8080/v1.0/forgotPassword/token/validate';   //Add current hostname

const audit_post_db_direct = true;
const AUDITS_MESSAGE_EXCHANGE_PRIMARY = 'audits.topic.primary';
const AUDITS_MESSAGE_QUEUE_PRIMARY = 'auditsmessage';
const AUDITS_MESSAGE_ROUTING_KEY = 'auditsmessage';
const AUDITS_MESSAGE_EXCHANGE_TYPE = 'topic';
const AUDITS_MESSAGE_EXCHANGE_DLX = 'audits.topic.dlx';
const AUDITS_MESSAGE_QUEUE_DLX = 'auditsmessagedlx';
const AUDITS_MESSAGE_ROUTING_KEY_DLX = 'auditsmessagedlx';
const AUDITS_MESSAGE_MAX_RETRY_COUNT = 3;

const FORGRROCK_URL= "http://vega1forgerock.centralindia.cloudapp.azure.com:8080/VegaIDM";			// Forgerock base url
const PROXY='yes';
const NETWORK_PROXY_ENABLE = false;

const USER_REG_TEMPLATE_ID= 1;					// email template id in templates collection
const USER_REG_VERSION='1.0';
const USER_REG_TEMPLATE_COMPANY_ID='1';

const PLATFORMUSER_TEMPLATE_ID=1;				// email template id in templates collection
const PLATFORMUSER_TEMPLATE_VERSION= 1.0;
const PLATFORMUSER_COMPANYID= 1;			//use same for otp template
const EMAIL_TEMPLATE_FROM= 'noreplyEDT@persistent.com';
const EMAIL_TEMPLATE_SUBJECT='Welcome to Vega - Accelerating Digital Transformation';

const FORGOT_PASSWORD_MESSAGE="Forgot Your Password?\n\nTo reset your password please click on this link or copy paste this url in browser\n";

const COMPANY_ID= 1;					// Parent company id for Persistent Systems
const COMPANY_NAME="PSL";

const DEFAULT_SURVEY_RATING_ID = 1;
const QR_IMAGE_BASE_PATH= '/var/www/html/qrcodes';	// location to save qr codes

const vmDetails = {
    "provider" : "AZURE",
    "osFamily" : "ubuntu",
    "osVersion" : "14.04",
    "size": "MEDIUM"
};

const FORGEROCK_USERID="amadmin";			// forgerock userid
const FORGEROCK_PASSWORD="Vega!@#123";			// forgerock password

const USERS_PASSWORD_MANAGEMENT='EXTERNAL';
const PLATFORMUSERS_PASSWORD_MANAGEMENT='EXTERNAL';

const ROLE_MANAGEMENT='EXTERNAL';
const DEFAULT_USER_ROLE = 'User';

const AZURE_API_URL= 'http://psledtplatform-test.apigee.net/azure/usages';
const AZURE_AUTHORIZATION= 'MetricsEndpoint-Key 859b3e60f5dc3d2f493b4c0466b22660';
const AZURE_SERVER_HOST= 'http://" + COMPONENT_SERVER_HOST  + ":8084';		// add vm provisioning hostname

const TRACE_API_TOP_VAL= 50;

const SMS_GATEWAY_ID_FOR_OTP = 1;
const SMS_DEFAULT_MAX_RETRY_COUNT = 3;

const MANDATORY_APPS = ['NokNok'];

const TWILIO_ACCOUNT_SID = "ACe427b2fb9b2fb25eb36754db34471b1e";
const TWILIO_AUTH_TOKEN = "0bedd8bf809d036a23570773e73c14d5";
const TWILIO_NUMBER = "+14087676501";

const ENVIRONMENT = "dev";		// dev=No user and role checks, replace with 'qa' to enable

const PATH_EXPORT_TO_EXCEL_PLATFORMUSER_DETAILS = "/opt/node/EDTPlatformAPIs/platformUser/tempExport";	// User statistics excel file location

const SKIP_RADIA = true;			// No use, ignore

const BINARY_STORAGE = {			// no use, ignore
  BASE_PATH: '/var/www/html/carenetBlob/',
  BASE_URL: 'http://' + PLATFORM_API_TARGET + '/carenetBlob/',
  SCRIPT: 'scripts/',
  MESSAGE: 'messages/',
  ALGORITHM: 'algorithms/',
  VISUALIZATION: 'visualizations/',
  MYVISUALIZATION: 'myVisualizations/',
  WIDGET: 'widgets/'
};

const OOZIE_BASE_URL = 'http://vegahcaredtlake.persistent.co.in:11000/oozie/v1/';

const HDFS_BASE_URL = 'http://vega1datalakehdpsvr.centralindia.cloudapp.azure.com:50070/webhdfs/v1/algorithms/';

const PASSWORD_LENGTH = 8;

exports.NETWORK_PROXY= NETWORK_PROXY;
exports.NETWORK_PROXY_PORT= NETWORK_PROXY_PORT;
exports.USERNAME= NETWORK_PROXY_USERNAME;
exports.PASSWORD= NETWORK_PROXY_PASSWORD;
exports.SMTP_HOST=SMTP_HOST;
exports.SMTP_PORT=SMTP_PORT;
exports.EMAIL_TOTAL_ATTACHMENT_SIZE= EMAIL_TOTAL_ATTACHMENT_SIZE;
exports.EMAIL_INDIVIDUAL_FILE_SIZE= EMAIL_INDIVIDUAL_FILE_SIZE;
exports.EMAIL_NUMBER_OF_ATTACHMENTS= EMAIL_NUMBER_OF_ATTACHMENTS;
exports.EMAIL_FILE_TYPES_ALLOWED= EMAIL_FILE_TYPES_ALLOWED;
exports.EMAIL_FILE_TYPES_NOT_ALLOWED =EMAIL_FILE_TYPES_NOT_ALLOWED;
exports.OTP_TIME_LIMIT= OTP_TIME_LIMIT;
exports.OTP_VERSION= OTP_VERSION;
exports.OTP_TEMPLATE_ID= OTP_TEMPLATE_ID;
exports.QRCODE_TEMP_DIRECTORY = QRCODE_TEMP_DIRECTORY;
exports.SENDGRID_API_KEY = SENDGRID_API_KEY;
exports.USER_EMAIL_TEMPLATE_PATH = USER_EMAIL_TEMPLATE_PATH;
exports.RADIA_JAR_PATH = RADIA_JAR_PATH;
exports.JAVA_COMMAND_LINE = JAVA_COMMAND_LINE;
exports.RADIA_CONFIG_PATH = RADIA_CONFIG_PATH;
exports.RADIA_GROUP_TYPE = RADIA_GROUP_TYPE;
exports.RADIA = RADIA;
exports.DOCKER_IMAGE_CONNECTIVITY_CHECK_INTERVAL = DOCKER_IMAGE_CONNECTIVITY_CHECK_INTERVAL;
exports.DOCKER_IMAGE_CONNECTIVITY_CHECK_ATTEMPTS = DOCKER_IMAGE_CONNECTIVITY_CHECK_ATTEMPTS;
exports.VM_PROVISION_CHECK_INTERVAL = VM_PROVISION_CHECK_INTERVAL;
exports.VM_PROVISION_CHECK_ATTEMPTS = VM_PROVISION_CHECK_ATTEMPTS;
exports.DOCKER_VM_USER = DOCKER_VM_USER;
exports.DOCKER_VM_PASSWORD = DOCKER_VM_PASSWORD;
exports.COMPONENT_SERVER_HOST = COMPONENT_SERVER_HOST;
exports.COMPONENT_SERVER_PORT = COMPONENT_SERVER_PORT;
exports.REQUEST_TIMEOUT = REQUEST_TIMEOUT;
exports.RADIA_BASE_URL = RADIA_BASE_URL;

exports.FILE_SERVER_APPLICATION_APK_PATH = FILE_SERVER_APPLICATION_APK_PATH;
exports.FILE_SERVER_APPLICATION_IPA_PATH = FILE_SERVER_APPLICATION_IPA_PATH;
exports.FILE_SERVER_APPLICATION_IMAGES_PATH = FILE_SERVER_APPLICATION_IMAGES_PATH;

exports.MEDIA_SITE_LOCATION = MEDIA_SITE_LOCATION;
exports.MEDIA_DISTRIBUTION_LOCATION = MEDIA_DISTRIBUTION_LOCATION;
exports.MEDIA_SITE_BASEURL = MEDIA_SITE_BASEURL;
exports.MEDIA_TYPES = MEDIA_TYPES;
exports.SUPPORTED_MEDIA_TYPES = SUPPORTED_MEDIA_TYPES;
exports.MAX_MEDIA_SIZE = MAX_MEDIA_SIZE;

exports.EXPERIENCE_PROVISION_LIMIT_PER_ORG = EXPERIENCE_PROVISION_LIMIT_PER_ORG;
exports.EXPERIENCE_EXPIRY_DAYS = EXPERIENCE_EXPIRY_DAYS;
exports.FILE_SERVER_EXPERIENCE_IMAGES_PATH = FILE_SERVER_EXPERIENCE_IMAGES_PATH;

exports.CRONJOBS_DIR_PATH= CRONJOBS_DIR_PATH;

exports.RESET_PASSWORD_TEMPLATE_ID= RESET_PASSWORD_TEMPLATE_ID;
exports.RESET_PASSWORD_VERSION= RESET_PASSWORD_VERSION;

exports.SERVER_HOST = SERVER_HOST;
exports.FORGOT_PASS_URL = FORGOT_PASS_URL;

exports.audit_post_db_direct = audit_post_db_direct;
exports.AUDITS_MESSAGE_EXCHANGE_PRIMARY = AUDITS_MESSAGE_EXCHANGE_PRIMARY;
exports.AUDITS_MESSAGE_QUEUE_PRIMARY = AUDITS_MESSAGE_QUEUE_PRIMARY;
exports.AUDITS_MESSAGE_ROUTING_KEY = AUDITS_MESSAGE_ROUTING_KEY;
exports.AUDITS_MESSAGE_EXCHANGE_TYPE = AUDITS_MESSAGE_EXCHANGE_TYPE;
exports.AUDITS_MESSAGE_EXCHANGE_DLX = AUDITS_MESSAGE_EXCHANGE_DLX;
exports.AUDITS_MESSAGE_QUEUE_DLX = AUDITS_MESSAGE_QUEUE_DLX;
exports.AUDITS_MESSAGE_ROUTING_KEY_DLX = AUDITS_MESSAGE_ROUTING_KEY_DLX;
exports.AUDITS_MESSAGE_MAX_RETRY_COUNT = AUDITS_MESSAGE_MAX_RETRY_COUNT;

exports.FORGRROCK_URL= FORGRROCK_URL;

exports.DISTRIBUTION_LOCATION_TYPE = DISTRIBUTION_LOCATION_TYPE;
exports.REMOTE_DISTRIBUTION = REMOTE_DISTRIBUTION;
exports.EXPERIENCE_DISTRIBUTION = EXPERIENCE_DISTRIBUTION;
exports.SERVER = SERVER;

exports.APP_BLOB_LOCATION = APP_BLOB_LOCATION;

exports.CORDOVA_PROJECT = CORDOVA_PROJECT;
exports.APPLICATION_TYPE = APPLICATION_TYPE;
exports.PROXY = PROXY;
exports.DOCKER = DOCKER;
exports.NETWORK_PROXY_ENABLE = NETWORK_PROXY_ENABLE;

exports.USER_REG_TEMPLATE_ID = USER_REG_TEMPLATE_ID;
exports.USER_REG_VERSION = USER_REG_VERSION;
exports.USER_REG_TEMPLATE_COMPANY_ID = USER_REG_TEMPLATE_COMPANY_ID;

exports.PLATFORMUSER_TEMPLATE_ID= PLATFORMUSER_TEMPLATE_ID;
exports.PLATFORMUSER_TEMPLATE_VERSION = PLATFORMUSER_TEMPLATE_VERSION;
exports.PLATFORMUSER_COMPANYID= PLATFORMUSER_COMPANYID;
exports.EMAIL_TEMPLATE_FROM= EMAIL_TEMPLATE_FROM;
exports.EMAIL_TEMPLATE_SUBJECT= EMAIL_TEMPLATE_SUBJECT;

exports.FORGOT_PASSWORD_MESSAGE= FORGOT_PASSWORD_MESSAGE;

exports.COMPANY_ID= COMPANY_ID;
exports.COMPANY_NAME= COMPANY_NAME;


exports.QR_IMAGE_BASE_PATH = QR_IMAGE_BASE_PATH;
exports.DEFAULT_SURVEY_RATING_ID = DEFAULT_SURVEY_RATING_ID;
exports.vmDetails = vmDetails;

exports.FORGEROCK_USERID= FORGEROCK_USERID;
exports.FORGEROCK_PASSWORD= FORGEROCK_PASSWORD;

exports.USERS_PASSWORD_MANAGEMENT= USERS_PASSWORD_MANAGEMENT;
exports.PLATFORMUSERS_PASSWORD_MANAGEMENT= PLATFORMUSERS_PASSWORD_MANAGEMENT;

exports.ROLE_MANAGEMENT= ROLE_MANAGEMENT;
exports.DEFAULT_USER_ROLE = DEFAULT_USER_ROLE;

exports.AZURE_API_URL= AZURE_API_URL;
exports.AZURE_AUTHORIZATION= AZURE_AUTHORIZATION;
exports.AZURE_SERVER_HOST= AZURE_SERVER_HOST;

exports.TRACE_API_TOP_VAL= TRACE_API_TOP_VAL;

exports.SMS_GATEWAY_ID_FOR_OTP = SMS_GATEWAY_ID_FOR_OTP;
exports.SMS_DEFAULT_MAX_RETRY_COUNT = SMS_DEFAULT_MAX_RETRY_COUNT;

exports.PLATFORM_API_TARGET = PLATFORM_API_TARGET;

exports.MANDATORY_APPS = MANDATORY_APPS;

exports.TWILIO_ACCOUNT_SID = TWILIO_ACCOUNT_SID;
exports.TWILIO_AUTH_TOKEN = TWILIO_AUTH_TOKEN;
exports.TWILIO_NUMBER = TWILIO_NUMBER;
exports.ENVIRONMENT = ENVIRONMENT;
exports.PATH_EXPORT_TO_EXCEL_PLATFORMUSER_DETAILS = PATH_EXPORT_TO_EXCEL_PLATFORMUSER_DETAILS;
exports.SKIP_RADIA = SKIP_RADIA;
exports.BINARY_STORAGE = BINARY_STORAGE;
exports.OOZIE_BASE_URL = OOZIE_BASE_URL;
exports.HDFS_BASE_URL = HDFS_BASE_URL;
exports.PASSWORD_LENGTH = PASSWORD_LENGTH;
