var mongoose = require('mongoose');
var pass = 'Pass!@#123';
mongoose.connect('mongodb://10.0.2.8:27017/edt-healthcare');

var connection = mongoose.connection;

connection.on('error', function() {
	console.log('db connection error');
});

connection.once('open', function() {
  console.log('mongo db connection opened.');
});

module.exports.mongoose = mongoose;
