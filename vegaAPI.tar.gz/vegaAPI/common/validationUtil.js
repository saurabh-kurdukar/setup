/**
 * Utility codes
 */

/*
 * Validate whether an Array contains only Numeric Values
 * 
 */
var validateNumbericArray = function(numericArray){
	console.log("in Validfation :"+numericArray);
	var reg = new RegExp('^\\d+$');
	for(var i = 0; i <  numericArray.length; i++){
		if(isNaN(numericArray[i]) || !reg.test(numericArray[i])){
			return false;
		}
	}
	return true;
};

module.exports.validateNumbericArray = validateNumbericArray;