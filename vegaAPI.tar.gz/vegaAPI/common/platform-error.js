'use strict';

var util = require('util');

function PlatformError(code, args, httpCode, inner) {
  this.code = code;
  this.args = [];
  this.httpCode = httpCode;
  this.stack = (new Error()).stack;
  if(inner) {

    if(typeof inner === 'object') {
      this.stack += '\nRoot Cause:\n' + JSON.stringify(inner);
    } else {
      this.stack += '\nRoot Cause:\n' + JSON.stringify(inner);
    }

    if(inner.stack) {

      if(typeof inner.stack === 'object') {
        this.stack += '\nRoot cause stack:\n' + JSON.stringify(inner.stack);
      } else {
        this.stack += '\nRoot cause stack:\n' + inner.stack;
      }
    }
  }

  if(args) {
    args.forEach(function(arg) {
      this.args.push(arg);
    }, this);
  }

  if(!httpCode) {
    this.httpCode = 500;  // defaults to internal server error
  }
}

util.inherits(PlatformError, Error);

module.exports = PlatformError;
