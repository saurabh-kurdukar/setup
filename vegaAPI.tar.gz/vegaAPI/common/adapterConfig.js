const addUserPostProcess = "adapters/sampleAdapter.js";
const addPlatformUserPostProcess = "adapters/autoAllocateAdapter.js";
const allocatePostDeprovision = "adapters/allocatePostDeprovision.js"; 
const postSignUpPlatformUserAdapter = "adapters/postSignUpPlatformUserAdapter.js";



exports.addUserPostProcess = addUserPostProcess;
exports.addPlatformUserPostProcess = addPlatformUserPostProcess;
exports.allocatePostDeprovision = allocatePostDeprovision;
exports.postSignUpPlatformUserAdapter = postSignUpPlatformUserAdapter;