var ErrorResponse = function() {

}

var ErrorResponse = function(errorCode, errorMessage, httpResponseCode) {
	this.errorCode = errorCode;
	this.errorMessage = errorMessage;
	this.httpResponseCode = httpResponseCode;
};

/*
 * Setters
 */
ErrorResponse.prototype.setErrorCode = function(errorCode) {
	this.errorCode = errorCode;
};

ErrorResponse.prototype.setErrorMessage = function(errorMessage) {
	this.errorMessage = errorMessage;
};

ErrorResponse.prototype.setHttpResponseCode = function(httpResponseCode) {
	this.httpResponseCode = httpResponseCode;
};

/*
 * Getters
 */
ErrorResponse.prototype.getErrorCode = function() {
	return this.errorCode;
};

ErrorResponse.prototype.getErrorMessage = function() {
	return this.errorMessage;
};

ErrorResponse.prototype.getHttpResponseCode = function() {
	return this.httpResponseCode;
};

ErrorResponse.prototype.toJSON = function() {
	this.errorJSON = {
		"errorCode" : this.errorCode,
		"errorMessage" : this.errorMessage,
		"httpResponseCode" : this.httpResponseCode
	};
	return this.errorJSON;
};

module.exports.ErrorResponse = ErrorResponse;