var logger = require('./logger').log;
var request = require('request');

var audit = function(req, res, updatedData) {
	logger.info('common : Audit : received request : data: ' + JSON.stringify(updatedData));	
	var json = new Object();
	for(i = 0; i < updatedData.length; i++) {
		json.identifier = updatedData[i].identifier;
		json.column = updatedData[i].column;
		json.oldValue = updatedData[i].oldValue;
		json.newValue = updatedData[i].newValue;
		json.modifiedBy = updatedData[i].modifiedBy;
		json.modifiedOn = updatedData[i].modifiedOn;
		/*
		 *	call audit API 
		 */	
		logger.info('common : Audit : auditing data : ' + JSON.stringify(json));
		request({
			method : 'POST',
			url : req.protocol + '://' + req.headers.host + '/v1.0/audits',
			headers : { 'Content-Type':'application/json' },
			body : JSON.stringify(json)
		}, function(error, response, body) {
			if (!error && response.statusCode == 200) {				
				logger.info('common : Audit : audit successful !' + JSON.stringify(body));				
			} else {
				logger.error('common : Audit : audit failed : error :' + error);				
			}
		});
	}	
}

module.exports.audit = audit;