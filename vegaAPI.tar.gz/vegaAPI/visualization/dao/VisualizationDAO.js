var Visualization = require('../models/Visualization');
var logger = require('../../common/logger').log;
var config = require('../../common/Config');
var fs = require('fs');
var rimraf = require('rimraf');
var async = require('async');

/*
 * logging format followed: logger.info(<module_name>: <component name> : <description> : [<long_description>] : <data/params/errors>);
 */


/*
 * Add new visualization details
 */
var addNewVisualization = function(req, res, callback) {
	logger.info('Visualization : DAO : received request : addNewVisualization : body : ' + JSON.stringify(req.body));
	if(req.body.createdBy) {
		req.body.updatedBy = req.body.createdBy;
	}
	var visualization = new Visualization(req.body);

	var regex = new RegExp(['^', req.body.name, '$'].join(''), 'i');

	Visualization.findOne({
		name: regex
	}, function(err, data) {
		if(err) {
			logger.error('Visualization : DAO : failed addNewVisualization : get by id : error : ' + err);
			callback(err, null);
		}
		else if(data) {
			var err = new Error('Visualization name already exists');
			err.status = 409;
			logger.error('Visualization : DAO : failed addNewVisualization : error : Name already exists');
			callback(err, null);
		}
		else {
			visualization.save(function(err, data) {
				if (err) {
					logger.error('Visualization : DAO : failed addNewVisualization : error : ' + err);
					callback(err, null);
				} else if(data != null){
					logger.info('Visualization : DAO : addNewVisualization successful !');
					callback(null, data);
				} else {
					var err = new Error('Failed to add new visualization details');
					logger.error('Visualization : DAO : failed addNewVisualization : error : '+ err);
					callback(err, null);
				}
			});
		}
	})
};

/*
 * Get all visualizations
 */
var getAllVisualizations = function(req, res, callback) {
	logger.info('Visualization : DAO : received request : getAllVisualizations');

	var query = {};
	var regex;
	if(req.query.name) {
		logger.info('Visualization : DAO : received request : getAllVisualizations : name : ' + req.query.name);
		var visualizationName = decodeURIComponent(req.query.name);
		regex = new RegExp(['^', visualizationName, '$'].join(''), 'i');
		query.name = regex;
	}

	Visualization.find(query, function(err, data) {
		if(err) {
			logger.error('Visualization : DAO : failed getAllVisualizations : error : ' + err);
			callback(err, null);
		}
		else {
			if (data.length != 0) {
				logger.info('Visualization : DAO : getAllVisualizations successful !');
				callback(null, data);
			} else {
				var err = new Error('No records found');
				err.status = 404;
				logger.error('Visualization : DAO : failed getAllVisualizations : error : ' + err);
				callback(err, null);
			}
		}
	})
}

/*
 * Get visualization by id
 */
var getVisualizationById = function(req, res, callback) {
	logger.info('Visualization : DAO : received request : getVisualizationById : id : ' + req.params.id);

	Visualization.findOne({
		id: req.params.id
	}, function(err, data) {
		if(err) {
			logger.error('Visualization : DAO : failed getVisualizationById : error : ' + err);
			callback(err, null);
		}
		else {
			if(data) {
				logger.info('Visualization : DAO : getVisualizationById successful !');
				callback(null, data);
			} else {
				var err = new Error('Invalid visualization id');
				err.status = 404;
				logger.error('Visualization : DAO : failed getVisualizationById : error : ' + err);
				callback(err, null);
			}
		}
	})
}

/*
 * Update visualization by id
 */
var updateVisualizationById = function(req, res, callback) {
	logger.info('Visualization : DAO : received request : updateVisualizationById : id : ' + req.params.id);

	var json = {};
	if(req.body.name) {
		json.name = req.body.name;
	}
	if(req.body.description) {
		json.description = req.body.description;
	}
	if(req.body.version) {
		json.version = req.body.version;
	}
	if(req.body.chartLibName) {
		json.chartLibName = req.body.chartLibName;
	}
	if(req.body.chartJs) {
		json.chartJs = req.body.chartJs;
	}
	if(req.body.inputJson) {
		json.inputJson = req.body.inputJson;
	}
	if(req.body.tags && req.body.tags.length > 0) {
		json.tags = req.body.tags;
	}
	else {
		json.tags = [];
	}
	if(req.body.updatedBy) {
		json.updatedBy = req.body.updatedBy;
	}
	json.updatedOn = new Date();

	Visualization.findOne({
		id: req.params.id
	}, function(err, data) {
		if(err) {
			logger.error('Visualization : DAO : failed updateVisualizationById : get by id : error : ' + err);
			callback(err, null);
		}
		else {
			if(data) {
				var oldFolderName = data.name;
			  async.series([
					function(cb) {
						if(req.body.name === data.name) {
							cb(null, "One");
						}
						else {
							req.query.name = req.body.name;
							if(req.query.name) {
								getAllVisualizations(req, res, function(err, data) {
									if(err && err.status != 404) {
										logger.error('Visualization : DAO : failed updateVisualizationById : getAllVisualizations : error : ' + err);
										cb(err, data);
									}
									else if(err && err.status == 404) {
										cb(null, "One");
									}
									else {
										var error = new Error('Visualization name already exists');
										logger.error('Visualization : DAO : failed updateVisualizationById : getAllVisualizations : error : ' + error);
										cb(error, data);
									}
								});
							}
							else {
								cb(null, "One");
							}
						}
					},
			    function(cb) {
			      var deleteFiles = req.body.deleteFiles;
			      if(deleteFiles && deleteFiles.length > 0) {
			        async.eachSeries(deleteFiles, function(file, call) {
			          var filePath = file.replace(config.BINARY_STORAGE.BASE_URL, config.BINARY_STORAGE.BASE_PATH);
			          deleteVisualizationFolder(filePath, function(fail, success) {
			            if(fail) {
			              call(fail, null);
			            }
			            else {
			              logger.info('Visualization : DAO : updateVisualizationById : File deleted : ' + success);
			              var deletePos = data.dependentFiles.indexOf(file);
										if(deletePos != -1) {
											data.dependentFiles.splice(deletePos, 1);
										}
			              call(null, success);
			            }
			          });
			        }, function(err) {
			          if(err) {
			            logger.error('Visualization : DAO : updateVisualizationById : Failed to delete file : error : ' + err);
			            cb(err, null);
			          }
			          else {
			            json.dependentFiles = data.dependentFiles;
			            cb(null, "Two");
			          }
			        });
			      }
			      else {
			        cb(null, "Two");
			      }
			    },
			    function(cb) {
						var visualizationFiles = req.files;
			      if(visualizationFiles && visualizationFiles.length != 0) {
			        async.eachSeries(visualizationFiles, function(file, call) {
			          var saveFile = config.BINARY_STORAGE.BASE_URL + config.BINARY_STORAGE.VISUALIZATION + data.name + '/' + file.filename;
			          if((file.filename.split('.').pop().toLowerCase() === 'png'
			                || file.filename.split('.').pop().toLowerCase() === 'jpg'
			                || file.filename.split('.').pop().toLowerCase() === 'jpeg')
			              && file.fieldname.toLowerCase() === 'thumbnail') {
			            var deleteFile = data.visualizationLocationBasePath + '/' + data.thumbnail.split('/').pop();
									if(deleteFile.split('/').pop() === file.filename) {
										call(null, deleteFile);
									}
									else {
										deleteVisualizationFolder(deleteFile, function(fail, success) {
				              if(fail) {
				                logger.error('Visualization : DAO : updateVisualizationById : delete thumbnail : error : ' + fail);
				                call(fail, null);
				              }
				              else {
				                logger.info('Visualization : DAO : updateVisualizationById : thumbnail deleted successfully!');
												data.thumbnail = saveFile;
				                json.thumbnail = saveFile;
				                call(null, success);
				              }
				            })
									}
			          }
			          else if(file.fieldname.toLowerCase() === 'jscode' && file.filename.split('.').pop().toLowerCase() === 'js') {
			            var deleteFile = data.visualizationLocationBasePath + '/' + data.jsCode.split('/').pop();
									if(deleteFile.split('/').pop() === file.filename) {
										call(null, deleteFile);
									}
									else {
										deleteVisualizationFolder(deleteFile, function(fail, success) {
				              if(fail) {
				                logger.error('Visualization : DAO : updateVisualizationById : delete jsCode : error : ' + fail);
				                call(fail, null);
				              }
				              else {
				                logger.info('Visualization : DAO : updateVisualizationById : jsCode deleted successfully!');
												data.jsCode = saveFile;
												json.jsCode = saveFile;
				                call(null, success);
				              }
				            })
									}
			          }
			          else {
			            if(data.dependentFiles.indexOf(saveFile) == -1) {
			              data.dependentFiles.push(saveFile);
			            }
			            call(null, saveFile);
			          }
			        }, function(err) {
			          if(err) {
			            logger.error('Visualization : DAO : updateVisualizationById : Failed to delete file : error : ' + err);
			            cb(err, null);
			          }
			          else {
			            json.dependentFiles = data.dependentFiles;
			            cb(null, "Three");
			          }
			        })
			      }
			      else {
			        cb(null, "Three");
			      }
			    },
					function(cb) {
						if(req.body.name && req.body.name != data.name) {
							json.visualizationLocationBasePath = config.BINARY_STORAGE.BASE_PATH + config.BINARY_STORAGE.VISUALIZATION + req.body.name;
							fs.rename(data.visualizationLocationBasePath, json.visualizationLocationBasePath, function(err) {
								if(err) {
									logger.error('Visualization : DAO : updateVisualizationById : Failed to rename visualization directory : error : ' + err);
									cb(err, null);
								}
								else {
									var oldBaseUrl = config.BINARY_STORAGE.BASE_URL + config.BINARY_STORAGE.VISUALIZATION + oldFolderName;
									var newBaseUrl = config.BINARY_STORAGE.BASE_URL + config.BINARY_STORAGE.VISUALIZATION + req.body.name;
									json.thumbnail = data.thumbnail.replace(oldBaseUrl, newBaseUrl);
									json.jsCode = data.jsCode.replace(oldBaseUrl, req.body.name);
									var updatedFileLocatiion = [];
									data.dependentFiles.forEach(function(file) {
										updatedFileLocatiion.push(file.replace(oldBaseUrl, newBaseUrl));
									})
									json.dependentFiles = updatedFileLocatiion;
									cb(null, "Four");
								}
							});
						}
						else {
							cb(null, "Four");
						}
					}
			  ], function(err, data) {
			    if(err) {
			      logger.error('Visualization : DAO : updateVisualizationById : Failed to update record : error : ' + err);
			      callback(err, null);
			    }
			    else {
			      Visualization.findOneAndUpdate({
			        id: req.params.id
			      }, json, {
			        new: true
			      }, function(err, data) {
			        if(err) {
			          logger.error('Visualization : DAO : failed updateVisualizationById : error : ' + err);
								var newVisualName = config.BINARY_STORAGE.BASE_PATH + config.BINARY_STORAGE.VISUALIZATION + req.body.name;
								var oldVisualName = config.BINARY_STORAGE.BASE_PATH + config.BINARY_STORAGE.VISUALIZATION + oldFolderName;
								fs.rename(newVisualName, oldVisualName, function(error) {
									if(error) {
										logger.error('Visualization : DAO : updateVisualizationById : Failed to revert visualization directory name : error : ' + error);
										callback(error, null);
									}
									else {
										callback(err, null);
									}
								});
			        }
			        else {
			          if(data) {
			            logger.info('Visualization : DAO : updateVisualizationById successful !');
			            callback(null, data);
			          }
			          else {
			            var err = new Error('Invalid visualization id');
			            err.status = 404;
			            logger.error('Visualization : DAO : failed updateVisualizationById : error : ' + err);
			            callback(err, null);
			          }
			        }
			      })
			    }
			  });
			} else {
				var err = new Error('Invalid visualization id');
				err.status = 404;
				logger.error('Visualization : DAO : failed updateVisualizationById : error : ' + err);
				callback(err, null);
			}
		}
	})
}

/*
 * Delete visualization by id
 */
var deleteVisualizationById = function(req, res, callback) {
	logger.info('Visualization : DAO : received request : deleteVisualizationById : id : ' + req.params.id);

	Visualization.findOne({
		id: req.params.id
	}, function(err, data) {
		if(err) {
			logger.error('Visualization : DAO : failed deleteVisualizationById : get visualization by id : error : ' + err);
			callback(err, null);
		}
		else {
			if(data) {
				var folderPath = data.visualizationLocationBasePath;
				Visualization.remove({
					id: req.params.id
				}, function(err, data) {
					if(err) {
						logger.error('Visualization : DAO : failed deleteVisualizationById : error : ' + err);
						callback(err, null);
					}
					else {
						deleteVisualizationFolder(folderPath, function(err, data) {
							if(err) {
								callback(err, null);
							}
							else {
								logger.info('Visualization : DAO : deleteVisualizationById successful !');
								callback(null, "Visualization deleted successfully");
							}
						});
					}
				})
			} else {
				var err = new Error('Invalid visualization id');
				err.status = 404;
				logger.error('Visualization : DAO : failed getVisualizationById : error : ' + err);
				callback(err, null);
			}
		}
	})
}

/*
 * Delete visualization file/folder
 */
var deleteVisualizationFolder = function(folder, callback) {
	logger.error('Visualization : DAO : deleteVisualizationFolder : folder : ' + folder);
	if(fs.existsSync(folder)) {
		rimraf(folder, function(err) {
			if(err) {
				logger.error('Visualization : DAO : deleteVisualizationFolder : error : ' + err);
				callback(err, null);
			}
			else {
				logger.error('Visualization : DAO : deleteVisualizationFolder successful !');
				callback(null, folder);
			}
		})
	}
	else {
		logger.error('Visualization : DAO : deleteVisualizationFolder : No visualizations found to delete !');
		callback(null, folder);
	}
}

/*
 * Search visualizations
 */
var searchVisualizations = function(req, res, callback) {
	logger.info('Visualization : DAO : received request : searchVisualizations : text : ' + req.query.text);

	if(!req.query.text) {
		var err = new Error('No tags found');
		logger.error('Visualization : DAO : failed searchVisualizations : error : No text found');
		callback(err, null);
	}
	else {
		var queryString = decodeURIComponent(req.query.text);
		var split = queryString.split(",");
		var searchString = "";
		split.forEach(function(word) {
			searchString += "\"" + word + "\" ";
		})

		Visualization.find({
			$text: {
				$search: req.query.text
			}
		}, function(err, data) {
			if(err) {
				logger.error('Visualization : DAO : failed searchVisualizations : error : ' + err);
				callback(err, null);
			}
			else {
				if(data.length > 0) {
					logger.info('Visualization : DAO : searchVisualizations successful !');
					callback(null, data);
				} else {
					var err = new Error('No records found');
					err.status = 404;
					logger.error('Visualization : DAO : failed searchVisualizations : error : ' + err);
					callback(err, null);
				}
			}
		})
	}
}


module.exports.addNewVisualization = addNewVisualization;
module.exports.getAllVisualizations = getAllVisualizations;
module.exports.getVisualizationById = getVisualizationById;
module.exports.updateVisualizationById = updateVisualizationById;
module.exports.deleteVisualizationById = deleteVisualizationById;
module.exports.searchVisualizations = searchVisualizations;
