var multer  = require('multer');
var fs = require('fs');
var config = require('../../common/Config');
var Visualization = require('../models/Visualization');

var filePath = config.BINARY_STORAGE.BASE_PATH;

if(!fs.existsSync(filePath)) {
  fs.mkdirSync(filePath);
}
if(!fs.existsSync(filePath + config.BINARY_STORAGE.VISUALIZATION)) {
  fs.mkdirSync(filePath + config.BINARY_STORAGE.VISUALIZATION);
}

var storage = multer.diskStorage({
  destination: function (req, file, cb) {
    // console.log("File", req);
    var folderName = req.body.name;
    if(folderName && !req.params.id) {
      if(!fs.existsSync(filePath + config.BINARY_STORAGE.VISUALIZATION + folderName)) {
        fs.mkdirSync(filePath + config.BINARY_STORAGE.VISUALIZATION + folderName);
      }
      req.body.visualizationLocationBasePath = filePath + config.BINARY_STORAGE.VISUALIZATION + folderName;
      cb(null, filePath + config.BINARY_STORAGE.VISUALIZATION + folderName);
    }
    else if(req.params.id) {
      Visualization.findOne({
        id: req.params.id
      }, function(err, data) {
        if(err) {
          var error = new Error("Cannot save visualization file", file);
          cb(error, null);
        }
        else {
          if(data) {
            cb(null, data.visualizationLocationBasePath);
          }
          else {
            var error = new Error("Invalid visualization id");
            cb(error, null);
          }
        }
      })
    }
    else {
      var error = new Error("Visualization name or id not found");
      cb(error, null);
    }
  },
  filename: function (req, file, cb) {
  	var fileName = file.originalname;
  	cb(null, fileName);
  }
});

function fileFilter(req, file, cb) {
	var ext = file.originalname.split('.').pop();
	if(!file.fieldname) {
    req.fileValidationError = 'No fieldname provided for the file';
	  cb(null, false);
	}
  else {
    cb(null, true);
  }
}

var upload = multer({ storage: storage,  fileFilter: fileFilter });

module.exports = upload;
