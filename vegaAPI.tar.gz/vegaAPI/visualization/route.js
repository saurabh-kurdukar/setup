var express = require('express');
var visualizationController = require('./controller/VisualizationController');
var logger = require('../common/logger').log;
var ErrorResponse = require('../common/ErrorResponse').ErrorResponse;
var router = express.Router();
var upload = require('./helpers/uploadFile');
var config = require('../common/Config');

/*
 * logging format followed: logger.info(<module_name>: <component name> : <description> : [<long_description>] : <data/params/errors>);
 */

/*
 * Add new visualization details
 */
router.post('/', upload.any(), function(req, res) {

	if(req.fileValidationError) {
		logger.info('Visualization : router : received request : addNewVisualization : error : ' + req.fileValidationError);
		var error = new ErrorResponse();
		error.setErrorMessage(req.fileValidationError);
		error.setErrorCode("V0001");
		error.setHttpResponseCode(500);
		res.status(500).end(JSON.stringify(error));
	}
	else if(req.files.length == 0) {
		logger.info('Visualization : router : received request : addNewVisualization : error : No file found');
		var error = new ErrorResponse();
		error.setErrorMessage("No file found");
		error.setErrorCode("V0001");
		error.setHttpResponseCode(500);
		res.status(500).end(JSON.stringify(error));
	}
	else {
		var visualizationFiles = req.files;
		var dependentFiles = [];
		visualizationFiles.forEach(function(file) {
			var saveFile = config.BINARY_STORAGE.BASE_URL + config.BINARY_STORAGE.VISUALIZATION + req.body.name + '/' + file.filename;
			if((file.filename.split('.').pop().toLowerCase() === 'png'
						|| file.filename.split('.').pop().toLowerCase() === 'jpg'
						|| file.filename.split('.').pop().toLowerCase() === 'jpeg')
					&& file.fieldname.toLowerCase() === 'thumbnail') {
				req.body.thumbnail = saveFile;
			}
			else if(file.filename.split('.').pop().toLowerCase() === 'js' && file.fieldname.toLowerCase() === 'jscode') {
				req.body.jsCode = saveFile;
			}
			else {
				dependentFiles.push(saveFile);
			}
		})
		req.body.dependentFiles = dependentFiles;

		logger.info('Visualization : router : received request : addNewVisualization : body : ' + JSON.stringify(req.body));
		visualizationController.addNewVisualization(req, res, function(err, data) {
			if(err) {
				logger.error('Visualization : router : failed addNewVisualization : error : '+err);
				var error = new ErrorResponse();
				if(err.name == 'ValidationError'){
					error.setErrorMessage(err.errors[Object.keys(err.errors)[0]].message);
				} else {
					error.setErrorMessage(err.message);
				}
				error.setErrorCode("V0001");
				var errorStatus = 500;
				if(err.status) {
					errorStatus = err.status;
				}
				error.setHttpResponseCode(errorStatus);
				res.status(errorStatus).end(JSON.stringify(error));
			}
			else {
				logger.info('Visualization : router : addNewVisualization successful !');
				res.status(200).end(JSON.stringify(data));
			}
		});
	}
});

/*
 * Get all visualizations
 */
router.get('/', function(req, res) {
	logger.info('Visualization : router : received request : getAllVisualizations');
	visualizationController.getAllVisualizations(req, res, function(err, data) {
		if(err) {
			logger.error('Visualization : router : failed getAllVisualizations : error : ' + err);
			var error = new ErrorResponse();
			error.setErrorCode("V0002");
			error.setErrorMessage(err.message);
			var errorStatus = 500;
			if(err.status) {
				errorStatus = err.status;
			}
			error.setHttpResponseCode(errorStatus);
			res.status(errorStatus).end(JSON.stringify(error));
		}
		else {
			logger.info('Visualization : router : getAllVisualizations successful!');
			res.status(200).end(JSON.stringify(data));
		}
	})
})

/*
 * Search visualizations
 */
router.get('/search', function(req, res) {
	logger.info('Visualization : router : received request : searchVisualizations : text : ' + req.query.text);
	visualizationController.searchVisualizations(req, res, function(err, data) {
		if(err) {
			logger.error('Visualization : router : failed searchVisualizations : error : ' + err);
			var error = new ErrorResponse();
			error.setErrorCode("V0006");
			error.setErrorMessage(err.message);
			var errorStatus = 500;
			if(err.status) {
				errorStatus = err.status;
			}
			error.setHttpResponseCode(errorStatus);
			res.status(errorStatus).end(JSON.stringify(error));
		}
		else {
			logger.info('Visualization : router : searchVisualizations successful!');
			res.status(200).end(JSON.stringify(data));
		}
	})
})

/*
 * Get visualization by id
 */
router.get('/:id', function(req, res) {
	logger.info('Visualization : router : received request : getVisualizationById : id : ' + req.params.id);
	visualizationController.getVisualizationById(req, res, function(err, data) {
		if(err) {
			logger.error('Visualization : router : failed getVisualizationById : error : ' + err);
			var error = new ErrorResponse();
			error.setErrorCode("V0003");
			error.setErrorMessage(err.message);
			var errorStatus = 500;
			if(err.status) {
				errorStatus = err.status;
			}
			error.setHttpResponseCode(errorStatus);
			res.status(errorStatus).end(JSON.stringify(error));
		}
		else {
			logger.info('Visualization : router : getVisualizationById successful!');
			res.status(200).end(JSON.stringify(data));
		}
	})
})

/*
 * Update visualization by id
 */
router.put('/:id', upload.any(), function(req, res) {
	logger.info('Visualization : router : received request : updateVisualizationById : id : ' + req.params.id);
	visualizationController.updateVisualizationById(req, res, function(err, data) {
		if(err) {
			logger.error('Visualization : router : failed updateVisualizationById : error : ' + err);
			var error = new ErrorResponse();
			error.setErrorCode("V0004");
			error.setErrorMessage(err.message);
			var errorStatus = 500;
			if(err.status) {
				errorStatus = err.status;
			}
			error.setHttpResponseCode(errorStatus);
			res.status(errorStatus).end(JSON.stringify(error));
		}
		else {
			logger.info('Visualization : router : updateVisualizationById successful!');
			res.status(200).end(JSON.stringify(data));
		}
	})
})

/*
 * Delete visualization by id
 */
router.delete('/:id', function(req, res) {
	logger.info('Visualization : router : received request : deleteVisualizationById : id : ' + req.params.id);
	visualizationController.deleteVisualizationById(req, res, function(err, data) {
		if(err) {
			logger.error('Visualization : router : failed deleteVisualizationById : error : ' + err);
			var error = new ErrorResponse();
			error.setErrorCode("V0005");
			error.setErrorMessage(err.message);
			var errorStatus = 500;
			if(err.status) {
				errorStatus = err.status;
			}
			error.setHttpResponseCode(errorStatus);
			res.status(errorStatus).end(JSON.stringify(error));
		}
		else {
			logger.info('Visualization : router : deleteVisualizationById successful!');
			res.status(200).end(JSON.stringify(data));
		}
	})
})


module.exports = router;
