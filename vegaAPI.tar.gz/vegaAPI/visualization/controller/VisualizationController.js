var visualizationDao = require('../dao/VisualizationDAO');
var logger = require('../../common/logger').log;

/*
 * logging format followed: logger.info(<module_name>: <component name> : <description> : [<long_description>] : <data/params/errors>);
 */


/*
 * Add new visualization details
 */
var addNewVisualization = function(req, res, callback) {
	logger.info('Visualization : controller : received request : addNewVisualization : body : ' + JSON.stringify(req.body));
	visualizationDao.addNewVisualization(req, res, callback);
};

/*
 * Get all visualizations
 */
var getAllVisualizations = function(req, res, callback) {
	logger.info('Visualization : controller : received request : getAllVisualizations');
	visualizationDao.getAllVisualizations(req, res, callback);
}

/*
 * Get visualization by id
 */
var getVisualizationById = function(req, res, callback) {
	logger.info('Visualization : controller : received request : getVisualizationById : id : ' + req.params.id);
	visualizationDao.getVisualizationById(req, res, callback);
}

/*
 * Update visualization by id
 */
var updateVisualizationById = function(req, res, callback) {
	logger.info('Visualization : controller : received request : updateVisualizationById : id : ' + req.params.id);
	visualizationDao.updateVisualizationById(req, res, callback);
}

/*
 * Delete visualization by id
 */
var deleteVisualizationById = function(req, res, callback) {
	logger.info('Visualization : controller : received request : deleteVisualizationById : id : ' + req.params.id);
	visualizationDao.deleteVisualizationById(req, res, callback);
}

/*
 * Search visualizations
 */
var searchVisualizations = function(req, res, callback) {
	logger.info('Visualization : controller : received request : searchVisualizations : text : ' + req.query.text);
	visualizationDao.searchVisualizations(req, res, callback);
}


module.exports.addNewVisualization = addNewVisualization;
module.exports.getAllVisualizations = getAllVisualizations;
module.exports.getVisualizationById = getVisualizationById;
module.exports.updateVisualizationById = updateVisualizationById;
module.exports.deleteVisualizationById = deleteVisualizationById;
module.exports.searchVisualizations = searchVisualizations;
