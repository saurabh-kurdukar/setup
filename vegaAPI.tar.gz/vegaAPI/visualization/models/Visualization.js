var mongoose = require('../../common/MongoDbConnection').mongoose;
var autoIncrement = require('mongoose-auto-increment');
var logger = require('../../common/logger').log;
var connection = mongoose.connection;
autoIncrement.initialize(connection);
/*
 * logging format followed: logger.info(<module_name>: <component name> :
 * <description> : <long_description> : <data/params/errors>);
 */


/*
 * Define schema
 */
var visualizationSchema = mongoose.Schema({
  id: Number,
	name: { type: String, unique : true, required : true },
  description: String,
  version: String,
  chartLibName: String,
  chartJs: String,
  inputJson: String,
  tags: [ String ],
  visualizationLocationBasePath: String,
  thumbnail: String,
  jsCode: String,
  dependentFiles: [ String ],
  createdBy: String,
  updatedBy: String,
  createdOn: { type: Date, default: Date.now },
  updatedOn: { type: Date, default: Date.now }
});


// logger.info('Visualization : model : created schema : Visualization :'+JSON.stringify(visualizationSchema.paths));

/*
 * Add Auto increment plugin for field visualization id
 */
visualizationSchema.plugin(autoIncrement.plugin, { model: 'Visualization', field: 'id', startAt: 1 });

// Create index for text search
visualizationSchema.index({name:"text", description: "text", tags: "text"});

/*
 * Create collection/model in mongo db using Schema
 */
var Visualization = mongoose.model('Visualization', visualizationSchema);
logger.info('Visualization : model : created model : Visualization : ' + Visualization);


module.exports = Visualization;
