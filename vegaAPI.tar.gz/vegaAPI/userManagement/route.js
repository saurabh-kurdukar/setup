var express = require('express');
var UserRegistrationController = require('./controller/UserRegistrationController');
//var ForgotPasswordController = require('./controller/ForgotPasswordController');
var otpController= require('./controller/OtpController');
var logger = require('../common/logger').log;
var ErrorResponse = require('../common/ErrorResponse').ErrorResponse;
var router = express.Router();
var ResourceBundle = require('./../common/resource-bundle.js'),
PlatformError = require('../common/platform-error'),
rsBundle = new ResourceBundle(['./../radia-adapter/resource/lang/']);

/*
 * logging format followed: logger.info(<module_name>: <component name> : <description> : [<long_description>] : <data/params/errors>);
 */


/*
 *	Add new User Registration
 */
router.post('/', function(req, res){
	logger.info('userManagement : router : received request : addUserRegistration : body : '+JSON.stringify(req.body));
	UserRegistrationController.addUserRegistration(req, res, function(err, data) {
        if(err) {

					if (err instanceof PlatformError) {
			      logger.error(`An error occurred while creating company. Stack trace : \n ${JSON.stringify(err)}`);
			      var error = new ErrorResponse(err.code, rsBundle.getMessage(err.code, err.args), err.httpCode);
						res.status(error.getHttpResponseCode()).json(error);
			    } else {
						logger.error('userManagement : router : failed addUserRegistration : error : '+err);
						var error = new ErrorResponse();
						if(err.name =='ValidationError'){
							error.setErrorMessage(err.errors[Object.keys(err.errors)[0]].message);
						} else {
							error.setErrorMessage(err.message);
						}
						error.setErrorCode("UM001");
						error.setHttpResponseCode(500);
						res.status(500).end(JSON.stringify(error));
					}
        } else {
        	logger.info("userManagement : router : addUserRegistration successful !");
        	res.status(200).end(JSON.stringify(data));
        }
    });
});



/*
 * get User configured for the given company id
 */
router.get('/:username', function (req, res) {
	logger.info('userManagement : router : received request : getUser : id : '+req.params.username);

	UserRegistrationController.getUser(req, res, function(err, data) {
        if(err){
        	logger.error('userManagement : router : failed getUser : error : '+err);
        	var error = new ErrorResponse();
        	error.setErrorCode("UM002");
        	error.setErrorMessage(err.message);
        	error.setHttpResponseCode(500);
            res.status(500).end(JSON.stringify(error));
        }else{
        	logger.info("userManagement : router : getUser successful !") ;
        	res.status(200).end(JSON.stringify(data));
        }
    });
});



/*
 * Update User
 */
router.put('/:username', function(req, res){
	logger.info('userManagement : router : received request : updateUser : id : '+req.params.username);
	UserRegistrationController.updateUser(req, res, function(err, data) {
        if(err){
        	logger.error('userManagement : router : failed updateUser : error : '+err);
        	var error = new ErrorResponse();
        	if(err.name == 'ValidationError'){
        		error.setErrorMessage(err.errors[Object.keys(err.errors)[0]].message);
        	} else {
        		error.setErrorMessage(err.message);
        	}
        	error.setErrorCode("UM003");
        	error.setHttpResponseCode(500);
            res.status(500).end(JSON.stringify(error));
        }else{
        	logger.info("userManagement : router : updateUser successful !");
        	res.status(200).end(JSON.stringify(data));
        }
    });
});



/*
 * Deletes an user specified by the companyid and username parameter
 */
router.delete('/:username', function(req, res){
	logger.info('userManagement : router : received request : deleteUser : id : '+req.params.username);
	UserRegistrationController.deleteUser(req, res, function(err, data) {
        if(err){
        	logger.error('userManagement : router : failed deleteUser : error : '+err);
        	var error = new ErrorResponse();
        	error.setErrorCode("UM004");
        	error.setErrorMessage(err.message);
        	error.setHttpResponseCode(500);
            res.status(500).end(JSON.stringify(error));
        }else{
        	logger.info("userManagement : router : deleteUser successful !");
        	res.status(200).end(JSON.stringify(data));
        }
    });
});




/*
 *	Add otp details
 */
router.post('/otp', function(req, res){
	logger.info('userManagement : router : received request : addOtpDetails : body : '+JSON.stringify(req.body));
	otpController.addOtpDetails(req, res, function(err, data) {
        if(err) {
        	logger.error('userManagement : router : failed addOtpDetails : error : '+err);
        	var error = new ErrorResponse();
        	if(err.name =='ValidationError'){
        		error.setErrorMessage(err.errors[Object.keys(err.errors)[0]].message);
        	} else {
        		error.setErrorMessage(err.message);
        	}
        	error.setErrorCode("UM006");
        	error.setHttpResponseCode(500);
        	res.status(500).end(JSON.stringify(error));
        } else {
        	logger.info("userManagement : router : addOtpDetails successful !");
        	res.status(200).end(JSON.stringify(data));
        }
    });
});

/*
 * Update otp verified status
 */
router.put('/otp/verify', function(req, res){
	logger.info('userManagement : router : received request : updateOtpStatus : (companyId: '+req.headers['companyid']+')');
	otpController.verifyOtp(req, res, function(err, data) {
        if(err){
        	logger.error('userManagement : router : failed updateOtpStatus : error : '+err);
        	var error = new ErrorResponse();
        	if(err.name == 'ValidationError'){
        		error.setErrorMessage(err.errors[Object.keys(err.errors)[0]].message);
        	} else {
        		error.setErrorMessage(err.message);
        	}
        	error.setErrorCode("UM007");
        	error.setHttpResponseCode(500);
            res.status(500).end(JSON.stringify(error));
        }else{
        	logger.info("userManagement : router : updateOtpStatus successful !");
        	res.status(200).end(JSON.stringify(data));
        }
    });
});


//validate activationlink
router.get('/activationLink/active', function(req, res){		
	logger.info('userManagement : router : received request : validateActivationLink : body : '+JSON.stringify(req.body));		
	UserRegistrationController.validateActivationLink(req, res, function(err, data) {
        if(err) {
        	logger.error('userManagement : router : failed validateActivationLink : error : '+err);
        	var error = new ErrorResponse();
        	if(err.name =='ValidationError'){
        		error.setErrorMessage(err.errors[Object.keys(err.errors)[0]].message);
        	} else {
        		error.setErrorMessage(err.message);
        	}
        	error.setErrorCode("UM005");
        	error.setHttpResponseCode(500);
        	res.status(500).end(JSON.stringify(error));
        } else {
        	logger.info("userManagement : router : validateActivationLink successful !");
        	res.status(200).end(JSON.stringify(data));
        }
    });
});


/*
 *	Generate Captcha Code
 */

router.get('/captcha/generate',function(req,res){
		UserRegistrationController.generateCaptcha(req, res, function(err, data) {
        if(err){
        	logger.error('userManagement : router : failed to generate captcha : error : '+err);
        	error.setHttpResponseCode(500);
            res.status(500).end(JSON.stringify(error));
        }else{
        	logger.info("userManagement : router : generated captcha !");
        	res.status(200).end(JSON.stringify(data));
        }
    });
});

/*
 * get getAllUsers
 */
router.get('/', function (req, res) {
	logger.info('userManagement : router : received request : getAllUsers ');

	UserRegistrationController.getAllUsers(req, res, function(err, data) {
        if(err){
        	logger.error('userManagement : router : failed getAllUsers : error : '+err);
        	var error = new ErrorResponse();
        	error.setErrorCode("UM008");
        	error.setErrorMessage(err.message);
        	error.setHttpResponseCode(500);
            res.status(500).end(JSON.stringify(error));
        }else{
        	logger.info("userManagement : router : getAllUsers successful !") ;
        	res.status(200).end(JSON.stringify(data));
        }
    });
});

/*
 * Reset Password
 */
router.post('/:username/resetPassword', function(req, res) {
  logger.info('userManagement : router : received request : resetPassword : (username:' + req.params.username+'body'+JSON.stringify(req.body) + ')');
  UserRegistrationController.resetPassword(req,res, function(err, data) {
    if (err) {
      logger.error('userManagement : router : failed resetPassword : error : ' + err);
      var error = new ErrorResponse();
      error.setErrorCode("UM009");
      error.setErrorMessage(err.message);
      error.setHttpResponseCode(err.status);
      return res.status(err.status).end(JSON.stringify(error));
    }
    logger.info("userManagement : router : resetPassword successful !");
    res.status(200).end(JSON.stringify(data));
  });
});

/*
 * Forgot Password Reset
 */
router.post('/:username/forgotPasswordReset', function(req, res) {
  logger.info('userManagement : router : received request : forgotPasswordReset : (username:' + req.params.username+'body'+JSON.stringify(req.body) + ')');
  UserRegistrationController.forgotPasswordReset(req,res, function(err, data) {
    if (err) {
      logger.error('userManagement : router : failed forgotPasswordReset : error : ' + err);
      var error = new ErrorResponse();
      error.setErrorCode("UM010");
      error.setErrorMessage(err.message);
      error.setHttpResponseCode(err.status);
      return res.status(err.status).end(JSON.stringify(error));
    }
    logger.info("userManagement : router : forgotPasswordReset successful !");
    res.status(200).end(JSON.stringify(data));
  });
});

/*
 * Options for user registration apis
 */
router.options('/', function(req, res) {
	logger.info('userManagement : router : received request : Options call userregistration APIs');
	res.header('Allow-Access-Allow-Origin', '*');
	res.header('Access-Control-Allow-Headers', '*');
	res.header('Access-Control-Allow-Methods', 'GET,POST,DELETE,PUT,OPTIONS');
	res.header('Connection', 'keep-alive');
	res.header('Content-Type', 'application/json;charset=UTF-8');
	res.end();
	logger.info('userManagement : router : Options call userregistration APIs processed !');
});


router.all('/*', function (req, res) {
	logger.info('userManagement : router : received request : with URL : ' + req.originalUrl);
	logger.error('userManagement : router : No matching resource for URL : ' + req.originalUrl);
	var error = new ErrorResponse();
	error.setErrorCode("UM008");
	error.setErrorMessage('No matching resource for URL: ' + req.originalUrl);
	error.setHttpResponseCode(404);
	res.status(404).send(JSON.stringify(error));
});

module.exports = router;
