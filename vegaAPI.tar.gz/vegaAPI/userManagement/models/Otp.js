var mongoose = require('../../common/MongoDbConnection').mongoose;
var logger = require('../../common/logger').log;
var connection = mongoose.connection;

/*
 * logging format followed: logger.info(<module_name>: <component name> :
 * <description> : <long_description> : <data/params/errors>);
 */


/*
 * Define schema
 */
var otpSchema = mongoose.Schema({
		
	appId: Number,
	username: {type:String, unique: true},
	countryCode: {type:String},
	mobileNo: String ,
	otp: String,	
	status: {type:String , default: 'Pending'},
	createdOn: { type: Date, default: Date.now },
	updatedOn:{ type: Date, default: Date.now },
	updatedBy:{type:String , default:'System'}		
    });


logger.info('otp : model : created schema : otps :'+JSON.stringify(otpSchema.paths));


otpSchema.path('countryCode').validate(function (v) {
	  return v.length <= 5;
}, 'data too long for field countryCode'); 

otpSchema.path('mobileNo').validate(function (v) {
	  return v.length <= 12;
}, 'data too long for field mobileNo');

otpSchema.path('otp').validate(function (v) {
	  return v.length <= 10;
}, 'data too long for field otp');


/*
 * Setters
 */
otpSchema.methods.setAppId = function(appId) {	
	this.appId = appId;
};

otpSchema.methods.setUsername = function(username) {
	this.username = username;
};

otpSchema.methods.setCountryCode = function(countryCode) {
	this.countryCode = countryCode;
};

otpSchema.methods.setMobileNo = function(mobileNo) {
	this.mobileNo = mobileNo;
};

otpSchema.methods.setOtp = function(otp) {
	this.otp = otp;
};


otpSchema.methods.setStatus = function(status) {
	this.status = status;
};

otpSchema.methods.setCreatedOn = function(createdOn) {
	this.createdOn = createdOn;
};

otpSchema.methods.setUpdatedOn = function(updatedOn) {
	this.updatedOn = updatedOn;
};

otpSchema.methods.setUpdatedBy = function(updatedBy) {
	this.updatedBy = updatedBy;
};
/*
 * Getters
 */
otpSchema.methods.getAppId = function() {
	return this.appId;
};

otpSchema.methods.getUsername = function() {
	return this.username;
};

otpSchema.methods.getCountryCode = function() {
	return this.countryCode;
};

otpSchema.methods.getMobileNo = function() {
	return this.mobileNo;
};

otpSchema.methods.getOtp = function() {
	return this.otp;
};

otpSchema.methods.getStatus = function() {
	return this.status;
};

otpSchema.methods.getCreatedOn = function() {
	return this.createdOn;
};

otpSchema.methods.getUpdatedOn = function() {
	return this.updatedOn;
};

otpSchema.methods.getUpdatedBy = function() {
	return this.updatedBy;
};

/*
 * Create collection/model in mongo db using Schema
 */
var Otp = mongoose.model('otps', otpSchema);
logger.info('otp : model : created model : otps');

module.exports = Otp;