var mongoose = require('../../common/MongoDbConnection').mongoose;
var autoIncrement = require('mongoose-auto-increment');
var logger = require('../../common/logger').log;
var connection = mongoose.connection;
autoIncrement.initialize(connection);
var activityenum = require('../enum/AccountStatus');

/*
 * Define schema userLoginInfo
 */
var userLoginInfoSchema = mongoose.Schema({
  userId: {
    type: Number
  },
  username: {
    type: String,
    unique: true
  },
  password: {
    type: String
  },
  companyId: {
    type: Number,
    required: true
  },
  appId: {
    type: Number
  },
  experienceId: {
    type: Number
  },
  verified: {
    type: Boolean,
    default: false
  }

});

userLoginInfoSchema.plugin(autoIncrement.plugin, {
  model: 'UserLoginInfo',
  field: 'userId',
  startAt: 1
});

userLoginInfoSchema.path('username').validate(function(value, fn) {
  var UserLoginInfo = mongoose.model('UserLoginInfo');
  UserLoginInfo.find({
    'username': value
  }, function(err, data) {
    fn(err || data.length === 0);
  });
}, 'username is already taken');

/*
 * Define schema userProfile
 */
var userProfileSchema = mongoose.Schema({

  userId: {
    type: Number
  },
  firstname: {
    type: String,
    required: true
  },
  lastname: {
    type: String,
    required: true
  },
  gender: {
    type: String
  },
  dateOfBirth: {
    type: Date
  },
  termsAndConditions: {
    type: String
  },
  CreatedBy: {
    type: String,
    minLength: 0,
    maxLength: 50
  },
  CreatedOn: {
    type: Date,
    default: Date.now
  },
  UpdatedBy: {
    type: String,
    minLength: 0,
    maxLength: 50
  },
  UpdatedOn: {
    type: Date,
    default: Date.now
  },
  telephoneNumber: {
    type: String
  },
  username: {
    type: String,
    unique: true
  },
  companyId: {
    type: Number,
    required: true
  },
  lastLoginDatetime: {
    type: Date,
    default: Date.now
  },
  accountStatus: {
    type: String,
    default: activityenum.get(0)
  }
});

var generateActivateTokenSchema = mongoose.Schema({
  username: {
    type: String,
    unique: true
  },
  accessKey: {
    type: String
  },
  clickedStatus: {
    type: Boolean,
    default: false
  },
  createdOn: {
    type: Date,
    default: Date.now
  },
  updatedOn: {
    type: Date,
    default: Date.now
  }
});

generateActivateTokenSchema.path('username').validate(function(value, fn) {
  var GenerateActivateToken = mongoose.model('GenerateActivateToken');
  GenerateActivateToken.find({
    'username': value
  }, function(err, data) {
    fn(err || data.length === 0);
  });
}, 'token with username is already taken ');

userProfileSchema.path('firstname').validate(function(v) {
  return v.length <= 30;
}, 'data too long for field firstname');

userProfileSchema.path('lastname').validate(function(v) {
  return v.length <= 30;
}, 'data too long for field lastname');

userProfileSchema.path('gender').validate(function(v) {
  return v.length <= 10;
}, 'data too long for field gender');

userProfileSchema.path('CreatedBy').validate(function(v) {
  return v.length <= 50;
}, 'data too long for field CreatedBy');

userProfileSchema.path('UpdatedBy').validate(function(v) {
  return v.length <= 50;
}, 'data too long for field UpdatedBy');

/*
 **setters login info
 */
userLoginInfoSchema.methods.setuserId = function(userId) {
  this.userId = userId;
};

userLoginInfoSchema.methods.setusername = function(username) {
  this.username = username;
};

userLoginInfoSchema.methods.setpassword = function(password) {
  this.password = password;
};

userLoginInfoSchema.methods.setcompanyId = function(companyId) {
  this.companyId = companyId;
};

userLoginInfoSchema.methods.setappId = function(appId) {
  this.appId = appId;
};

userLoginInfoSchema.methods.setexperienceId = function(experienceId) {
  this.experienceId = experienceId;
};

/*
 * Getters login info
 */
userLoginInfoSchema.methods.getuserId = function() {
  return this.userId;
};

userLoginInfoSchema.methods.getusername = function() {
  return this.username;
};

userLoginInfoSchema.methods.getpassword = function() {
  return this.password;
};

userLoginInfoSchema.methods.getcompanyId = function() {
  return this.companyId;
};
userLoginInfoSchema.methods.getappId = function() {
  return this.appId;
};

userLoginInfoSchema.methods.getexperienceId = function() {
  return this.experienceId;
};

/*
 **setters user Profile
 */
userProfileSchema.methods.setuserId = function(userId) {
  this.userId = userId;
};

userProfileSchema.methods.setfirstname = function(firstname) {
  this.firstname = firstname;
};
userProfileSchema.methods.setlastname = function(lastname) {
  this.lastname = lastname;
};

userProfileSchema.methods.setgender = function(gender) {
  this.gender = gender;
};

userProfileSchema.methods.setdateOfBirth = function(dateOfBirth) {
  this.dateOfBirth = dateOfBirth;
};

userProfileSchema.methods.settermsAndConditions = function(termsAndConditions) {
  this.termsAndConditions = termsAndConditions;
};
userProfileSchema.methods.setCreatedBy = function(CreatedBy) {
  this.CreatedBy = CreatedBy;
};

userProfileSchema.methods.setCreatedOn = function(CreatedOn) {
  this.CreatedOn = CreatedOn;
};

userProfileSchema.methods.setUpdatedBy = function(UpdatedBy) {
  this.UpdatedBy = UpdatedBy;
};
userProfileSchema.methods.setUpdatedOn = function(UpdatedOn) {
  this.UpdatedOn = UpdatedOn;
};
userProfileSchema.methods.settelephoneNumber = function(telephoneNumber) {
  this.telephoneNumber = telephoneNumber;
};
userProfileSchema.methods.setusername = function(username) {
  this.username = username;
};
userProfileSchema.methods.setcompanyId = function(companyId) {
  this.companyId = companyId;
};

userProfileSchema.methods.setLastLoginDatetime = function(lastLoginDatetime) {
  this.lastLoginDatetime = lastLoginDatetime;
};

/*
 * Getters profile info
 */
userProfileSchema.methods.getuserId = function() {
  return this.userId;
};

userProfileSchema.methods.getfirstname = function() {
  return this.firstname;
};

userProfileSchema.methods.getlastname = function() {
  return this.lastname;
};
userProfileSchema.methods.getgender = function() {
  return this.gender;
};

userProfileSchema.methods.getdateOfBirth = function() {
  return this.dateOfBirth;
};

userProfileSchema.methods.gettermsAndConditions = function() {
  return this.termsAndConditions;
};
userProfileSchema.methods.getCreatedBy = function() {
  return this.CreatedBy;
};

userProfileSchema.methods.getCreatedOn = function() {
  return this.CreatedOn;
};
userProfileSchema.methods.getUpdatedBy = function() {
  return this.UpdatedBy;
};

userProfileSchema.methods.getUpdatedOn = function() {
  return this.UpdatedOn;
};

userProfileSchema.methods.gettelephoneNumber = function() {
  return this.telephoneNumber;
};

userProfileSchema.methods.getusername = function() {
  return this.username;
};

userProfileSchema.methods.getcompanyId = function() {
  return this.companyId;
};

userProfileSchema.methods.getLastLoginDatetime = function() {
  return this.lastLoginDatetime;
};

/*
 **Setter Method
 */
generateActivateTokenSchema.methods.setUsername = function(username) {
  this.username = username;
};

generateActivateTokenSchema.methods.setAccessKey = function(accessKey) {
  this.accessKey = accessKey;
};

/*
 **Getter Method
 */
generateActivateTokenSchema.methods.getUsername = function() {
  return this.username;
};

generateActivateTokenSchema.methods.getAccessKey = function() {
  return this.accessKey;
};


var UserLoginInfo = mongoose.model('UserLoginInfo', userLoginInfoSchema);
logger.info('userManagement : model : created model : UserLoginInfo');

var UserProfile = mongoose.model('UserProfile', userProfileSchema);
logger.info('userManagement : model : created model : UserProfile');

var GenerateActivateToken = mongoose.model('GenerateActivateToken', generateActivateTokenSchema);
logger.info('userManagement : model : created model : GenerateActivateToken');

module.exports.UserLoginInfo = UserLoginInfo;
module.exports.UserProfile = UserProfile;
module.exports.GenerateActivateToken = GenerateActivateToken;
