var logger = require('../../common/logger').log;
var otpDao= require('../dao/OtpDAO');


/*
 * logging format followed: logger.info(<module_name>: <component name> : <description> : [<long_description>] : <data/params/errors>);
 */


/*
 * Add new otp details
 */
var addOtpDetails = function(req, res, callback) {
	logger.info('otp : controller : received request : addOtpDetails : body : '+JSON.stringify(req.body));
	otpDao.addOtpDetails(req, res, callback);
};

/*
 * update OTP Status
 */
var verifyOtp = function(req, res, callback) {
	logger.info('otp : controller : received request : updateOtpStatus : (companyId: '+req.headers['companyid']+')');	
	otpDao.verifyOtp(req, res, callback);
};

module.exports.addOtpDetails = addOtpDetails;
module.exports.verifyOtp= verifyOtp;

