var userRegistrationDao = require('../dao/UserRegistrationDAO');
var encryptdecrypt = require('../../common/EncryptDecrypt');
var logger = require('../../common/logger').log;
var Q = require('q');
var async = require("async");
var generateActivateTokenDAO = require('../dao/GenerateActivateTokenDAO');
var userRegistrationdelegate = require('../delegate/UserRegistrationDelegate');
var internalDelegate = require('../delegate/InternalDelegate');
var captchapng = require('captchapng');
var config = require('../../common/Config');
var adapterConfig = require('../../common/adapterConfig');
var addUserPostProcessAdapter = require('../../' + adapterConfig.addUserPostProcess);
var resetPasswordDelegate = require('../../resetPassword/delegate/ResetPassowrdDelegate');
var forgotPasswordDelegate = require('../../forgotPassword/delegate/ForgotPasswordDelegate');
var registrationDao = require('../../registration/dao/RegistrationDAO');
var provisionUser = require('./../../provision/controller/provision-user');
var roleDao = require('../../roles/dao/RoleDAO');
var userRoleDao = require('../../userRoles/dao/UserRoleDAO');
var userRoleDelegate = require('../../userRoles/delegate/UserRoleDelegate');
var ForgeRockGetToken = require('../../common/ForgeRockGetToken');
var userattributesdao = require('../../userAttributes/dao/UserAttributeDAO');

/*
 *	Add new User Registration
 */
var addUserRegistration = function(req, res, callback) {
  logger.info('userManagement : controller : received request : addUserRegistration : body : ' + JSON.stringify(req.body));
  
  req.body.username = req.body.username.toLowerCase();
  req.params.username=req.body.username;
  
  //password validation	 
  var passMgt = config.USERS_PASSWORD_MANAGEMENT;
  var re = /[0-9]/;
  var isValid = false;
  var pass = null;
  if (req.body.type === 'addUser') {
    pass = getRandomPassword();
    req.body.password = pass;
    isValid = true;
  } else {
    pass = req.body.password;
    isValid = /^[0-9,.]*$/.test(pass);
  }
  if (!isValid) {
    var err = new Error('password must contain only numbers (0-9)!');
    err.status = 400;
    logger.error('userManagement : DAO : failed addUserRegistration : error : ' + err);
    callback(err, null);
  } else if (pass.length > 6) {
    var err = new Error('Password should contain maximum 6 digits');
    err.status = 400;
    logger.error('userManagement : DAO : failed addUserRegistration : error : ' + err);
    callback(err, null);
  } else {
    var json = {};
    json.username = req.body.username;
    json.userpassword = req.body.password;
    json.mail = req.body.username;
    json.givenName = req.body.firstname;
    json.sn = req.body.lastname;
    json.telephoneNumber = req.body.telephoneNumber;
    json.companyId = req.headers['companyid'];
	
    Q.fcall(function() {
        var deferred = Q.defer();
        if (typeof(config.USERS_PASSWORD_MANAGEMENT) == 'undefined' || config.USERS_PASSWORD_MANAGEMENT == '' || config.USERS_PASSWORD_MANAGEMENT == 'INTERNAL') {
          deferred.resolve();
        } else {
          userRegistrationdelegate.addUserRegistration(req, res, function(err, addUserResponse) {
            if (err) {
              logger.error('userManagement : Controller : failed addUserRegistration : error : ' + err);
              deferred.reject(err);
            } else {
              deferred.resolve(addUserResponse);
            }
          });
        }
        return deferred.promise;
      })
      .then(function(addUserResponse) {
        var deferred = Q.defer();
		var tokenId='';
		if(addUserResponse!=undefined){
			tokenId = addUserResponse.tokenId;
		}		        
        addUser(tokenId, req, res, function(err, data) {
          if (err) {
            logger.error('userManagement : Controller : failed addUser : error : ' + err);
            deferred.reject(err);
          } else {
            data.tokenId = tokenId;
            deferred.resolve(data);
          }
        });
        return deferred.promise;
      })
      .then(function(addUserResponse) {
        var deferred = Q.defer();
        tokenId = addUserResponse.tokenId;        
        addUserOnRadia(json, tokenId, req, res, function(err, data) {
          if (err) {
            logger.error('userManagement : Controller : failed addUserOnRadia : error : ' + err);
            deferred.reject(err);
          } else {
            deferred.resolve(addUserResponse);
          }
        });
        return deferred.promise;
      })
      .then(function(addUserResponse) {
        var deferred = Q.defer();
        addUserPostProcessAdapter.processMethod(req, function(err, data) {
          if (err) {
            logger.error('userManagement : Controller : failed processMethod : error : ' + err);
            deferred.reject(err);
          } else {
            deferred.resolve(addUserResponse);
          }
        });
        return deferred.promise;
      })
      .then(function(addUserResponse) {
        var deferred = Q.defer();
        assignRoles(req, res, addUserResponse, function(err, data) {
          if (err) {
            logger.error('userManagement : Controller : failed assignRoles : error : ' + err);            
			deferred.reject(err);
          } else {
			  deferred.resolve(addUserResponse);			 
          }
        });
		return deferred.promise;
      })
	  .then(function(addUserResponse) {
        var deferred = Q.defer();
		req.body.username = json.username;
        userRegistrationdelegate.sendEmail(req, res,addUserResponse,function(err,data){
			if (err) {
            logger.error('userManagement : Controller : failed sendEmail : error : ' + err);
            return callback(err);
          }
		  else{
			  var resp={};
			  resp.userId=addUserResponse.userId;
			  resp.username=addUserResponse.username;
			  resp.companyId=addUserResponse.companyId;
			  resp.firstname=addUserResponse.firstname;
			  resp.lastname=addUserResponse.lastname;
            return callback(null, resp);
		  }
		});        
      })
      .fail(function(err) {
        return callback(err);
      })
      .done();
  }
};

var addUser = function(tokenId, req, res, callback) {
  userRegistrationDao.addUserRegistration(req, res, function(err, data) {
    var response = data;
    if (err) {
      //rollback forgeRock	  
      userRegistrationdelegate.deleteUser(tokenId,req, res, function(error, data) {
        if (error) {
          callback(error, null);
        } else {
          callback(err, null);
        }
      })
    } else {
      callback(null, data);
    }
  })
}

var addUserOnRadia = function(json, tokenId, req, res, callback) {
  provisionUser.provisionUser(json, function(err) {
    if (err) {
      logger.error('userManagement : controller : failed UserRegistrationDelegate: error : ' + err);
      callback(err,null);
    } else {
      callback(null, 'Provision User created successfully');
    }
  })
}

var assignRoles = function(req, res, response, callback) {	
  var userName = req.body.username;
  //check if default flag is presen or not in roles
  roleDao.getRolesByDefaultCustomerFlag(req, res, function(err, roleData) {
    if (err) {
      logger.error('userManagement : controller : failed getRolesByFlag: error : ' + err);
      callback(err, null);
    } else {
		roleData.forEach(function(roles,index, array){			
		
      getUserReq = req;
      getUserReq.params.rolename = roles.roleName;
      userRoleDao.getUsersByRoleName(getUserReq, res, function(err, getUsersResponse) {
        if (err) {
          logger.error('userManagement : controller : failed getUsersByRoleName: error : ' + err);
          callback(err, null);
        } else {
          //get Token
          ForgeRockGetToken.getToken(function(err, tokenData) {
            if (err) {
              logger.error('userManagement : controller : failed getToken: error : ' + err);
              callback(err, null);
            } else {
              var usernamesArray = [];
              usernamesArray = getUsersResponse[0].username;
              usernamesArray.push(userName);

              updateRoleReq = req;
              updateRoleReq.headers['access-token'] = tokenData.tokenId;
              updateRoleReq.params.rolename = roles.roleName;
              updateRoleReq.body.username = usernamesArray;			  
			  
              userRoleDelegate.updateRoleUsersByRoleName(updateRoleReq, res, function(err, updateroleresponse) {
                if (err) {					
                  logger.error('userManagement : controller : failed updateRoleUsersByRoleName: error : ' + err);
                  callback(err, null);
                } else {
					logger.info('userManagement : controller : updateRoleUsersByRoleName Delegate successful !');
					var updateRequest=req;
					updateRequest.body.usernamesArray= updateroleresponse.groupUsers;
					updateRequest.params.rolename= updateroleresponse.groupName;
											                  
                  userRoleDao.updateRoleUsersByRoleName(updateRequest, res, function(err, updateRoleResposne) {
                    if (err) {						
                      logger.error('userManagement : controller : failed updateRoleUsersByRoleName: error : ' + err);
                      callback(err, null);
                    } else {
                      logger.info('userManagement : controller : updateRoleUsersByRoleName DAO successful !');
                      //if admin role present
                      if (req.body.role != undefined || req.body.role != null) {
                        getAdminUserReq = req;
                        getAdminUserReq.params.rolename = req.body.role;
                        userRoleDao.getUsersByRoleName(getAdminUserReq, res, function(err, getAdminUsersResponse) {
                          if (err) {
                            logger.error('userManagement : controller : failed getUsersByRoleName: error : ' + err);
                            callback(err, null);
                          } else {
                            var AdminuserNamesArray = [];
                            AdminuserNamesArray = getAdminUsersResponse[0].username;
                            AdminuserNamesArray.push(userName);

                            updateAdminRoleReq = {};
                            updateAdminRoleReq.headers = {};
                            updateAdminRoleReq.params = {};
                            updateAdminRoleReq.body = {};
                            updateAdminRoleReq.headers['access-token'] = tokenData.tokenId;
                            updateAdminRoleReq.params.rolename = req.body.role;
                            updateAdminRoleReq.body.username = AdminuserNamesArray;

                            userRoleDelegate.updateRoleUsersByRoleName(updateAdminRoleReq, res, function(err, updateroleresponse) {
                              if (err) {
                                logger.error('userManagement : controller : failed updateRoleUsersByRoleName: error : ' + err);
                                callback(err, null);
                              } else {
                                userRoleDao.updateRoleUsersByRoleName(updateAdminRoleReq, res, function(err, updateRoleResposne) {
                                  if (err) {
                                    logger.error('userManagement : controller : failed updateRoleUsersByRoleName: error : ' + err);
                                    callback(err, null);
                                  } 
									if(index === array.length-1) {											
											logger.info('userManagement : Controller : updateRoleUsersByRoleName successful !');	
											return callback(null, response);
										}	
                                })
                              }
                            })
                          }
                        })
                      } else {						  						  					  						
						  if(index === array.length-1) {											
							logger.info('userManagement : Controller : updateRoleUsersByRoleName successful !');	
											return callback(null, response);
						}							  
                      }
                    }
                  })
                }
              });
            }
          })
        }
      })
	  });
    }
  })
}

/*
 ** generate random password
 */
function getRandomPassword() {
  var pass = Math.floor(100000 + Math.random() * 900000);
  return pass;
}

/*
 **get User configured for the given company id
 */
var getUser = function(req, res, callback) {
  logger.info('userManagement : controller : received request : getUser : username : ' + req.params.username);
  userRegistrationDao.getUser(req, res, callback);
};

/*
 * Update User 
 */
var updateUser = function(req, res, callback) {
  logger.info('userManagement : controller : received request : updateUser : username : ' + req.params.username);
  userRegistrationDao.updateUser(req, res, callback);
};

/*
 *  Deletes an User
 */
var deleteUser = function(req, res, callback) {
  logger.info('userManagement : controller : received request : deleteUser : id : ' + req.params.username);
  userRegistrationDao.deleteUser(req, res, callback);
};

var validateActivationLink = function(req, res, callback) {
  logger.info('userManagement : controller : received request : validateActivationLink : body : ' + JSON.stringify(req.body));
  generateActivateTokenDAO.validateActivationLink(req, res, callback);
};

/*
 **get User by username
 */
var getUserByUsername = function(req, res, callback) {
  logger.info('userManagement : controller : received request : getUserByUsername : username : ' + req.params.username);
  userRegistrationDao.getUserByUsername(req, res, callback);
};

/*
 * Generate Captcha Code
 */
var generateCaptcha = function(req, res, callback) {
  logger.info('Captcha code generation');

  var value = parseInt(Math.random() * 9000 + 1000);
  var p = new captchapng(80, 30, value); // width,height,numeric captcha

  p.color(0, 0, 0, 0); // First color: background (red, green, blue, alpha)
  p.color(80, 80, 80, 255); // Second color: paint (red, green, blue, alpha)

  var img = p.getBase64();
  var imgbase64 = new Buffer(img, 'base64');
  var data = {
    "captchaImage": imgbase64,
    'captchaCode': value
  }
  callback(null, data);
};

/*
 * getAllUsers
 */
var getAllUsers = function(req, res, callback) {
  logger.info('userManagement : controller : received request : getAllUsers : ');
  userRegistrationDao.getAllUsers(req, res, callback);
};

/*
 * Reset Password
 */
var resetPassword = function(req, res, callback) {
  logger.info('userManagement : controller : received request : resetPassword  ');
  registrationDao.getAllUserByUsername(req, res, function(err, data) {
    if (err) {
      logger.error('Registration : DAO : failed resetPassword : error : ' + err);
      callback(err, null);
    } else {
      logger.info('Registration : DAO : resetPassword successful !');
      if (data[0].verified) {
        resetPasswordDelegate.resetPassword(req, res, callback);
      } else {
        var err = new Error('User Not Verified');
        err.status = 500;
        logger.error('Registration : DAO : failed resetPassword : error : ' + err);
        callback(err, null);
      }
    }
  });
};

/*
 * Forgot Password Reset
 */
var forgotPasswordReset = function(req, res, callback) {
  logger.info('userManagement : controller : received request : forgotPasswordReset' + JSON.stringify(req.body));
  forgotPasswordDelegate.forgotPasswordReset(req, res, function(err, response) {
    if (err) {
      logger.error('Registration : DAO : failed forgotPasswordReset : error : ' + err);
      callback(err, null);
    } else {
      logger.info('Registration : DAO : forgotPasswordReset successful !');
      callback(null, response);
    }
  });
};

module.exports.addUserRegistration = addUserRegistration;
module.exports.getUser = getUser;
module.exports.updateUser = updateUser;
module.exports.deleteUser = deleteUser;
module.exports.validateActivationLink = validateActivationLink;
module.exports.generateCaptcha = generateCaptcha;
module.exports.getUserByUsername = getUserByUsername;
module.exports.getAllUsers = getAllUsers;
module.exports.resetPassword = resetPassword;
module.exports.forgotPasswordReset = forgotPasswordReset;
