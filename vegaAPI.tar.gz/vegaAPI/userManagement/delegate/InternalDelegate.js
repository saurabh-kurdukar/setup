var logger = require('../../common/logger').log;
var userRegistrationDao = require('../dao/UserRegistrationDAO');
var config = require('../../common/Config');
var provisionUser = require('./../../provision/controller/provision-user');
var userRegistrationDelegate = require('./UserRegistrationDelegate');

/*
 * call userRegistration
 */

var addUserRegistration = function(req, res, callback) {
  logger.info('userManagement : delegate : received request : addUserRegistration : body : ' + JSON.stringify(req.body));

  var reqBody = req.body;

  var uname = reqBody.username;
  var json = {};

  json.username = reqBody.username;
  json.userpassword = reqBody.password;
  json.mail = reqBody.username;
  json.givenName = reqBody.firstname;
  json.sn = reqBody.lastname;
  json.telephoneNumber = reqBody.telephoneNumber;
  json.companyId = req.headers['companyid'];

  userRegistrationDao.addUserRegistration(req, res, function(err, data) {
    var response = data;
    if (err) {
      logger.error('userManagement : delegate : failed UserRegistrationDelegate: error : ' + err);
      callback(err, null);
    } else {
      provisionUser.provisionUser(json, function(err) {
        if (err) {
          logger.error('userManagement : delegate : failed UserRegistrationDelegate: error : ' + err);
          //rollback if the provision user fails
          var req2 = req;
          req2.params.username = uname;

          userRegistrationDao.deleteUser(req2, res, function(error, data) {
            if (error) {
              callback(error, null);
            } else {
              logger.info("deleted successfully DAO........" + data);
              callback(err, null);
            }
          })
        } else {
          userRegistrationDelegate.sendEmail(req, res, callback, response);
        }
      });
    }
  });
};

module.exports.addUserRegistration = addUserRegistration;
