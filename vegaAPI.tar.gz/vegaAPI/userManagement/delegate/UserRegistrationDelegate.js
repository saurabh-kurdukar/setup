var logger = require('../../common/logger').log;
var userRegistrationDao = require('../dao/UserRegistrationDAO');
var request = require('request');
var config = require('../../common/Config');
var GenerateActivateTokenDAO = require('../dao/GenerateActivateTokenDAO');
var provisionUser = require('./../../provision/controller/provision-user');
var RabbitMQ = require('../../common/RabbitMQ');
var sMTPEmailListener = require('../dao/SMTPEmailListener');
var templateDao = require('../../template/dao/TemplateDAO');
var qr = require('qr-image');
var fs = require('fs');
var messagedao = require('../../sendMessage/dao/MessageDAO');
var passwordHash = require('password-hash');
var messageId = 0;
var roleDao = require('../../roles/dao/RoleDAO');
var userRoleDao = require('../../userRoles/dao/UserRoleDAO');
var userRoleDelegate = require('../../userRoles/delegate/UserRoleDelegate');
var ForgeRockGetToken = require('../../common/ForgeRockGetToken');
var userattributesdao = require('../../userAttributes/dao/UserAttributeDAO');
/*
 * call forgeRock
 */

var addUserRegistration = function(req, res, callback) {
  logger.info('userManagement : delegate : received request : addUserRegistration : body : ' + JSON.stringify(req.body));

  var reqBody = req.body;
  var accessToken;
  var q = 'sendgridqueue';

  var uname = reqBody.username;
  var pass = reqBody.password;
  var fname = reqBody.firstname;

  var proxyurl = config.NETWORK_PROXY + ":" + config.NETWORK_PROXY_PORT;
  var json = {};

  var UserName = reqBody.username;
  json.username = reqBody.username;
  json.userpassword = reqBody.password;
  json.mail = reqBody.username;
  json.givenName = reqBody.firstname;
  json.sn = reqBody.lastname;
  json.telephoneNumber = reqBody.telephoneNumber;
  json.companyId = req.headers['companyid'];

  var token;

  //forgeRock call for auth
  var proxyurl = config.NETWORK_PROXY + ":" + config.NETWORK_PROXY_PORT;
  request({
    //'proxy': proxyurl,
    url: config.FORGRROCK_URL + '/api/v1/users/authenticate',
    method: 'POST',
    headers: {
      'Content-Type': 'application/json'
    },
    json: {
      "userId": config.FORGEROCK_USERID,
      "password": config.FORGEROCK_PASSWORD
    }
  }, function(error, response, body) {
    if (error) {
      callback(error, null);
    } else {
      tokenId = body.tokenId

      //forgeRock call for create user
      request({
        url: config.FORGRROCK_URL + '/api/v1/users',
        //'proxy': proxyurl,
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': tokenId
        },
        json: json
      }, function(error, response, body) {
        if (error) {
          logger.error('userManagement : delegate : failed UserRegistrationDelegate: error : ' + err);
          callback(error, null);
        } else {
          logger.info('userManagement : delegate :  create user successful !' + JSON.stringify(body));
          if (body.code == 401) {
            callback(body, null);
          } else if (body.code == 409) {
            callback(body, null);
          } else {
            body.tokenId = tokenId;
            callback(null, body);
          }
        }
      });
    }
  });
}

/*
 *delete user
 */
var deleteUser = function(tokenId, req, res, callback) {
  logger.info('userManagement : Delegate : received request : deleteUser');

  var proxyurl = config.NETWORK_PROXY + ":" + config.NETWORK_PROXY_PORT;
  //forgeRock call
  request({
    //'proxy': proxyurl,
    url: config.FORGRROCK_URL + '/api/v1/users/' + req.body.username,
    method: 'DELETE',
    headers: {
      'Content-Type': 'application/json',
      'Authorization': tokenId
    }
  }, function(error, response, body) {
    if (error) {
      callback(error, null);
    } else {
      if (body.code == 404) {
        callback(body, null);
      } else {
        callback(null, body);
      }
    }
  });
}


function sendEmail(req, res, response, callback) {
  var companyId = req.headers['companyid'];
  var reqBody = req.body;
  var accessToken;
  var q = 'sendgridqueue';
  var uname = reqBody.username;
  var pass = reqBody.password;
  var fname = reqBody.firstname;

  accessToken = GenerateActivateTokenDAO.getActivateToken();
  GenerateActivateTokenDAO.saveToken(uname, accessToken, function(err, doc) {
    logger.info("Record saved");
  });

  //get qr code
  var queryString = `name=${req.body.username}&password=${req.body.password}&server=${config.RADIA.HOSTNAME}&port=${config.RADIA.PORT}`,
    url = `${config.RADIA.AGENT_URL}?${new Buffer(queryString).toString('base64')}`;

  var qr_image = qr.image(url);
  var qr_file_path = config.QR_IMAGE_BASE_PATH + '/qr_' + new Date().getTime() + '.png';
  qr_image.pipe(fs.createWriteStream(qr_file_path));

  var splitPath = qr_file_path.split('/');
  //save Qr Image
  var saveQrImageReq = {};
  saveQrImageReq.body = {};
  saveQrImageReq.body.username = req.body.username;
  saveQrImageReq.body.attributes = [];
  saveQrImageReq.body.attributes.push({
    "attributeKey": "ENTERPRISE_APPSTORE_QR_CODE",
    "attributeValue": splitPath[4] + '/' + splitPath[5]
  });
  userattributesdao.addNewUserAttributes(saveQrImageReq, res, function(err, data) {
    if (err) {
      logger.error('userManagement : delegate : failed addNewUserAttributes : error : ' + err);
    } else {
      logger.info('userManagement : delegate : addNewUserAttributes successful !');
    }
  })

  var req1 = req;

  req1.headers['companyid'] = config.USER_REG_TEMPLATE_COMPANY_ID;
  req1.body.version = config.USER_REG_VERSION;
  req1.body.jsonData = {
    "username": uname,
    "password": pass,
    "token": accessToken + "&u=U",
    "givenname": fname,
    "serverurl": config.SERVER_HOST,
    "radiaurl": config.RADIA.HOSTNAME,
    "radiadownloadlink": config.RADIA.AGENT_URL
  };
  req1.params.id = config.USER_REG_TEMPLATE_ID;
  //Template

  templateDao.getFilledTemplateById(req1, res, function(err, data) {
    if (err) {
      callback(err, null);
    } else {
      //Rabbit MQ
      var email_data = JSON.stringify({
        'template': data,
        'qr_file_path': qr_file_path
      });

      RabbitMQ.getConnection(function(connection) {
        connection.createChannel(function(err, ch) {
          ch.assertQueue(q, {
            durable: false
          });
          ch.sendToQueue(q, new Buffer(email_data));
          console.log(" [x] Message Sent");

          //save sent message to db
          var req3 = req;
          //encrypt password
          var hashedPassword = passwordHash.generate(req3.body.username + '_' + req3.body.password);

          req3.body.MessageType = 'Email';
          req3.headers['companyid'] = companyId;
          req3.body.Message = email_data;
          req3.body.To = req.body.username;
          messagedao.addNewMessage(req3, res, function(err, data) {
            if (err)
              logger.error('User : DAO : failed addNewMessage : error : ' + err);
            else {
              logger.info('User : DAO : addNewMessage successful !');
              messageId = data.messageId;
            }
          })
          setTimeout(function() {
            connection.close();
          }, 500);
        });
      });
      logger.info('userManagement : Delegate :  provision users successfull');
      callback(null, response);
    }
  })
}

var getMessageId = function() {
  return messageId;
}

module.exports.addUserRegistration = addUserRegistration;
module.exports.deleteUser = deleteUser;
module.exports.sendEmail = sendEmail;
module.exports.getMessageId = getMessageId;
