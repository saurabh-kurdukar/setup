var db = require('../../common/MongoDbConnection');
var Otp= require('../models/Otp');
var userRegistrationDAO= require('../dao/UserRegistrationDAO');
var logger = require('../../common/logger').log;
var audit = require('../../common/Audit').audit;
var otplib = require('otplib/lib/totp');
var config= require('../../common/Config');
var SMSGatewayDAO= require('../../smsGateway/dao/SMSGatewayDAO');
var Decrypt= require('../../common/EncryptDecrypt');
var request=require('request');
var audit = require('../../common/Audit').audit;
var templateDao= require('../../template/dao/TemplateDAO');

/*
 * logging format followed: logger.info(<module_name>: <component name> : <description> : [<long_description>] : <data/params/errors>);
 */


/*
 * Add new otp details
 */
var addOtpDetails = function(req, res, callback) {
	logger.info('otp : DAO : received request : addOtpDetails : body : '
			+ JSON.stringify(req.body));
	
	var reqBody = req.body;
	var username = req.headers['username'];	
	var appId = req.headers['appid'];
	var otp = new Otp();
	
	//OTP generation
	var secret = otplib.utils.generateSecret();
	var code = otplib.generate(secret);
	console.log(code);			
		
		otp.setAppId(appId);
		otp.setUsername(username);	
		otp.setCountryCode(reqBody.CountryCode);
		otp.setMobileNo(reqBody.MobileNo);
		otp.setOtp(code);		
		
		otp.save(function(err, data) {
			if (err) {
				logger.error('otp : DAO : failed addOtpDetails : error : ' + err);
				callback(err, null);
			} else if(data != null){
				logger.info('otp : DAO : addOtpDetails successful !');
				
				//getTemplate for OTP
				
				req.body.version= config.OTP_VERSION;
				req.body.jsonData= {"Otp":code};
				req.params.id= config.OTP_TEMPLATE_ID;																													
				
				templateDao.getFilledTemplateById(req,res,function(err,data){
					if(err)
					{
						callback(err,null);
					}
					else
					{						
						//send SMS with OTP
						getSmsConfig(code,data,req ,res,function(err,data){
							if(err)
								callback(err,null)
							else{
								req.body.status='In-Process';							
								updateOtpStatus(req,res,function(err,data){
									if(err)
										callback(err,null);
									else
										callback(null,'OTP Sent');
								})
							}
						} );   
						
				/*		var account_sid = "AC06c0f5b24d4c422efe28c3e822e42146";
var auth_token = "c0ddfd4a2e383709d80e39cb8e1b66df";
var twilio_number = "+14348300060";

var phone_number = "+91"+req.body.MobileNo;
	
	var client = require('twilio')(account_sid, auth_token);

	
	client.sendSms({
        to: phone_number,
        from: twilio_number,
        //body: 'Your verification code is: ' + code
		body : data
    }, function(twilioerr, responseData) {
      if (twilioerr) { 
	  console.log("got error , remove number from db "+JSON.stringify(twilioerr));	  
callback(twilioerr,null);	  
      } else {
		  console.log(responseData);	    
		console.log("Sent SMS successfully ");	
		
		req.body.status='In-Process';							
								updateOtpStatus(req,res,function(err,data){
									if(err)
										callback(err,null);
									else
										callback(null,'OTP Sent');
								})
		
		
callback(null,'OTP Sent');		
      }
    }); */



					}
					
				})
								
			} else {
				var err = new Error('Failed to add new otp details');			
				logger.error('otp : DAO : failed addOtpDetails : error : '+ err);
				callback(err, null);
			}
		});							
};


/*
 * update OTP Status
 */
var updateOtpStatus = function(req, res, callback) {
	logger.info('otp : DAO : received request : updateOtpStatus : (companyId: '+req.headers['companyid']+')');
	
	//find otp by username from OTP collection
	var username = req.headers['username'];	
	
					/*
					 * Callback function after getting original record to update with new values.
					 */ 
					var callbackUpdate = function(err, data) {	
						if(err) {
							logger.error('otp : DAO : failed updateOtpStatus : error :' + err);
							callback(err, null);
						} else if(data != null) {
							/*
							 *	Compare updatable fields values in db with request data
							 *	Add those fields in temproary object which are having new values
							 */			
							var otpdata = data;
							var json = {};
							var updatedData = [];																					
														
							if (req.body.status && otpdata['status'] != req.body.status) {
								json.status = req.body.status;
								var obj = {};
								obj.column = 'status';
								obj.oldValue = otpdata['status'];
								obj.newValue = req.body.status;
								obj.identifier = 'Platform_otp_'+username;
								obj.modifiedBy = 'admin';
								obj.modifiedOn = new Date();
								updatedData.push(obj);
							}
									
							if (req.body.updatedBy && otpdata['updatedBy'] != req.body.updatedBy) {
								json.updatedBy = req.body.updatedBy;
								var obj = {};
								obj.column = 'updatedBy';
								obj.oldValue = otpdata['updatedBy'];
								obj.newValue = req.body.updatedBy;
								obj.identifier = 'Platform_otp_'+username;
								obj.modifiedBy = 'admin';
								obj.modifiedOn = new Date();
								updatedData.push(obj);
							}
							
							/*
							 *	Update the data to database 
							 */
							if (Object.keys(json).length != 0) {	
								json.updatedOn = new Date();								
								logger.info('otp : DAO : updateOtpStatus : updating data : ' + JSON.stringify(json));
								console.log(JSON.stringify(json));
								Otp.findOneAndUpdate({
									'username' : username
								}, json, {
									'new' : true
								// returns updated entity if update successful, if false then old entry
								}, function(err, data) {
									if (err) {
										logger.error('otp : DAO : failed updateOtpStatus : error :' + err);
										console.log(err);
										callback(err, null);
									} else {
										if(data != null) {
											logger.info('otp : DAO : updateOtpStatus successful !');		
											/*
											 *	Call audit function for changed data 
											 */
											audit(req, res, updatedData);
											/*
											 *	Call function to send response to client 
											 */
											callback(null, data);
										} else {
											var err = new Error('Bad request data');
											logger.error('otp : DAO : failed updateOtpStatus : error :' + err);
											callback(err, null);
										}
									}
								});
							} else {
								var err = new Error('Cannot update data');
								logger.error('otp : DAO : failed updateOtpStatus : error :' + err);
								callback(err, null);
							}
						} else {
							var err = new Error('Failed to get otp details');
							logger.error('otp : DAO : failed updateOtpStatus : error :' + err);
							callback(err, null);
						}
					}
					
					/*
					 * Get the original record from db before update.
					 */ 
					getOtpByUsername(req, res, callbackUpdate);																											
};

/*
 * get SMS Config
 */
var getSmsConfig= function(otp,templateMessage,req ,res,callback){
		
	SMSGatewayDAO.getSMSServerDetails(req, res, function(err,data){				
		if (err) {
			callback(err, data);
		} 
		else {
			if (data.length != 0) {						
				var url= data.SMSGwatewayURL;
				 var httpMethod= data.HTTPMethod;
				 var contentType=data.contentType;				 					 			 
				 var attributes= data.attributes;					 
				 
				 //form Url							    
					headerName='';
					 var j=0;
					 var decpwd='';
					 var headerslist = {};					 					 					
					 
					//iterate over attributes
					 for(var i = 0; i < attributes.length; i++) {					 
						    var obj = attributes[i];
						   
						    if(obj.attributeParamType=="queryParam")
						    	{
						    if(j==0)	
						    	{
						    	if(obj.attributeKey=="password")
						    		{		    		
						    		//decrypt password
						    		decpwd=Decrypt.decryption(obj.attributeValue);		    		
						    		 url +="?"+obj.attributeKey+"="+decpwd;
						    		 j++;
						    		}
						    	else{
						    	url +="?"+obj.attributeKey+"="+obj.attributeValue;
						    	j++;}
						    	}
						    else	
						    	{
						    	if(obj.attributeKey=="password")
					    		{
					    		//decrypt password
					    		 decpwd= Decrypt.decryption(obj.attributeValue);	    		
					    		 url +="&"+obj.attributeKey+"="+decpwd;	    		 
					    		}
						    	else		    		
						    url +="&"+obj.attributeKey+"="+obj.attributeValue;		    	
						    	}
					 }
						    else
						    	{
						    	if(obj.attributeKey=="password")
						    		{
						    		//decrypt password
						    		decpwd= Decrypt.decryption(obj.attributeValue);
						    		 headerName= obj.attributeKey;		   
						    		 headerslist[headerName] = decpwd;      
						    		}
						    	else
						    		{
						    	headerName= obj.attributeKey;		    		
						    	headerslist[headerName] = obj.attributeValue;
						    		}
						    	}
					 }		
					 if(j==0)
						 url +="?"+"mobileno="+req.body.CountryCode +req.body.MobileNo + "&message=" +templateMessage;
					 else		 
					 url +="&mobileno="+req.body.CountryCode + req.body.MobileNo + "&message=" +templateMessage;			
					console.log(url);		
					console.log(headerslist);	
					
					//calling sendSMS					
					
					
					if(config.NETWORK_PROXY_ENABLE)
					{
					var proxyurl=config.NETWORK_PROXY+":"+config.NETWORK_PROXY_PORT;		
						
					request({
						headers: headerslist ,
						method: httpMethod,
						'url':url
						//Proxy block to be removed
						,'proxy':proxyurl
						}, function (error, response, body) {		
							if (!error){
								console.log(body);	
								logger.info('otp : DAO : sendSMS successful !'+ body);											
								callback(null,body);
							}
							else{								
								console.log(error);		
								logger.error('otp : DAO : failed sendSMS : error : '+error);   								
								callback(error,null);
							}
						});	 //Proxy block ends here
			}
			else
			{
				request({
						headers: headerslist ,
						method: httpMethod,
						'url':url						
						}, function (error, response, body) {		
							if (!error){
								console.log(body);	
								logger.info('otp : DAO : sendSMS successful !'+ body);											
								callback(null,body);
							}
							else{								
								console.log(error);		
								logger.error('otp : DAO : failed sendSMS : error : '+error);   								
								callback(error,null);
							}
						});	
			}
				 
					
			} else {
				var err = new Error('Invalid company id');
				err.status = 404;
				logger.error('otp : DAO : failed : error : '+ err);
				callback(err, data);
			}
		}
	});	
	
}

/*
 * verify OTP
 */
var verifyOtp = function(req, res, callback) {
	logger.info('otp : DAO : received request : updateOtpStatus : (companyId: '+req.headers['companyid']+')');
	
	//find otp by username from OTP collection
	var username = req.headers['username'];
	var userEnteredOtpvalue= req.headers['otp'];
	
	Otp.find({
		'username' : username
	}, function(err, data) {
		if (err) {
			console.log(err);
			logger.error('otp : DAO : failed getOtp : error : ' + err);
			callback(err, null);
		} else {
			if (data.length != 0) {
				logger.info('otp : DAO : getOtp successful !');
				var otpVal= data[0].otp;				
				
				//check for expired OTP
				var otpTimeLimit= config.OTP_TIME_LIMIT;
				var otpCreatedDate= data[0].createdOn;				
				console.log(otpCreatedDate);
				var currentDate= new Date();
				console.log(currentDate);
				var timeDiff = Math.abs(currentDate.getTime() - otpCreatedDate.getTime());
				console.log(timeDiff);
				var timeDiffInMin = Math.floor((timeDiff/1000/60) << 0);
				console.log(timeDiffInMin);
				
				if(otpVal==userEnteredOtpvalue)
				{	
					if(otpTimeLimit>timeDiffInMin)
					{
						req.body.status='Verified';	
						req.body.updatedBy= username;
						updateOtpStatus(req,res,function(err,data){
							if(err)
								callback(err,null);
							else
								callback(null,'OTP verified');
						})							
					}
					else
						{
						//update status as expired
						req.body.status='Expired';						
						updateOtpStatus(req,res,function(err,data){
							if(err)
								callback(err,null);
							else
								callback(null,'OTP expired');
						})							
						}
				}
				else
					{
						var err = new Error('Invalid OTP');
				err.status = 500;
				logger.error('otp : DAO : failed getOtp : error : '+ err);				
					callback(err,null);
					}								
			} else {
				var err = new Error('Invalid username');
				err.status = 404;
				logger.error('otp : DAO : failed getOtp : error : '+ err);
				callback(err, null);
			}
		}
	});
	
};



/*
* Get otp by username
*/
var getOtpByUsername = function(req, res, callback) {
	var username= req.headers['username'];
	logger.info('otp : DAO : received request : getOtpByUsername : username : '+username);
	Otp.find({
		'username' : username
	}, function(err, data) {
		if (err) {
			console.log(err);
			logger.error('otp : DAO : failed getOtp : error : ' + err);
			callback(err, null);
		} else {
			if (data.length != 0) {
				logger.info('otp : DAO : getOtp successful !');				
				callback(null, data[0]);
			} else {
				var err = new Error('Invalid username');
				err.status = 404;
				logger.error('otp : DAO : failed getOtp : error : '+ err);
				callback(err, null);
			}
		}
	});
};


module.exports.addOtpDetails = addOtpDetails;
module.exports.updateOtpStatus= updateOtpStatus;
module.exports.verifyOtp= verifyOtp;
