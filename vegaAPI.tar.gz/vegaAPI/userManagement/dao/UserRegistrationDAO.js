var db = require('../../common/MongoDbConnection');
var UserRegistration = require('../models/UserRegistration');
var Company = require('../../company/models/Company');
var encryptdecrypt = require('../../common/EncryptDecrypt');
var logger = require('../../common/logger').log;
var crypto = require('crypto');
var userlogin = UserRegistration.UserLoginInfo;
var GenerateActivateTokenDAO = require('./GenerateActivateTokenDAO');
var config = require('../../common/Config');
var request = require('request');
var RabbitMQ = require('../../common/RabbitMQ');
var sMTPEmailListener = require('./SMTPEmailListener');
var templateDao = require('../../template/dao/TemplateDAO');
var companyDao = require('../../company/dao/CompanyDAO');
var passwordHash = require('password-hash');


var q = 'sendgridqueue';
var uname;
var accessToken;

/*
 *	Add new User Registration
 */
var addUserRegistration = function(req, res, callback) {

  logger.info('userManagement : DAO : received request : addUserRegistration : body : ' + JSON.stringify(req.body));

  var reqBody = req.body;

  //GenerateActivateToken
  var token = UserRegistration.GenerateActivateToken;

  var pass = passwordHash.generate(reqBody.username + '_' + reqBody.password);

  if (config.USERS_PASSWORD_MANAGEMENT === 'EXTERNAL') {
    pass = "";
  }

  //UserLoginInfo
  var userlogin = UserRegistration.UserLoginInfo;
  var userLoginInfo = new userlogin();
  var usernm = reqBody.username;
  uname = usernm;
  var companyid = req.headers['companyid'];
  var fname = reqBody.firstname;

  if (!companyid) {
    var err = new Error('Provide companyid from header');
    logger.error('userManagement : DAO : failed addUserRegistration : error : ' + err);
    callback(err, null);
  } else {
    var appid = req.headers['appid'];
    var experienceid = req.headers['experienceid'];
    var username = reqBody.username;

    userLoginInfo.setusername(reqBody.username);
    userLoginInfo.setpassword(pass);
    userLoginInfo.setcompanyId(companyid);
    userLoginInfo.setappId(appid);
    userLoginInfo.setexperienceId(experienceid);

    Company.find({
      'companyId': companyid
    }, function(err, data) {
      if (err) {
        logger.error('userManagement : DAO : failed addUserRegistration : error : ' + err);
        callback(err, null);
      } else {
        if (data.length != 0) {
          var json = {};
          var json1 = {};

          userLoginInfo.save(function(err, data) {
            if (err) {
              logger.error('userManagement : DAO : failed addUserRegistration : error : ' + err);
              callback(err, null);
            } else {
              logger.info('userManagement : DAO : addUserRegistration successful !');

              //find userid by username from userlogin collection						
              userlogin.find({
                'username': reqBody.username
              }, function(err, data) {
                if (err) {
                  logger.error('userManagement : DAO : failed finduserIdbyusername : error : ' + err);
                  callback(err, null);
                } else {
                  if (data.length != 0) {

                    userid = data[0].userId;
                    username = data[0].username;

                    json.userId = data[0].userId;
                    json.username = data[0].username;
                    json.companyId = data[0].companyId;

                    //store user Profile details
                    var userProfile = new UserRegistration.UserProfile();

                    userProfile.setuserId(data[0].userId);
                    userProfile.setfirstname(reqBody.firstname);
                    userProfile.setlastname(reqBody.lastname);
                    userProfile.setgender(reqBody.gender);
                    userProfile.setdateOfBirth(reqBody.dateOfBirth);
                    userProfile.settermsAndConditions(reqBody.termsAndConditions);
                    userProfile.setCreatedBy(reqBody.CreatedBy);
                    userProfile.setCreatedOn(new Date());
                    userProfile.setUpdatedBy(reqBody.UpdatedBy);
                    userProfile.setUpdatedOn(new Date());
                    userProfile.settelephoneNumber(reqBody.telephoneNumber);
                    userProfile.setusername(reqBody.username);
                    userProfile.setcompanyId(companyid);

                    userProfile.save(function(err, data) {
                      if (err) {
                        logger.error('userManagement : DAO : failed saveuserProfile : error : ' + err);

                        //rollback if userProfile fails to save
                        userlogin.remove({
                            'userId': userid
                          },
                          function(err, data) {
                            if (err) {
                              //console.log(err)
                              //callback(err, data);
                            } else {
                              //callback(err, data);																								
                            }
                          });
                        callback(err, null);
                      } else {
                        json.firstname = data.firstname;
                        json.lastname = data.lastname;
                        logger.info('userManagement : DAO : saveuserProfile successful !');
                        //update userCount
                        companyDao.incrementUserCounter(req.headers['companyid']);
                        callback(null, json);
                      }
                    });
                  } else {
                    var err = new Error('Invalid username');
                    err.status = 404;
                    logger.error('userManagement : DAO : failed finduserIdbyusername : error : ' + err);
                    callback(err, null);
                  }
                }
              });
            }
          });
        } else {
          var err = new Error('Invalid company id');
          err.status = 404;
          callback(err, data);
        }
      }
    });
  } //else validation
};

/*
 * get User configured for the given company id
 */
var getUser = function(req, res, callback) {
  logger.info('userManagement : DAO : received request : getUser : id : ' + req.params.username);

  //UserLoginInfo
  var userlogin = UserRegistration.UserLoginInfo;
  var userLoginInfo = new userlogin();

  var json = {};

  var companyid = req.headers['companyid'];
  var appid = req.headers['appid'];
  var experienceid = req.headers['experienceid'];

  //get userid from companyid ,appid,appgroupid and username
  var searchCriteria;

  if (!companyid) {
    var err = new Error('Provide company id from header');
    logger.error('userManagement : DAO : failed getUser : error : ' + err);
    callback(err, null);
  } else {
    userlogin.find({
        'username': req.params.username,
        'companyId': companyid,
      },
      function(err, data) {
        if (err) {
          logger.error('userManagement : DAO : failed getUser : error : ' + err);
          callback(err, null);
        } else {
          if (data.length != 0) {
            logger.info('userManagement : DAO : getUser successful !');
            var userid = data[0].userId;

            //get user profile by userid
            var userProfile = new UserRegistration.UserProfile();

            UserRegistration.UserProfile.find({
              'userId': userid
            }, function(err, data) {
              if (err) {
                logger.error('userManagement : DAO : failed getProfilebyuserid : error : ' + err);
                callback(err, null);
              } else {
                if (data.length != 0) {
                  logger.info('userManagement : DAO : getProfilebyuserid successful !');
                  json.userId = data[0].userId;
                  json.firstname = data[0].firstname;
                  json.lastname = data[0].lastname;
                  json.gender = data[0].gender;
                  json.dateOfBirth = data[0].dateOfBirth;
                  json.termsAndConditions = data[0].termsAndConditions;
                  json.CreatedBy = data[0].CreatedBy;
                  json.CreatedOn = data[0].CreatedOn;
                  json.UpdatedBy = data[0].UpdatedBy;
                  json.telephoneNumber = data[0].telephoneNumber;

                  userlogin.find({
                    'userId': data[0].userId
                  }, function(err, data) {
                    if (err) {

                      callback(err, null);
                    } else {
                      if (data.length != 0) {

                        json.username = data[0].username;
                        json.companyId = data[0].companyId;

                        callback(null, json);
                      } else {
                        var err = new Error('Invalid id');
                        err.status = 404;

                        callback(err, null);
                      }
                    }
                  });
                } else {
                  var err = new Error('Invalid userid id');
                  err.status = 404;
                  logger.error('userManagement : DAO : failed getProfilebyuserid : error : ' + err);
                  callback(err, null);
                }
              }
            });
          } else {
            var err = new Error('No record found');
            err.status = 404;
            logger.error('userManagement : DAO : failed getUser : error : ' + err);
            callback(err, null);
          }
        }
      });
  }
};

/*
 * Update User 
 */
var updateUser = function(req, res, callback) {
  logger.info('userManagement : DAO : received request : updateUser : username : ' + req.params.username + ' & body: ' + JSON.stringify(req.body));

  var json = {};
  var companyid = req.headers['companyid'];
  var appid = req.headers['appid'];
  var experienceId = req.headers['experienceid'];

  //UserLoginInfo
  var userlogin = UserRegistration.UserLoginInfo;
  var userLoginInfo = new userlogin();

  if (req.body.password) {
    var err = new Error('password will not update');
    logger.error('userManagement : DAO : failed updateUser : error : ' + err);
    callback(err, null);
  } else {
    userlogin.find({
        'username': req.params.username,
        'companyId': companyid,
      },
      function(err, data) {
        if (err) {
          logger.error('userManagement : DAO : failed getUserid : error : ' + err);
          callback(err, null);
        } else {
          if (data.length != 0) {
            logger.info('userManagement : DAO : getUserid successful !');

            var userid = data[0].userId;
            //get user profile by userid
            var userProfile = new UserRegistration.UserProfile();

            UserRegistration.UserProfile.find({
              'userId': userid
            }, function(err, data) {
              if (err) {
                logger.error('userManagement : DAO : failed getProfilebyuserid : error : ' + err);
                callback(err, null);
              } else {
                if (data.length != 0) {
                  logger.info('userManagement : DAO : getProfilebyuserid successful !');

                  //update data								
                  if (req.body.UpdatedBy) {
                    json.UpdatedBy = req.body.UpdatedBy;
                  }
                  if (req.body.UpdatedOn) {
                    json.UpdatedOn = new Date();
                  }
                  if (Object.keys(json).length != 0) {
                    json.updatedOn = new Date();
                    json.updatedBy = req.body.UpdatedBy;
                    logger.info('userManagement : DAO : updateuser : updating data : ' + JSON.stringify(json));
                    UserRegistration.UserProfile.findOneAndUpdate({
                      'userId': userid,
                    }, json, {
                      'new': true
                        // returns updated entity if update successful
                    }, function(err, data) {
                      if (err) {
                        logger.error('userManagement : DAO : failed updateuser : error :' + err);
                        callback(err, null);
                      } else {
                        if (data != null) {
                          logger.info('userManagement : DAO : updateuser successful !');
                          callback(null, data);
                        } else {
                          var err = new Error('Bad request data');
                          logger.error('userManagement : DAO : failed updateuser : error :' + err);
                          callback(err, null);
                        }
                      }
                    });
                  } else {
                    var err = new Error('Cannot update data');
                    logger.error('userManagement : DAO : failed updateuser : error :' + err);
                    callback(err, null);
                  }
                } else {
                  var err = new Error('invalid userid');
                  err.status = 404;
                  logger.error('userManagement : DAO : failed getProfilebyuserid : error : ' + err);
                  callback(err, null);
                }
              }
            });
          } else {
            var err = new Error('No record to update');
            err.status = 404;
            logger.error('userManagement : DAO : failed getUserid : error : ' + err);
            callback(err, null);
          }
        }
      });
  }
};

/*
 *  Deletes User
 */
var deleteUser = function(req, res, callback) {
  logger.info('userManagement : DAO : received request : deleteUser : (id: ' + req.params.username);

  //UserLoginInfo
  var userlogin = UserRegistration.UserLoginInfo;
  var userLoginInfo = new userlogin();

  //GenerateActivateToken
  var token = UserRegistration.GenerateActivateToken;

  var companyid = req.headers['companyid'];

  var callbackDelete = function(err, data) {
    if (err) {
      logger.error('userManagement : DAO : failed deleteUser : error :' + err);
      callback(err, data);
    } else {
      userlogin.find({
        'username': req.params.username,
        'companyId': companyid
      }, function(err, data) {
        if (err) {
          logger.error('userManagement : DAO : failed  : error : ' + err);
          callback(err, null);
        } else {
          if (data.length != 0) {
            logger.info('userManagement : DAO :  successful !');

            var userid = data[0].userId;

            userlogin.remove({
                'userId': userid
              },
              function(err, data) {
                if (err) {
                  callback(err, data);
                } else {
                  var userProfile = new UserRegistration.UserProfile();
                  UserRegistration.UserProfile.remove({
                      'userId': userid
                    },
                    function(err, data) {
                      if (err) {
                        callback(err, data);
                      } else {

                        //decrement UserCount
                        companyDao.decrementUserCounter(companyid);
                        callback(err, data);
                      }
                    });
                }
              });
          } else {
            var err = new Error('Invalid userid id');
            err.status = 404;
            logger.error('userManagement : DAO : failed  : error : ' + err);
            callback(err, null);
          }
        }
      });
    }
  };
  getUser(req, res, callbackDelete);
};

/*
 * get User Login details by username and CompanyId
 */
var getUserLoginDetails = function(req, res, callback) {
  logger.info('userManagement : DAO : received request : getUserLoginDetails');
  var username = req.headers['username'];
  var companyId = req.headers['companyid'];

  userlogin.find({
    'companyId': companyId,
    'username': username
  }, function(err, data) {
    if (err) {
      logger.error('userManagement : DAO : failed getUserLoginDetails : error : ' + err);
      callback(err, null);
    } else {
      if (data.length != 0) {
        logger.info('userManagement : DAO : getUserLoginDetails successful !');
        callback(null, data[0]);
      } else {
        var err = new Error('Invalid company id or username');
        err.status = 404;
        logger.error('userManagement : DAO : failed getUserLoginDetails : error : ' + err);
        callback(err, null);
      }
    }
  });
};

/*
 * 		Get users by company id
 */
var getUsersByCompanyId = function(req, res, callback) {
  logger.info('userManagement : DAO : received request : getUsersByCompanyId : id : ' + req.params.id);
  UserRegistration.UserProfile.find({
    'companyId': req.params.id
  }, function(err, data) {
    if (err) {
      logger.error('userManagement : DAO : failed getUsersByCompanyId : error : ' + err);
      callback(err, null);
    } else {
      if (data.length != 0) {
        logger.info('userManagement : DAO : getUsersByCompanyId successful !');
        callback(null, data);
      } else {
        var err = new Error('Invalid company id');
        err.status = 404;
        logger.error('userManagement : DAO : failed getUsersByCompanyId : error : ' + err);
        callback(err, null);
      }
    }
  });
};


var getUsername = function() {
  return uname;
}

/*
 * Get user by username
 */
var getUserByUsername = function(req, res, callback) {
  logger.info('userManagement : DAO : received request : getUserByUsername : id : ' + req.params.username);

  userlogin.find({
    'username': req.params.username
  }, function(err, data) {
    if (err) {
      logger.error('userManagement : DAO : failed getUserByUsername : error : ' + err);
      callback(err, null);
    } else {
      if (data.length != 0) {
        logger.info('userManagement : DAO : getUserByUsername successful !');
        getUserDetailsByUsername(req, res, function(err, userDetails) {
          if (err) {
            logger.error('userManagement : DAO : failed getUserDetailsByUsername : error : ' + err);
            callback(err, null);
          } else {
            logger.info('userManagement : DAO : getUserDetailsByUsername successful !');
            var responseArray = [];
            var response = {};
            response.verified = data[0].verified;
            response.username = data[0].username;
            response.password = data[0].password;
            response.companyId = data[0].companyId;
            response.userId = data[0].userId;
            response.userroles = data[0].userroles;
            response.givenName = userDetails[0].firstname;
            response.lastname = userDetails[0].lastname;
            responseArray.push(response);
            callback(null, responseArray);
          }
        })

      } else {
        var err = new Error('Invalid username');
        err.status = 404;
        logger.error('userManagement : DAO : failed getUserByUsername : error : ' + err);
        callback(err, null);
      }
    }
  });
};

/*
 * Update lastLoginDatetime 
 */
var updateLastLoginDatetime = function(req, res) {
  var json = {};
  json.lastLoginDatetime = new Date();

  UserRegistration.UserProfile.update({
    'username': req.body.username
  }, json, function(err, data) {
    if (err) {
      logger.error('userManagement : DAO : failed updateLastLoginDatetime : error : ' + err);
    } else {
      logger.info('userManagement : DAO :  updateLastLoginDatetime successfull');
    }
  });
};

var getAllUsers = function(req, res, callback) {
  logger.info('userManagement : DAO : received request : getAllUsers ');

  UserRegistration.UserProfile.find(function(err, data) {
    if (err) {
      callback(err, data);
    } else {
      if (data.length != 0) {
        var response = {};
        response = data;
        for (var i = 0; i < response.length; i++) {
          response[i].password = '';
          //console.log(response);
        }
        callback(err, response);
      } else {
        var err = new Error('Invalid username');
        err.status = 404;
        callback(err, data);
      }
    }
  });
};

/*
 * Get user by orgId
 */
var getUserByOrgId = function(orgId, callback) {
  logger.info('userManagement : DAO : received request : getUserByOrgId : id : ' + orgId);
  userlogin.find({
    'companyId': orgId
  }, function(err, data) {
    if (err) {
      logger.error('userManagement : DAO : failed getUserByOrgId : error : ' + err);
      callback(err, data);
    } else {
      if (data.length != 0) {
        logger.info('userManagement : DAO : getUserByOrgId successful !');
        callback(err, data);
      } else {
        var err = new Error('No record found');
        err.status = 404;
        logger.error('userManagement : DAO : failed getUserByOrgId : error : ' + err);
        callback(err, data);
      }
    }
  });
};

/*
 * Get user by username
 */
var getUserDetailsByUsername = function(req, res, callback) {
  logger.info('userManagement : DAO : received request : getUserDetailsByUsername : id : ' + req.params.username);

  var userProfile = new UserRegistration.UserProfile();

  UserRegistration.UserProfile.find({
    'username': req.params.username
  }, function(err, data) {
    if (err) {
      logger.error('userManagement : DAO : failed getUserDetailsByUsername : error : ' + err);
      callback(err, null);
    } else {
      if (data.length != 0) {
        logger.info('userManagement : DAO : getUserDetailsByUsername successful !');
        callback(null, data);
      } else {
        var err = new Error('Invalid username');
        err.status = 404;
        logger.error('userManagement : DAO : failed getUserDetailsByUsername : error : ' + err);
        callback(err, null);
      }
    }
  });
};

module.exports.addUserRegistration = addUserRegistration;
module.exports.getUser = getUser;
module.exports.updateUser = updateUser;
module.exports.deleteUser = deleteUser;
module.exports.getUserLoginDetails = getUserLoginDetails;
module.exports.getUsersByCompanyId = getUsersByCompanyId;
module.exports.getUsername = getUsername;
module.exports.getUserByUsername = getUserByUsername;
module.exports.updateLastLoginDatetime = updateLastLoginDatetime;
module.exports.getAllUsers = getAllUsers;
module.exports.getUserByOrgId = getUserByOrgId;
