var amqp = require('amqplib/callback_api');
var RabbitMQ= require('../../common/RabbitMQ');
var email   = require('emailjs/email');
var config= require('../../common/Config');
var messageDao= require('../../sendMessage/dao/MessageDAO');
var fs= require('fs');
var async= require('async');
var emailDelegate= require('../../sendMessage/delegate/SendEmailMessageDelegate');
var logger = require('../../common/logger').log;
var UserRegistrationDao = require('./UserRegistrationDAO');
var GenerateActivateTokenDAO = require('./GenerateActivateTokenDAO');
var messageDao = require('../../sendMessage/dao/MessageDAO');
var accessToken;
var userdelegate= require('../delegate/UserRegistrationDelegate');
 /*
  * Receive Email
  */

RabbitMQ.getConnection(function(connection){	
	connection.createChannel(function(err, ch) {	  	  	  
    var q = 'sendgridqueue';		
    ch.assertQueue(q, {durable: false});	
	console.log(" [*] Waiting for messages in sendgridqueue");	
ch.consume(q, function(msg) {
  console.log(" [x] Received %s", msg.content.toString()); 
    
  sendMail(msg.content.toString());
}, {noAck: true});

  });
});
	
	
	
	
							var sendMail = function(msg){
							
							//var sendgrid = require("sendgrid")(config.SENDGRID_API_KEY, { proxy: "http://<username>:<password>@hjproxy.persistent.co.in:8080" });
							if(config.NETWORK_PROXY_ENABLE ==true){
							var sendgrid = require("sendgrid")(config.SENDGRID_API_KEY, { proxy: "http://<username>:<password>@hjproxy.persistent.co.in:8080" });
							}
							else{
									var sendgrid = require("sendgrid")(config.SENDGRID_API_KEY);
									}
									

							var toMail = UserRegistrationDao.getUsername();
							
							var email_data = msg;
							
							var email_data_json = JSON.parse(email_data);
							
							qr_image = fs.readFileSync(email_data_json.qr_file_path);
							
							var email = new sendgrid.Email({
								
								to: toMail,
								from: config.EMAIL_TEMPLATE_FROM,
								subject: 'Welcome to Vega - Accelerating Digital Transformation',
								//html: msg
								html: email_data_json.template,
								files: [
								  {
									filename: 'image.png',
									cid: 'qrcode_image',
									content: qr_image
								  }
								]
								
							});
							sendgrid.send(email, function(err, json){
								if(err) { 
								logger.error('Listener :  failed sendMail : error : ' + err);
								console.error(err); 								
								//update message status as Failed
								var status = 'Failed';								
						messageDao.updateMessageStatus(status, userdelegate.getMessageId(), function(err, data) {
							if (err) {
						logger.error('SMTPEmailListener : LISTENER : failed updateMessageStatus : error : ' + err);
							} else {
						logger.info('SMTPEmailListener : LISTENER : updateMessageStatus successful !');
							}
						})
								}
								else
								{
								logger.info('Listener :  sendMail successful !');								
      //update message status as Sent
      var status = 'Sent';	  
      messageDao.updateMessageStatus(status, userdelegate.getMessageId(), function(err, data) {
        if (err) {
          logger.error('SMTPEmailListener : LISTENER : failed updateMessageStatus : error : ' + err);
        } else {
          logger.info('SMTPEmailListener : LISTENER : updateMessageStatus successful !');
        }
      })
								}
								
							});
}



