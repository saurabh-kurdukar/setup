var mongoose = require('../../common/MongoDbConnection').mongoose;
var autoIncrement = require('mongoose-auto-increment');
var logger = require('../../common/logger').log;
var connection = mongoose.connection;
autoIncrement.initialize(connection);
var activityenum= require('../enum/AccountStatus');

/*
 * Define schema
 */
var platformUserSchema = mongoose.Schema({

  id: Number,
  username: {
    type: String,
    unique: true
  },
  userpassword: String,
  givenName: String,
  sn: String,
  mail: String,
  telephoneNumber: String,
  verified: {
    type: Boolean,
    default: false
  } ,
  companyId : Number ,
  referenceCompanyId: {type: Number, default: 0} ,
  experienceCount: {type: Number, default: 0} ,
  vmCount: {type: Number, default: 0} ,
  lastLoginDatetime : { type: Date, default: Date.now } ,
  //createdOn : { type: Date, default: Date.now } ,
  createdOn : { type: Date} ,
  accountStatus: {type: String, default: activityenum.get(0) },
  attributes: []
});


var generateActivateTokenSchemaPlatformUser = mongoose.Schema({
  username: {
    type: String,
    unique: true
  },
  accessKey: {
    type: String
  },
  clickedStatus:{
	type:Boolean,default: false},
  createdOn: { type: Date, default: Date.now },  
  updatedOn: { type: Date, default: Date.now }
});

var loginactivitySchemaPlatformUser = mongoose.Schema({
  username: {
    type: String
  },
  usertype: {
    type: String
  },
  logints:{
	type:Date}
});

logger.info('PlatformUser : model : created schema : PlatformUser :' + JSON.stringify(platformUserSchema.paths));


platformUserSchema.path('username').validate(function(value, fn) {	  
	  var PlatformUser = mongoose.model('platformusers');
	  PlatformUser.find({'username': value}, function (err, data) {
	    fn(err || data.length === 0);
	  });
}, 'Username already exist');
	
	
platformUserSchema.path('username').validate(function(v) {
  return v.length <= 50;
}, 'data too long for field username');

platformUserSchema.path('givenName').validate(function(v) {
  return v.length <= 50;
}, 'data too long for field givenName');

platformUserSchema.path('userpassword').validate(function(v) {
  return v.length <= 20;
}, 'data too long for field userpassword');

platformUserSchema.path('sn').validate(function(v) {
  return v.length <= 50;
}, 'data too long for field sn');

platformUserSchema.path('mail').validate(function(v) {
  return v.length <= 50;
}, 'data too long for field mail');

platformUserSchema.path('telephoneNumber').validate(function(v) {
  return v.length <= 10;
}, 'data too long for field telephoneNumber');

/*
 * Add Auto increment plugin for field SMTPServerId
 */
platformUserSchema.plugin(autoIncrement.plugin, {
  model: 'platformusers',
  field: 'id', startAt: 1
});


/*
 * Setters
 */
platformUserSchema.methods.setId = function(id) {
  this.id = id;
}

platformUserSchema.methods.setUsername = function(username) {
  this.username = username;
}

platformUserSchema.methods.setPassword = function(userpassword) {
  this.userpassword = userpassword;
}

platformUserSchema.methods.setGivenName = function(givenName) {
  this.givenName = givenName;
}

platformUserSchema.methods.setSn = function(sn) {
  this.sn = sn;
}


platformUserSchema.methods.setMail = function(mail) {
  this.mail = mail;
}

platformUserSchema.methods.setverified = function(verified) {
  this.verified = verified;
};


platformUserSchema.methods.setTelephoneNumber = function(telephoneNumber) {
  this.telephoneNumber = telephoneNumber;
}

platformUserSchema.methods.setCompanyId = function(companyId) {
  this.companyId = companyId;
};


platformUserSchema.methods.setReferenceCompanyId = function(referenceCompanyId) {
  this.referenceCompanyId = referenceCompanyId;
}

platformUserSchema.methods.setLastLoginDatetime = function(lastLoginDatetime) {
  this.lastLoginDatetime = lastLoginDatetime;
}

platformUserSchema.methods.setAccountStatus = function(accountStatus) {
  this.accountStatus = accountStatus;
}

platformUserSchema.methods.setAttributes = function(attributes) {
  this.attributes.push(attributes);
}

platformUserSchema.methods.setCreatedOn = function(createdOn) {
  this.createdOn = createdOn;
}
/*
 * Getters
 */
platformUserSchema.methods.getId = function() {
  return this.id;
}

platformUserSchema.methods.getUsername = function() {
  return this.username;
}

platformUserSchema.methods.getPassword = function() {
  return this.userpassword;
}

platformUserSchema.methods.getGivenName = function() {
  return this.givenName;
}

platformUserSchema.methods.getSn = function() {
  return this.sn;
}

platformUserSchema.methods.getMail = function() {
  return this.mail;
}

platformUserSchema.methods.getTelephoneNumber = function() {
  return this.telephoneNumber;
}

platformUserSchema.methods.getverified = function() {
  return this.verified;
}

platformUserSchema.methods.getCompanyId = function() {
  return this.companyId;
}

platformUserSchema.methods.getReferenceCompanyId = function() {
  return this.referenceCompanyId;
}

platformUserSchema.methods.getLastLoginDatetime = function() {
  return this.lastLoginDatetime;
}

platformUserSchema.methods.getAccountStatus = function() {
  return this.accountStatus;
}

platformUserSchema.methods.getCreatedOn = function() {
  return this.createdOn;
}

// Setter Method
generateActivateTokenSchemaPlatformUser.methods.setUsername = function(username) {
  this.username = username;
};

generateActivateTokenSchemaPlatformUser.methods.setAccessKey = function(accessKey) {
  this.accessKey = accessKey;
};

// Getter Method
generateActivateTokenSchemaPlatformUser.methods.getUsername = function() {
  return this.username;
};

generateActivateTokenSchemaPlatformUser.methods.getAccessKey = function() {
  return this.accessKey;
};


/*
*  login activity
*/
loginactivitySchemaPlatformUser.methods.getUsername = function() {
  return this.username;
};

loginactivitySchemaPlatformUser.methods.getUsertype = function() {
  return this.usertype;
};

loginactivitySchemaPlatformUser.methods.getLogints = function() {
  return this.logints;
};

/*
* setters
*/
loginactivitySchemaPlatformUser.methods.setUsername = function(username) {
  this.username = username;
};

loginactivitySchemaPlatformUser.methods.setUsertype = function(usertype) {
  this.usertype = usertype;
};
loginactivitySchemaPlatformUser.methods.setLogints = function(logints) {
  this.logints = logints;
};



/*
 * Create collection/model in mongo db using Schema
 */
var PlatformUser = mongoose.model('platformusers', platformUserSchema);

var generateActivateTokenSchemaPlatformUser = mongoose.model('GenerateActivateTokenPlatformUser', generateActivateTokenSchemaPlatformUser);

var LoginActivity = mongoose.model('loginactivity', loginactivitySchemaPlatformUser);

module.exports.PlatformUser = PlatformUser;
module.exports.generateActivateTokenSchemaPlatformUser = generateActivateTokenSchemaPlatformUser;
module.exports.LoginActivity= LoginActivity;
