var logger = require('../../common/logger').log;
var userDao = require('../dao/PlatformUserDAO');
var request = require('request');
var config = require('../../common/Config');
var amqp = require('amqplib/callback_api');
var RabbitMQ = require('../../common/RabbitMQ');

/*
 * create user
 */
var addNewUser = function(req, res, callback) {
  logger.info('PlatformUser : Delegate : received request : addNewUser : body : ' + JSON.stringify(req.body));

  var reqBody = req.body;
  var password = req.body.userpassword;

  //generate tokenId using forgeRock API
  var proxyurl = config.NETWORK_PROXY + ":" + config.NETWORK_PROXY_PORT;
  request({
    //'proxy':proxyurl ,
    url: config.FORGRROCK_URL + '/api/v1/users/authenticate',
    method: 'POST',
    headers: {
      'Content-Type': 'application/json'
    },
    json: {
      "userId": config.FORGEROCK_USERID,
      "password": config.FORGEROCK_PASSWORD
    }
  }, function(error, response, authResBody) {
    if (error) {
      logger.error('PlatformUser : Delegate : failed addNewUser : error : ' + error);
      callback(error, null);
    } else {
      tokenId = authResBody.tokenId
        //createUser forgeRock call
      request({
        //'proxy':proxyurl ,
        url: config.FORGRROCK_URL + '/api/v1/users',
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': tokenId
        },
        json: reqBody
      }, function(error, response, body) {
        if (error) {
          logger.error('PlatformUser : Delegate : failed addNewUser : error : ' + error);
          callback(error, null);
        } else {
          logger.info('PlatformUser : DAO : addNewUser response !' + body);
          if (body.code == 409)
            callback(new Error('User already exist'), null);
          else if (body.code == 401)
            callback(body, null);
          else if (body.code == 404)
            callback(body, null);
          else
            callback(null, authResBody);
          //userDao.addNewUser(tokenId, req, res, callback);
        }
      });
    }
  });
};

/*
 *get user
 */
var getUser = function(req, res, callback) {
  logger.info('PlatformUser : Delegate : received request : getUser :');

  var tokenId = req.headers['tokenId'];
  var id = req.params.id;
  //forgeRock call
  request({
    url: config.FORGRROCK_URL + '/api/v1/users/' + id,
    method: 'GET',
    headers: {
      'Content-Type': 'application/json',
      'tokenId': tokenId
    }
  }, function(error, response, body) {
    if (error) {
      logger.error('PlatformUser : Delegate : failed getUser : error : ' + error);
    } else {
      logger.info('PlatformUser : DAO : getUser successful !');
      callback(null, body);
    }
  });
};

/*
 *delete user
 */
var deleteUser = function(tokenId, req, res, callback) {
  logger.info('PlatformUser : Delegate : received request : deleteUser');

  var proxyurl = config.NETWORK_PROXY + ":" + config.NETWORK_PROXY_PORT;
  //forgeRock call
  request({
    //'proxy':proxyurl ,
    url: config.FORGRROCK_URL + '/api/v1/users/' + req.body.username,
    method: 'DELETE',
    headers: {
      'Content-Type': 'application/json',
      'Authorization': tokenId
    }
  }, function(error, response, body) {
    if (error) {
      logger.error('PlatformUser : DAO : failed deleteUser : error : ' + error);
      callback(error, null);
    } else {
      if (body.code == 404) {
        logger.info('PlatformUser : DAO : deleteUser response' + body);
        callback(body, null);
      } else {
        logger.info('PlatformUser : DAO : deleteUser successful !');
        callback(null, body);
      }
    }
  });
}

module.exports.addNewUser = addNewUser;
module.exports.getUser = getUser;
module.exports.deleteUser = deleteUser;
