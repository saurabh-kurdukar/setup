var db = require('../../common/MongoDbConnection');
var User = require('../models/PlatformUser');
var logger = require('../../common/logger').log;
var audit = require('../../common/Audit').audit;
var config = require('../../common/Config');
var platformUserDelegate = require('../delegate/PlatformUserDelegate');
var companyDAO = require('../../company/dao/CompanyDAO');
var qr = require('qr-image');
var fs = require('fs');
var passwordHash = require('password-hash');
var loginActivity = require('../models/PlatformUser').LoginActivity;
var messagedao = require('../../sendMessage/dao/MessageDAO');
var encryptDecrypt = require('../../common/EncryptDecrypt');
var async = require('async');
var userRegistrationDao = require('../../userManagement/dao/UserRegistrationDAO')

/*
 * Add new Platform User details
 */
var addNewUser = function(tokenId, req, res, callback) {
  logger.info('PlatformUser : DAO : received request : addNewUser : body : ' + JSON.stringify(req.body));

  var reqBody = req.body;
  var Users = User.PlatformUser;
  var user = new Users();
  var password = req.body.userpassword;
  var userName = reqBody.username;
  var pwd = reqBody.userpassword;
  user.setUsername(reqBody.username);
  user.setPassword("");
  user.setTelephoneNumber(reqBody.telephoneNumber);
  user.setMail(reqBody.mail);
  user.setGivenName(reqBody.givenName);
  user.setSn(reqBody.sn);
  user.setCompanyId(config.COMPANY_ID);
  user.setCreatedOn(new Date());

  user.save(function(err, data) {
    if (err) {
      logger.error('PlatformUser : DAO : failed addNewUser : error : ' + err);
      callback(err);
      return;
    } else if (data) {
      logger.info('PlatformUser : DAO : addNewUser successful !');
      callback(null, data);
    } else {
      var err = new Error('Failed to add new PlatformUser details');
      logger.error('PlatformUser : DAO : failed addNewUser : error : ' + err);
      callback(err);
    }
  });
};

/*
 * Get user by username
 */
var getUserByUsername = function(req, res, callback) {
  logger.info('PlatformUser : DAO : received request : getUserByUsername : id : ' + req.params.username);

  var Users = User.PlatformUser;

  Users.find({
    'username': req.params.username
  }, function(err, data) {
    if (err) {
      logger.error('PlatformUser : DAO : failed getUserByUsername : error : ' + err);
      callback(err, data);
    } else {
      if (data.length != 0) {
        logger.info('PlatformUser : DAO : getUserByUsername successful !');
        callback(err, data);
      } else {
        var err = new Error('Invalid username');
        err.status = 404;
        logger.error('PlatformUser : DAO : failed getUserByUsername : error : ' + err);
        callback(err, data);
      }
    }
  });
};

/*
 * Update Platform user details
 */
var updatePlatformUser = function(attributes, req, res, callback) {
  logger.info('PlatformUser : DAO : received request : updatePlatformUser  ');

  var Users = User.PlatformUser;
  var json = JSON.parse(JSON.stringify(req.body));
  json.attributes = attributes;

  if (typeof(config.PLATFORMUSERS_PASSWORD_MANAGEMENT) == 'undefined' || config.PLATFORMUSERS_PASSWORD_MANAGEMENT == '' || config.PLATFORMUSERS_PASSWORD_MANAGEMENT == 'INTERNAL') {
    var hashedPassword = passwordHash.generate(req.body.username + '_' + req.body.userpassword);
    json.userpassword = hashedPassword;
  } else {
    json.userpassword = "";
  }
  json.UpdatedOn = new Date();
  json.UpdatedBy = 'Admin';

  Users.findOneAndUpdate({
    'username': req.body.username
  }, json, function(err, data) {
    if (err) {
      logger.error('PlatformUser : DAO : failed updatePlatformUser : error : ' + err);
      callback(err, data);
    } else {
      logger.info('PlatformUser : DAO : updatePlatformUser successful !');
      callback(err, data);
    }
  });
};

/*
 * Get user by orgId
 */
var getUserByOrgId = function(orgId, callback) {
  logger.info('PlatformUser : DAO : received request : getUserByOrgId : id : ' + orgId);

  var Users = User.PlatformUser;

  Users.find({
    'referenceCompanyId': orgId
  }, function(err, data) {
    if (err) {
      logger.error('PlatformUser : DAO : failed getUserByOrgId : error : ' + err);
      callback(err, data);
    } else {
      if (data.length != 0) {
        logger.info('PlatformUser : DAO : getUserByOrgId successful !');
        callback(err, data);
      } else {
        var err = new Error('No record found');
        err.status = 404;
        logger.error('PlatformUser : DAO : failed getUserByOrgId : error : ' + err);
        callback(err, data);
      }
    }
  });
};

/*
 * Update lastLoginDatetime
 */
var updateLastLoginDatetime = function(req, res) {
  var Users = User.PlatformUser;
  var json = {};
  json.lastLoginDatetime = new Date();

  Users.update({
    'username': req.body.username
  }, json, function(err, data) {
    if (err) {
      logger.error('Platform User : DAO : failed updateLastLoginDatetime : error : ' + err);
    } else {
      logger.info('Platform User : DAO :  updateLastLoginDatetime successfull');
    }
  });
};

/*
 * Get getAllUsers
 */
var getAllUsers = function(req, res, callback) {
  logger.info('PlatformUser : DAO : received request : getAllUsers ');

  var Users = User.PlatformUser;
  var top = req.query.top;
  var searchKeyword = req.query.q;
  if ((top != undefined) || (top != null)) {
    Users.find({
      'verified': true
    }).sort('-experienceCount').exec(function(err, data) {
      if (err) {
        logger.error('PlatformUser : DAO : failed getTop5Users : error : ' + err);
        callback(err, null);
      } else {
        if (data.length != 0) {
          logger.info('PlatformUser : DAO : getTop5Users successful !');
          if (data.length > top) {
            data.splice(top, data.length - 1);
          }
          //check for null date
          for (var i = 0; i < data.length; i++) {
            if (data[i].createdOn == 'undefined' || data[i].createdOn == null) {
              data[i].createdOn = '';
            }
          }
          callback(null, data);
        } else {
          var err = new Error('no records found');
          err.status = 404;
          logger.error('PlatformUser : DAO : failed getTop5Users : error : ' + err);
          callback(err, null);
        }
      }
    });
  } else if (searchKeyword != undefined || searchKeyword != null) {
    searchUser(req, res, callback);
  } else {
    Users.find({
      'verified': true
    }, function(err, data) {
      if (err) {
        callback(err, data);
      } else {
        if (data.length != 0) {
          var response = {};
          response = data;
          for (var i = 0; i < response.length; i++) {
            response[i].userpassword = '';
            if (response[i].createdOn == 'undefined' || response[i].createdOn == null) {
              response[i].createdOn = '';
            }
          }
          callback(err, response);
        } else {
          var err = new Error('Invalid username');
          err.status = 404;
          callback(err, data);
        }
      }
    });
  }
};

/*
 * Add new login activity
 */
var addNewLoginActivity = function(req, res, callback) {
  logger.info('PlatformUser : DAO : received request : addNewLoginActivity : body : ' + JSON.stringify(req.body));

  var reqBody = req.body;
  var LoginActivity = new loginActivity();

  LoginActivity.setUsername(req.body.username);
  LoginActivity.setUsertype(req.body.usertype);
  LoginActivity.setLogints(new Date());

  LoginActivity.save(function(err, data) {
    if (err) {
      logger.error('PlatformUser : DAO : failed addNewLoginActivity : error : ' + err);
      callback(err, null);
    } else {
      logger.info('PlatformUser : DAO : addNewLoginActivity successful !');
      callback(null, data);
    }
  });
};

/* Update experience and vm count for platformuser */
var updateProvisioningInfo = function(orgId, expCounter, vmCounter) {
  logger.info('PlatformUser : DAO : request received : updateProvisioningInfo');
  if (!isNaN(Number(vmCounter)) && !isNaN(Number(expCounter))) {
    User.PlatformUser.update({
        'referenceCompanyId': orgId
      }, {
        $inc: {
          vmCount: vmCounter,
          experienceCount: expCounter
        }
      },
      function(err, data) {
        if (err) {
          //console.log("Error", err);
          err.status = 500;
          logger.error('PlatformUser : DAO : failed updateProvisioningInfo : error : ' + err);
          //callback(err);
        } else {
          if (data) {
            // console.log("platform user success");
            logger.info('PlatformUser : DAO : updateProvisioningInfo successful !');
            //callback(null, data);
          } else {
            //console.log("No Data");
            var err = new Error('Org id does not exist');
            err.status = 200;
            logger.error('PlatformUser : DAO : failed updateProvisioningInfo : error : ' + err);
            //callback(err);
          }
        }
      });
  } else {
    //console.log("Error invalid value for vmCounter or expCounter");
    var err = new Error('invalid value for vmCounter or expCounter');
    err.status = 200;
    logger.error('PlatformUser : DAO : failed updateProvisioningInfo : error : ' + err);
  }
}

/*
 * Search user by keyword
 */
var searchUser = function(req, res, callback) {
  logger.info('PlatformUser : router : received request : searchUser : keyword : ' + req.query.q);
  var keyword = new RegExp(".*" + req.query.q + ".*");
  var PlatformUser = User.PlatformUser;
  PlatformUser.find({
    $or: [{
      username: keyword
    }, {
      givenName: keyword
    }, {
      sn: keyword
    }],
    'verified': true
  }, function(err, data) {
    if (err) {
      logger.error('PlatformUser : DAO : failed searchUser : error : ' + err);
      callback(err, null);
    } else {
      if (data.length != 0) {
        logger.info('PlatformUser : DAO : searchUser successful !');
        callback(null, data);
      } else {
        var err = new Error('No User found for given keyword');
        err.status = 404;
        logger.error('Roles : DAO : failed searchUser : error : ' + err);
        callback(err, null);
      }
    }
  });
}

module.exports.addNewUser = addNewUser;
module.exports.getUserByUsername = getUserByUsername;
module.exports.updatePlatformUser = updatePlatformUser;
module.exports.getUserByOrgId = getUserByOrgId;
module.exports.updateLastLoginDatetime = updateLastLoginDatetime;
module.exports.getAllUsers = getAllUsers;
module.exports.addNewLoginActivity = addNewLoginActivity;
module.exports.updateProvisioningInfo = updateProvisioningInfo;
