var db = require('../../common/MongoDbConnection');
var platformuser = require('../models/PlatformUser');
var encryptdecrypt = require('../../common/EncryptDecrypt');
var logger = require('../../common/logger').log;
var config = require('../../common/Config');
var activateToken = platformuser.generateActivateTokenSchemaPlatformUser;
var platformuserlogin = platformuser.PlatformUser;
var audit = require('../../common/Audit').audit;
/*
 * logging format followed: logger.info(<module_name>: <component name> : <description> : [<long_description>] : <data/params/errors>);
 */
var getActivateToken = function() {
  var hat = require('hat');
  var id = hat();
  return id;
};

var saveToken = function(username, accessKey, callback) {
  var record = platformuser.generateActivateTokenSchemaPlatformUser();
  record.setUsername(username);
  record.setAccessKey(accessKey);
  record.save(callback);
};

var validateActivationLink = function(req, res, callback) {
  logger.info('GenerateActivateToken : DAO : received request : validateActivationLink : body : ' + JSON.stringify(req.body));
  var username = req.query.e;
  var token = req.query.t;
  activateToken.find({
    'username': username,
    'accessKey': token
  }, function(err, data) {
    if (err) {
      logger.error('GenerateActivateToken : DAO : failed getToken : error : ' + err);
      callback(err, null);
    } else {
      if (data.length != 0) {
        if (data[0].clickedStatus) {
          var err = new Error('The Link has already been used..!! ');
          err.status = 500;
          callback(err, null);
        } else if (new Date().getTime() > data[0].updatedOn.getTime() + (24 * 60 * 60 * 1000)) {
          var err = new Error('The Link has Expired..!! ');
          err.status = 500;
          callback(err, null);
        } else {
          platformuserlogin.update({
            username: username
          }, {
            $set: {
              verified: true
            }
          }, function(err, data) {
            if (err) {
              logger.error('GenerateActivateToken : DAO : failed saveusertoken : error : ' + err);
              callback(err, null);
            } else {

              activateToken.update({
                username: username
              }, {
                $set: {
                  clickedStatus: true
                }
              }, function(err, data) {
                if (err) {
                  logger.error('userManagement : DAO : failed changeClickedStatus : error : ' + err);
                  callback(err, null);
                } else {
                  logger.info('userManagement : DAO : changeClickedStatus successful !');
                }
              });
              logger.info('GenerateActivateToken : DAO : saveusertoken successful !');
              callback(null, "Your Account has been activated");
            }
          });
        }
      } else {
        var err = new Error('Invalid token');
        err.status = 404;
        callback(err, null);
      }
    }
  });
};

/*
 ** Get token details by username
 */
var getToken = function(req, res, callback) {
  logger.info('GenerateActivateToken : DAO : received request : getToken : username : ' + req.params.username);
  activateToken.findOne({
    'username': req.params.username
  }, function(err, data) {
    if (err) {
      logger.error('GenerateActivateToken : DAO : failed getToken : error :' + err);
      callback(err, null);
    } else {
      if (data && data.length != 0) {
        logger.info('GenerateActivateToken : DAO : getToken Successful !');
        callback(null, data);
      } else {
        var err = new Error('invalid username');
        err.status = 404;
        logger.error('GenerateActivateToken : DAO : failed getToken : error : ' + err);
        callback(err, null);
      }
    }
  });
}

/*
 * Update token details
 */
var updateToken = function(req, res, callback) {
  logger.info('GenerateActivateToken : DAO : received request : updateToken : body : ' + JSON.stringify(req.body));
  var callbackUpdate = function(err, data) {
      if (err) {
        logger.error('GenerateActivateToken : DAO : failed updateToken : error :' + err);
        callback(err, null);
      } else if (data != null) {
        /*
         *	Compare updatable fields values in db with request data
         *	Add those fields in temproary object which are having new values
         */
        var token = data;
        var json = {};
        var updatedData = [];

        if (req.body.accessKey && token['accessKey'] != req.body.accessKey) {
          json.accessKey = req.body.accessKey;
          var obj = {};
          obj.column = 'accessKey';
          obj.oldValue = token['accessKey'];
          obj.newValue = req.body.accessKey;
          obj.identifier = 'Platform_token_' + req.params.username;
          obj.modifiedBy = 'admin';
          obj.modifiedOn = new Date();
          updatedData.push(obj);
        }
        /*
         *	Update data to database 
         */
        if (Object.keys(json).length != 0) {
          json.updatedOn = new Date();
          logger.info('GenerateActivateToken : DAO : updateToken : updating data : ' + JSON.stringify(json));
          activateToken.findOneAndUpdate({
            'username': req.params.username
          }, json, {
            'new': true
              // returns updated entity if update successful, if false then old entry
          }, function(err, data) {
            if (err) {
              logger.error('GenerateActivateToken : DAO : failed updateToken : error :' + err);
              callback(err, null);
            } else {
              if (data != null) {
                logger.info('GenerateActivateToken : DAO : updateToken successful !');
                /*
                 *	Call audit function for changed data 
                 */
                audit(req, res, updatedData);
                /*
                 *	Call function to send response to client 
                 */
                callback(null, data);
              } else {
                var err = new Error('Bad request data');
                logger.error('GenerateActivateToken  : DAO : failed updateToken : error :' + err);
                callback(err, null);
              }
            }
          });
        } else {
          var err = new Error('Cannot update data');
          logger.error('GenerateActivateToken  : DAO : failed updateToken : error :' + err);
          callback(err, null);
        }
      } else {
        var err = new Error('Failed to get token details');
        logger.error('GenerateActivateToken  : DAO : failed updateToken : error :' + err);
        callback(err, null);
      }
    }
    /*
     * Get the original record from db before update.
     */
  getToken(req, res, callbackUpdate);
};
module.exports.getActivateToken = getActivateToken;
module.exports.saveToken = saveToken;
module.exports.validateActivationLink = validateActivationLink;
module.exports.getToken = getToken;
module.exports.updateToken = updateToken;
