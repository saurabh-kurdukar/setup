var Enum = require('enum');

var accountstatus = new Enum({
  'ACTIVE': 0,
  'INACTIVE': 1,
  'SUSPENDED': 2,
  'DEACTIVATED': 3,
  'ARCHIVED' : 4,
  'RESIGNED' : 5
});

module.exports = accountstatus;
