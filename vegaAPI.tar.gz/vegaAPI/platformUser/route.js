var express = require('express');
var fs = require('fs');
var path = require('path');
var mime = require('mime');
var logger = require('../common/logger').log;
var platformUserController = require('./controller/PlatformUserController');
var ErrorResponse = require('../common/ErrorResponse').ErrorResponse;
var router = express.Router();


/*
 * Add new platform user details
 */
router.post('/', function(req, res) {
  logger.info('PlatformUser : router : received request : addNewUser : body : ' + JSON.stringify(req.body));
  platformUserController.addNewUser(req, res, function(err, data) {
    if (err) {
      logger.error('PlatformUser : router : failed addNewUser : error : ' + JSON.stringify(err));
      var error = new ErrorResponse();
      if (err.name == 'ValidationError') {
        error.setErrorMessage(err.errors[Object.keys(err.errors)[0]].message);
      } else {
        error.setErrorMessage(err.message);
      }
      error.setErrorCode("PU001");
      error.setHttpResponseCode(500);
      res.status(500).end(JSON.stringify(error));

    } else {
      logger.info("PlatformUser : router : addNewUser successful !");
      res.status(200).end(JSON.stringify(data));
    }
  });
});

/*
 * Get user
 */
/*
router.get('/:id', function(req, res) {
  logger.info('PlatformUser : router : received request : getUser :');
  platformUserController.getUser(req, res, function(err, data) {
    if (err) {
      logger.error('PlatformUser : router : failed getUser : error : ' + err);
      var error = new ErrorResponse();
      error.setErrorCode("PU002");
      error.setErrorMessage(err.message);
      error.setHttpResponseCode(500);
      res.status(500).end(JSON.stringify(error));
    } else {
      logger.info("PlatformUser : router : getUser successful !");
      res.status(200).end(JSON.stringify(data));
    }
  });
});

*/


//validate activationlink
router.get('/activationLink/active', function(req, res) {

  logger.info('PlatformUser : router : received request : validateActivationLink : body : ' + JSON.stringify(req.body));

  platformUserController.validateActivationLink(req, res, function(err, data) {
    if (err) {
      logger.error('PlatformUser : router : failed validateActivationLink : error : ' + err);
      var error = new ErrorResponse();
      if (err.name == 'ValidationError') {
        error.setErrorMessage(err.errors[Object.keys(err.errors)[0]].message);
      } else {
        error.setErrorMessage(err.message);
      }
      error.setErrorCode("PU005");
      error.setHttpResponseCode(500);
      res.status(500).end(JSON.stringify(error));
    } else {
      logger.info("userManagement : router : validateActivationLink successful !");
      res.status(200).end(JSON.stringify(data));
    }
  });
});


/*
 * Get provisioned experiences for user
 */
router.get('/:username/provisions', function(req, res) {

  logger.info('PlatformUser : router : received request : getProvisionedExperiencesByUserName : username : ' + req.params.username);

  platformUserController.getProvisionedExperiencesByUserName(req, function(err, data) {
    if (err) {
      logger.error('PlatformUser : router : failed getProvisionedExperiencesByUserName : error : ' + err);
      var error = new ErrorResponse();
      if (err.name == 'ValidationError') {
        error.setErrorMessage(err.errors[Object.keys(err.errors)[0]].message);
      } else {
        error.setErrorMessage(err.message);
      }
      error.setErrorCode("PU006");
      error.setHttpResponseCode(500);
      res.status(500).end(JSON.stringify(error));
    } else {
      logger.info("userManagement : router : getProvisionedExperiencesByUserName successful !");
      res.status(200).end(JSON.stringify(data));
    }
  });
});

/*
 * Export usage data for user 
 */
router.get('/export', function(req, res) {
  logger.info('PlatformUser : router : received request : exportUserData : (username:' + req.headers.username + ')');
  platformUserController.exportUserData(req, function(err, filePath) {
    if (err) {
      logger.error('PlatformUser : router : failed exportUserData : error : ' + err);
      var error = new ErrorResponse();
      error.setErrorCode("PU009");
      error.setErrorMessage(err.message);
      error.setHttpResponseCode(err.status);
      return res.status(err.status).end(JSON.stringify(error));
    }
    logger.info("PlatformUser : router : exportUserData successful !");        
	var filename = path.basename(filePath);
	var mimetype = mime.lookup(filePath);	
	res.setHeader('Content-disposition', 'attachment; filename=PlatformUsersReport.xlsx');
	res.setHeader('Content-type', mimetype);	
	var filestream = fs.createReadStream(filePath);
	filestream.pipe(res);
	filestream.on('close', function (error) {
	    if (err) return res.send(500);
	    fs.unlink(filePath);
	});
  });
});

/*
 * Get user by username
 */
router.get('/:username', function(req, res) {
  logger.info('PlatformUser : router : received request : getUserByUsername :');
  platformUserController.getUserByUsername(req, res, function(err, data) {
    if (err) {
      logger.error('PlatformUser : router : failed getUserByUsername : error : ' + err);
      var error = new ErrorResponse();
      error.setErrorCode("PU006");
      error.setErrorMessage(err.message);
      error.setHttpResponseCode(500);
      res.status(500).end(JSON.stringify(error));
    } else {
      logger.info("PlatformUser : router : getUserByUsername successful !");
      res.status(200).end(JSON.stringify(data));
    }
  });
});

/*
 * Get lastLoginDatetime of all users
 */
router.get('/', function(req, res) {
  logger.info('PlatformUser : router : received request : getAllUsers :');
  platformUserController.getAllUsers(req, res, function(err, data) {
    if (err) {
      logger.error('PlatformUser : router : failed getAllUsers : error : ' + err);
      var error = new ErrorResponse();
      error.setErrorCode("PU007");
      error.setErrorMessage(err.message);
      error.setHttpResponseCode(500);
      res.status(500).end(JSON.stringify(error));
    } else {
      logger.info("PlatformUser : router : getAllUsers successful !");
      res.status(200).end(JSON.stringify(data));
    }
  });
});

/*
 * Get VM Details .
 * Returns all VM details based on the given ‘Platform username’
 */
router.get('/:username/vmDetails', function(req, res) {
  logger.info('PlatformUser : router : received request : getVmDetailsByUsername :');
  platformUserController.getVmDetailsByUsername(req, res, function(err, data) {
    if (err) {
      logger.error('PlatformUser : router : failed getVmDetailsByUsername : error : ' + err);
      var error = new ErrorResponse();
      error.setErrorCode("PU009");
      error.setErrorMessage(err.message);
      error.setHttpResponseCode(500);
      res.status(500).end(JSON.stringify(error));
    } else {
      logger.info("PlatformUser : router : getVmDetailsByUsername successful !");
      res.status(200).end(JSON.stringify(data));
    }
  });
});



/*
 * Get All Provisioned Experience Details By Username
 */
router.get('/:username/experiences', function(req, res) {
  logger.info('PlatformUser : router : received request : getAllProvisionedExperienceDetailsByUsername : (platforusername:' + req.params.username + ')');
  platformUserController.getAllProvisionedExperienceDetailsByUsername(req, function(err, data) {
    if (err) {
      logger.error('PlatformUser : router : failed getAllProvisionedExperienceDetailsByUsername : error : ' + err);
      var error = new ErrorResponse();
      error.setErrorCode("PU008");
      error.setErrorMessage(err.message);
      error.setHttpResponseCode(err.status);
      return res.status(err.status).end(JSON.stringify(error));
    }
    logger.info("PlatformUser : router : getAllProvisionedExperienceDetailsByUsername successful !");
    res.status(200).end(JSON.stringify(data));
  });
});

/*
 * Reset Password
 */
router.post('/:username/resetPassword', function(req, res) {
  logger.info('PlatformUser : router : received request : resetPassword : (platforusername:' + req.params.username+'body'+JSON.stringify(req.body) + ')');
  platformUserController.resetPassword(req,res, function(err, data) {
    if (err) {
      logger.error('PlatformUser : router : failed resetPassword : error : ' + err);
      var error = new ErrorResponse();
      error.setErrorCode("PU009");
      error.setErrorMessage(err.message);
      error.setHttpResponseCode(err.status);
      return res.status(err.status).end(JSON.stringify(error));
    }
    logger.info("PlatformUser : router : resetPassword successful !");
    res.status(200).end(JSON.stringify(data));
  });
});

/*
 * Forgot Password Reset
 */
router.post('/:username/forgotPasswordReset', function(req, res) {
  logger.info('PlatformUser : router : received request : forgotPasswordReset : (platforusername:' + req.params.username+'body'+JSON.stringify(req.body) + ')');
  platformUserController.forgotPasswordReset(req,res, function(err, data) {
    if (err) {
      logger.error('PlatformUser : router : failed forgotPasswordReset : error : ' + err);
      var error = new ErrorResponse();
      error.setErrorCode("PU010");
      error.setErrorMessage(err.message);
      error.setHttpResponseCode(err.status);
      return res.status(err.status).end(JSON.stringify(error));
    }
    logger.info("PlatformUser : router : forgotPasswordReset successful !");
    res.status(200).end(JSON.stringify(data));
  });
});

module.exports = router;






