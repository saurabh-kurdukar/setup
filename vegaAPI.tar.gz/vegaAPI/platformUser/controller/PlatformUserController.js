var async = require('async');
var request = require('request');
var qr = require('qr-image');
var fs = require('fs');
var Q = require('q');
var userDao = require('../dao/PlatformUserDAO');
var logger = require('../../common/logger').log;
var generateActivateTokenDAO = require('../dao/GenerateActivateTokenDAO');
var platformuserdelegate = require('../delegate/PlatformUserDelegate');
var provisionedExperienceDao = require('../../provision/dao/provision-experience-dao');
var config = require('../../common/Config');
var platformuserdao = require('../dao/PlatformUserDAO');
var experienceDao = require('../../experience/dao/ExperienceDAO');
var MandatoryGroupApplicationAssociation = require('../../radia-adapter/dto/mandatory-user-group-assoc');
var PlatformError = require('../../common/platform-error');
var adapterConfig = require('../../common/adapterConfig');
var addPlatformUserPostProcessAdapter = require('../../'+adapterConfig.addPlatformUserPostProcess);
var postSignUpPlatformUserAdapter = require('../../'+adapterConfig.postSignUpPlatformUserAdapter);
var templateDao = require('../../template/dao/TemplateDAO');
var RabbitMQ = require('../../common/RabbitMQ');
var messagedao = require('../../sendMessage/dao/MessageDAO');
var roleDao= require('../../roles/dao/RoleDAO');
var userRoleDao= require('../../userRoles/dao/UserRoleDAO');
var ForgeRockGetToken = require('../../common/ForgeRockGetToken');
var userRoleDelegate= require('../../userRoles/delegate/UserRoleDelegate');
var userattributesdao= require('../../userAttributes/dao/UserAttributeDAO');
var Excel = require('exceljs');
var resetPasswordDelegate= require('../../resetPassword/delegate/ResetPassowrdDelegate');
var forgotPasswordDelegate= require('../../forgotPassword/delegate/ForgotPasswordDelegate');
var registrationDao= require('../../registration/dao/RegistrationDAO');
var q = 'ActivationLinkQueue';

/*
 * Add new Platform User details
 */
var addNewUser = function(req, res, callback) {
  logger.info('PlatformUser : controller : received request : addNewUser : body : ' + JSON.stringify(req.body))
  req.body.username = req.body.username.toLowerCase();
  req.body.mail = req.body.mail.toLowerCase();
  var re = /[0-9]/;
  var password = req.body.userpassword;
  var isValid = /^[0-9,.]*$/.test(password);
  if (!isValid) {
	    var err = new Error('password must contain only numbers (0-9)!');
	    err.status = 400;
	    logger.error('PlatformUser : Controller : failed addNewUser : error : ' + err);
	    return callback(err);
  } else if (password.length > config.PASSWORD_LENGTH) {
	    var err = new Error('maximum password length should be ' + config.PASSWORD_LENGTH);
	    err.status = 400;
	    logger.error('PlatformUser : Controller : failed addNewUser : error : ' + err);
	    return callback(err);
  } else {
    	var tokenId = '', response;

    	Q.fcall(function() {
    		//console.log('in nxt fn1 : chk INTERNAL or EXTERNAL : if EXTERNAL add to forgerock else nxt fn');
    		var deferred = Q.defer();
    		if (typeof(config.PLATFORMUSERS_PASSWORD_MANAGEMENT) == 'undefined' || config.PLATFORMUSERS_PASSWORD_MANAGEMENT == '' || config.PLATFORMUSERS_PASSWORD_MANAGEMENT == 'INTERNAL') {
    			//console.log('in nxt fn1 : pwd mgnt=INTERNAL, skip forgerock');
    			deferred.resolve();
    		} else {
    			//console.log('in nxt fn1 : pwd mgnt=EXTERNAL');
    			platformuserdelegate.addNewUser(req, res, function(err, data) {
    				if(err) {
    					logger.error('PlatformUser : Controller : failed addNewUser : error : ' + err);
    					deferred.reject(err);
    				} else {
    					deferred.resolve(data);
    				}
    			});
    		}
    		return deferred.promise;
    	})
    	.then(function(data) {
    		//console.log('in nxt fn2 : addNewUser in db');
    		var deferred = Q.defer();
    		if(data) {
	    		//console.log('nxt fn2 data: '+JSON.stringify(data));
	    		tokenId = data.tokenId;
    		}
    		addUser(tokenId, req, res, function(err, data) {
    			if (err) {
	            	logger.error('PlatformUser : Controller : failed addUser : error : ' + err);
	            	//console.log('nxt fn2 : err addUser: '+JSON.stringify(err));
					deferred.reject(err);
	            } else {
	            	//console.log('nxt fn2 : success addUser');
	            	deferred.resolve(data);
	            }
    		});
    		return deferred.promise;
    	})
    	.then(function(data) {
    	    //console.log('nxt fn3 : postSignUpPlatformUserAdapter : data frm fn2 : '+JSON.stringify(data));
    	    var deferred = Q.defer();
		    req.body.companyName = config.COMPANY_NAME + "_" + data.id;
		    response = data;
		    addCompanyFromAdapter(req, function(err, attributes) {
    			if(err) {
    				logger.error('PlatformUser : Controller : failed addCompanyAdapter : error : ' + err);
    				//console.log('nxt fn3 : err addCompanyFromAdapter: '+JSON.stringify(err));
    				deferred.reject(err);
    			} else {
    				response.attributes = attributes;
    				//console.log('nxt fn3 : success addCompanyFromAdapter');
    				deferred.resolve(attributes);
    			}
    		});
    		return deferred.promise;
    	})
    	.then(function(attributes) {
    	    //console.log('nxt fn4 : data from f3 : attributes='+JSON.stringify(attributes));
    	    var deferred = Q.defer();
    	    userDao.updatePlatformUser(attributes, req, res, function(err, data) {
	            if (err) {
	            	logger.error('PlatformUser : Controller : failed updatePlatformUser : error : ' + err);
	            	//console.log('nxt fn4 : err updatePlatformUser: '+JSON.stringify(err));
					deferred.reject(err);
	            } else {
	            	//console.log('nxt fn4 : success updatePlatformUser');
	            	deferred.resolve();
	            }
    	    });
    	    return deferred.promise;
    	})
    	.then(function() {
    		//console.log('nxt fn5: radia add group & user');
    		var deferred = Q.defer();
        if(config.SKIP_RADIA) {
          deferred.resolve();
        }
        else {
          postSignUpPlatformUserAdapter.addUserOnRadia(req, function(err, data) {
      			if(err) {
      				logger.error('PlatformUser : Controller : failed addUserOnRadia : error : ' + err);
      				//console.log('nxt fn5 : err addUserOnRadia: '+JSON.stringify(err));
      				deferred.reject(err);
      			} else {
      				//console.log('nxt fn5 : success addUserOnRadia');
      				deferred.resolve();
      			}
      		});
        }
    		return deferred.promise;
    	})
    	.then(function() {
    		 //console.log('nxt fn6: assign roles to user');
    		 var deferred = Q.defer();
    		 assignRolesToUser(req, res, function(err, data) {
    			if(err) {
    				logger.error('PlatformUser : Controller : failed assignRolesToUser : error : ' + err);
    				//console.log('nxt fn6 : err assignRolesToUser: '+JSON.stringify(err));
    				deferred.reject(err);
    			} else {
    				//console.log('nxt fn6 : success assignRolesToUser');
    				deferred.resolve();
    			}
    		 });
    		 return deferred.promise;
    	})
    	.then(function() {
    		 //console.log('nxt fn6.1: assign additional roles to user');
    		 var deferred = Q.defer();
    		 postSignUpPlatformUserAdapter.assignAdditionalRoles(req, function(err, data) {
    			if(err) {
    				logger.error('PlatformUser : Controller : failed assignAdditionalRoles : error : ' + err);
    				//console.log('nxt fn6.1 : err assignAdditionalRoles: '+JSON.stringify(err));
    				deferred.reject(err);
    			} else {
    				//console.log('nxt fn6.1 : success assignAdditionalRoles');
    				deferred.resolve();
    			}
    		 });
    		 return deferred.promise;
    	})
    	.then(function() {
    		//console.log('nxt fn7 : createEmailData');
    		var deferred = Q.defer();
    		createEmailData(req, res, function(err, email_data) {
    			if(err) {
    				//console.log('nxt fn7 : err createEmailData: '+JSON.stringify(err));
    				deferred.reject(err);
    			} else {
    				//console.log('nxt fn7 : success createEmailData');
    				deferred.resolve(email_data);
    			}
    		});
    		return deferred.promise;

    	})
		.then(function(email_data) {
    		var deferred = Q.defer();
        if(config.SKIP_RADIA) {
          deferred.resolve(email_data);
        }
        else {
          var emailData= JSON.parse(email_data);
    			var qr_path=emailData.qr_file_path
    			var splitPath =qr_path.split('/');
    			var saveQrReq={};
    			saveQrReq.body={};
    			saveQrReq.body.username= emailData.toMail;
    			saveQrReq.body.attributes=[];
    			saveQrReq.body.attributes.push({"attributeKey":"ENTERPRISE_APPSTORE_QR_CODE",
    									        "attributeValue":splitPath[4]+'/'+splitPath[5]
    										  });
        		userattributesdao.addNewUserAttributes(saveQrReq,res, function(err, data) {
        			if(err) {
        				//console.log('nxt fn8 : err addNewUserAttributes: '+JSON.stringify(err));
        				deferred.reject(err);
        			} else {
        				//console.log('nxt fn8 : success addNewUserAttributes');
        				deferred.resolve(email_data);
        			}
        		});
        }
    		return deferred.promise;
    	})
    	.then(function(email_data) {
    		//console.log('nxt fn9: add mail to queue'+JSON.stringify(email_data));
    		var deferred = Q.defer();
    		addMailToQueue(email_data, function(err, data) {
    			if(err) {
    				//console.log('nxt fn9 : err addMailToQueue: '+JSON.stringify(err));
    				deferred.reject(err);
    			} else {
    				//console.log('nxt fn9 : success addMailToQueue');
    				deferred.resolve();
    			}
    		});
    		return deferred.promise;
    	})
    	.then(function() {
    		//console.log('nxt fn10: associate mandatory apps on radia.');
    		var deferred = Q.defer();
        if(config.SKIP_RADIA) {
          deferred.resolve();
        }
        else {
          postSignUpPlatformUserAdapter.associateMandatoryAppsOnRadia(req, function(err, data) {
      			if(err) {
      				logger.error('PlatformUser : Controller : failed associateMandatoryAppsOnRadia : error : ' + err);
      				//console.log('nxt fn10 : err associateMandatoryAppsOnRadia: '+JSON.stringify(err));
      				deferred.reject(err);
      			} else {
      				//console.log('nxt fn10 : success associateMandatoryAppsOnRadia');
      				deferred.resolve();
      			}
      		});
        }
    		return deferred.promise;
    	})
    	.then(function() {
    		//console.log('nxt fn11: processMethod : adapter to allocate all experiences.');
    		addPlatformUserPostProcessAdapter.processMethod(req, function(err, data) {
    			if(err) {
    				logger.error('PlatformUser : Controller : failed processMethod : error : ' + err);
    				//console.log('nxt fn11 : err processMethod: '+JSON.stringify(err));
    				return callback(err);
    			} else {
    				logger.info('PlatformUser : Controller : processMethod successful');
    				//console.log('nxt fn11 : success processMethod');
    				return callback(null, response);
    			}
    		});
    	})
    	.fail(function(err) {
    	    //console.error('last err fn: Error received:', JSON.stringify(err));
    	    return callback(err);
    	})
    	.done();
  	}
};

var addUser = function(tokenId, req, res, callback) {
	userDao.addNewUser(tokenId, req, res, function(err, data) {
		if(err) {
			//console.log('fn2: userDao.addNewUser err: '+err);
			logger.error('PlatformUser : Controller : failed addNewUser : error : ' + err);
			if (tokenId == '') {
				return callback(err);
		    } else {
		    	platformuserdelegate.deleteUser(tokenId, req, res, function(error, data) {
		        if (error) {
		        	return callback(error);
		        } else {
		          //console.log("fn2: deleted successfully: " + JSON.stringify(data));
		          return callback(err);
		        }
		      })
		    }
		} else {
			//console.log('fn2: userDao.addNewUser data: '+JSON.stringify(data));
			return callback(null, data);
		}
	});
}

function addCompanyFromAdapter(req, callback) {
	postSignUpPlatformUserAdapter.addCompany(req, function(err, data) {
    	if(err) {
			logger.error('PlatformUser : Controller : failed addCompany : error : ' + err);
			return callback(err);
		} else {
      	    var company = data;
      	    //console.log('nxt fn3 : company: '+JSON.stringify(company));
            var referenceCompanyId = company.companyId;
            req.orgId = company.companyId;
            req.company = company;
            req.referenceCompanyId = referenceCompanyId;
	      	attributes = [];
	      	attributesObj = {
	      		  attributeName:"referenceCompanyId",
	      		  attributeValue: referenceCompanyId
	      	};
	      	attributes.push(attributesObj);
	      	return callback(null, attributes);
		}
    });
}

function assignRolesToUser(req, res, callback) {
	  roleDao.getRolesByFlag(req, res, function(err, roleData){
		  if(err) {
				logger.error('PlatformUser : Controller : failed getRolesByFlag : error : ' + err);
				return callback(err);
		  } else {
			  roleData.forEach(function(roles, index, array){
			  //logger.info("PlatformUser : Controller : Get Roles By Flag : " + JSON.stringify(roles));
			  getUserReq=req;
			  getUserReq.params.rolename= roles.roleName;
			  userRoleDao.getUsersByRoleName(getUserReq, res, function(err, getUsersResponse){
				if(err) {
					logger.error('PlatformUser : Controller : failed getUsersByRoleName: error : ' + err);
					return callback(err);
				} else {
					//logger.info("PlatformUser : Controller : Get Users By RoleName : " + JSON.stringify(getUsersResponse));
					//update on forgerock & then in db
					ForgeRockGetToken.getToken(function(err, tokenData) {
						if(err) {
							logger.error('PlatformUser : Controller : failed getToken: error : ' + err);
							return callback(err);
						} else {
							//logger.info("PlatformUser : Controller : ForgeRockGetTokenData " + tokenData);
							var usernamesArray=[];
							//console.log('req.body.username='+JSON.stringify(req.body.username));
							usernamesArray = getUsersResponse[0].username;
							usernamesArray.push(req.body.username);
							//console.log('usernamesArray='+usernamesArray);
							var updateRoleReq = req;
							updateRoleReq.headers['access-token'] = tokenData.tokenId ;
							updateRoleReq.params.rolename = roles.roleName;
							updateRoleReq.body.usernamesArray = usernamesArray;
							//console.log('updateRoleReq.body.usernamesArray='+JSON.stringify(updateRoleReq.body.usernamesArray));
							userRoleDelegate.updateRoleUsersByRoleName(updateRoleReq, res, function(err, updateroleresponse){
								if(err) {
									logger.error('PlatformUser : Controller : failed updateRoleUsersByRoleName: error : ' + err);
									return callback(err);
								} else {
									var updateRequest=req;
									updateRequest.body.usernamesArray= updateroleresponse.groupUsers;
									updateRequest.params.rolename= updateroleresponse.groupName;
									userRoleDao.updateRoleUsersByRoleName(updateRequest, res, function(err, data){
										if(err) {
											logger.error('PlatformUser : Controller : failed updateRoleUsersByRoleName: error : ' + err);
											return callback(err);
										}
										if(index === array.length-1) {
											logger.info('PlatformUser : Controller : updateRoleUsersByRoleName successful !');
											return callback(null, 'assign roles to user successful');
										}
									});
								}
							});
							}
							});
						}
			  		});
			  });
		  }
	 });
}

function createEmailData(req, res, callback) {
    var reqBody = req.body;
    var uname = reqBody.username;
    var pwd = reqBody.userpassword;
    accessToken = generateActivateTokenDAO.getActivateToken();
    generateActivateTokenDAO.saveToken(uname, accessToken, function(err, doc) {
		logger.info("saveToken success!");
    });

    /************************************************************************************************

    var queryString = `name=${uname}&password=${pwd}&server=${config.RADIA.HOSTNAME}&port=${config.RADIA.PORT}`,
    url = `${config.RADIA.AGENT_URL}?${new Buffer(queryString).toString('base64')}`;
    var qr_image = qr.image(url);
    //console.log("qr_image" + qr_image);
    var qr_file_path = config.QR_IMAGE_BASE_PATH + '/qr_' + new Date().getTime() + '.png';
    qr_image.pipe(fs.createWriteStream(qr_file_path));

    ************************************************************************************************/

    req.body.version = config.PLATFORMUSER_TEMPLATE_VERSION;
    req.body.jsonData = {
      "givenname": reqBody.givenName,
      "username": uname,
      "password": reqBody.userpassword,
      "token": accessToken+"&u=PU",
      "serverurl": config.SERVER_HOST
      // "radiaurl": config.RADIA.HOSTNAME,
      // "radiadownloadlink": config.RADIA.AGENT_URL
    };
    req.params.id = config.PLATFORMUSER_TEMPLATE_ID;
    req.headers['companyid'] = config.PLATFORMUSER_COMPANYID;
	//get email Template
    templateDao.getFilledTemplateById(req, res, function(err, data) {
      if (err) {
    	  logger.error('PlatformUser : Controller : failed getFilledTemplateById : error : ' + err);
		  return callback(err);
      } else {
        var emailObj = {
          	'toMail': uname,
              'template': data
              // 'qr_file_path': qr_file_path
        };
        var email_data = JSON.stringify(emailObj);
        //save message to db
        var req1 = req;
        req1.body.MessageType = 'Email';
        req1.headers['companyid'] = req.referenceCompanyId;
        req1.body.Message = email_data;
        req1.body.To = req.body.username;
        messagedao.addNewMessage(req1, res, function(err, data) {
			if (err) {
				logger.error('PlatformUser : Controller : failed addNewMessage : error : ' + err);
				return callback(err);
			} else {
				var messageId = data.messageId;
				emailObj.messageId = messageId;
				email_data = JSON.stringify(emailObj);
				logger.info('PlatformUser : Controller : addNewMessage successful !');
				//console.log('nxt fn7 createEmailData : email_data='+email_data);
				return callback(null, email_data);
			}
        });
       }
    });
}

function addMailToQueue(email_data, callback) {
    RabbitMQ.getConnection(function(connection) {
        connection.createChannel(function(err, ch) {
              //console.log("in queue");
              ch.assertQueue(q, {
                durable: false
              });
              ch.sendToQueue(q, new Buffer(email_data));
              console.log(" [x] Message sent to queue");
              setTimeout(function() {
                connection.close();
              }, 500);
        });
    });
    return callback(null, 'Message sent to queue');
}

function processAdapter(req, callback) {
	//console.log('nxt fn10: adapter to allocate all experiences.');
	addPlatformUserPostProcessAdapter.processMethod(req, function(err, data) {
		if(err) {
			logger.error('PlatformUser : Controller : failed processMethod : error : ' + err);
			return callback(err);
		} else {
			logger.info('PlatformUser : Controller : processMethod successful');
			return callback(null, 'adapter processing completed.');
		}
	});
}

/*
 * get user
 */
var getUser = function(req, res, callback) {
  logger.info('PlatformUser : controller : received request : getUser : body : ' + JSON.stringify(req.body))
  platformuserdelegate.getUser(req, res, callback);
};

/*
 * get UserByUsername
 */
var getUserByUsername = function(req, res, callback) {
  logger.info('PlatformUser : controller : received request : getUserByUsername  ')
  userDao.getUserByUsername(req, res, callback);

};


/*
 *activation link
 */
var validateActivationLink = function(req, res, callback) {
  logger.info('PlatformUser : controller : received request : validateActivationLink : body : ' + JSON.stringify(req.body));
  //encryptdecrypt.encryption(req.body.password);
  generateActivateTokenDAO.validateActivationLink(req, res, callback);
};

/*
 *	Get provisioned experiences for user
 */
var getProvisionedExperiencesByUserName = function(req, callback) {
  logger.info('PlatformUser : controller : received request : getProvisionedExperiencesByUserName : username : ' + req.params.username);
  provisionedExperienceDao.getProvisionedExperiencesByUserName(req, callback);
};

/*
 * get getAllUsers
 */
var getAllUsers = function(req, res, callback) {
  logger.info('PlatformUser : controller : received request : getAllUsers  ')
  userDao.getAllUsers(req, res, callback);

};

/*
 * Get All Provisioned Experience Details By Username
 */
var getAllProvisionedExperienceDetailsByUsername = function(req, callback) {
  logger.info('PlatformUser : controller : received request : getAllProvisionedExperienceDetailsByUsername : (platforusername:' + req.params.username + ')');

  provisionedExperienceDao.getProvisionedExperiencesByUserName(req, function(err, experiences) {
    if (err) {
      return callback(err);
    }
    var expIds = [];
    experiences.forEach(function(experience) {
      expIds.push(experience.experienceId);
    });
    experienceDao.getAllExperiencesByIds(expIds, callback);
  });

};

/*
 * get getVmDetailsByUsername
 */
var getVmDetailsByUsername = function(req, res, callback) {
  logger.info('PlatformUser : controller : received request : getVmDetailsByUsername  ')
  provisionedExperienceDao.getVmDetailsByUserName(req, res, callback);
};


var exportUserData = function(req, callback) {
	logger.info('PlatformUser : controller : received request : exportUserData : (username:' + req.headers.username + ')');
	platformuserdao.getAllUsers(req, null, function(err, platformUsers) {
		if(err) {
			err.status = 500;
			logger.error('PlatformUser : controller : exportUserData : getAllUsers : error :' + JSON.stringify(err));
			return callback(err);
		}
		var platformUsersDetails = [];
		async.forEach(platformUsers, function (platformUser, cb) {
			var numberOfExperiencesProvisioned = 0;
			var experienceNames = [];
			var user = {
				username: platformUser.username,
				mail: platformUser.mail,
				lastLoginDatetime: platformUser.lastLoginDatetime.toString()
			};
			provisionedExperienceDao.getAllProvisionedExperiencesByUserName(user.username, function(err, provExperiences) {
				if(err) {
					err.status = 500;
					logger.error('PlatformUser : controller : exportUserData : getAllProvisionedExperiencesByUserName : error :' + JSON.stringify(err));
					user.numberOfExperiencesProvisioned = numberOfExperiencesProvisioned;
					user.experiences = experienceNames.join();
					platformUsersDetails.push(user);
					cb();
				} else {
					numberOfExperiencesProvisioned = provExperiences.length;
					user.numberOfExperiencesProvisioned = numberOfExperiencesProvisioned;
					var expIds = [];
					provExperiences.forEach(function(experience){
						expIds.push(experience.experienceId);
					});
					experienceDao.getExperiencesByIds(expIds, function(err, experiences) {
						if(err) {
							err.status = 500;
							logger.error('PlatformUser : controller : exportUserData : getExperiencesByIds : error :' + JSON.stringify(err));
							user.experiences = experienceNames.join();
							cb();
						} else {
							experiences.forEach(function(exp) {
								experienceNames.push(exp.name);
							});
							user.experiences = experienceNames.join();
							platformUsersDetails.push(user);
							cb();
						}
					});
				}
			});
		}, function(err) {
		    if(err) {
		    	err.status = 500;
		    	return callback(err);
		    }
		    var exportPath = config.PATH_EXPORT_TO_EXCEL_PLATFORMUSER_DETAILS;
		    if(!fs.existsSync(exportPath)) {
		    	  fs.mkdirSync(exportPath);
		    }
		    var workbook = new Excel.Workbook();
		    var worksheet = workbook.addWorksheet('Platform_Users_Data');
		    worksheet.columns = [
                 { header: 'Username', key: 'username', width:35 },
                 { header: 'E-mail ID', key: 'mail', width:35 },
                 { header: '# experiences provisioned', key: 'numberOfExperiencesProvisioned', width:35 },
                 { header: 'Names of experiences provisioned', key: 'experiences', width:35 },
                 { header: 'Last login date time', key: 'lastLoginDatetime', width:35 }
            ];
		    worksheet.getRow(1).alignment = { vertical: 'top', horizontal: 'center' };
		    worksheet.getRow(1).font = { bold: true, alignment: 'center' };
		    worksheet.addRows(platformUsersDetails);
		    var filePath = exportPath + "\\file_" + new Date().getTime() + ".xlsx"
		    workbook.xlsx.writeFile(filePath)
		    .then(function() {
		    	logger.info('PlatformUser : controller : exportUserData : write xlsx file success : (filePath : '+filePath+')');
		    	callback(null, filePath)
			});
		});
	});
}

/*
 * Reset Password
 */
var resetPassword = function(req, res, callback) {
  logger.info('PlatformUser : controller : received request : resetPassword  ');
  registrationDao.getAllUserByUsername(req, res, function(err, data) {
		 if (err) {
      logger.error('Registration : DAO : failed getUserByUsername : error : ' + err);
      callback(err, null);
    } else {
		logger.info('Registration : DAO : getUserByUsername successful !');
      if (data[0].verified) {
		  resetPasswordDelegate.resetPassword(req, res, callback);
	  }
	  else {
        var err = new Error('User Not Verified');
        err.status = 500;
        callback(err, null);
      }
	}
	});
};

/*
 * Forgot Password Reset
 */
var forgotPasswordReset = function(req, res, callback) {
  logger.info('PlatformUser : controller : received request : forgotPasswordReset'+JSON.stringify(req.body));
  forgotPasswordDelegate.forgotPasswordReset(req, res, function(err,response){
	if(err){
	  callback(err,null);
	}
	else{
	  callback(null,response);
	}
  });
};

module.exports.addNewUser = addNewUser;
module.exports.getUser = getUser;
module.exports.validateActivationLink = validateActivationLink;
module.exports.getUserByUsername = getUserByUsername;
module.exports.getProvisionedExperiencesByUserName = getProvisionedExperiencesByUserName;
module.exports.getAllUsers = getAllUsers;
module.exports.getAllProvisionedExperienceDetailsByUsername = getAllProvisionedExperienceDetailsByUsername;
module.exports.getVmDetailsByUsername = getVmDetailsByUsername;
module.exports.exportUserData = exportUserData;
module.exports.resetPassword= resetPassword;
module.exports.forgotPasswordReset= forgotPasswordReset;
