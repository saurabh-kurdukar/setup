var bunyan = require('bunyan');
var fs = require('fs');
//var auditEventDAO = require('../dao/auditEventDAO');
var auditLogger = require('../../common/logger').auditEventLog;


var postAuditEvent = function(req, res, callback) {
  auditLogger.info(req.body);
  callback(null);
};

var getAllAuditEvents = function(req, res, callback) {
  fs.readFile('auditEvent.log', 'utf8', function (err,data) {
  if (err) {
    callback(err);
	return;
  }
  callback(null,data);
});

};

module.exports.postAuditEvent = postAuditEvent;
module.exports.getAllAuditEvents = getAllAuditEvents;

/*  USAGE - Call audit function for changed data
var auditEvent = require('../../common/Audit').audit;

var newAuditEvent =
				{"username" : "varsha_gadekar@persistent.com",
				"payload" : "buddy pay",
				"event" : "provision",
				"status" : "PROVISIONED",
				"date" : "2016-03-12"};

auditEvent(req, res, newAuditEvent);
 */
