var mongoose = require('../../common/MongoDbConnection').mongoose;
var autoIncrement = require('mongoose-auto-increment');
var logger = require('../../common/logger').log;
var connection = mongoose.connection;
autoIncrement.initialize(connection);
const MODULE_NAME = "experience";


/*
 * Define schema
 */
var component = mongoose.Schema({

	id : Number,
    name : { type: String },
    description : { type: String },
    summary : { type: String },
    logo : { type: String },
    baseUrl : { type: String },
    versionNo: String

});

var experienceSchema = mongoose.Schema({
	id : Number,
  name : { type: String, unique: true, required: 'Experience name is required' },
  description : { type: String, required: 'field description is required' },
  longDescription : { type: String },
  logo : { type: String },
  screenshots : [],
  components : [ component ],
  domain : { type: String, required: 'field domain is required' },
  webAppOffered : { type: String, default: 'false' },
  androidAppOffered : { type: String, default: 'false' },
  iOSAppOffered : { type: String, default: 'false' },
  apiOffered : { type: String, default: 'false' },
  datasetOffered : { type: String, default: 'false' },
  tabletOffered : { type: String, default: 'false' },
  wearableOffered : { type: String, default: 'false' },
  owner : { type: String, required: 'field owner is required' },
  status : { type: String, default: 'ACTIVE' },				// what are possible values ? default value ?
  version : { type: String, required: 'field version is required' },
  numberOfInstalls : { type: Number, default: 0 },
  hitsCounter: { type: Number, default: 0 },
  userCount: { type: Number, default: 0 },
  vmCount: { type: Number, default: 0 },
	deviceSupported: [{type: String, enum: ["MOBILE","DESKTOP","TABLET","WEARABLE", "Android Less than 7 Inches", "Android Tablet more than 7 Inches", "All Android Devices", "iPhone Only", "iPad Only", "Both iPhone and iPad"]}], 	// values: MOBILE,DESKTOP,TABLET,WEARABLE. It is used for filtering
	classification: [],			// values : "Employee", "Product", "Customers", "Partners", "Top Line", "Productivity", "Bottom line", "Satisfaction"
  createdOn: { type: Date },
	createdBy: {type: String},
	updatedOn: { type: Date },
	updatedBy: {type: String}
});


logger.info(MODULE_NAME+' : model : created schema : Experiences :'+JSON.stringify(experienceSchema.paths));


experienceSchema.path('name').validate(function(value, fn) {
	  var Experience = mongoose.model('Experiences');
	  Experience.find({'name': value}, function (err, data) {
	    fn(err || data.length === 0);
	  });
}, 'Experience name is already taken');


experienceSchema.pre('findOneAndUpdate', function(next) {
	  this.options.runValidators = true;
	  next();
});

experienceSchema.pre('update', function(next) {
	  this.options.runValidators = true;
	  next();
});

experienceSchema.path('name').validate(function (v) {
	  return (v.length > 0 && v.length <= 100);
}, 'data too long/short for field name');


experienceSchema.plugin(autoIncrement.plugin, { model: 'Experiences', field: 'id', startAt: 1 });

/*
 * Setters
 */
experienceSchema.methods.setId = function(id) {
	this.id = id;
};

experienceSchema.methods.setName = function(name) {
	this.name = name;
};

experienceSchema.methods.setDescription = function(description) {
	this.description = description;
};

experienceSchema.methods.setLongDescription = function(longDescription) {
	this.longDescription = longDescription;
};

experienceSchema.methods.setLogo = function(logo) {
	this.logo = logo;
};

experienceSchema.methods.setScreenshots = function(screenshots) {
	this.screenshots = screenshots;
};

experienceSchema.methods.addScreenshot = function(screenshot) {
	this.screenshots.push(screenshot);
};

experienceSchema.methods.setComponents = function(components) {
	this.components = components;
};

experienceSchema.methods.addComponent = function(component) {
	this.components.push(component);
};

experienceSchema.methods.setDomain = function(domain) {
	this.domain = domain;
};

experienceSchema.methods.setWebAppOffered = function(webAppOffered) {
	this.webAppOffered = webAppOffered;
};

experienceSchema.methods.setAndroidAppOffered = function(androidAppOffered) {
	this.androidAppOffered = androidAppOffered;
};

experienceSchema.methods.setiOSAppOffered = function(iOSAppOffered) {
	this.iOSAppOffered = iOSAppOffered;
};

experienceSchema.methods.setApiOffered = function(apiOffered) {
	this.apiOffered = apiOffered;
};

experienceSchema.methods.setDatasetOffered = function(datasetOffered) {
	this.datasetOffered = datasetOffered;
};

experienceSchema.methods.setOwner = function(owner) {
	this.owner = owner;
};

experienceSchema.methods.setStatus = function(status) {
	this.status = status;
};

experienceSchema.methods.setVersion = function(version) {
	this.version = version;
};

experienceSchema.methods.setNumberOfInstalls = function(numberOfInstalls) {
	this.numberOfInstalls = numberOfInstalls;
};

experienceSchema.methods.setHitsCounter = function(hitsCounter) {
	this.hitsCounter = hitsCounter;
};

experienceSchema.methods.setUserCount = function(userCount) {
	this.userCount = userCount;
};

experienceSchema.methods.setVMCount = function(vmCount) {
	this.vmCount = vmCount;
};

experienceSchema.methods.addDeviceSupported = function(deviceSupported) {
	this.deviceSupported.push(deviceSupported);
};

experienceSchema.methods.setCreatedOn = function(createdOn) {
	this.createdOn = createdOn;
};

experienceSchema.methods.setCreatedBy = function(createdBy) {
	this.createdBy = createdBy;
};

experienceSchema.methods.setUpdatedOn = function(updatedOn) {
	this.updatedOn = updatedOn;
};

experienceSchema.methods.setUpdatedBy = function(updatedBy) {
	this.updatedBy = updatedBy;
};

/*
 * Create collection/model in mongo db using Schema
 */
var Experience = mongoose.model('Experiences', experienceSchema);
logger.info(MODULE_NAME+' : model : created model : Experiences : ' + Experience);

module.exports = Experience;
