var experienceDao = require('../dao/ExperienceDAO');
var companyDao = require('../../company/dao/CompanyDAO');
var appDao = require('../../application/dao/AppDAO');
var documentDao = require('../../documents/dao/DocumentDAO');
var manifestDao = require('../../manifest/dao/ManifestDAO');
var attributesDao = require('../../attributes/dao/AttributesDAO');
var logger = require('../../common/logger').log;
const MODULE_NAME = "experience";

/*
 * Add new experience
 */
var addNewExperience = function(req, res, callback) {
	logger.info(MODULE_NAME+' : controller : received request : addNewExperience : body : '+JSON.stringify(req.body));	
	experienceDao.addNewExperience(req, res, callback);
};

/*
 * Get experience by experience id
 */
var getExperienceById = function(req, res, callback) {
	logger.info(MODULE_NAME+' : controller : received request : getExperienceById : (id:'+req.params.id+')');	
	experienceDao.getExperienceById(req, res, callback);
};

/*
 * Get all experiences
 */
var getAllExperiences = function(req, res, callback) {
	logger.info(MODULE_NAME+' : controller : received request : getAllExperiences : query params : '+JSON.stringify(req.query));	
	experienceDao.getAllExperiences(req, res, callback);
};

/*
 * Edit/Update experience details
 */
var updateExperienceById = function(req, res, callback) {
	logger.info(MODULE_NAME+' : controller : received request : updateExperienceById : (id:'+req.params.id+', body:'+JSON.stringify(req.body)+')');
	experienceDao.updateExperienceById(req, res, callback);
};

/*
 * Get all apps created for given experience id
 */
var getAllApps = function(req, res, callback) {
	logger.info(MODULE_NAME+' : controller : received request : getAllApps : (experienceId:'+req.params.id+', companyId:'+req.header('companyId')+')');
	appDao.getAllApps(req, res, callback);
};

/*
 * Delete experience by id
 */
var deleteExperienceById = function(req, res, callback) {
	logger.info(MODULE_NAME+' : controller : received request : deleteExperienceById : (experienceId:'+req.params.id+')');
	experienceDao.deleteExperienceById(req, res, callback);
};

/*
 * Publish experience by id
 */
var publishExperienceById = function(req, res, callback) {
	logger.info(MODULE_NAME+' : controller : received request : publishExperienceById : (experienceId:'+req.params.id+')');
	experienceDao.publishExperienceById(req, res, callback);
};

/*
 * Get manifest by experience id
 */
var getManifestByExperienceId = function(req, res, callback) {
	logger.info(MODULE_NAME+' : controller : received request : getManifestByExperienceId : (id:'+req.params.id+')');	
	experienceDao.getManifestByExperienceId(req, res, callback);
};

/*
* Get Experiences for given Experience Id's (comma separated in query)
*/
var getExperiencesByExperienceIdsInQuery = function(req, res, callback) {
	logger.info(MODULE_NAME+' : controller : received request : getExperiencesByExperienceIdsInQuery : experienceIds :'+req.query.experiences);	
	experienceDao.getExperiencesByExperienceIdsInQuery(req, res, callback);
};

/*
* Get most viewed experiences
*/
var getMostViewedExperiences = function(req, res, callback) {
	logger.info(MODULE_NAME+' : controller : received request : getMostViewedExperiences');	
	experienceDao.getMostViewedExperiences(req, res, callback);
};


/*
* Get most viewed experiences by domain
*/
var getMostViewedExperiencesByDomain = function(req, res, callback) {
	logger.info(MODULE_NAME+' : controller : received request : getMostViewedExperiencesByDomain : domain : ' + req.params.domain);	
	experienceDao.getMostViewedExperiencesByDomain(req, res, callback);
};


/*
* Get documents
*/
var getDocumentsByExperienceId = function(req, callback) {
	logger.info(MODULE_NAME+' : controller : received request : getDocumentsByExperienceId : id : ' + req.params.id);	
	documentDao.getDocumentsByExperienceId(req.params.id, callback);
};


/*
* Get manifest by experience id & version
*/
var getManifestByExperienceIdAndVersion = function(req, callback) {
	logger.info(MODULE_NAME+' : controller : received request : getManifestByExperienceIdAndVersion : ' +
    		+ '(experienceId=' + req.params.id + ', version=' + req.params.version);	
	experienceDao.getManifestByExperienceIdAndVersion(req.params.id, req.params.version, callback);
};

/*
* Get vms by experience id
*/
var getVMsByExperienceId = function(req, res,callback) {
	logger.info(MODULE_NAME+' : controller : received request : getVMsByExperienceId : ' +
    		+ '(experienceId=' + req.params.id );	
	experienceDao.getVMsByExperienceId(req,res ,callback);
};

/*
* Get users by experience id
*/
var getUsersByExperienceId = function(req, res,callback) {
	logger.info(MODULE_NAME+' : controller : received request : getUsersByExperienceId : ' +
    		+ '(experienceId=' + req.params.id );	
	experienceDao.getUsersByExperienceId(req,res ,callback);
};

/*
* Get all experiences using filters
*/
var getExperiencesUsingFilters = function(req, callback) {
	logger.info(MODULE_NAME+' : controller : received request : getExperiencesUsingFilters : body : '+JSON.stringify(req.body)
			+'query params: '+JSON.stringify(req.query));
	manifestDao.getExperiencesUsingFilters(req, function(err, experiences) {		
		if(err) {			
			return callback(err);
		}
		var experienceIds = [];	
		experiences.forEach(function(experience){
			experienceIds.push(experience.experienceId);
		});		
		experienceDao.getExperiencesByIds(experienceIds, callback);
	});
};


/*
* Get all experiences using filters in query params
*/
var getExperiencesUsingFiltersInQuery = function(req, callback) {
	logger.info(MODULE_NAME+' : controller : received request : getExperiencesUsingFiltersInQuery : query params: '+JSON.stringify(req.query));
	manifestDao.getExperiencesUsingFiltersInQuery(req, function(err, experiences) {		
		if(err) {			
			return callback(err);
		}
		var experienceIds = [];	
		experiences.forEach(function(experience){
			experienceIds.push(experience.experienceId);
		});		
		experienceDao.getExperiencesByIds(experienceIds, callback);
	});
};


/*
* Get all attributes by experience id
*/
var getAllAttributes = function(req, callback) {
	logger.info(MODULE_NAME+' : controller : received request : getAllAttributes : expid: '+req.params.id);
	req.params.experienceId = req.params.id; 
	attributesDao.getAllAttributes(req, callback);
};


/*
* Get all experience only attributes by experience id
*/
var getAllExperienceAttributes = function(req, callback) {
	logger.info(MODULE_NAME+' : controller : received request : getAllExperienceAttributes : expid: '+req.params.id);	 
	attributesDao.getAllExperienceAttributes(req.params.id, callback);
};






module.exports.addNewExperience = addNewExperience;
module.exports.getExperienceById = getExperienceById;
module.exports.getAllExperiences = getAllExperiences;
module.exports.updateExperienceById = updateExperienceById;
module.exports.getAllApps = getAllApps;
module.exports.deleteExperienceById = deleteExperienceById;
module.exports.publishExperienceById = publishExperienceById;
module.exports.getManifestByExperienceId = getManifestByExperienceId;
module.exports.getExperiencesByExperienceIdsInQuery = getExperiencesByExperienceIdsInQuery;
module.exports.getMostViewedExperiences = getMostViewedExperiences;
module.exports.getMostViewedExperiencesByDomain = getMostViewedExperiencesByDomain;
module.exports.getDocumentsByExperienceId = getDocumentsByExperienceId;
module.exports.getManifestByExperienceIdAndVersion = getManifestByExperienceIdAndVersion;
module.exports.getVMsByExperienceId= getVMsByExperienceId;
module.exports.getUsersByExperienceId= getUsersByExperienceId;
module.exports.getExperiencesUsingFilters = getExperiencesUsingFilters;
module.exports.getExperiencesUsingFiltersInQuery = getExperiencesUsingFiltersInQuery;
module.exports.getAllAttributes = getAllAttributes;
module.exports.getAllExperienceAttributes = getAllExperienceAttributes;







