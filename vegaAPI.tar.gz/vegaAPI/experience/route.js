var express = require('express');
var experienceController = require('./controller/ExperienceController');
var logger = require('../common/logger').log;
var ErrorResponse = require('../common/ErrorResponse').ErrorResponse;
var router = express.Router();
var serviceController = require('../service/controller/ServiceController');
var manifestController = require('../manifest/controller/ManifestController');
var validationUtil = require('../common/validationUtil');
const MODULE_NAME = "experience";

/*
 * Add new experience
 */
router.post('/', function(req, res) {
	logger.info(MODULE_NAME+' : router : received request : addNewExperience : body : '+JSON.stringify(req.body));		
	experienceController.addNewExperience(req, res, function(err, data) {
		if (err) {
			logger.error(MODULE_NAME+' : router : failed addNewExperience : error : '+err);   
			var error = new ErrorResponse();
			if(err.name == 'ValidationError'){
        		error.setErrorMessage(err.errors[Object.keys(err.errors)[0]].message);
        	} else {
        		error.setErrorMessage(err.message);
        	}
        	error.setErrorCode("E0001");        	
        	error.setHttpResponseCode(500);
			res.status(500).end(JSON.stringify(error));
		} else {
			logger.info("experience : router : addNewExperience successful !");
			res.status(200).end(JSON.stringify(data));
		}
	});	
});

/*
 * Get experience by 	 id
 */
router.get('/:id(\\d+)', function(req, res) {
	logger.info(MODULE_NAME+' : router : received request : getExperienceById : (experienceId:'+req.params.id+')');
	experienceController.getExperienceById(req, res, function(err, data) {
		if (err) {
			logger.error(MODULE_NAME+' : router : failed getExperienceById : error : '+err); 
			var error = new ErrorResponse();
			error.setErrorCode("E0002");
			error.setErrorMessage(err.message);
			error.setHttpResponseCode(500);
			res.status(500).end(JSON.stringify(error));
		} else {
			logger.info("experience : router : getExperienceById successful !");
			res.status(200).end(JSON.stringify(data));
		}
	});	
});

/*
 * Get all experiences
 */
/*router.get('/', function(req, res) {
	logger.info(MODULE_NAME+' : router : received request : getAllExperiences : (experienceId:'+req.params.id+')');
	experienceController.getAllExperiences(req, res, function(err, data) {
		if (err) {
			logger.error(MODULE_NAME+' : router : failed getAllExperiences : error : '+err); 
			var error = new ErrorResponse();
			error.setErrorCode("E0003");
			error.setErrorMessage(err.message);
			error.setHttpResponseCode(500);
			res.status(500).end(JSON.stringify(error));
		} else {
			logger.info("experience : router : getAllExperiences successful !");
			res.status(200).end(JSON.stringify(data));
		}
	});	
});*/

/*
 * Get experiences : All or Multiples by experience id's
 */
router.get('/', function(req, res) {	
	if(JSON.stringify(req.query) != null && JSON.stringify(req.query) !== '{}'){
		logger.info(MODULE_NAME+' : router : received request : getAllExperiences : query params : '+JSON.stringify(req.query));
		if( ( req.query.top != undefined ) || ( req.query.top != null ) || req.query.status ){
			logger.info(MODULE_NAME+' : router : received request : getAllExperiences...');
			experienceController.getAllExperiences(req, res, function(err, data) {
				if (err) {
					logger.error(MODULE_NAME+' : router : failed getAllExperiences : error : '+err); 
					var error = new ErrorResponse();
					error.setErrorCode("E0003");
					error.setErrorMessage(err.message);
					error.setHttpResponseCode(500);
					res.status(500).end(JSON.stringify(error));
				} else {
					logger.info("experience : router : getAllExperiences successful !");
					res.status(200).end(JSON.stringify(data));
				}
			});	
		}
		else if(req.query.companyId != null && req.query.experiences != null){			
			var experienceIds = [];
			experienceIds = req.query.experiences.split(',');
			// Remove white spaces
			for(var i = 0; i < experienceIds.length; i++){
				if(experienceIds[i]){
					experienceIds[i] = experienceIds[i].trim();
				}
			}
			if(validationUtil.validateNumbericArray(experienceIds)){
				experienceController.getExperiencesByExperienceIdsInQuery(req, res, function(err, data) {
					if (err) {
						logger.error(MODULE_NAME+' : router : failed getExperiencesByExperienceIdsInQuery : error : '+err); 
						var error = new ErrorResponse();
						error.setErrorCode("E0003");
						error.setErrorMessage(err.message);
						error.setHttpResponseCode(500);
						res.status(500).end(JSON.stringify(error));
					} else {
						logger.info("experience : getExperiencesByExperienceIdsInQuery successful !");
						res.status(200).end(JSON.stringify(data));
					}
				});
			}else{
				var error = new ErrorResponse();
				error.setErrorCode("E0003");
				error.setErrorMessage('experienceIds and company id must be Numberic');
				error.setHttpResponseCode(500);
				logger.error('company : router : failed getExperiencesByExperienceIdsInQuery : error :'+JSON.stringify(error));    	
				res.status(500).end(JSON.stringify(error));
			}
		}else{
			var error1 = new ErrorResponse();
			error1.setErrorCode("E0003");
			error1.setErrorMessage('experienceIds and/ or company id not passed in query');
			error1.setHttpResponseCode(500);
			logger.error('company : router : failed getExperiencesByExperienceIdsInQuery : error :'+JSON.stringify(error1));    	
			res.status(500).end(JSON.stringify(error1));
		}
	}
	else{
		logger.info(MODULE_NAME+' : router : received request : getAllExperiences');
		experienceController.getAllExperiences(req, res, function(err, data) {
			if (err) {
				logger.error(MODULE_NAME+' : router : failed getAllExperiences : error : '+err); 
				var error = new ErrorResponse();
				error.setErrorCode("E0003");
				error.setErrorMessage(err.message);
				error.setHttpResponseCode(500);
				res.status(500).end(JSON.stringify(error));
			} else {
				logger.info("experience : router : getAllExperiences successful !");
				res.status(200).end(JSON.stringify(data));
			}
		});	
	}
});


/*
 * Edit/Update experience
 */
router.put('/:id', function(req, res) {
	logger.info(MODULE_NAME+' : router : received request : updateExperienceById : (id:'+req.params.id+', body:'+JSON.stringify(req.body)+')');
	experienceController.updateExperienceById(req, res, function(err, data) {
		if (err) {
			logger.error(MODULE_NAME+' : router : failed updateExperienceById : error : '+err); 
			var error = new ErrorResponse();
			if(err.name == 'ValidationError'){
        		error.setErrorMessage(err.errors[Object.keys(err.errors)[0]].message);
        	} else {
        		error.setErrorMessage(err.message);
        	}
			error.setErrorCode("E0004");				
			error.setHttpResponseCode(500);
			res.status(500).end(JSON.stringify(error));
		} else {
			logger.info("experience : router : updateExperienceById successful !");
			res.status(200).end(JSON.stringify(data));
		}
	});		
});

/*
 * Get all apps created for given experience id
 */
router.get('/:id/apps', function(req, res) {
	logger.info(MODULE_NAME+' : router : received request : getAllApps : (experienceId:'+req.params.id+')');	
	experienceController.getAllApps(req, res, function(err, data) {
		if (err) {
			logger.error(MODULE_NAME+' : router : failed getAllApps : error : '+err); 
			var error = new ErrorResponse();
			error.setErrorCode("E0005");
			error.setErrorMessage(err.message);
			error.setHttpResponseCode(500);
			res.status(500).end(JSON.stringify(error));
		} else {
			logger.info("experience : getAllApps successful !");
			res.status(200).end(JSON.stringify(data));
		}
	});	
});

/*
* Get Services for given Experience id
*/
router.get('/:id/services', function(req, res) {
    logger.info(MODULE_NAME+' : router : received request : getServicesByExperienceId : experienceId :'+req.params.id);
    serviceController.getServicesByExperienceId(req, res, function(err, data) {
        if (err) {
            logger.error(MODULE_NAME+' : router : failed getServicesByExperienceId : error : '+err); 
            var error = new ErrorResponse();
            error.setErrorCode("E0006");
            error.setErrorMessage(err.message);
            error.setHttpResponseCode(500);
            res.status(500).end(JSON.stringify(error));
        } else {
            logger.info("experience : getServicesByExperienceId successful !");
            res.status(200).end(JSON.stringify(data));
        }
    });           
});

/*
* Delete experience by id
*/
router.delete('/:id', function(req, res) {
    logger.info(MODULE_NAME+' : router : received request : deleteExperienceById : experienceId :'+req.params.id);
    experienceController.deleteExperienceById(req, res, function(err, data) {
        if (err) {
            logger.error(MODULE_NAME+' : router : failed deleteExperienceById : error : '+err); 
            var error = new ErrorResponse();
            error.setErrorCode("E0007");
            error.setErrorMessage(err.message);
            error.setHttpResponseCode(500);
            res.status(500).end(JSON.stringify(error));
        } else {
            logger.info("experience : deleteExperienceById successful !");
            res.status(200).end(JSON.stringify(data));
        }
    });           
});

/*
* Publish experience by id
*/
router.put('/:id/publish', function(req, res) {
    logger.info(MODULE_NAME+' : router : received request : publishExperienceById : experienceId :'+req.params.id);
    experienceController.publishExperienceById(req, res, function(err, data) {
        if (err) {
            logger.error(MODULE_NAME+' : router : failed publishExperienceById : error : '+err); 
            var error = new ErrorResponse();
            error.setErrorCode("E0008");
            error.setErrorMessage(err.message);
            error.setHttpResponseCode(500);
            res.status(500).end(JSON.stringify(error));
        } else {
            logger.info("experience : publishExperienceById successful !");
            res.status(200).end(JSON.stringify(data));
        }
    });           
});

/*
* Get manifest by experience id
*/
router.get('/:id/manifest', function(req, res) {
    logger.info(MODULE_NAME+' : router : received request : getManifestByExperienceId : experienceId :'+req.params.id);
    experienceController.getManifestByExperienceId(req, res, function(err, data) {
        if (err) {
            logger.error(MODULE_NAME+' : router : failed getManifestByExperienceId : error : '+err); 
            var error = new ErrorResponse();
            error.setErrorCode("E0009");
            error.setErrorMessage(err.message);
            error.setHttpResponseCode(500);
            res.status(500).end(JSON.stringify(error));
        } else {
            logger.info("experience : getManifestByExperienceId successful !");
            res.status(200).end(JSON.stringify(data));
        }
    });           
});


/*
* Get most viewed experiences
*/
router.get('/mostviewed', function(req, res) {
    logger.info(MODULE_NAME+' : router : received request : getMostViewedExperiences');
    experienceController.getMostViewedExperiences(req, res, function(err, data) {
        if (err) {
            logger.error(MODULE_NAME+' : router : failed getMostViewedExperiences : error : '+err); 
            var error = new ErrorResponse();
            error.setErrorCode("E00010");
            error.setErrorMessage(err.message);
            error.setHttpResponseCode(500);
            res.status(500).end(JSON.stringify(error));
        } else {
            logger.info("experience : getMostViewedExperiences successful !");
            res.status(200).end(JSON.stringify(data));
        }
    });           
});


/*
* Get most viewed experiences by domain
*/
router.get('/mostviewed/:domain', function(req, res) {
    logger.info(MODULE_NAME+' : router : received request : getMostViewedExperiencesByDomain: domain : ' + req.params.domain);
    experienceController.getMostViewedExperiencesByDomain(req, res, function(err, data) {
        if (err) {
            logger.error(MODULE_NAME+' : router : failed getMostViewedExperiencesByDomain : error : '+err); 
            var error = new ErrorResponse();
            error.setErrorCode("E00011");
            error.setErrorMessage(err.message);
            error.setHttpResponseCode(500);
            res.status(500).end(JSON.stringify(error));
        } else {
            logger.info("experience : getMostViewedExperiencesByDomain successful !");
            res.status(200).end(JSON.stringify(data));
        }
    });           
});


/*
* Get documents by experience id
*/
router.get('/:id/documents', function(req, res) {
    logger.info(MODULE_NAME+' : router : received request : getDocumentsByExperienceId: domain : ' + req.params.domain);
    experienceController.getDocumentsByExperienceId(req, function(err, data) {
        if (err) {
            logger.error(MODULE_NAME+' : router : failed getDocumentsByExperienceId : error : '+err); 
            var error = new ErrorResponse();
            error.setErrorCode("E00012");
            error.setErrorMessage(err.message);
            error.setHttpResponseCode(err.status);
            res.status(err.status).end(JSON.stringify(error));
        } else {
            logger.info(MODULE_NAME + " : getDocumentsByExperienceId successful !");
            res.status(200).end(JSON.stringify(data));
        }
    });           
});


/*
* Get manifest by experience id & version
*/
router.get('/:id/manifest/:version', function(req, res) {
    logger.info(MODULE_NAME+' : router : received request : getManifestByExperienceIdAndVersion : ' +
    		+ '(experienceId=' + req.params.id + ', version=' + req.params.version);
    experienceController.getManifestByExperienceIdAndVersion(req, function(err, data) {
        if (err) {
            logger.error(MODULE_NAME+' : router : failed getManifestByExperienceIdAndVersion : error : '+err); 
            var error = new ErrorResponse();
            error.setErrorCode("E00013");
            error.setErrorMessage(err.message);
            error.setHttpResponseCode(err.status);
            return  res.status(err.status).end(JSON.stringify(error));
        }
        logger.info(MODULE_NAME + " : router : getManifestByExperienceIdAndVersion successful !");
        res.status(200).end(JSON.stringify(data));    
    });           
});

/*
* Get vms by experience id
*/
router.get('/:id/vms', function(req, res) {
    logger.info(MODULE_NAME+' : router : received request : getVMsByExperienceId : ' +
    		+ '(experienceId=' + req.params.id);
    experienceController.getVMsByExperienceId(req, res, function(err, data) {
        if (err) {
            logger.error(MODULE_NAME+' : router : failed getVMsByExperienceId : error : '+err); 
            var error = new ErrorResponse();
            error.setErrorCode("E00014");
            error.setErrorMessage(err.message);
            error.setHttpResponseCode(err.status);
            return  res.status(err.status).end(JSON.stringify(error));
        }
        logger.info(MODULE_NAME + " : router : getVMsByExperienceId successful !");
        res.status(200).end(JSON.stringify(data));    
    });           
});

/*
* Get users by experience id
*/
router.get('/:id/users', function(req, res) {
    logger.info(MODULE_NAME+' : router : received request : getUsersByExperienceId : ' +
    		+ '(experienceId=' + req.params.id);
    experienceController.getUsersByExperienceId(req, res, function(err, data) {
        if (err) {
            logger.error(MODULE_NAME+' : router : failed getUsersByExperienceId : error : '+err); 
            var error = new ErrorResponse();
            error.setErrorCode("E00015");
            error.setErrorMessage(err.message);
            error.setHttpResponseCode(err.status);
            return  res.status(err.status).end(JSON.stringify(error));
        }
        logger.info(MODULE_NAME + " : router : getUsersByExperienceId successful !");
        res.status(200).end(JSON.stringify(data));    
    });           
});


/*
* Get all experiences using filters in request body
*/
router.post('/search', function(req, res) {
    logger.info(MODULE_NAME+' : router : received request : getExperiencesUsingFilters : body : '+JSON.stringify(req.body)
			+'query params: '+JSON.stringify(req.query));
    experienceController.getExperiencesUsingFilters(req, function(err, data) {
        if (err) {
            logger.error(MODULE_NAME+' : router : failed getExperiencesUsingFilters : error : '+err); 
            var error = new ErrorResponse("E00016", err.message, err.status);            
            return res.status(err.status).end(JSON.stringify(error));
        }
        logger.info(MODULE_NAME + " : router : getExperiencesUsingFilters successful !");
        res.status(200).end(JSON.stringify(data));    
    });    
});


/*
* Get all experiences using filters in query params
*/
router.get('/search', function(req, res) {
    logger.info(MODULE_NAME+' : router : received request : getExperiencesUsingFiltersInQuery : query params: '+JSON.stringify(req.query));
    experienceController.getExperiencesUsingFiltersInQuery(req, function(err, data) {
        if (err) {
            logger.error(MODULE_NAME+' : router : failed getExperiencesUsingFiltersInQuery : error : '+err); 
            var error = new ErrorResponse("E00017", err.message, err.status);            
            return res.status(err.status).end(JSON.stringify(error));
        }
        logger.info(MODULE_NAME + " : router : getExperiencesUsingFiltersInQuery successful !");
        res.status(200).end(JSON.stringify(data));    
    });    
});


/*
* Get all attributes by experience id
*/
router.get('/:id(\\d+)/allattributes', function(req, res) {
    logger.info(MODULE_NAME+' : router : received request : getAllAttributes : expid: '+req.params.id);
    experienceController.getAllAttributes(req, function(err, data) {
        if (err) {
            logger.error(MODULE_NAME+' : router : failed getAllAttributes : error : '+err); 
            var error = new ErrorResponse("E00018", err.message, 500);            
            return res.status(500).end(JSON.stringify(error));
        }
        logger.info(MODULE_NAME + " : router : getAllAttributes successful !");
        res.status(200).end(JSON.stringify(data));    
    });    
});


/*
* Get all experience only attributes by experience id
*/
router.get('/:id(\\d+)/attributes', function(req, res) {
    logger.info(MODULE_NAME+' : router : received request : getAllExperienceAttributes : expid: '+req.params.id);
    experienceController.getAllExperienceAttributes(req, function(err, data) {
        if (err) {
            logger.error(MODULE_NAME+' : router : failed getAllExperienceAttributes : error : '+err); 
            var error = new ErrorResponse("E00019", err.message, 500);            
            return res.status(500).end(JSON.stringify(error));
        }
        logger.info(MODULE_NAME + " : router : getAllExperienceAttributes successful !");
        res.status(200).end(JSON.stringify(data));    
    });    
});




module.exports = router;








