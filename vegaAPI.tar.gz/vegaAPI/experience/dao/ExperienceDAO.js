var async = require('async');
var logger = require('../../common/logger').log;
var audit = require('../../common/Audit').audit;
var Experience = require('../models/Experience');
var appDao = require('../../application/dao/AppDAO');
var serviceDao = require('../../service/dao/ServiceDAO');
var Manifest = require('../../manifest/models/Manifest');
var manifestDao = require('../../manifest/dao/ManifestDAO');
var SurveyAssociationDao = require('../../survey/dao/SurveyAssociationDAO');
var documentDao = require('../../documents/dao/DocumentDAO');
var config = require('../../common/Config');
const MODULE_NAME = "experience";
const NUMBER_OF_RECORDS_FOR_MOSTVIEWED = 5;
var Provisionedvms= require('../../provision/models/provisioned-vm').ProvisionedVM;
var ObjectId = require('mongoose').Types.ObjectId;
var provisionexpdao= require('../../provision/dao/provision-experience-dao');
var Provisionedexp= require('../../provision/models/provisioned-experience').ProvisionedExperience;
var platformuserdao= require('../../platformUser/dao/PlatformUserDAO');
var userdao= require('../../userManagement/dao/UserRegistrationDAO');
var azureVmDao= require('../../vmDetails/dao/AzureVmdetailsDao');
var attributesDao= require('../../attributes/dao/AttributesDAO');

/*
 * Add new experience
 */
var addNewExperience = function(req, res, callback) {
	logger.info(MODULE_NAME+' : DAO : received request : addNewExperience : body : '+JSON.stringify(req.body));
	var reqBody = req.body;
	var experience = new Experience(reqBody);
	if(reqBody.androidAppOffered === "true" || reqBody.iOSAppOffered === "true") {
		experience.addDeviceSupported("MOBILE");
	}
	if(reqBody.webAppOffered === "true") {
		experience.addDeviceSupported("DESKTOP");
	}
	if(reqBody.tabletOffered === "true") {
		experience.addDeviceSupported("TABLET");
	}
	if(reqBody.wearableOffered === "true") {
		experience.addDeviceSupported("WEARABLE");
	}
	experience.setCreatedOn(new Date());
	experience.setUpdatedOn(new Date());
	experience.setCreatedBy(req.header('username'));
	experience.setUpdatedBy(req.header('username'));
	
    var callbackSave = function(err, data) {
        if (err) {
            return callback(err, null);
        } else {
	     logger.info(MODULE_NAME+' : DAO : SurveyAssociation Created Successfully !');
        }
    }
	experience.save(function(err, data) {
		if (err) {
			logger.error(MODULE_NAME+' : DAO : failed addNewExperience : error : ' + err);
			callback(err, null);
		} else {
            req.body.surveyId = config.DEFAULT_SURVEY_RATING_ID;
            req.body.surveyEntityType = "experience";
            req.body.surveyEntityTypeReF = data.id;
             SurveyAssociationDao.addNewSurveyAssociation(req, res, callbackSave);
			logger.info(MODULE_NAME+' : DAO : addNewExperience successful !');
			callback(null, data);
		}
	});
};

/*
 * Get experience by experience id
 */
var getExperienceById = function(req, res, callback) {
	logger.info(MODULE_NAME+' : DAO : received request : getExperienceById : (id:'+req.params.id+')');
	Experience.findOne({
		'id' : req.params.id
	}, function(err, data) {
		if (err) {
			logger.error(MODULE_NAME+' : DAO : failed getExperienceById : error : ' + err);
			callback(err, null);
		} else {
			if (data != null) {
				logger.info(MODULE_NAME+' : DAO : getExperienceById successful !');
				callback(null, data);
			} else {
				var err = new Error('experience id not exist');
				err.status = 404;
				logger.error(MODULE_NAME+' : DAO : failed getExperienceById : error : ' + err);
				callback(err, null);
			}
		}
	});
};


/*
 * Get all experiences
 */
var getAllExperiences = function(req, res, callback) {
	logger.info(MODULE_NAME+' : DAO : received request : getAllExperiences : query params : '+JSON.stringify(req.query));
	var top = req.query.top;
	var obj = {
		'status' : { $ne : 'ARCHIVED' }
	};
	if(req.query.status && req.query.status.trim()) {
		obj.status = req.query.status;
	}
	
	if( ( top != undefined ) || ( top != null )  ){
		console.log("value of top given");
		Experience.find(obj).sort('-userCount').exec(function(err, data) {
		// code here
		/* Experience.find().sort([['userCount','descending']]).all(function (err, data) { */
			if(err) {
				logger.error(MODULE_NAME+' : DAO : failed getTop5Experiences : error : ' + err);
				callback(err, null); }
			else{
				if (data.length != 0) {
					logger.info(MODULE_NAME+' : DAO : getTop5Experiences successful !');
					if( data.length > top )
					{
						data.splice( top , data.length-1  );
					}
					callback(null, data);
				} else {
					var err = new Error('No records found');
					err.status = 404;
					logger.error(MODULE_NAME+' : DAO : failed getTop5Experiences : error : ' + err);
					callback(err, null);
				}
			}
		});
	} else {
		if (req.query.domain) {
			obj.domain = new RegExp('^' + req.query.domain.toLowerCase() + '$', 'i');
		}	
		Experience.find(obj, function(err, data) {
			if (err) {
				logger.error(MODULE_NAME+' : DAO : failed getAllExperiences : error : ' + err);
				callback(err, null);
			} else {
				if (data.length != 0) {
					logger.info(MODULE_NAME+' : DAO : getAllExperiences successful !');
					callback(null, data);
				} else {
					var err = new Error('No records found');
					err.status = 404;
					logger.error(MODULE_NAME+' : DAO : failed getAllExperiences : error : ' + err);
					callback(err, null);
				}
			}
		});
	}
};


/*
 * Edit/Update experience details
 */
var updateExperienceById = function(req, res, callback) {
	logger.info(MODULE_NAME+' : DAO : received request : updateExperienceById : (id:'+req.params.id+', body:'+JSON.stringify(req.body)+')');

	/*
	 * If experience exist, compare existing details with new request details.
	 * Update details which are new.
	 */
	var callbackUpdate = function(err, data) {
		if(err) {
			logger.error(MODULE_NAME+' : DAO : failed updateExperienceById : error : ' + err);
			callback(err, null);
		} else if(data != null) {
			var experience = data;
			var updatableFields = [
			                       "description", "longDescription", "logo", "webAppOffered",  "androidAppOffered",
			                       "iOSAppOffered",  "apiOffered", "datasetOffered", "owner", "version", "numberOfInstalls",
			                       "hitsCounter", "userCount", "vmCount", "tabletOffered", "wearableOffered"
			                      ];
			var updatedData = [];
			var json = {};
			var reqBodyKeys = Object.keys(req.body);
			for(var i = 0; i < reqBodyKeys.length; i++) {
				if(updatableFields.indexOf(reqBodyKeys[i]) > -1 && experience[reqBodyKeys[i]] != req.body[reqBodyKeys[i]]) {
					json[reqBodyKeys[i]] = req.body[reqBodyKeys[i]];
					var obj = {};
					obj.column = reqBodyKeys[i];
					obj.oldValue = experience[reqBodyKeys[i]];
					obj.newValue = req.body[reqBodyKeys[i]];
					obj.identifier = 'Platform_experience_'+req.params.id;
					obj.modifiedBy = 'admin';
					obj.modifiedOn = new Date();
					updatedData.push(obj);
				}
			}	
			var deviceSupported = [];
			if(req.body.androidAppOffered === "true" || req.body.iOSAppOffered === "true") {
				deviceSupported.push("MOBILE");
			}
			if(req.body.webAppOffered === "true") {
				deviceSupported.push("DESKTOP");
			}
			if(req.body.tabletOffered === "true") {
				deviceSupported.push("TABLET");
			}
			if(req.body.wearableOffered === "true") {
				deviceSupported.push("WEARABLE");
			}
			if(deviceSupported.length) {
				json.deviceSupported = deviceSupported;
			}
			if(req.body.screenshots && req.body.screenshots.length) {
				json.screenshots = req.body.screenshots;
			}			
			if(req.body.components && req.body.components.length) {
				json.components = req.body.components;
			}
			if(req.body.classification && req.body.classification.length) {
				json.classification = req.body.classification;
			}
			var updateDoc = false;
			if(Object.keys(json).length != 0) {
				updateDoc = true;
			}

			if (updateDoc) {
				json.updatedOn = new Date();
				json.updatedBy = req.header('username');
				logger.info(MODULE_NAME+' : DAO : updateExperienceById : updating data : ' + JSON.stringify(json));
				Experience.findOneAndUpdate({
					'id' : req.params.id
				}, json, {
					'new' : true
				}, function(err, data) {
					if (err) {
						logger.error(MODULE_NAME+' : DAO : failed updateExperienceById : error : ' + err);
						callback(err, null);
					} else {
							logger.info(MODULE_NAME+' : DAO : updateExperienceById successful !');
							/* Call audit function for changed data */
							audit(req, res, updatedData);

							/* Call function to send response to client */
							callback(null, data);
					}
				});
			} else {
				var err = new Error('No fields modified');
				logger.error(MODULE_NAME+' : DAO : failed updateExperienceById : error : ' + err);
				callback(err, null);
			}
		} else {
			var err = new Error('No record exist for experience Id');
			logger.error(MODULE_NAME+' : DAO : failed updateExperienceById : error : ' + err);
			callback(err, null);
		}
	}

	/*
	 *  Get existing record from database to get current values (will be used for audit)
	 */
	getExperienceById(req, res, callbackUpdate);


};

/*
 * Get all experiences created for the given companyid
 */
var getExperiencesByCompanyId = function(req, res, callback) {
	logger.info(MODULE_NAME+' : DAO : received request : getExperiencesByCompanyId : companyId:'+req.header('companyId'));
	Experience.find({
		'companyId' : req.header('companyId')
	}, function(err, data) {
		if (err) {
			logger.error(MODULE_NAME+' : DAO : failed getExperiencesByCompanyId : error : ' + err);
			callback(err, data);
		} else {
			if (data.length != 0) {
				logger.info(MODULE_NAME+' : DAO : getExperiencesByCompanyId successful !');
				callback(null, data);
			} else {
				var err = new Error('No Experience exist for company id');
				err.status = 404;
				logger.error(MODULE_NAME+' : DAO : failed getExperiencesByCompanyId : error : ' + err);
				callback(err, null);
			}
		}
	});
};

/*
 * Delete experience by id
 */
var deleteExperienceById = function(req, res, callback) {
	logger.info(MODULE_NAME+' : DAO : received request : deleteExperienceById : (id:'+req.params.id+')');
	var json = {
		"status" : "ARCHIVED"
	};
	Experience.update({ 'id' : req.params.id }, json , { 'new' : true },
	function(err, data) {
		if (err) {
			logger.error(MODULE_NAME+' : DAO : failed deleteExperienceById : error : ' + err);
			callback(err, data);
		} else {
			if (data != null) {
				logger.info(MODULE_NAME+' : DAO : deleteExperienceById successful !');
				callback(null, data);
			} else {
				var err = new Error('experience id not exist');
				err.status = 404;
				logger.error(MODULE_NAME+' : DAO : failed deleteExperienceById : error : ' + err);
				callback(err, null);
			}
		}
	});
};

/*
 * Publish experience by id
 */
var publishExperienceById = function(req, res, callback) {
	logger.info(MODULE_NAME+' : DAO : received request : publishExperienceById : (id:'+req.params.id+', body: '+JSON.stringify(req.body)+')');
	if(req.body.publishManifest == true) {
		async.waterfall([
        	 async.apply(getManifestIfAlreadyExist, req),
        	 updateManifestStatusIfExist,
        	 updateExperienceStatusToPublishing
	    ],
		function(err, result){
			if(err) {
				return callback(err, null);
			}
			callbackCreateManifest(req, res, callback);
		});
	} else {
		var err = new Error('missing parameter value');
		logger.error(MODULE_NAME+' : DAO : failed publishExperienceById : error : ' + err);
		callback(err, null);
	}
};


function getManifestIfAlreadyExist(req, cb) {
 	manifestDao.getManifestByExperienceIdAndStatus(req, function(err, manifest) {
 		if(err) {
 			return cb(null, req, null);
 		}
 		cb(null, req, manifest);
 	});
}

function updateManifestStatusIfExist(req, manifest, cb) {
	//console.log(JSON.stringify(manifest))
	if(manifest && manifest.status == 'PUBLISHED') {
		var json = { 'status' : 'ARCHIVED' }
		manifestDao.updateManifest(manifest.id, json, function(err, data) {
			if(err) {
				return cb(err);
			}
			cb(null, req);
		});
	} else {
		cb(null, req);
	}
}

function updateExperienceStatusToPublishing(req, cb) {
	Experience.update({ 'id' : req.params.id }, { "status" : 'PUBLISHING' },
		function(err, data) {
			if (err) {
				logger.error(MODULE_NAME+' : DAO : failed updateExperienceStatusToPublishing : error : ' + err);
				return cb(err);
			}
			logger.info(MODULE_NAME+' : DAO : updateExperienceStatusToPublishing : status changed : PUBLISHING');
			cb(null, data);
		}
	);
}

/*
 *	To create manifest
 */
var callbackCreateManifest = function(req, res, callback) {
	var manifestJSON = {};
	manifestJSON.status = 'PUBLISHED';
	manifestJSON.vmDetails = config.vmDetails;
	async.parallel([
        function(cb) {
        	getExperienceById(req, res, function(err, data) {
        		if(err) {
        			return cb(err);
        		}
        		manifestJSON.experienceId = data.id;
        		manifestJSON.name = data.name;
        		manifestJSON.description = data.description;
        		manifestJSON.version = data.version;
        		manifestJSON.owner = data.owner;
        		manifestJSON.domain = data.domain;
        		manifestJSON.components = data.components;
        		manifestJSON.classification = data.classification;
        		manifestJSON.deviceSupported = data.deviceSupported;
        		manifestJSON.createdBy = req.header('username');
        		manifestJSON.updatedBy = req.header('username');
        		attributesDao.getAllExperienceAttributes(data.id, function(err, attributesObj) {
        			if(err) {
            			return cb();
            		}
        			manifestJSON.attributes = attributesObj.attributes;
        			cb(null, 'Got experience details!');
        		});
        	});
        },
        function(cb) {
        	documentDao.getDocumentsByExperienceId(req.params.id, function(err, data) {
        		if(err) {
        			return cb();
        		}
        		manifestJSON.documents = data;
        		cb(null, 'Got documents for experience!');
        	});
        },
        function(cb) {
        	appDao.getAllApps(req, res, function(err, apps) {
        		if(err) {
        			return cb();
        		}        	
        		var tempApps = [];
        		async.forEach(apps, function (app, tempCb) {
        			var tempApp = JSON.parse(JSON.stringify(app));
        			req.params.appId = app.id;
        			req.params.experienceId = req.params.id;
        			attributesDao.getAllAttributes(req, function(err, attributesObj) {
	        			if(err) {
	        				tempApps.push(tempApp);
		        			tempApp = null;
	            			return tempCb();
	            		}
	        			tempApp.attributes = attributesObj[0].attributes;	        			
	        			tempApps.push(tempApp);
	        			tempApp = null;
	        			tempCb(null, 'Got attributes!');
        			});        			
        		}, function(err) {     
        			manifestJSON.applications = tempApps;
        			tempApps = null;
        			cb(null, 'Got apps details!'); 
        		});
        	});
        },
        function(cb) {
        	serviceDao.getServicesByExperienceId(req, res, function(err, data) {
        		if(err) {
        			return cb();
        		}
        		manifestJSON.services = data;
        		cb(null, 'Got services!');
        	});
        }
	],
	function(err, results){
		if(err){
			return callback(err);
		}
		logger.info(MODULE_NAME+' : DAO : callbackCreateManifest : details : ' + results);
		async.waterfall([
              function(cb){
            	  manifestDao.saveManifest(manifestJSON, function(err, data) {
          			if(err) {
          				return cb(err);
          			}
          			cb();
          		  });
              },
              function(cb){
            	  updateExperienceStatusToPublished(req, res, function(err, data) {
	          			if(err) {
	          				return cb(err);
	          			}
	          			cb(null, data);
	              });
              }
		],
		function(err, doc){
			if(err) {
				return callback(err);
			}
			var appTypes = [];
			// console.log("Manifest", JSON.stringify(manifestJSON));
			if(manifestJSON.applications && manifestJSON.applications.length) {
				manifestJSON.applications.forEach(function(app) {
					if(app.supportedDevices.length != 0) {
						app.supportedDevices.forEach(function(support) {
							if(appTypes.indexOf(support) == -1) {
								appTypes.push(support);
							}
						})
					}
				});
				addSupportedDevices(manifestJSON.experienceId, appTypes);
			}
			callback(null, doc);
		});
	});
}

var updateExperienceStatusToPublished = function(req, res, cb) {
	Experience.update({ 'id' : req.params.id }, { "status" : 'PUBLISHED' },
		function(err, data) {
			if (err) {
				logger.error(MODULE_NAME+' : DAO : failed updateExperienceStatusToPublishing : error : ' + err);
				cb(err);
			}
			logger.info(MODULE_NAME+' : DAO : updateExperienceStatusToPublishing : status changed : ' + data.status);
			cb(null, data);
		}
	);
}


/*
 * Get manifest by experience id
 */
var getManifestByExperienceId = function(req, res, callback) {
	logger.info(MODULE_NAME+' : DAO : received request : getManifestByExperienceId : (id:'+req.params.id+')');
	Manifest.findOne({
		'experienceId' : req.params.id,
		'status' : 'PUBLISHED'
	}, function(err, data) {
		if (err) {
			logger.error(MODULE_NAME+' : DAO : failed getManifestByExperienceId : error : ' + err);
			callback(err, null);
		} else if (data != null) {
				logger.info(MODULE_NAME+' : DAO : getManifestByExperienceId successful !');
				/*	send response  */
				callback(null, data);
				/*	increment experience hit count  */
				incrementHitsCounter(req.params.id);
		} else {
			var err = new Error('No manifest exist for experience');
			err.status = 404;
			logger.error(MODULE_NAME+' : DAO : failed getManifestByExperienceId : error : ' + err);
			callback(err, null);
		}
	});
};

/*
* Get Experiences for given Experience Id's (comma separated in query)
*/
var getExperiencesByExperienceIdsInQuery = function(req, res, callback) {
	logger.info(MODULE_NAME+' : DAO : received request : getExperiencesByExperienceIdsInQuery : experienceIds :'+req.query.experiences);

	// Split the query by comma, and pass the array holding experienceIds
	var experienceIds = [];
	experienceIds = req.query.experiences.split(',');

	Experience.find( { 'id' : {"$in":experienceIds} }, function(err, data) {
		if (err) {
			logger.error(MODULE_NAME+' : DAO : failed getExperiencesByExperienceIdsInQuery : error : ' + err);
			callback(err, null);
		} else {
			if (data != null) {
				logger.info(MODULE_NAME+' : DAO : getExperiencesByExperienceIdsInQuery successful !');
				callback(null, data);
			} else {
				var err = new Error('No record exist of experience id');
				logger.error(MODULE_NAME+' : DAO : failed getExperiencesByExperienceIdsInQuery : error : ' + err);
				callback(err, null);
			}
		}
	});

};


/*
 * Get most viewed experiences
 */
var getMostViewedExperiences = function(req, res, callback) {
	logger.info(MODULE_NAME+' : DAO : received request : getMostViewedExperiences');
	Experience.find({}, function(err, data) {
		if (err) {
			logger.error(MODULE_NAME+' : DAO : failed getMostViewedExperiences : error : ' + err);
			callback(err, null);
		} else if (data.length) {
				logger.info(MODULE_NAME+' : DAO : getMostViewedExperiences successful !');
				callback(null, data);
		} else {
			var err = new Error('No records found');
			err.status = 404;
			logger.error(MODULE_NAME+' : DAO : failed getMostViewedExperiences : error : ' + err);
			callback(err, null);
		}
	}).sort({hitsCounter: 'descending'}).limit(NUMBER_OF_RECORDS_FOR_MOSTVIEWED);
};


/*
 * Get most viewed experiences by domain
 */
var getMostViewedExperiencesByDomain = function(req, res, callback) {
	logger.info(MODULE_NAME+' : DAO : received request : getMostViewedExperiencesByDomain : domain : ' + req.params.domain);
	Experience.find({
		domain: req.params.domain
	}, function(err, data) {
		if (err) {
			logger.error(MODULE_NAME+' : DAO : failed getMostViewedExperiencesByDomain : error : ' + err);
			callback(err, null);
		} else if (data.length) {
				logger.info(MODULE_NAME+' : DAO : getMostViewedExperiencesByDomain successful !');
				callback(null, data);
		} else {
			var err = new Error('No records found');
			err.status = 404;
			logger.error(MODULE_NAME+' : DAO : failed getMostViewedExperiencesByDomain : error : ' + err);
			callback(err, null);
		}
	}).sort({hitsCounter: 'descending'}).limit(NUMBER_OF_RECORDS_FOR_MOSTVIEWED);
};


/*
 * Increment hit count
 */
var incrementHitsCounter = function(id) {
	Experience.update({ 'id' : id }, { $inc: { hitsCounter: +1 } }, function(err, data) {
		if (err) {
			logger.error(MODULE_NAME+' : DAO : failed incrementHitsCounter : error : ' + err);
		} else if(data){
			logger.info(MODULE_NAME+' : DAO : incrementHitsCounter successful !');
		} else {
			var err = new Error('failed to update');
			logger.error(MODULE_NAME+' : DAO : failed incrementHitsCounter : error : ' + err);
		}
	});
}


var existExperienceId = function(id, callback) {
	Experience.count({id: id}, function (err, count){
	    if(err){
	        return callback(err);
	    }
	    if(count > 0) {
	    	return callback();
	    }
	    var err = new Error('no record exist for experience id');
	    err.status = 200;
	    callback(err);
	});
}


/*
 * Get manifest by experience id & version
 */
var getManifestByExperienceIdAndVersion = function(experienceId, version, callback) {
	logger.info(MODULE_NAME+' : DAO : received request : getManifestByExperienceIdAndVersion : ' +
    		+ '(experienceId=' + experienceId + ', version=' + version);
	Manifest.findOne({
		experienceId: experienceId,
		version: version
	}, function(err, data) {
		if (err) {
			err.status = 500;
			logger.error(MODULE_NAME+' : DAO : failed getManifestByExperienceIdAndVersion : error : ' + err);
			return callback(err);
		} if (data) {
			logger.info(MODULE_NAME+' : DAO : getManifestByExperienceIdAndVersion successful !');
			return callback(null, data);
		}
		var err = new Error('No manifest found');
		err.status = 200;
		logger.error(MODULE_NAME+' : DAO : failed getManifestByExperienceIdAndVersion : error : ' + err);
		callback(err);
	});
};

var getVMsByExperienceId = function(req, res, callback) {
   logger.info('experience : DAO : received request : getVMsByExperienceId');
	
   var vmdetailsresponse= [];
   var vmNames=[];
	
   Provisionedvms.find({
	'experienceId' : req.params.id ,
	'deleted': false
   }, function(err, data) {
	if (err) {
	  logger.error(MODULE_NAME+' : DAO : failed getVMsByExperienceId : error : ' + err);
	  callback(err, null);
	} else {
	  if (data.length != 0) {
				
		async.each(data,function(item, callback){

		  var vmId= new ObjectId(item.vmId);
			provisionexpdao.getVmDetailsById(vmId,req,res,function(err,vmresponse){
				if(err)
				  {
					logger.error(MODULE_NAME+' : DAO : failed getVMsByExperienceId : error : ' + err);
					if(err.status !=404)
					   callback(err,null);
					else
					   callback();
				  }
				  else{								
					var vmId= vmresponse[0]._id;
					var vmname= vmresponse[0].hostname;
					var vmtype= vmresponse[0].type;
					var fqdn= vmresponse[0].fqdn;						
					var usageData= vmresponse[0].usageData;
										
					var totalCost = 0;
					//iterate over usageData to get total cost of VM										
					 var jsonData=JSON.stringify(usageData);
					 if(jsonData!= undefined || jsonData!= null)
					{
					var jsonUsage = JSON.parse(jsonData);
					for (var key in jsonUsage) {					  					  
					  var val = jsonUsage[key];					  
					  totalCost= totalCost+ val;					  					  
					}
					}
						
					var response={};
					//response.vmId= vmId;
					response.hostname= vmname;
					response.type= vmtype;
					response.fqdn= fqdn;
					response.username=vmresponse[0].username;
					response.osType= vmresponse[0].osType;
					response.osVersion= vmresponse[0].osVersion;
					response.status= vmresponse[0].status;
					response.diskSize= vmresponse[0].diskSize;
					response.dateCreated= vmresponse[0].dateCreated;
					response.ports= vmresponse[0].tcpPorts;
					response.runningCost= totalCost;	
					response.currency='$';
					response.vmId= vmId;

					//VM names array to be used for getting real time cpu and disk usage
					vmNames.push(vmname);
						
					vmdetailsresponse.push(response);						
					callback();
				  }
			})					
		},
		function(err){									
			//get real-time cpuUsage and diskusage
			azureVmDao.getVmUsage(vmNames,req,res,function(err,data){
				if(err)
					callback(err,null);
				else{	
					for(var j=0;j<data.length;j++)
					{
						for(var k=0;k<vmdetailsresponse.length;k++)
						{
						   if(data[j].vmName== vmdetailsresponse[k].hostname)
						   {
							   vmdetailsresponse[k].currentCPUUsage=data[j].cpuUsage+' %';
							   vmdetailsresponse[k].currentDiskUsage= data[j].diskUsage+' %';
							   vmdetailsresponse[k].currentNetworkUsage= data[j].networkUsage+' bytes';			
							   logger.info(MODULE_NAME+' : DAO : getVMsByExperienceId successful !');
						   }
						}																
					}
					callback(null,vmdetailsresponse);
				}
			})					
		}
		);
	  } else {
		var err = new Error('No record found');
		err.status = 404;
		callback(err, null);
		}
	  }
	});
};

/*
 * Get users by experience id
 */
var getUsersByExperienceId = function(req,res, callback) {
	logger.info(MODULE_NAME+' : DAO : received request : getUsersByExperienceId : ' +
    		+ '(experienceId=' + req.params.id);

			var response=[];
	Provisionedexp.find({
		'experienceId' : req.params.id
	}, function(err, data) {
		if (err) {
			logger.error(MODULE_NAME+' : DAO : failed getUsersByExperienceId : error : ' + err);
			callback(err, null);
		} else {
			if (data.length != 0) {
				console.log(data);

				//search for each orgId in platformusers
				async.each(data,function(item, callback){

					var orgId= item.orgId;

					//get username from platformusers
					platformuserdao.getUserByOrgId(orgId, function(err,userdata){
					if(err)
					{
						if(err.status !=404)
						callback(err,null);

					//if user by orgId does not exist in platformusers then search into users
						else
						{
							//get username from users
							req.params.id= orgId;
					userdao.getUsersByCompanyId(req,res, function(err,usersdata){
					if(err)
					{
						console.log(err);
						if(err.status !=404){
						callback(err,null);
						}
						else{
							callback();
						}

					}
					else
					{
						logger.info(MODULE_NAME+' : DAO : getUsersByExperienceId successful !');
						for(var i=0; i<usersdata.length;i++)
						{
							var username=usersdata[i].username;

								var usersresponse={};
										usersresponse.companyId=usersdata[i].companyId;
										usersresponse.sn=usersdata[i].lastname;
										usersresponse.givenName=usersdata[i].firstname;
										usersresponse.mail=usersdata[i].username;
										usersresponse.telephoneNumber=usersdata[i].telephoneNumber;
										usersresponse.username=usersdata[i].username;
										usersresponse.createdOn=usersdata[i].CreatedOn;
										usersresponse.lastLoginDatetime=usersdata[i].lastLoginDatetime;
							response.push(usersresponse);
						}
						console.log(response);
						callback();
					}
				})


						}
					}
					else
					{
						logger.info(MODULE_NAME+' : DAO : getUsersByExperienceId successful !');
						for(var i=0; i<userdata.length;i++)
						{
							var username=userdata[i].username;


								var userresponse={};
										userresponse.companyId=userdata[i].referenceCompanyId;
										userresponse.sn=userdata[i].sn;
										userresponse.givenName=userdata[i].givenName;
										userresponse.mail=userdata[i].mail;
										userresponse.telephoneNumber=userdata[i].telephoneNumber;
										userresponse.username=userdata[i].username;
										userresponse.createdOn=userdata[i].createdOn;
										userresponse.lastLoginDatetime=userdata[i].lastLoginDatetime;

							response.push(userresponse);
						}
						console.log(response);
						callback();
					}
				})
				},
				function(err){
					callback(err,response);
					}
		);
			} else {
				var err = new Error('invalid experience id');
				err.status = 404;
				logger.error(MODULE_NAME+' : DAO : failed getUsersByExperienceId : error : ' + err);
				callback(err, null);
			}
		}
	});
};

/*
 * Get all experiences by ids
 */
var getAllExperiencesByIds = function(expIds, callback) {
	logger.info(MODULE_NAME+' : DAO : received request : getAllExperiencesByIds : (expIds:' + JSON.stringify(expIds) + ')');
	var obj = {
		'id' : { $in : expIds },
		'status' : { $ne : 'ARCHIVED' }
	};
	Experience.find(obj, function(err, data) {
		if (err) {
			err.status = 500;
			logger.error(MODULE_NAME+' : DAO : failed getAllExperiencesByIds : error : ' + err);
			callback(err);
		} else {
			if (data.length != 0) {				
				logger.info(MODULE_NAME+' : DAO : getAllExperiencesByIds successful !');
				callback(null, data);
			} else {
				var err = new Error('No records found');
				err.status = 200;
				logger.error(MODULE_NAME+' : DAO : failed getAllExperiencesByIds : error : ' + err);
				callback(err);
			}
		}
	});
};

var updateProvisioningInfo = function(experienceId, vmCounter, userCounter) {
	if(!isNaN(Number(vmCounter)) && !isNaN(Number(userCounter))) {			
		Experience.find({ 'id' : experienceId },
			function(err, data) {
				if (err) {
					err.status = 500;
					logger.error(MODULE_NAME+' : DAO : failed updateProvisioningInfo : error : ' + err);					
				} else if (data) {
					var json = { 
						$inc: { 
							vmCount: vmCounter								 
						} 
					};
					if(userCounter < 0 && data.userCount > 0) {
						json.$inc.userCount = userCounter;
					}
					if(userCounter > 0) {
						json.$inc.userCount = userCounter;
						json.$inc.numberOfInstalls = userCounter;
					}
					Experience.update({ 'id' : experienceId }, json,
						function(err, data) {
							if (err) {
								err.status = 500;
								logger.error(MODULE_NAME+' : DAO : failed updateProvisioningInfo : error : ' + err);								
							} else if (data) {
								logger.info(MODULE_NAME+' : DAO : updateProvisioningInfo successful !');										
							} else {
								var err = new Error('experience id not exist');
								err.status = 200;
								logger.error(MODULE_NAME+' : DAO : failed updateProvisioningInfo : error : ' + err);										
							}							
					});
					logger.info(MODULE_NAME+' : DAO : updateProvisioningInfo successful !');						
				} else {
					var err = new Error('experience id not exist');
					err.status = 200;
					logger.error(MODULE_NAME+' : DAO : failed updateProvisioningInfo : error : ' + err);						
				}				
		});
	} else {
		var err = new Error('invalid value for vmCounter or userCounter');
		err.status = 200;
		logger.error(MODULE_NAME+' : DAO : failed updateProvisioningInfo : error : ' + err);
	}
}

var addSupportedDevices = function(experienceId, appTypes) {

	Experience.update({ 'id' : experienceId }, { $set : { deviceSupported : appTypes } },
		function(err, data){
			if (err) {
				err.status = 500;
				logger.error(MODULE_NAME+' : DAO : failed addSupportedDevices : error : ' + err);
			}
			else {
				if (data) {
					logger.info(MODULE_NAME+' : DAO : addSupportedDevices successful !');
				} else {
					var err = new Error('Experience id does not exist');
					err.status = 500;
					logger.error(MODULE_NAME+' : DAO : failed addSupportedDevices : error : ' + err);
				}
			}
		})
}


/*
 * Get all experiences by ids
 */
var getExperiencesByIds = function(expIds, callback) {
	logger.info(MODULE_NAME+' : DAO : received request : getExperiencesByIds : (expIds:' + JSON.stringify(expIds) + ')');
	var obj = {
		'id' : { $in : expIds }
	};
	Experience.find(obj, function(err, data) {
		if (err) {
			err.status = 500;
			logger.error(MODULE_NAME+' : DAO : failed getExperiencesByIds : error : ' + err);
			callback(err);
		} else {
			if (data.length != 0) {				
				logger.info(MODULE_NAME+' : DAO : getExperiencesByIds successful !');
				callback(null, data);
			} else {
				var err = new Error('No records found');
				err.status = 200;
				logger.error(MODULE_NAME+' : DAO : failed getExperiencesByIds : error : ' + err);
				callback(err);
			}
		}
	});
};


var getExperiencesByStatus = function(status, callback) {
	logger.info(MODULE_NAME+' : DAO : received request : getExperiencesByStatus : (status:' + status + ')');
	Experience.find({
		status : status
	}, function(err, data) {
		if (err) {
			err.status = 500;
			logger.error(MODULE_NAME+' : DAO : failed getExperiencesByStatus : error : ' + err);
			callback(err);
		} else {
			if (data.length) {				
				logger.info(MODULE_NAME+' : DAO : getExperiencesByStatus successful !');
				callback(null, data);
			} else {
				var err = new Error('No records found');
				err.status = 200;
				logger.error(MODULE_NAME+' : DAO : failed getExperiencesByStatus : error : ' + err);
				callback(err);
			}
		}
	});
}



module.exports.addNewExperience = addNewExperience;
module.exports.getExperienceById = getExperienceById;
module.exports.getAllExperiences = getAllExperiences;
module.exports.updateExperienceById = updateExperienceById;
module.exports.getExperiencesByCompanyId = getExperiencesByCompanyId;
module.exports.deleteExperienceById = deleteExperienceById;
module.exports.publishExperienceById = publishExperienceById;
module.exports.getManifestByExperienceId = getManifestByExperienceId;
module.exports.getExperiencesByExperienceIdsInQuery = getExperiencesByExperienceIdsInQuery;
module.exports.getMostViewedExperiences = getMostViewedExperiences;
module.exports.getMostViewedExperiencesByDomain = getMostViewedExperiencesByDomain;
module.exports.incrementHitsCounter = incrementHitsCounter;
module.exports.existExperienceId = existExperienceId;
module.exports.getManifestByExperienceIdAndVersion = getManifestByExperienceIdAndVersion;
module.exports.getVMsByExperienceId= getVMsByExperienceId;
module.exports.getUsersByExperienceId= getUsersByExperienceId;
module.exports.getAllExperiencesByIds = getAllExperiencesByIds;
module.exports.updateProvisioningInfo = updateProvisioningInfo;
module.exports.getExperiencesByIds = getExperiencesByIds;
module.exports.getExperiencesByStatus = getExperiencesByStatus;









