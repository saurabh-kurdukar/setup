var db = require('../../common/MongoDbConnection');
var UserRole = require('../models/UserRole');
var logger = require('../../common/logger').log;
var audit = require('../../common/Audit').audit;
var roleDao = require('../../roles/dao/RoleDAO');
var userRoleDelegate = require('../delegate/UserRoleDelegate');
var async = require('async');
var Role = require('../../roles/models/Role');
var mongoose = db.mongoose;

/*
 * Add new Role
 */
var addNewUserRole = function(tokenId, expId, req, res, callback) {
  logger.info('userRoles : DAO : received request : addNewUserRole : body : ' + JSON.stringify(req.body));
  var reqBody = req.body;
  var userRole = new UserRole();

  userRole.setusername(reqBody.username);
  userRole.setroleId(reqBody.roleId);
  userRole.setcompanyId(reqBody.companyId);
  userRole.setexperienceId(reqBody.experienceId);
  userRole.setroleName(reqBody.roleName);

  req.params.roleId = reqBody.roleId;
  req.headers['rolename'] = reqBody.roleName;

  roleDao.getRolesByRoleNameAndRoleId(req, res, function(err, data) {
    if (err) {
      logger.error('userRoles : DAO : failed getRolesByRoleNameAndRoleId : error : ' + err);
      callback(err, null);
    } else {
      userRole.save(function(err, data) {
        if (err) {
          logger.error('userRoles : DAO : failed addNewUserRole : error : ' + err);
          callback(err, null);
        } else if (data != null) {
          logger.info('userRoles : DAO : addNewUserRole successful !');
          callback(null, data);
        } else {
          var err = new Error('Failed to addNewUserRole details');
          logger.error('userRoles : DAO : failed addNewUserRole : error : ' + err);
          callback(err, null);
        }
      });
    }
  });
};

/*
 *  Get UserRoles specified by the username(userid) parameter
 */
var getUserRolesByUsername = function(req, res, callback) {
  logger.info('userRoles : DAO : received request : getUserRolesByUsername : id : ' + req.params.username);

  UserRole.find({
    'username': req.params.username
  }, {
    username: 0,
    experienceId: 0,
    companyId: 0
  }, function(err, data) {
    if (err) {
      logger.error('userRoles : DAO : failed getUserRolesByUsername : error : ' + err);
      callback(err, null);
    } else {
      if (data.length != 0) {
        logger.info('userRoles : DAO : getUserRolesByUsername successful !');

        var responseArray = [];
        async.forEach(data, function(userRoles, callback) {
          req.headers['rolename'] = userRoles.roleName;
          req.params.roleId = userRoles.roleId;
          roleDao.getRolesByRoleNameAndRoleId(req, res, function(err, rolesResponse) {
            if (err) {
              logger.error('userRoles : DAO : failed getRolesByRoleNameAndRoleId : error : ' + err);
              callback(err, null);
            } else {
              logger.info('userRoles : DAO : getRolesByRoleNameAndRoleId successful !');
              var response = {};
              response.roleName = userRoles.roleName;
              response.roleId = userRoles.roleId;
              response.hierarchy = rolesResponse[0].hierarchy;
              responseArray.push(response);
              callback();
            }
          })
        }, function(err) {
          if (err) {
            logger.error('userRoles : DAO : failed getUserRolesByUsername : error : ' + err);
            callback(err, null);
          } else {
            logger.info('userRoles : DAO : getUserRolesByUsername successful !');
            callback(null, responseArray);
          }
        })
      } else {
        var err = new Error('No UserRoles found for given Username');
        err.status = 404;
        logger.error('userRoles : DAO : failed getUserRolesByUsername : error : ' + err);
        callback(err, null);
      }
    }
  });
};

/*
 *  Get users specified by the rolename parameter
 */
var getUsersByRoleName = function(req, res, callback) {
  logger.info('userRoles : DAO : received request : getUsersByRoleName : id : ' + req.params.rolename);

  UserRole.find({
    'roleName': req.params.rolename
  }, function(err, data) {
    if (err) {
      logger.error('userRoles : DAO : failed getUsersByRoleName : error : ' + err);
      callback(err, null);
    } else {
      if (data.length != 0) {
        logger.info('userRoles : DAO : getUsersByRoleName successful !');
        callback(null, data);
      } else {
        var err = new Error('user role not found');
        err.status = 404;
        logger.error('userRoles : DAO : failed getUsersByRoleName : error : ' + err);
        callback(err, null);
      }
    }
  });
};

/*
 *   Deletes UserRoles by rolename
 */
var deleteUserRolesByRoleName = function(req, res, callback) {
  logger.info('userRoles : DAO : received request : deleteUserRolesByRoleName : (id: ' + req.params.rolename);
  var callbackDelete = function(err, data) {
    if (err) {
      logger.error('userRoles : DAO : failed deleteUserRolesByRoleName : error :' + err);
      callback(err, data);
    } else {
      UserRole.remove({
          'roleName': req.params.rolename
        },
        function(err, data) {
          if (err) {
            callback(err, null);
          } else {
            callback(null, 'User Role Deleted Successfully');
          }
        });
    }
  };

  getUsersByRoleName(req, res, callbackDelete);
};

/*
 * update UserRoles by RoleName
 */
var updateRoleUsersByRoleName = function(req, res, callback) {
  var reqBody = req.body;

  logger.info('userRoles : DAO : received request : updateRoleUsersByRoleName : (id: ' + req.params.rolename);

  var json = {};

  if (reqBody.usernamesArray) {
    json.username = reqBody.usernamesArray;
  } else {
    json = req.body;
    json.username = reqBody.username;
  }
  UserRole.update({
    'roleName': req.params.rolename
  }, json, function(err, data) {
    if (err) {
      callback(err, null);
    } else {
      callback(null, 'User Role Updated Successfully');
    }
  });
};


/*
 *  Get users specified by the rolename parameter
 */
var getUserRoleByUsernameAndRoleName = function(username, roleName, callback) {

  logger.info('userRoles : DAO : received request : getUserRoleByUsernameAndRoleName : (username:' + username + ', roleName:' + roleName + ')');
  UserRole.findOne({
    'roleName': roleName,
    'username': username
  }, function(err, data) {
    if (err) {
      logger.error('userRoles : DAO : failed getUserRoleByUsernameAndRoleName : error : ' + err);
      callback(err);
    } else {
      if (data) {
        logger.info('userRoles : DAO : getUserRoleByUsernameAndRoleName successful !');
        callback(null, data);
      } else {
        var err = new Error('user role not found');
        err.status = 404;
        logger.error('userRoles : DAO : failed getUserRoleByUsernameAndRoleName : error : ' + err);
        callback(err);
      }
    }
  });
};

module.exports.addNewUserRole = addNewUserRole;
module.exports.getUserRolesByUsername = getUserRolesByUsername;
module.exports.getUsersByRoleName = getUsersByRoleName;
module.exports.deleteUserRolesByRoleName = deleteUserRolesByRoleName;
module.exports.updateRoleUsersByRoleName = updateRoleUsersByRoleName;
module.exports.getUserRoleByUsernameAndRoleName = getUserRoleByUsernameAndRoleName;
