var mongoose = require('../../common/MongoDbConnection').mongoose;
var autoIncrement = require('mongoose-auto-increment');
var logger = require('../../common/logger').log;
var connection = mongoose.connection;
autoIncrement.initialize(connection);
/*
 * logging format followed: logger.info(<module_name>: <component name> :
 * <description> : <long_description> : <data/params/errors>);
 */

/*
 * Define schema
 */
var userRoleSchema = mongoose.Schema({
  username: [{
    type: String
  }],
  roleId: {
    type: Number
  },
  companyId: {
    type: Number
  },
  experienceId: {
    type: Number
  },
  roleName: {
    type: String,
    unique: true
  }

});

logger.info('UserRoles : model : created schema : Roles :' + JSON.stringify(userRoleSchema.paths));

userRoleSchema.path('roleName').validate(function(value, fn) {
  var UserRole = mongoose.model('UserRoles');
  UserRole.find({
    'roleName': value
  }, function(err, data) {
    fn(err || data.length === 0);
  });
}, 'Role name is already taken');

/*
 * Setters
 */
userRoleSchema.methods.setusername = function(username) {
  this.username = username;
};

userRoleSchema.methods.setroleId = function(roleId) {
  this.roleId = roleId;
};

userRoleSchema.methods.setcompanyId = function(companyId) {
  this.companyId = companyId;
};

userRoleSchema.methods.setexperienceId = function(experienceId) {
  this.experienceId = experienceId;
};

userRoleSchema.methods.setroleName = function(roleName) {
  this.roleName = roleName;
};

/*
 * Getters
 */
userRoleSchema.methods.getusername = function() {
  return this.username;
};

userRoleSchema.methods.getroleId = function() {
  return this.roleId;
};

userRoleSchema.methods.getcompanyId = function() {
  return this.companyId;
};

userRoleSchema.methods.getexperienceId = function() {
  return this.experienceId;
};

userRoleSchema.methods.getroleName = function() {
  return this.roleName;
};

/*
 * Create collection/model in mongo db using Schema
 */
var UserRole = mongoose.model('UserRoles', userRoleSchema);
logger.info('UserRoles : model : created model : UserRoles : ' + UserRole);

module.exports = UserRole;
