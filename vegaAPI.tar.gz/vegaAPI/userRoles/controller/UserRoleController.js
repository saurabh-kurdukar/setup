var userRoleDAO = require('../dao/UserRoleDAO');
var logger = require('../../common/logger').log;
var userRoleDelegate = require('../delegate/UserRoleDelegate');
var config = require('../../common/Config');

/*
 * Add new Role
 */
var addNewUserRole = function(req, res, callback) {
  logger.info('userRoles : controller : received request : addNewUserRole : body : ' + JSON.stringify(req.body));

  var roleMgt = config.ROLE_MANAGEMENT;

  if (roleMgt === 'EXTERNAL') {
    logger.info('userRoles : controller : addNewUserRole :EXTERNAL Role Mgt  ');
    userRoleDelegate.addNewUserRole(req, res, function(err, data) {
      if (err) {
        logger.error('userRoles : controller : failed addNewUserRole : error : ' + err);
        callback(err, null);
      } else {
        userRoleDAO.addNewUserRole('', '', req, res, callback);
      }
    });
  } else if (!roleMgt || (roleMgt != 'EXTERNAL' && roleMgt != 'INTERNAL') || roleMgt === 'INTERNAL') {
    logger.info('userRoles : controller : addNewUserRole :INTERNAL Role Mgt  ');
    userRoleDAO.addNewUserRole('', '', req, res, callback);
  }
};

/*
 * Get UserRoles specified by the username(userid) parameter
 */
var getUserRolesByUsername = function(req, res, callback) {
  logger.info('userRoles : controller : received request : getUserRolesByUsername : Expid : ' + req.params.username);
  userRoleDAO.getUserRolesByUsername(req, res, callback);
};

/*
 * Get users specified by the rolename parameter
 */
var getUsersByRoleName = function(req, res, callback) {
  logger.info('userRoles : controller : received request : getUsersByRoleName : Expid : ' + req.params.rolename);
  userRoleDAO.getUsersByRoleName(req, res, callback);
};

/*
 *  Deletes UserRoles by rolename
 */
var deleteUserRolesByRoleName = function(req, res, callback) {
  logger.info('userRoles : controller : received request : deleteUserRolesByRoleName : id : ' + req.params.rolename);

  var roleMgt = config.ROLE_MANAGEMENT;

  if (roleMgt === 'EXTERNAL') {
    logger.info('userRoles : controller :deleteUserRolesByRoleName : EXTERNAL Role Mgt  ');
    userRoleDelegate.deleteUserRolesByRoleName(req, res, function(err, data) {
      if (err) {
        logger.error('userRoles : controller : failed deleteUserRolesByRoleName : error : ' + err);
        callback(err, null);
      } else {
        userRoleDAO.deleteUserRolesByRoleName(req, res, callback);
      }
    });
  } else if (!roleMgt || (roleMgt != 'EXTERNAL' && roleMgt != 'INTERNAL') || roleMgt === 'INTERNAL') {
    logger.info('userRoles : controller : deleteUserRolesByRoleName :INTERNAL Role Mgt  ');
    userRoleDAO.deleteUserRolesByRoleName(req, res, callback);
  }
};

/*
 **update UserRoles by RoleName
 */
var updateRoleUsersByRoleName = function(req, res, callback) {
  logger.info('userRoles : controller : received request : updateRoleUsersByRoleName : id : ' + req.params.rolename);

  var roleMgt = config.ROLE_MANAGEMENT;

  if (roleMgt === 'EXTERNAL') {
    logger.info('userRoles : controller :updateRoleUsersByRoleName : EXTERNAL Role Mgt  ');
    userRoleDelegate.updateRoleUsersByRoleName(req, res, function(err, data) {
      if (err) {
        logger.error('userRoles : controller : failed updateRoleUsersByRoleName : error : ' + err);
        callback(err, null);
      } else {
        userRoleDAO.updateRoleUsersByRoleName(req, res, callback);
      }
    });
  } else if (!roleMgt || (roleMgt != 'EXTERNAL' && roleMgt != 'INTERNAL') || roleMgt === 'INTERNAL') {
    logger.info('userRoles : controller : updateRoleUsersByRoleName :INTERNAL Role Mgt  ');
    userRoleDAO.updateRoleUsersByRoleName(req, res, callback);
  }
};

module.exports.addNewUserRole = addNewUserRole;
module.exports.getUserRolesByUsername = getUserRolesByUsername;
module.exports.getUsersByRoleName = getUsersByRoleName;
module.exports.deleteUserRolesByRoleName = deleteUserRolesByRoleName;
module.exports.updateRoleUsersByRoleName = updateRoleUsersByRoleName;
