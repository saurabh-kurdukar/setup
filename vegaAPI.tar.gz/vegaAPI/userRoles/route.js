var express = require('express');
var userRoleController = require('./controller/UserRoleController');
var logger = require('../common/logger').log;
var ErrorResponse = require('../common/ErrorResponse').ErrorResponse;
var router = express.Router();

/*
 * logging format followed: logger.info(<module_name>: <component name> : <description> : [<long_description>] : <data/params/errors>);
 */

/*
 * Add new User Role
 */
router.post('/', function(req, res) {
  logger.info('userRoles : router : received request : addNewUserRole : body : ' + JSON.stringify(req.body));
  userRoleController.addNewUserRole(req, res, function(err, data) {
    if (err) {
      logger.error('userRoles : router : failed addNewUserRole : error : ' + err);
      var error = new ErrorResponse();
      if (err.name == 'ValidationError') {
        error.setErrorMessage(err.errors[Object.keys(err.errors)[0]].message);
      } else {
        error.setErrorMessage(err.message);
      }
      error.setErrorCode("UR001");
      error.setHttpResponseCode(500);
      res.status(500).end(JSON.stringify(error));
    } else {
      logger.info("userRoles : router : addNewUserRole successful !");
      res.status(200).end(JSON.stringify(data));
    }
  });
});

/*
 * Get UserRoles specified by the username(userid) parameter
 */
router.get('/:username', function(req, res) {
  logger.info('userRoles : router : received request : getUserRolesByUsername : id : ' + req.params.username);
  userRoleController.getUserRolesByUsername(req, res, function(err, data) {
    if (err) {
      logger.error('userRoles : router : failed getUserRolesByUsername : error : ' + err);
      var error = new ErrorResponse();
      error.setErrorCode("UR002");
      error.setErrorMessage(err.message);
      error.setHttpResponseCode(500);
      res.status(500).end(JSON.stringify(error));
    } else {
      logger.info("userRoles : router : getUserRolesByUsername successful !");
      res.status(200).end(JSON.stringify(data));
    }
  });
});

/*
 * Get users specified by the rolename parameter
 */
router.get('/users/:rolename', function(req, res) {
  logger.info('userRoles : router : received request : getUsersByRoleName : id : ' + req.params.rolename);
  userRoleController.getUsersByRoleName(req, res, function(err, data) {
    if (err) {
      logger.error('userRoles : router : failed getUsersByRoleName : error : ' + err);
      var error = new ErrorResponse();
      error.setErrorCode("UR003");
      error.setErrorMessage(err.message);
      error.setHttpResponseCode(500);
      res.status(500).end(JSON.stringify(error));
    } else {
      logger.info("userRoles : router : getUsersByRoleName successful !");
      res.status(200).end(JSON.stringify(data));
    }
  });
});


/*
 * Deletes UserRoles by rolename
 */
router.delete('/:rolename', function(req, res) {
  logger.info('userRoles : router : received request : deleteUserRolesByRoleName : rolename : ' + req.params.rolename);
  userRoleController.deleteUserRolesByRoleName(req, res, function(err, data) {
    if (err) {
      logger.error('userRoles : router : failed deleteUserRolesByRoleName : error : ' + err);
      var error = new ErrorResponse();
      error.setErrorCode("UR004");
      error.setErrorMessage(err.message);
      error.setHttpResponseCode(500);
      res.status(500).end(JSON.stringify(error));
    } else {
      logger.info("userRoles : router : deleteUserRolesByRoleName successful !");
      res.status(200).end(JSON.stringify(data));
    }
  });
});

/*
 *	update UserRoles by RoleName
 */
router.put('/:rolename', function(req, res) {
  logger.info('userRoles : router : received request : updateRoleUsersByRoleName : id : ' + req.params.rolename);
  userRoleController.updateRoleUsersByRoleName(req, res, function(err, data) {
    if (err) {
      logger.error('userRoles : router : failed updateRoleUsersByRoleName : error : ' + err);
      var error = new ErrorResponse();
      if (err.name == 'ValidationError') {
        error.setErrorMessage(err.errors[Object.keys(err.errors)[0]].message);
      } else {
        error.setErrorMessage(err.message);
      }
      error.setErrorCode("UR005");
      error.setErrorMessage(err.message);
      error.setHttpResponseCode(500);
      res.status(500).end(JSON.stringify(error));
    } else {

      logger.info("userRoles : router :  updateRoleUsersByRoleName  successful !");
      res.status(200).end(JSON.stringify(data));
    }
  });
});


module.exports = router;
