var logger = require('../../common/logger').log;
var userRoleDAO = require('../dao/UserRoleDAO');
var request = require('request');
var config = require('../../common/Config');

/*
 * add new user roles
 */
var addNewUserRole = function(req, res, callback) {
  logger.info('UserRoles : delegate : received request : addNewUserRole : body : ' + JSON.stringify(req.body));

  var reqBody = req.body;
  var expId = reqBody.experienceId;
  var tokenId = req.headers['access-token'];

  var json1 = {};

  if (expId != undefined || expId != null) {
    json1.groupName = reqBody.roleName + '_' + expId;
  } else {
    json1.groupName = reqBody.roleName;
  }

  json1.groupUsers = reqBody.username;

  var proxyurl = config.NETWORK_PROXY + ":" + config.NETWORK_PROXY_PORT;

  //createGroup forgeRock call
  request({
    //'proxy': proxyurl,
    url: config.FORGRROCK_URL + '/api/v1/groups',
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      'Authorization': tokenId
    },
    json: json1
  }, function(error, response, body) {
    if (error) {
      logger.error('userRoles : delegate : failed addNewUserRole : error : ' + error);
      callback(error, null);
    } else {
      if (body.code == 405)
        callback(body, null);
      else if (body.code == 400)
        callback(body, null);
      else if (body.code == 409)
        callback(body, null);
      else if (body.code == 401)
        callback(body, null);
      else {
        logger.info('userRoles : delegate : addNewUserRole successful !');
        //userRoleDAO.addNewUserRole(tokenId, expId, req, res, callback);
        callback(null, body);
      }
    }
  });
}

/*
 *delete user forgeRock api
 */
var deleteUserRolesByRoleName = function(req, res, callback) {
  logger.info('UserRoles : Delegate : received request : deleteUserRolesByRoleName');

  var reqBody = req.body;
  var expId = reqBody.experienceId;
  var token = req.headers['access-token'];
  var rolename = '';

  if (expId != undefined || expId != null) {
    rolename = req.params.rolename + '_' + expId;
  } else {
    rolename = req.params.rolename;
  }

  var proxyurl = config.NETWORK_PROXY + ":" + config.NETWORK_PROXY_PORT;

  //createGroup forgeRock call
  request({
    //'proxy': proxyurl,
    url: config.FORGRROCK_URL + '/api/v1/groups/' + rolename,
    method: 'DELETE',
    headers: {
      'Content-Type': 'application/json',
      'Authorization': token
    }
  }, function(error, response, body) {
    if (error) {
      logger.error('userRoles : Delegate : failed deleteUserRolesByRoleName : error : ' + error);
      callback(error, null);
    } else {
      if (response.statusCode == 401) {
        var err = new Error('Unauthorized');
        err.status = 401;
        logger.error('Roles : DAO : failed deleteUserRolesByRoleName : error : ' + err);
        callback(err, null);
      } else if (response.statusCode == 404) {
        var err = new Error('Not Found');
        err.status = 404;
        logger.error('Roles : DAO : failed deleteUserRolesByRoleName : error : ' + err);
        callback(err, null);
      } else {
        logger.info('userRoles : delegate : deleteUserRolesByRoleName successful !');
        //userRoleDAO.deleteUserRolesByRoleName(req, res, callback);
        callback(null, body);
      }
    }
  });
}

var updateRoleUsersByRoleName = function(req, res, callback) {
  logger.info('UserRoles : delegate : received request : updateRoleUsersByRoleName : body : ' + JSON.stringify(req.body));

  var reqBody = req.body;
  var expId = reqBody.experienceId;
  var token = req.headers['access-token'];
  var json1 = {};

  if (req.body.experienceId != undefined || req.body.experienceId != null) {
    json1.groupName = req.params.rolename + '_' + expId;
  } else {
    json1.groupName = req.params.rolename;
  }

  if (reqBody.usernamesArray) {
    json1.groupUsers = reqBody.usernamesArray;
  } else {
    json1.groupUsers = reqBody.username;
  }

  var proxyurl = config.NETWORK_PROXY + ":" + config.NETWORK_PROXY_PORT;

  //createGroup forgeRock call
  request({
    //'proxy': proxyurl,
    url: config.FORGRROCK_URL + '/api/v1/groups/' + json1.groupName,
    method: 'PUT',
    headers: {
      'Content-Type': 'application/json',
      'Authorization': token
    },
    json: json1
  }, function(error, response, body) {
    if (error) {
      logger.error('userRoles : delegate : failed updateRoleUsersByRoleName : error : ' + error);
      callback(error, null);
    } else {
      if (body.code == 401)
        callback(body, null);
      else if (body.code == 404)
        callback(body, null);
      else if (body.code == 400)
        callback(body, null);
      else {
        logger.info('userRoles : delegate : updateRoleUsersByRoleName successful !');
        callback(null, body);
      }
    }
  });
}

/*
 *delete Group
 */
var deleteGroup = function(tokenId, expId, req, res, callback) {
  logger.info('UserRoles : Delegate : received request : deleteGroup');
  var reqBody = req.body;
  var roleName = '';
  if (expId != undefined || expId != null) {
    roleName = reqBody.roleName + '_' + expId;
  } else {
    roleName = reqBody.roleName;
  }

  var proxyurl = config.NETWORK_PROXY + ":" + config.NETWORK_PROXY_PORT;
  //forgeRock call
  request({
    //'proxy': proxyurl,
    url: config.FORGRROCK_URL + '/api/v1/groups/' + roleName,
    method: 'DELETE',
    headers: {
      'Content-Type': 'application/json',
      'Authorization': tokenId
    }
  }, function(error, response, body) {
    if (error) {
      logger.error('userRoles : DAO : failed deleteGroup : error : ' + error);
      callback(error, null);
    } else {
      if (body.code == 404) {
        logger.error('userRoles : DAO : failed deleteGroup : error : ' + body);
        callback(body, null);
      } else {
        logger.info('userRoles : delegate : deleteGroup successful !');
        callback(null, body);
      }
    }
  });
}

module.exports.addNewUserRole = addNewUserRole;
module.exports.deleteUserRolesByRoleName = deleteUserRolesByRoleName;
module.exports.updateRoleUsersByRoleName = updateRoleUsersByRoleName;
module.exports.deleteGroup = deleteGroup;
