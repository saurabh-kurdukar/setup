var express = require('express');
var logger = require('../common/logger').log;
var registrationController = require('./controller/RegistrationController');
var ErrorResponse = require('../common/ErrorResponse').ErrorResponse;
var router = express.Router();

/*
 * Resend Activation Link Email
 */
router.post('/', function(req, res) {
  logger.info('Registration : router : received request : resendEmail : username : ' + req.query.username);
  registrationController.resendEmail(req, res, function(err, data) {
    if (err) {
      logger.error('Registration : router : failed resendEmail : error : ' + err);
      var error = new ErrorResponse();
      if (err.name == 'ValidationError') {
        error.setErrorMessage(err.errors[Object.keys(err.errors)[0]].message);
      } else {
        error.setErrorMessage(err.message);
      }
      error.setErrorCode("RG001");
      error.setHttpResponseCode(500);
      res.status(500).end(JSON.stringify(error));

    } else {
      logger.info("Registration : router : resendEmail successful !");
      res.status(200).end(JSON.stringify(data));
    }
  });
});

module.exports = router;