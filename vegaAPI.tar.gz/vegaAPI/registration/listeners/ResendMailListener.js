var amqp = require('amqplib/callback_api');
var RabbitMQ = require('../../common/RabbitMQ');
var logger = require('../../common/logger').log;
var sendEmail = require('../../common/SendEmail');

/*
 * Receive Email
 */

RabbitMQ.getConnection(function(connection) {
  connection.createChannel(function(err, ch) {
    var q = 'resendMailQueue';    
    ch.assertQueue(q, {
      durable: false
    });
    console.log(" [*] Waiting for messages in resendMailQueue");
    ch.consume(q, function(msg) {
      console.log(" [x] Received %s", msg.content.toString());
      //send email
      sendEmail.sendMail(msg);
    }, {
      noAck: true
    });

  });
});



