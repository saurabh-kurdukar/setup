var db = require('../../common/MongoDbConnection');
var logger = require('../../common/logger').log;
var userRegistrationDao= require('../../userManagement/dao/UserRegistrationDAO')
var platformuserdao= require('../../platformUser/dao/PlatformUserDAO');
var amqp = require('amqplib/callback_api');
var RabbitMQ = require('../../common/RabbitMQ');
var resendMailQueue='resendMailQueue';


/*
 * Get both user by username
 */
var getAllUserByUsername = function(req, res, callback) {
  logger.info('Registration : DAO : received request : getAllUserByUsername : id : ' + req.params.username);

  platformuserdao.getUserByUsername(req,res,function(err,platformUserData){
	  if(err)
	  {
		if(err.status=404)
		 {
		   userRegistrationDao.getUserByUsername(req,res,function(err,userData){
			if(err)
			{
			  logger.error('Registration : DAO : failed getUserByUsername : error : ' + err);	
			  callback(err,null);	
			}		
			else
			{
			  logger.info('Registration : DAO :  getAllUserByUsername successfull');			
			  callback(null,userData);	
			}  
		   })
		 }
		else{
		  logger.error('Registration : DAO : failed getUserByUsername : error : ' + err);
		  callback(err,null);
		}
	  }
	  else
	   {
		logger.info('Registration : DAO :  getAllUserByUsername successfull');
		callback(null,platformUserData);
	   }
  })
};

/*
** add mail to queue
*/
var AddMailDataToQueue=function(email_data,callback)
{
	logger.info('Registration : DAO : received request : AddMailDataToQueue');
	RabbitMQ.getConnection(function(connection) {
	  connection.createChannel(function(err, ch) {
		if(err){
		  logger.error('Registration : DAO : failed AddMailDataToQueue : error : ' + err);	
		  callback(err,null);	
		}	
		else
		{					          
          ch.assertQueue(resendMailQueue, {
            durable: false
          });
          ch.sendToQueue(resendMailQueue, new Buffer(email_data));         
          setTimeout(function() {
          connection.close();
          }, 500);
		callback(null,'Email Sent Successfully');  
		}
        });
    });
}

module.exports.getAllUserByUsername= getAllUserByUsername;
module.exports.AddMailDataToQueue= AddMailDataToQueue;
