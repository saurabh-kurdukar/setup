var registrationDao = require('../dao/RegistrationDAO');
var messagedao = require('../../sendMessage/dao/MessageDAO');
var logger = require('../../common/logger').log;
var encryptDecrypt = require('../../common/EncryptDecrypt');
var tokendao = require('../../platformUser/dao/GenerateActivateTokenDAO');
var userTokenDao= require('../../userManagement/dao/GenerateActivateTokenDAO');
var messagedao = require('../../sendMessage/dao/MessageDAO');
var Q = require('q');

/*
 * Resend Activation Link Email
 */
var resendEmail = function(req, res, callback) {
  logger.info('Registration : controller : received request : resendEmail');

  req.params.username = req.query.username;
  Q.fcall(function() {
      var deferred = Q.defer();
      //check if user is verified or not
      registrationDao.getAllUserByUsername(req, res, function(err, data) {
        if (err) {
          logger.error('Registration : Controller : failed getUserByUsername : error : ' + err);
          deferred.reject(err);
        } else {
          logger.info('Registration : Controller : getUserByUsername successful !');
          deferred.resolve(data);
        }
      })
      return deferred.promise;
    })
    .then(function(data) {
      var deferred = Q.defer();
      if (!data[0].verified) {
        //get message details by createdBy
        messagedao.getMessageByCreatedBy(req, res, function(err, data) {
          if (err) {
            logger.error('Registration : Controller : failed getMessageByCreatedBy : error : ' + err);
            deferred.reject(err);
          } else {			  
            logger.info('Registration : Controller : getMessageByCreatedBy successful !');
            deferred.resolve(data);
          }
        })
      } else {
        var err = new Error('User Already Verified');
        err.status = 500;
        deferred.reject(err);
      }
      return deferred.promise;
    })
    .then(function(data) {
      var deferred = Q.defer();
      //check whether token is expired or not	  
      updateTokenAndMessageDetails(data,req,res,function(err, message) {
        if (err) {
          logger.error('Registration : Controller : failed updateTokenAndMessageDetails : error : ' + err);
          deferred.reject(err);
        } else {
          logger.info('Registration : Controller : updateTokenAndMessageDetails successful !');
          deferred.resolve(message);
        }
      })
      return deferred.promise;
    })
    .then(function(message) {
      var deferred = Q.defer();
      addToQueue(message, req, function(err, response) {
        if (err) {
          logger.error('Registration : Controller : failed addToQueue : error : ' + err);
          return callback(err);
        } else {
          logger.info('Registration : Controller : addToQueue successful !');
          return callback(null, response);
        }
      });
    })
    .fail(function(err) {
      return callback(err);
    })
    .done();
};


var updateTokenAndMessageDetails = function(data, req, res, callback) { 
logger.info('Registration : Controller : updateTokenAndMessageDetails: body:' +data); 
  var message = encryptDecrypt.decryption(data.message);
  var userType = message.match("&u=(.*)>Activation Link");
  //if userType is PU
  if (userType[1] == 'PU') {	  
    updatePlatformUserTokenDetails(message,req,res,function(err,response){
		if(err){			
			logger.error('Registration : Controller : failed updatePlatformUserTokenDetails : error : ' + err);
			callback(err,null);
		}
		else
		{
			logger.info('Registration : Controller : updatePlatformUserTokenDetails successful !');
			callback(null,response);
		}		
	})
  }
   else {
		//if user type is U
		updateUserTokenDetails(message,req,res,function(err,response){
		if(err){
			logger.error('Registration : Controller : failed updateUserTokenDetails : error : ' + err);
			callback(err,null);
		}
		else
		{
			logger.info('Registration : Controller : updateUserTokenDetails successful !');
			callback(null,response);
		}		
	})
            }
}

var addToQueue = function(data, req, callback) {
  var email_data_json = JSON.parse(data);
  email_data_json.messageId = data.messageId;
  email_data_json.toMail = req.params.username;
  //Add mail to queue
  registrationDao.AddMailDataToQueue(JSON.stringify(email_data_json), function(err, queueResponse) {
    if (err) {
      logger.error('Registration : Controller : failed AddMailDataToQueue : error : ' + err);
      callback(err, null);
    } else {
      logger.info('Registration : Controller : AddMailDataToQueue successful !');
      callback(null, queueResponse);
    }
  })
}

var updatePlatformUserTokenDetails= function(message,req,res,callback){
	tokendao.getToken(req, res, function(err, tokenData) {
    if (err) {
      logger.error('Registration : Controller : failed getToken : error : ' + err);
      callback(err, null);
    } else {
      logger.info('Registration : Controller : getToken successful !');	  	  
      if (new Date().getTime() > tokenData.updatedOn.getTime() + (24 * 60 * 60 * 1000)) {
        var accessToken = tokendao.getActivateToken();		
        var activationLink = '&t=' + accessToken + '&u=PU>Activation Link'        
        message = message.replace(/&t=.*>Activation Link/, activationLink);		
        //update message
        req.body.message = message;
        messagedao.updateMessage(req, res, function(err, response) {
          if (err) {
            logger.error('Registration : Controller : failed updateMessage : error : ' + err);
            callback(err, null);
          } else {
			  req.body.accessKey= accessToken;
              tokendao.updateToken(req, res, function(err, updatetokenResponse) {
                if (err) {
                  logger.error('Registration : Controller : failed updateToken : error : ' + err);
                  callback(err, null);
                } else {
                  logger.info('Registration : Controller : updateToken successful !');
                  callback(null, message);
                }
              })            
          }
        })
      } else {
        callback(null, message);
      }
    }
  })
}

var updateUserTokenDetails= function(message,req,res,callback){
	userTokenDao.getToken(req, res, function(err, tokenData) {
    if (err) {
      logger.error('Registration : Controller : failed getToken : error : ' + err);
      callback(err, null);
    } else {
      logger.info('Registration : Controller : getToken successful !');		   
      if (new Date().getTime() > tokenData.updatedOn.getTime() + (24 * 60 * 60 * 1000)) {
        var accessToken = tokendao.getActivateToken();
        var activationLink = '&t=' + accessToken + '&u=U>Activation Link'        
        message = message.replace(/&t=.*>Activation Link/, activationLink);
        //update message
        req.body.message = message;
        messagedao.updateMessage(req, res, function(err, response) {
          if (err) {
            logger.error('Registration : Controller : failed updateMessage : error : ' + err);
            callback(err, null);
          } else {
			  req.body.accessKey= accessToken;
              userTokenDao.updateToken(req, res, function(err, updatetokenResponse) {
                if (err) {
                  logger.error('Registration : Controller : failed updateToken : error : ' + err);
                  callback(err, null);
                } else {
                  logger.info('Registration : Controller : updateToken successful !');
                  callback(null, message);
                }
              })            
          }
        })

      } else {
        callback(null, message);
      }
    }
  })
}
module.exports.resendEmail = resendEmail;
