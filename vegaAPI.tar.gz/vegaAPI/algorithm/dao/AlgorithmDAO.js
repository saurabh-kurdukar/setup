var Algorithm = require('../models/Algorithm');
var logger = require('../../common/logger').log;
var config = require('../../common/Config');
var upload = require('../helpers/uploadFile');
var rimraf = require('rimraf');
var fs = require('fs');
var async = require('async');
var cp = require('child_process');

/*
 * logging format followed: logger.info(<module_name>: <component name> : <description> : [<long_description>] : <data/params/errors>);
 */


/*
 * Add new algorithm details
 */
var addNewAlgorithm = function(req, res, callback) {
	logger.info('Algorithm : DAO : received request : addNewAlgorithm : body : ' + JSON.stringify(req.body));
	if(req.body.createdBy) {
		req.body.updatedBy = req.body.createdBy;
	}
	var algorithm = new Algorithm(req.body);

	var regex = new RegExp(['^', req.body.name, '$'].join(''), 'i');

	Algorithm.findOne({
		name: regex
	}, function(err, data) {
		if(err) {
			logger.error('Algorithm : DAO : failed addNewAlgorithm : get by id : error : ' + err);
			callback(err, null);
		}
		else if(data) {
			var err = new Error('Algorithm name already exists');
			err.status = 409;
			logger.error('Algorithm : DAO : failed addNewAlgorithm : error : Name already exists');
			callback(err, null);
		}
		else {
			algorithm.save(function(err, data) {
				if (err) {
					logger.error('Algorithm : DAO : failed addNewAlgorithm : error : ' + err);
					callback(err, null);
				} else if(data != null) {
					logger.info('Algorithm : DAO : addNewAlgorithm successful !');
					callback(null, data);
				} else {
					var err = new Error('Failed to add new algorithm details');
					logger.error('Algorithm : DAO : failed addNewAlgorithm : error : '+ err);
					callback(err, null);
				}
			});
		}
	});
};

/*
 * Get all algorithms
 */
var getAllAlgorithms = function(req, res, callback) {
	logger.info('Algorithm : DAO : received request : getAllAlgorithms');

	var query = {};
	var regex;
	if(req.query.name) {
		logger.info('Algorithm : DAO : received request : getAllAlgorithms : name : ' + req.query.name);
		var algoName = decodeURIComponent(req.query.name);
		regex = new RegExp(['^', algoName, '$'].join(''), 'i');
		query.name = regex;
	}

	Algorithm.find(query, function(err, data) {
		if(err) {
			logger.error('Algorithm : DAO : failed getAllAlgorithms : error : ' + err);
			callback(err, null);
		}
		else {
			if (data.length != 0) {
				logger.info('Algorithm : DAO : getAllAlgorithms successful !');
				callback(null, data);
			} else {
				var err = new Error('No records found');
				err.status = 404;
				logger.error('Algorithm : DAO : failed getAllAlgorithms : error : ' + err);
				callback(err, null);
			}
		}
	})
}

/*
 * Get algorithm by id
 */
var getAlgorithmById = function(req, res, callback) {
	logger.info('Algorithm : DAO : received request : getAlgorithmById : id : ' + req.params.id);

	Algorithm.findOne({
		id: req.params.id
	}, function(err, data) {
		if(err) {
			logger.error('Algorithm : DAO : failed getAlgorithmById : error : ' + err);
			callback(err, null);
		}
		else {
			if(data) {
				logger.info('Algorithm : DAO : getAlgorithmById successful !');
				callback(null, data);
			} else {
				var err = new Error('Invalid algorithm id');
				err.status = 404;
				logger.error('Algorithm : DAO : failed getAlgorithmById : error : ' + err);
				callback(err, null);
			}
		}
	})
}

/*
 * Update algorithm by id
 */
var updateAlgorithmById = function(req, res, callback) {
	logger.info('Algorithm : DAO : received request : updateAlgorithmById : id : ' + req.params.id);

	var json = {};
	if(req.body.name) {
		json.name = req.body.name;
	}
	if(req.body.description) {
		json.description = req.body.description;
	}
	if(req.body.type) {
		json.type = req.body.type;
	}
	if(req.body.version) {
		json.version = req.body.version;
	}
	if(req.body.mainClass) {
		json.mainClass = req.body.mainClass;
	}
	if(req.body.inputMetadata) {
		json.inputMetadata = req.body.inputMetadata;
	}
	if(req.body.outputMetadata) {
		json.outputMetadata = req.body.outputMetadata;
	}
	if(req.body.showCalc) {
		json.showCalc = req.body.showCalc;
	}
	if(req.body.inputType) {
		json.inputType = req.body.inputType;
	}
	if(req.body.tags && req.body.tags.length > 0) {
		json.tags = req.body.tags;
	}
	else {
		json.tags = [];
	}
	if(req.body.updatedBy) {
		json.updatedBy = req.body.updatedBy;
	}
	json.updatedOn = new Date();

	Algorithm.findOne({
		id: req.params.id
	}, function(err, data) {
		if(err) {
			logger.error('Algorithm : DAO : failed updateAlgorithmById : get by id : error : ' + err);
			callback(err, null);
		}
		else {
			if(data) {
				var oldFolderName = data.name;
				async.series([
					function(cb) {
						if(req.body.name === data.name) {
							cb(null, "One");
						}
						else {
							req.query.name = req.body.name;
							if(req.query.name) {
								getAllAlgorithms(req, res, function(err, data) {
									if(err && err.status != 404) {
										logger.error('Algorithm : DAO : failed updateAlgorithmById : getAllAlgorithms : error : ' + err);
										cb(err, data);
									}
									else if(err && err.status == 404) {
										cb(null, "One");
									}
									else {
										var error = new Error('Algorithm name already exists');
										logger.error('Algorithm : DAO : failed updateAlgorithmById : getAllAlgorithms : error : ' + error);
										cb(error, data);
									}
								});
							}
							else {
								cb(null, "One");
							}
						}
					},
					function(cb) {
						var deleteFiles = req.body.deleteFiles;
						if(deleteFiles && deleteFiles.length > 0) {
							async.eachSeries(deleteFiles, function(file, call) {
							  var filePath = file.replace(config.BINARY_STORAGE.BASE_URL, config.BINARY_STORAGE.BASE_PATH);
							  deleteAlgorithmFolder(filePath, function(fail, success) {
							    if(fail) {
							      call(fail, null);
							    }
							    else {
							      logger.info('Algorithm : DAO : updateAlgorithmById : File deleted : ' + success);
							      var deletePos = data.algorithmFileLocation.indexOf(file);
										if(deletePos != -1) {
											data.algorithmFileLocation.splice(deletePos, 1);
										}
							      call(null, success);
							    }
							  });
							}, function(err) {
							  if(err) {
							    logger.error('Algorithm : DAO : updateAlgorithmById : Failed to delete file : error : ' + err);
							    cb(err, null);
							  }
								else {
									json.algorithmFileLocation = data.algorithmFileLocation;
									cb(null, "Two");
								}
							});
						}
						else {
							cb(null, "Two");
						}
					},
					function(cb) {
						var algorithmFiles = req.files;
						if(algorithmFiles && algorithmFiles.length != 0) {
							algorithmFiles.forEach(function(file) {
								var fileLocation = config.BINARY_STORAGE.BASE_URL + config.BINARY_STORAGE.ALGORITHM + data.name + '/' + file.filename;
								if(data.algorithmFileLocation.indexOf(fileLocation) == -1) {
									data.algorithmFileLocation.push(fileLocation);
								}
							})
							json.algorithmFileLocation = data.algorithmFileLocation;
							cb(null, "Three");
						}
						else {
							cb(null, "Three");
						}
					},
					function(cb) {
						if(req.body.name && req.body.name != data.name) {
							json.algorithmLocationBasePath = config.BINARY_STORAGE.BASE_PATH + config.BINARY_STORAGE.ALGORITHM + req.body.name;
							fs.rename(data.algorithmLocationBasePath, json.algorithmLocationBasePath, function(err) {
								if(err) {
									logger.error('Algorithm : DAO : updateAlgorithmById : Failed to rename algorithm directory : error : ' + err);
									cb(err, null);
								}
								else {
									var oldBaseUrl = config.BINARY_STORAGE.BASE_URL + config.BINARY_STORAGE.ALGORITHM + oldFolderName;
									var newBaseUrl = config.BINARY_STORAGE.BASE_URL + config.BINARY_STORAGE.ALGORITHM + req.body.name;
									var updatedFileLocatiion = [];
									data.algorithmFileLocation.forEach(function(file) {
										updatedFileLocatiion.push(file.replace(oldBaseUrl, newBaseUrl));
									})
									json.algorithmFileLocation = updatedFileLocatiion;
									cb(null, "Four");
								}
							});
						}
						else {
							cb(null, "Four");
						}
					}
				], function(err, data) {
					if(err) {
						logger.error('Algorithm : DAO : updateAlgorithmById : Failed to update record : error : ' + err);
						callback(err, null);
					}
					else {
						Algorithm.findOneAndUpdate({
							id: req.params.id
						}, json, {
							new: true
						}, function(err, data) {
							if(err) {
								logger.error('Algorithm : DAO : failed updateAlgorithmById : error : ' + err);
								var newAlgoName = config.BINARY_STORAGE.BASE_PATH + config.BINARY_STORAGE.ALGORITHM + req.body.name;
								var oldAlgoName = config.BINARY_STORAGE.BASE_PATH + config.BINARY_STORAGE.ALGORITHM + oldFolderName;
								fs.rename(newAlgoName, oldAlgoName, function(error) {
									if(error) {
										logger.error('Algorithm : DAO : updateAlgorithmById : Failed to revert algorithm directory name : error : ' + error);
										callback(error, null);
									}
									else {
										callback(err, null);
									}
								});
							}
							else {
								if(data) {
									logger.info('Algorithm : DAO : updateAlgorithmById successful !');
									callback(null, data);
								}
								else {
									var err = new Error('Invalid algorithm id');
									err.status = 404;
									logger.error('Algorithm : DAO : failed updateAlgorithmById : error : ' + err);
									callback(err, null);
								}
							}
						})
					}
				});
			} else {
				var err = new Error('Invalid algorithm id');
				err.status = 404;
				logger.error('Algorithm : DAO : failed updateAlgorithmById : error : ' + err);
				callback(err, null);
			}
		}
	})
}

/*
 * Delete algorithm by id
 */
var deleteAlgorithmById = function(req, res, callback) {
	logger.info('Algorithm : DAO : received request : deleteAlgorithmById : id : ' + req.params.id);

	Algorithm.findOne({
		id: req.params.id
	}, function(err, algorithm) {
		if(err) {
			logger.error('Algorithm : DAO : failed deleteAlgorithmById : get algorithm by id : error : ' + err);
			callback(err, null);
		}
		else {
			if(algorithm) {
				var folderPath = algorithm.algorithmLocationBasePath;
				Algorithm.remove({
					id: req.params.id
				}, function(err, data) {
					if(err) {
						logger.error('Algorithm : DAO : failed deleteAlgorithmById : error : ' + err);
						callback(err, null);
					}
					else {
						deleteAlgorithmFolder(folderPath, function(err, path) {
							if(err) {
								callback(err, null);
							}
							else {
								logger.info('Algorithm : DAO : deleteAlgorithmById successful !');
								callback(null, algorithm);
							}
						});
					}
				});
			} else {
				var err = new Error('Invalid algorithm id');
				err.status = 404;
				logger.error('Algorithm : DAO : failed getAlgorithmById : error : ' + err);
				callback(err, null);
			}
		}
	})
}

/*
 * Delete algorithm file/folder
 */
var deleteAlgorithmFolder = function(folder, callback) {
	logger.error('Algorithm : DAO : deleteAlgorithmFolder : folder : ' + folder);
	if(fs.existsSync(folder)) {
		rimraf(folder, function(err) {
			if(err) {
				logger.error('Algorithm : DAO : deleteAlgorithmFolder : error : ' + err);
				callback(err, null);
			}
			else {
				logger.error('Algorithm : DAO : deleteAlgorithmFolder successful !');
				callback(null, folder);
			}
		})
	}
	else {
		logger.error('Algorithm : DAO : deleteAlgorithmFolder : No algorithms found to delete !');
		callback(null, folder);
	}
}

/*
 * Search algorithms
 */
var searchAlgorithms = function(req, res, callback) {
	logger.info('Algorithm : DAO : received request : searchAlgorithms : text : ' + req.query.text);

	if(!req.query.text) {
		var err = new Error('No tags found');
		logger.error('Algorithm : DAO : failed searchAlgorithms : error : No text found');
		callback(err, null);
	}
	else {
		var queryString = decodeURIComponent(req.query.text);
		var split = queryString.split(",");
		var searchString = "";
		split.forEach(function(word) {
			searchString += "\"" + word + "\" ";
		})

		Algorithm.find({
			$text: {
				$search: req.query.text
			}
		}, function(err, data) {
			if(err) {
				logger.error('Algorithm : DAO : failed searchAlgorithms : error : ' + err);
				callback(err, null);
			}
			else {
				if(data.length > 0) {
					logger.info('Algorithm : DAO : searchAlgorithms successful !');
					callback(null, data);
				} else {
					var err = new Error('No records found');
					err.status = 404;
					logger.error('Algorithm : DAO : failed searchAlgorithms : error : ' + err);
					callback(err, null);
				}
			}
		})
	}
}

/*
 * Run algorithm
 */
var runAlgorithm = function(req, res, callback) {
	logger.info('Algorithm : DAO : received request : runAlgorithm : id : ' + req.params.id + ' : body : ' + JSON.stringify(req.body));

	getAlgorithmById(req, res, function(err, data) {
		if(err) {
			logger.error('Algorithm : DAO : failed runAlgorithm : getAlgorithmById : error : ' + err);
			callback(err, null);
		}
		else {
			var jarLocation = data.algorithmLocationBasePath;
			var inputData = req.body.inputData;
			if(typeof(inputData) == 'object') {
				inputData = "'" + JSON.stringify(inputData) + "'";
			}
			else if(typeof(inputData) == 'string') {
				inputData = "'" + inputData + "'";
			}
			var command = "java -cp '" + jarLocation + "/*' " + data.mainClass + " " + inputData;

			logger.info('Algorithm : DAO : runAlgorithm : Executing command : ' + command);
			cp.exec(command, function(error, stdout, stderr) {
				if (error) {
					logger.error('Algorithm : DAO : failed runAlgorithm : failed to execute command : error : ' + error);
					callback(error, null);
				}
				else if(stderr) {
					logger.error('Algorithm : DAO : failed runAlgorithm : failed to run jar : error : ' + stderr);
					callback(stderr, null);
				}
				else {
					var responseData = JSON.parse(stdout);
					logger.info('Algorithm : DAO : runAlgorithm : jar executed successfully : ' + stdout);
					callback(null, responseData);
				}
			})
		}
	});
}


module.exports.addNewAlgorithm = addNewAlgorithm;
module.exports.getAllAlgorithms = getAllAlgorithms;
module.exports.getAlgorithmById = getAlgorithmById;
module.exports.updateAlgorithmById = updateAlgorithmById;
module.exports.deleteAlgorithmById = deleteAlgorithmById;
module.exports.searchAlgorithms = searchAlgorithms;
module.exports.runAlgorithm = runAlgorithm;
