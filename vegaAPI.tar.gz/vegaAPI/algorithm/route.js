var express = require('express');
var algorithmController = require('./controller/AlgorithmController');
var logger = require('../common/logger').log;
var ErrorResponse = require('../common/ErrorResponse').ErrorResponse;
var router = express.Router();
var upload = require('./helpers/uploadFile');
var config = require('../common/Config');

/*
 * logging format followed: logger.info(<module_name>: <component name> : <description> : [<long_description>] : <data/params/errors>);
 */

/*
 * Add new algorithm details
 */
router.post('/', upload.any(), function(req, res) {

	if(req.fileValidationError) {
		logger.info('Algorithm : router : received request : addNewAlgorithm : error : ' + req.fileValidationError);
		var error = new ErrorResponse();
		error.setErrorMessage(req.fileValidationError);
		error.setErrorCode("ALG0001");
		error.setHttpResponseCode(500);
		res.status(500).end(JSON.stringify(error));
	}
	else if(req.files.length == 0) {
		logger.info('Algorithm : router : received request : addNewAlgorithm : error : No file found');
		var error = new ErrorResponse();
		error.setErrorMessage("No file found");
		error.setErrorCode("ALG0001");
		error.setHttpResponseCode(500);
		res.status(500).end(JSON.stringify(error));
	}
	else {
		var algorithmFiles = req.files;
		var algorithmFileLocation = [];
		algorithmFiles.forEach(function(file) {
			algorithmFileLocation.push(config.BINARY_STORAGE.BASE_URL + config.BINARY_STORAGE.ALGORITHM + req.body.name + '/' + file.filename);
		})
		req.body.algorithmFileLocation = algorithmFileLocation;

		logger.info('Algorithm : router : received request : addNewAlgorithm : body : ' + JSON.stringify(req.body));
		algorithmController.addNewAlgorithm(req, res, function(err, data) {
			if(err) {
				logger.error('Algorithm : router : failed addNewAlgorithm : error : '+err);
				var error = new ErrorResponse();
				if(err.name == 'ValidationError'){
					error.setErrorMessage(err.errors[Object.keys(err.errors)[0]].message);
				} else {
					error.setErrorMessage(err.message);
				}
				error.setErrorCode("ALG0001");
				var errorStatus = 500;
				if(err.status) {
					errorStatus = err.status;
				}
				error.setHttpResponseCode(errorStatus);
				res.status(errorStatus).end(JSON.stringify(error));
			}
			else {
				logger.info('Algorithm : router : addNewAlgorithm successful !');
				res.status(200).end(JSON.stringify(data));
			}
		});
	}
});

/*
 * Get all algorithms
 */
router.get('/', function(req, res) {
	logger.info('Algorithm : router : received request : getAllAlgorithms');
	algorithmController.getAllAlgorithms(req, res, function(err, data) {
		if(err) {
			logger.error('Algorithm : router : failed getAllAlgorithms : error : ' + err);
			var error = new ErrorResponse();
			error.setErrorCode("ALG0002");
			error.setErrorMessage(err.message);
			var errorStatus = 500;
			if(err.status) {
				errorStatus = err.status;
			}
			error.setHttpResponseCode(errorStatus);
			res.status(errorStatus).end(JSON.stringify(error));
		}
		else {
			logger.info('Algorithm : router : getAllAlgorithms successful!');
			res.status(200).end(JSON.stringify(data));
		}
	})
})

/*
 * Search algorithms
 */
router.get('/search', function(req, res) {
	logger.info('Algorithm : router : received request : searchAlgorithms : text : ' + req.query.text);
	algorithmController.searchAlgorithms(req, res, function(err, data) {
		if(err) {
			logger.error('Algorithm : router : failed searchAlgorithms : error : ' + err);
			var error = new ErrorResponse();
			error.setErrorCode("ALG0006");
			error.setErrorMessage(err.message);
			var errorStatus = 500;
			if(err.status) {
				errorStatus = err.status;
			}
			error.setHttpResponseCode(errorStatus);
			res.status(errorStatus).end(JSON.stringify(error));
		}
		else {
			logger.info('Algorithm : router : searchAlgorithms successful!');
			res.status(200).end(JSON.stringify(data));
		}
	})
})

/*
 * Run algorithm
 */
router.post('/:id/run', function(req, res) {
	logger.info('Algorithm : router : received request : runAlgorithm : id : ' + req.params.id + ' : body : ' + JSON.stringify(req.body));
	algorithmController.runAlgorithm(req, res, function(err, data) {
		if(err) {
			logger.error('Algorithm : router : failed runAlgorithm : error : ' + err);
			var error = new ErrorResponse();
			error.setErrorCode("ALG0007");
			error.setErrorMessage(err.message);
			var errorStatus = 500;
			if(err.status) {
				errorStatus = err.status;
			}
			error.setHttpResponseCode(errorStatus);
			res.status(errorStatus).end(JSON.stringify(error));
		}
		else {
			logger.info('Algorithm : router : runAlgorithm successful!');
			res.status(200).end(JSON.stringify(data));
		}
	})
})

/*
 * Get algorithm by id
 */
router.get('/:id', function(req, res) {
	logger.info('Algorithm : router : received request : getAlgorithmById : id : ' + req.params.id);
	algorithmController.getAlgorithmById(req, res, function(err, data) {
		if(err) {
			logger.error('Algorithm : router : failed getAlgorithmById : error : ' + err);
			var error = new ErrorResponse();
			error.setErrorCode("ALG0003");
			error.setErrorMessage(err.message);
			var errorStatus = 500;
			if(err.status) {
				errorStatus = err.status;
			}
			error.setHttpResponseCode(errorStatus);
			res.status(errorStatus).end(JSON.stringify(error));
		}
		else {
			logger.info('Algorithm : router : getAlgorithmById successful!');
			res.status(200).end(JSON.stringify(data));
		}
	})
})

/*
 * Update algorithm by id
 */
router.put('/:id', upload.any(), function(req, res) {
	logger.info('Algorithm : router : received request : updateAlgorithmById : id : ' + req.params.id);
	algorithmController.updateAlgorithmById(req, res, function(err, data) {
		if(err) {
			logger.error('Algorithm : router : failed updateAlgorithmById : error : ' + err);
			var error = new ErrorResponse();
			error.setErrorCode("ALG0004");
			error.setErrorMessage(err.message);
			var errorStatus = 500;
			if(err.status) {
				errorStatus = err.status;
			}
			error.setHttpResponseCode(errorStatus);
			res.status(errorStatus).end(JSON.stringify(error));
		}
		else {
			logger.info('Algorithm : router : updateAlgorithmById successful!');
			res.status(200).end(JSON.stringify(data));
		}
	})
})

/*
 * Delete algorithm by id
 */
router.delete('/:id', function(req, res) {
	logger.info('Algorithm : router : received request : deleteAlgorithmById : id : ' + req.params.id);
	algorithmController.deleteAlgorithmById(req, res, function(err, data) {
		if(err) {
			logger.error('Algorithm : router : failed deleteAlgorithmById : error : ' + err);
			var error = new ErrorResponse();
			error.setErrorCode("ALG0005");
			error.setErrorMessage(err.message);
			var errorStatus = 500;
			if(err.status) {
				errorStatus = err.status;
			}
			error.setHttpResponseCode(errorStatus);
			res.status(errorStatus).end(JSON.stringify(error));
		}
		else {
			logger.info('Algorithm : router : deleteAlgorithmById successful!');
			res.status(200).end(JSON.stringify(data));
		}
	})
})


module.exports = router;
