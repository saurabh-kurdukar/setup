var fs = require('fs');
var async = require('async');
var request = require('request');
var config = require('../../common/Config');
var logger = require('../../common/logger').log;

var copyToHDFS = function(algorithm, callback) {
  async.waterfall([
    async.apply(deleteFolder, algorithm),
    createFolder,
    createFiles
  ], function(err, data) {
    if(err) {
      logger.error('Algorithm : helpers : failed copyToHDFS : ' + err);
      callback(err, null);
    }
    else {
      logger.info('Algorithm : helpers : copyToHDFS successful!');
      callback(null, data);
    }
  });
}

var deleteFolder = function(algorithm, cb) {
  var folderName = algorithm.algorithmLocationBasePath.split('/').pop();
  var requestObj = {
    method: 'DELETE',
    url: config.HDFS_BASE_URL + folderName + '?op=DELETE&user.name=hdfs&recursive=true'
  };
  request(requestObj, function(err, response, body) {
    if(err) {
      logger.error('Algorithm : helpers : copyToHDFS : deleteFolder : error : ' + err);
      cb(err, null);
    }
    else {
      logger.info('Algorithm : helpers : copyToHDFS : folder : ' + folderName + ' : deleteFolder successful!');
      cb(null, algorithm);
    }
  });
}

var createFolder = function(algorithm, cb) {
  var folderName = algorithm.algorithmLocationBasePath.split('/').pop();
  var requestObj = {
    method: 'PUT',
    url: config.HDFS_BASE_URL + folderName + '?op=MKDIRS&user.name=hdfs'
  };
  request(requestObj, function(err, response, body) {
    if(err) {
      logger.error('Algorithm : helpers : copyToHDFS : createFolder : error : ' + err);
      cb(err, null);
    }
    else {
      logger.info('Algorithm : helpers : copyToHDFS : createFolder successful!');
      cb(null, algorithm);
    }
  });
}

var createFiles = function(algorithm, cb) {
  var folderName = algorithm.algorithmLocationBasePath.split('/').pop();
  fs.readdir(algorithm.algorithmLocationBasePath, function(err, files) {
    if(err) {
      logger.error('Algorithm : helpers : copyToHDFS : createFiles : error reading algorithm folder : ' + err);
      cb(err, null);
    }
    else {
      async.eachSeries(files, function(file, callback) {
        if(fs.statSync(algorithm.algorithmLocationBasePath + '/' + file).isFile()) {
          var requestObj = {
            method: 'PUT',
            url: config.HDFS_BASE_URL + folderName + '/' + file + '?op=CREATE&user.name=hdfs&overwrite=true'
          };
          request(requestObj, function(err, response, body) {
            if(err) {
              logger.error('Algorithm : helpers : copyToHDFS : createFiles : error : ' + err);
              callback(err, null);
            }
            else {
              var requestObj = {
                method: 'PUT',
                url: response.headers.location,
                formData: {
                  file: fs.createReadStream(algorithm.algorithmLocationBasePath + '/' + file)
                }
              };
              request(requestObj, function(err, response, body) {
                if(err) {
                  logger.error('Algorithm : helpers : copyToHDFS : createFiles : error creating file ' + file + ' : ' + err);
                  callback(err, null);
                }
                else {
                  logger.info('Algorithm : helpers : copyToHDFS : createFiles : File created : ' + file);
                  callback(null, file);
                }
              });
            }
          });
        }
        else {
          logger.info('Algorithm : helpers : copyToHDFS : createFiles : Skipped a directory : ' + file);
          callback(null, file);
        }
      }, function(error) {
        if(error) {
          cb(error, null);
        }
        else {
          logger.info('Algorithm : helpers : copyToHDFS : createFiles successful!');
          cb(null, algorithm);
        }
      })
    }
  });
}


module.exports.copyToHDFS = copyToHDFS;
module.exports.deleteFolder = deleteFolder;
