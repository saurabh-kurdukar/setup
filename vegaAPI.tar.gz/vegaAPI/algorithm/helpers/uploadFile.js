var multer  = require('multer');
var fs = require('fs');
var config = require('../../common/Config');
var Algorithm = require('../models/Algorithm');

var filePath = config.BINARY_STORAGE.BASE_PATH;

if(!fs.existsSync(filePath)) {
  fs.mkdirSync(filePath);
}
if(!fs.existsSync(filePath + config.BINARY_STORAGE.ALGORITHM)) {
  fs.mkdirSync(filePath + config.BINARY_STORAGE.ALGORITHM);
}

var storage = multer.diskStorage({
  destination: function (req, file, cb) {
    // console.log("File", req);
    var folderName = req.body.name;
    if(folderName && !req.params.id) {
      if(!fs.existsSync(filePath + config.BINARY_STORAGE.ALGORITHM + folderName)) {
        fs.mkdirSync(filePath + config.BINARY_STORAGE.ALGORITHM + folderName);
      }
      req.body.algorithmLocationBasePath = filePath + config.BINARY_STORAGE.ALGORITHM + folderName;
      cb(null, filePath + config.BINARY_STORAGE.ALGORITHM + folderName);
    }
    else if(req.params.id) {
      Algorithm.findOne({
        id: req.params.id
      }, function(err, data) {
        if(err) {
          var error = new Error("Cannot save algorithm file : ", file);
          cb(error, null);
        }
        else {
          if(data) {
            cb(null, data.algorithmLocationBasePath);
          }
          else {
            var error = new Error("Invalid algorithm id");
            cb(error, null);
          }
        }
      })
    }
    else {
      var error = new Error("Algorithm name or id not found");
      cb(error, null);
    }
  },
  filename: function (req, file, cb) {
  	var fileName = file.originalname;
  	cb(null, fileName);
  }
});

function fileFilter(req, file, cb) {
	var ext = file.originalname.split('.').pop();
	if(!file.fieldname) {
    req.fileValidationError = 'No fieldname provided for the file';
	  cb(null, false);
	}
  else {
    cb(null, true);
  }
}

var upload = multer({ storage: storage,  fileFilter: fileFilter });

module.exports = upload;
