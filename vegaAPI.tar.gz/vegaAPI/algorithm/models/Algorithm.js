var mongoose = require('../../common/MongoDbConnection').mongoose;
var autoIncrement = require('mongoose-auto-increment');
var logger = require('../../common/logger').log;
var connection = mongoose.connection;
autoIncrement.initialize(connection);
/*
 * logging format followed: logger.info(<module_name>: <component name> :
 * <description> : <long_description> : <data/params/errors>);
 */


/*
 * Define schema
 */
var algorithmSchema = mongoose.Schema({
  id: Number,
	name: { type : String , unique : true, required : true },
  description: String,
  type: String,
  version: String,
  mainClass: String,
  inputMetadata: Object,
  outputMetadata: Object,
  showCalc: Boolean,
  inputType: String,
  tags: [ String ],
  algorithmLocationBasePath: String,
  algorithmFileLocation: [ String ],
  createdBy: String,
  updatedBy: String,
  createdOn: { type: Date, default: Date.now },
  updatedOn: { type: Date, default: Date.now }
});


// logger.info('Algorithm : model : created schema : Algorithm :'+JSON.stringify(algorithmSchema.paths));

/*
 * Add Auto increment plugin for field algorithm id
 */
algorithmSchema.plugin(autoIncrement.plugin, { model: 'Algorithm', field: 'id', startAt: 1 });

// Create index for text search
algorithmSchema.index({name:"text", description: "text", tags: "text"});

/*
 * Create collection/model in mongo db using Schema
 */
var Algorithm = mongoose.model('Algorithm', algorithmSchema);
logger.info('Algorithm : model : created model : Algorithm : ' + Algorithm);


module.exports = Algorithm;
