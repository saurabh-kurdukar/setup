var algorithmDao = require('../dao/AlgorithmDAO');
var logger = require('../../common/logger').log;
var hdfsHelper = require('../helpers/hdfsHelper');
var async = require('async');

/*
 * logging format followed: logger.info(<module_name>: <component name> : <description> : [<long_description>] : <data/params/errors>);
 */


/*
 * Add new algorithm details
 */
var addNewAlgorithm = function(req, res, callback) {
	logger.info('Algorithm : controller : received request : addNewAlgorithm : body : ' + JSON.stringify(req.body));
	async.waterfall([
		async.apply(algorithmDao.addNewAlgorithm, req, res),
		hdfsHelper.copyToHDFS
	], function(err, data) {
		if(err) {
			callback(err, null);
		}
		else {
			callback(null, data);
		}
	});
};

/*
 * Get all algorithms
 */
var getAllAlgorithms = function(req, res, callback) {
	logger.info('Algorithm : controller : received request : getAllAlgorithms');
	algorithmDao.getAllAlgorithms(req, res, callback);
}

/*
 * Get algorithm by id
 */
var getAlgorithmById = function(req, res, callback) {
	logger.info('Algorithm : controller : received request : getAlgorithmById : id : ' + req.params.id);
	algorithmDao.getAlgorithmById(req, res, callback);
}

/*
 * Update algorithm by id
 */
var updateAlgorithmById = function(req, res, callback) {
	logger.info('Algorithm : controller : received request : updateAlgorithmById : id : ' + req.params.id);
	async.waterfall([
		async.apply(algorithmDao.updateAlgorithmById, req, res),
		hdfsHelper.copyToHDFS
	], function(err, data) {
		if(err) {
			callback(err, null);
		}
		else {
			callback(null, data);
		}
	})
}

/*
 * Delete algorithm by id
 */
var deleteAlgorithmById = function(req, res, callback) {
	logger.info('Algorithm : controller : received request : deleteAlgorithmById : id : ' + req.params.id);
	async.waterfall([
		async.apply(algorithmDao.deleteAlgorithmById, req, res),
		hdfsHelper.deleteFolder
	], function(err, data) {
		if(err) {
			callback(err, null);
		}
		else {
			callback(null, "Algorithm deleted successfully");
		}
	});
}

/*
 * Search algorithms
 */
var searchAlgorithms = function(req, res, callback) {
	logger.info('Algorithm : controller : received request : searchAlgorithms : text : ' + req.query.text);
	algorithmDao.searchAlgorithms(req, res, callback);
}

/*
 * Run algorithm
 */
 var runAlgorithm = function(req, res, callback) {
 	logger.info('Algorithm : controller : received request : runAlgorithm : id : ' + req.params.id + ' : body : ' + JSON.stringify(req.body));
 	algorithmDao.runAlgorithm(req, res, callback);
 }


module.exports.addNewAlgorithm = addNewAlgorithm;
module.exports.getAllAlgorithms = getAllAlgorithms;
module.exports.getAlgorithmById = getAlgorithmById;
module.exports.updateAlgorithmById = updateAlgorithmById;
module.exports.deleteAlgorithmById = deleteAlgorithmById;
module.exports.searchAlgorithms = searchAlgorithms;
module.exports.runAlgorithm = runAlgorithm;
